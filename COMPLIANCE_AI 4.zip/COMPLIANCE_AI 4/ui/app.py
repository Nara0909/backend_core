"""
Healthcare Compliance AI - Streamlit Frontend

Uses LangGraph for compliance orchestration + FastAPI backend for compliance checks
"""

import streamlit as st
import sys
import os
from datetime import datetime
import json

# Add parent directory to path
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from frontend import (
    create_compliance_agent,
    create_db_client,
    create_backend_client
)

# ============ PAGE CONFIG ============

st.set_page_config(
    page_title="Healthcare Compliance AI",
    page_icon="🏥",
    layout="wide"
)

# ============ INITIALIZATION ============

@st.cache_resource
def init_agent():
    """Initialize compliance agent and database client"""
    try:
        backend_client = create_backend_client()
        if not backend_client.health_check():
            st.error("❌ Backend is not running. Please start the backend first.")
            st.info("Run: `python -m uvicorn app.main:app --port 8000`")
            st.stop()
        
        db_client = create_db_client()
        agent = create_compliance_agent(
            backend_url="http://localhost:8000",
            db_client=db_client
        )
        return agent, db_client, backend_client
    except Exception as e:
        st.error(f"❌ Initialization failed: {e}")
        st.stop()

agent, db_client, backend_client = init_agent()

# ============ SIDEBAR ============

st.sidebar.title("🏥 Healthcare Compliance AI")
st.sidebar.markdown("---")

# User context
st.sidebar.subheader("User Context")
user_id = st.sidebar.text_input("User ID", value="clinician_001")
user_role = st.sidebar.selectbox(
    "User Role",
    ["clinician", "specialist", "admin", "nurse", "resident"]
)

st.sidebar.markdown("---")

# Request type
st.sidebar.subheader("Request Type")
request_type = st.sidebar.selectbox(
    "What are you doing?",
    ["triage", "scheduling", "referral", "diagnosis", "monitoring"]
)

st.sidebar.markdown("---")

# Navigation
st.sidebar.subheader("Navigation")
page = st.sidebar.radio(
    "Go to",
    ["Clinical Triage", "Compliance Dashboard", "Audit Trail", "Settings"]
)

st.sidebar.markdown("---")

# System status
st.sidebar.subheader("System Status")
col1, col2 = st.sidebar.columns(2)
with col1:
    backend_status = "🟢 Online" if backend_client.health_check() else "🔴 Offline"
    st.metric("Backend", backend_status)
with col2:
    st.metric("DB", "🟢 Online")


# ============ PAGE FUNCTIONS ============

def clinical_triage_page(user_id, user_role, request_type, agent, db_client):
    """Clinical triage workflow page"""
    
    st.title("🔍 Clinical Triage with Compliance")
    st.markdown("""
    Process patient information through compliance workflow:
    1. ✅ Access Control - Verify permissions
    2. 🔒 Privacy - Mask PII
    3. 🤖 Clinical AI - Generate decision
    4. 🛡️ Safety Check - Verify output
    5. 📋 Audit - Store record
    """)
    
    st.markdown("---")
    
    # Input section
    st.subheader("📋 Patient Information")
    
    col1, col2 = st.columns(2)
    with col1:
        patient_id = st.text_input("Patient ID", value="P12345")
    with col2:
        patient_name = st.text_input("Patient Name (for reference)", value="John Doe")
    
    # Clinical input
    st.subheader("📝 Clinical Input")
    input_text = st.text_area(
        "Describe patient presentation",
        height=150,
        placeholder="""Example:
60-year-old male, SSN: 123-45-6789
Chief complaint: Fever for 3 days
Temperature: 103°F
BP: 140/90
Heart rate: 98 bpm
Recent travel to Southeast Asia
Vaccination status: Up to date""",
        value="40-year-old female presents with acute chest pain radiating to left arm, associated with shortness of breath. Patient reports pain 8/10. Recent viral infection 2 weeks ago. No known allergies. Contact: jane.smith@email.com"
    )
    
    # Process button
    if st.button("🚀 Process Through Compliance Workflow", type="primary", use_container_width=True):
        
        with st.spinner("Processing through compliance checks..."):
            try:
                # Run through LangGraph agent
                result = agent.process_clinical_request(
                    user_id=user_id,
                    user_role=user_role,
                    patient_id=patient_id,
                    input_text=input_text,
                    request_type=request_type
                )
                
                # Store in session state for display
                st.session_state.last_result = result
                
            except Exception as e:
                st.error(f"❌ Processing failed: {e}")
                st.stop()
        
        # Display results
        st.markdown("---")
        st.subheader("📊 Compliance Workflow Results")
        
        # Overall status
        col1, col2, col3 = st.columns(3)
        with col1:
            status_icon = "✅" if result.get('compliance_passed') else "❌"
            st.metric("Compliance Status", status_icon, delta="PASSED" if result.get('compliance_passed') else "FAILED")
        with col2:
            st.metric("Audit ID", result.get('audit_id', 'N/A')[:8] if result.get('audit_id') else 'N/A')
        with col3:
            st.metric("PII Detected", len(result.get('pii_detected', [])))
        
        st.markdown("---")
        
        # Workflow steps
        st.subheader("🔄 Workflow Execution")
        
        step_cols = st.columns(5)
        steps = ["Access", "Mask", "LLM", "Sanitize", "Store"]
        
        for i, (col, step) in enumerate(zip(step_cols, steps)):
            with col:
                icon = "✅" if result.get('compliance_passed') else ("✅" if i < 4 else "❌")
                st.write(f"{icon}\n{step}")
        
        st.markdown("---")
        
        # Audit details
        with st.expander("📋 Full Audit Record", expanded=True):
            audit_record = result.get('audit_record', {})
            
            col1, col2 = st.columns(2)
            
            with col1:
                st.write("**Input Processing**")
                st.json({
                    "PII Detected": len(audit_record.get('pii_detected', [])),
                    "Masked Input Length": len(audit_record.get('masked_text', '')),
                    "Access Granted": audit_record.get('access_granted', False),
                })
            
            with col2:
                st.write("**Compliance**")
                st.json({
                    "Status": "PASSED" if result.get('compliance_passed') else "FAILED",
                    "Regulations": audit_record.get('applicable_regulations', []),
                    "Violations": len(result.get('violations', [])),
                })
            
            st.write("**Clinical Output**")
            st.info(audit_record.get('sanitized_output', 'No output')[:500])
        
        # Violations (if any)
        if result.get('violations'):
            st.error("⚠️ Compliance Violations Detected:")
            for violation in result.get('violations', []):
                st.write(f"- **{violation.get('type')}**: {violation.get('reason', '')}")
        
        st.markdown("---")
        
        # Save to database
        if result.get('compliance_passed'):
            st.success("✅ Audit trail saved to database")
        else:
            st.warning("⚠️ Compliance failed - audit recorded as violation")


def compliance_dashboard_page(db_client):
    """Compliance dashboard page"""
    
    st.title("📊 Compliance Dashboard")
    
    st.subheader("System Health")
    col1, col2, col3, col4 = st.columns(4)
    
    try:
        violations = db_client.get_compliance_violations(limit=1000)
        passed_audits = len([v for v in violations if v.get('event_type') == 'success'])
        failed_audits = len([v for v in violations if v.get('event_type') == 'violation'])
    except:
        passed_audits = 0
        failed_audits = 0
        violations = []
    
    with col1:
        st.metric("Total Audits", passed_audits + failed_audits)
    with col2:
        st.metric("Passed", passed_audits)
    with col3:
        st.metric("Failed", failed_audits)
    with col4:
        pass_rate = (passed_audits / (passed_audits + failed_audits) * 100) if (passed_audits + failed_audits) > 0 else 0
        st.metric("Pass Rate", f"{pass_rate:.1f}%")
    
    st.markdown("---")
    
    st.subheader("Recent Violations")
    if violations:
        for v in violations[:10]:
            with st.expander(f"🚨 {v.get('event_type', 'unknown').upper()} - {v.get('timestamp', 'Unknown')}"):
                st.json(v)
    else:
        st.info("✅ No violations")


def audit_trail_page(db_client, user_id):
    """Audit trail page"""
    
    st.title("🕐 Audit Trail")
    
    # Filter options
    col1, col2, col3 = st.columns(3)
    with col1:
        filter_user = st.text_input("Filter by User ID", value=user_id)
    with col2:
        filter_type = st.selectbox("Filter by Type", ["All", "triage", "scheduling", "referral"])
    with col3:
        limit = st.slider("Show last N records", 10, 100, 50)
    
    st.markdown("---")
    
    # Get audit logs
    try:
        audits = db_client.get_audit_logs_by_user(filter_user, limit=limit)
    except:
        audits = []
    
    if audits:
        st.subheader(f"Found {len(audits)} audit records")
        
        for audit in audits:
            with st.expander(f"📋 {audit.get('timestamp', 'Unknown')} - {audit.get('request_type', 'unknown')}"):
                col1, col2 = st.columns(2)
                
                with col1:
                    st.write(f"**Status**: {'✅ PASSED' if audit.get('compliance_passed') else '❌ FAILED'}")
                    st.write(f"**User**: {audit.get('user_id')}")
                    st.write(f"**Patient**: {audit.get('patient_id')}")
                    st.write(f"**PII Detected**: {len(audit.get('pii_detected', []))}")
                
                with col2:
                    st.write(f"**Regulations**: {', '.join(audit.get('applicable_regulations', []))}")
                    st.write(f"**Access**: {'✅ Granted' if audit.get('access_granted') else '❌ Denied'}")
                    st.write(f"**Violations**: {len(audit.get('violations', []))}")
                
                if audit.get('violations'):
                    st.warning("Violations:")
                    for v in audit.get('violations', []):
                        st.write(f"- {v}")
    else:
        st.info("No audit records found")


def settings_page():
    """Settings page"""
    
    st.title("⚙️ Settings")
    
    st.subheader("Backend Configuration")
    backend_url = st.text_input("Backend URL", value="http://localhost:8000")
    
    st.subheader("Database Configuration")
    db_url = st.text_input("Database URL", value="sqlite:///./compliance_frontend.db")
    
    st.subheader("LLM Configuration")
    llm_model = st.selectbox("LLM Model", ["gpt-4", "gpt-3.5-turbo", "claude-3-opus"])
    llm_temp = st.slider("Temperature", 0.0, 1.0, 0.7)
    
    if st.button("Save Settings"):
        st.success("✅ Settings saved")


# ============ ROUTE PAGES ============

if "last_result" not in st.session_state:
    st.session_state.last_result = None

if page == "Clinical Triage":
    clinical_triage_page(user_id, user_role, request_type, agent, db_client)
elif page == "Compliance Dashboard":
    compliance_dashboard_page(db_client)
elif page == "Audit Trail":
    audit_trail_page(db_client, user_id)
elif page == "Settings":
    settings_page()
