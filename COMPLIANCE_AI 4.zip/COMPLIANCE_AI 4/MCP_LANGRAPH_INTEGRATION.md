"""
LangGraph Agent with MCP Integration (Optional Enhancement)

This module shows how to optionally use MCP tools in the LangGraph agent
instead of direct HTTP calls. This provides better interoperability and
standardization.

To use this:
1. Ensure mcp_server.py is running
2. Replace import and initialization in healthcare_compliance_agent.py
3. Use await for async MCP calls
"""

# Optional integration example:
# In healthcare_compliance_agent.py, you could do:

"""
# Import MCP client
from mcp_client import create_mcp_client

class HealthcareComplianceAgent:
    def __init__(self, backend_url: str = "http://localhost:8000", 
                 db_client=None, use_mcp: bool = False):
        self.backend = BackendClient(backend_url)
        self.db = db_client
        self.use_mcp = use_mcp
        
        if use_mcp:
            self.mcp = create_mcp_client()
        
        self.graph = self._build_graph()
    
    # In any node, use MCP if enabled:
    
    async def _mask_pii_node(self, state: HealthcareComplianceState) -> dict:
        print(f"[COMPLIANCE] Masking PII from input text")
        
        if self.use_mcp:
            # Use MCP
            result = await self.mcp.mask_pii(state['input_text'])
        else:
            # Use direct backend call
            result = self.backend.mask_pii(state['input_text'])
        
        return {
            "masked_text": result.get("masked_text", ""),
            "pii_detected": result.get("pii_detected", []),
        }
"""

# Benefits of MCP integration:
# 1. Standardized tool interface
# 2. Easier Claude integration
# 3. Better error handling
# 4. Resource-based data access
# 5. Multi-server support
# 6. Better compatibility with other tools

print("""
MCP Integration for LangGraph

The healthcare_compliance_agent.py can optionally use MCP tools
instead of direct HTTP calls.

Current: Direct HTTP calls (simple, fast)
Optional: MCP tools (standardized, interoperable)

To enable MCP in the LangGraph agent:

1. Add to agent initialization:
   agent = create_compliance_agent(use_mcp=True)

2. This will:
   - Use MCP tools instead of HTTP calls
   - Maintain the same interface
   - Provide better Claude integration
   - Enable MCP server switching

3. Ensure MCP server is running:
   python mcp_server.py

Both approaches work! Use HTTP for simplicity or MCP for
standardization and interoperability.

See: MCP_INTEGRATION.md for detailed MCP usage
""")
