#!/bin/bash

# Complete System Startup Script
# Starts both backend and frontend

echo "🚀 Starting Complete Compliance AI System..."
echo ""

# Kill any existing processes on ports 8000, 8501 and background Python/Streamlit
echo "🧹 Cleaning up existing processes..."
lsof -ti :8000 | xargs kill -9 2>/dev/null
lsof -ti :8501 | xargs kill -9 2>/dev/null
pkill -9 -f "uvicorn app.main" 2>/dev/null
pkill -9 -f streamlit 2>/dev/null
sleep 2
echo "✅ Cleanup complete"
echo ""

# Function to cleanup background processes on exit
cleanup() {
    echo ""
    echo "🛑 Stopping all services..."
    kill $BACKEND_PID $FRONTEND_PID 2>/dev/null
    exit
}

trap cleanup EXIT INT TERM

# Start backend in background
echo "📡 Starting Backend API Server..."
./start_backend.sh &
BACKEND_PID=$!

# Wait for backend to start
echo "⏳ Waiting for backend to initialize..."
sleep 5

# Check if backend is running
if ! kill -0 $BACKEND_PID 2>/dev/null; then
    echo "❌ Backend failed to start!"
    exit 1
fi

echo "✅ Backend running (PID: $BACKEND_PID)"
echo ""

# Start frontend in background
echo "🎨 Starting Frontend Server..."
./start_frontend.sh &
FRONTEND_PID=$!

sleep 2

echo ""
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "✅ COMPLIANCE AI SYSTEM READY!"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo ""
echo "🎨 Frontend:  http://localhost:8501"
echo "📡 Backend:   http://localhost:8000"
echo "📚 API Docs:  http://localhost:8000/api/docs"
echo ""
echo "Press CTRL+C to stop all services"
echo ""

# Wait for processes
wait
