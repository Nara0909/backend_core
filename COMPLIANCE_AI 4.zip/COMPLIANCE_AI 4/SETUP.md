# SETUP GUIDE - Compliance AI Backend & Frontend

## 🚀 Complete Setup Instructions

### Step 1: Environment Setup

1. **Clone or navigate to the project**
```bash
cd /Users/chakravarthynara/Documents/COMPLIANCE_AI
```

2. **Create and activate virtual environment**
```bash
python -m venv .venv
source .venv/bin/activate  # On Mac/Linux
# OR
.venv\Scripts\activate     # On Windows
```

3. **Install dependencies**
```bash
pip install --upgrade pip
pip install -r requirements.txt
```

### Step 2: Environment Variables

Create a `.env` file in the project root:

```env
# OpenAI Configuration
OPENAI_API_KEY=your_openai_api_key_here
OPENAI_BASE_URL=https://api.openai.com/v1  # Optional: Use your gateway

# Security Keys
APP_ENCRYPTION_KEY=generate_with_fernet_generate_key
AUDIT_HMAC_SECRET=your_random_secret_here

# Optional: Compliance Settings
DATA_RETENTION_DAYS=90
ALLOW_LOG_VIEW_ROLES=admin,auditor
```

**Generate encryption key:**
```python
from cryptography.fernet import Fernet
print(Fernet.generate_key().decode())
```

### Step 3: Verify Installation

```bash
# Check Python packages
python -c "import fastapi, langgraph, cryptography; print('✅ All core packages installed')"

# Make scripts executable
chmod +x start_all.sh start_backend.sh start_frontend.sh
```

### Step 4: Start the System

**Option A - Start Everything (Recommended):**
```bash
./start_all.sh
```

**Option B - Start Separately:**

Terminal 1 (Backend):
```bash
./start_backend.sh
```

Terminal 2 (Frontend):
```bash
./start_frontend.sh
```

### Step 5: Verify System is Running

1. **Check Backend Health:**
```bash
curl http://localhost:8000/api/health
```

Expected output:
```json
{
  "status": "healthy",
  "compliance_enabled": true,
  "version": "1.0.0"
}
```

2. **Open Frontend:**
- Navigate to: http://localhost:8501
- You should see the Compliance AI Dashboard

3. **View API Documentation:**
- Interactive docs: http://localhost:8000/api/docs
- ReDoc: http://localhost:8000/api/redoc

---

## 🧪 Testing the System

### Quick Test 1: API Health Check
```bash
curl http://localhost:8000/api/health
```

### Quick Test 2: Toggle Compliance
```bash
# Disable compliance
curl -X POST http://localhost:8000/api/compliance/disable

# Check status
curl http://localhost:8000/api/compliance/status

# Enable compliance
curl -X POST http://localhost:8000/api/compliance/enable
```

### Quick Test 3: Process Request
```bash
curl -X POST http://localhost:8000/api/process \
  -H "Content-Type: application/json" \
  -d '{
    "input_text": "Patient John Doe (SSN: 123-45-6789) has diabetes",
    "request_type": "patient_triage",
    "user_role": "clinician"
  }'
```

### Automated Test Suite
```bash
# Run comprehensive tests
python test_api.py
```

### Interactive Demo
```bash
# Run guided demo
python demo.py
```

---

## 🎨 Using the Frontend

### 1. Compliance Toggle
- Click "Enable Compliance" or "Disable Compliance"
- Watch the status badge change
- Notice the regulations list when enabled

### 2. Process Healthcare Data
- Enter patient data in the text area
- Select request type (patient_triage, appointment_scheduling, etc.)
- Choose user role
- Click "Process Request"

### 3. View Results
- See original vs masked input
- Review execution path (which agents ran)
- Examine audit log entries
- Compare results with compliance ON vs OFF

### 4. Test the Difference
1. **With Compliance ON:**
   - Input: "Patient John Doe, SSN: 123-45-6789"
   - Output: "Patient [REDACTED], SSN: [REDACTED]"
   - Audit: 6+ log entries

2. **With Compliance OFF:**
   - Input: "Patient John Doe, SSN: 123-45-6789"
   - Output: Same as input (no masking)
   - Audit: 0 log entries

---

## 📊 Available Endpoints

### Compliance Management
```
GET    /api/compliance/status    - Get current compliance state
POST   /api/compliance/enable    - Enable compliance
POST   /api/compliance/disable   - Disable compliance (bypass)
```

### Data Processing
```
POST   /api/process              - Process healthcare data
```

### Audit & Logs
```
GET    /api/audit/logs           - Get audit logs
GET    /api/audit/logs?limit=50  - Limit number of logs
GET    /api/audit/logs?agent_filter=PrivacyAgent - Filter by agent
```

### Policy Management
```
GET    /api/policies             - List all policies
GET    /api/policies/{name}      - Get specific policy details
```

### System
```
GET    /api/health               - Health check
GET    /api/request-types        - List available request types
GET    /                         - API information
```

---

## 🔌 Integration with Your Frontend

### JavaScript/TypeScript
```javascript
const API_URL = 'http://localhost:8000/api';

// Check compliance status
const status = await fetch(`${API_URL}/compliance/status`).then(r => r.json());

// Process request
const result = await fetch(`${API_URL}/process`, {
  method: 'POST',
  headers: { 'Content-Type': 'application/json' },
  body: JSON.stringify({
    input_text: 'Patient data...',
    request_type: 'patient_triage'
  })
}).then(r => r.json());
```

### Python
```python
import requests

# Enable compliance
requests.post('http://localhost:8000/api/compliance/enable')

# Process data
result = requests.post('http://localhost:8000/api/process', json={
    'input_text': 'Patient data...',
    'request_type': 'patient_triage'
}).json()

print(result['processed_output'])
```

See `integration_examples.py` for more examples (React, Vue, Flask, etc.)

---

## 🐛 Troubleshooting

### Backend won't start
```bash
# Check if port 8000 is in use
lsof -i :8000
# Kill process if needed
kill -9 <PID>

# Check dependencies
pip list | grep -E "fastapi|langgraph|cryptography"

# Check environment variables
python -c "import os; from dotenv import load_dotenv; load_dotenv(); print('API Key:', os.getenv('OPENAI_API_KEY')[:10])"
```

### Frontend can't connect to backend
```bash
# Verify backend is running
curl http://localhost:8000/api/health

# Check CORS is enabled
curl -H "Origin: http://localhost:3000" \
     -H "Access-Control-Request-Method: POST" \
     -H "Access-Control-Request-Headers: Content-Type" \
     -X OPTIONS http://localhost:8000/api/process
```

### Compliance not toggling
```bash
# Check state file
cat app/compliance_state.json

# Reset state
rm app/compliance_state.json
./start_backend.sh  # Will create new state file
```

### API returns errors
```bash
# Check backend logs
# Look for error messages in the terminal running start_backend.sh

# Test with curl
curl -v http://localhost:8000/api/compliance/status

# Check request format
curl -X POST http://localhost:8000/api/process \
  -H "Content-Type: application/json" \
  -d '{"input_text":"test","request_type":"patient_triage"}' \
  | jq .
```

---

## 📦 Project Structure
```
COMPLIANCE_AI/
├── app/                           # Backend API
│   ├── main.py                    # FastAPI application
│   ├── compliance_state.py        # State management
│   ├── api_models.py              # Pydantic models
│   └── compliance_state.json      # State persistence
├── ui/
│   └── index.html                 # React frontend
├── agent_graph/                   # LangGraph compliance pipeline
├── policy_generator/              # Policy management
├── security/                      # Security utilities
├── start_all.sh                   # Start everything
├── start_backend.sh               # Start backend
├── start_frontend.sh              # Start frontend
├── test_api.py                    # Test suite
├── demo.py                        # Interactive demo
├── integration_examples.py        # Integration guides
└── README.md                      # Documentation
```

---

## 🎯 Next Steps

1. **Customize for your use case:**
   - Modify request types in `policy_generator/request_types.py`
   - Add custom agents in `agent_graph/nodes.py`
   - Update policies in `policy_generator/output_policies_AI/`

2. **Production deployment:**
   - Use proper database for audit logs (PostgreSQL, MongoDB)
   - Implement authentication (OAuth2, JWT)
   - Set up HTTPS with SSL certificates
   - Use environment-specific configs
   - Deploy to cloud (AWS, Azure, GCP)

3. **Extend functionality:**
   - Add user management
   - Implement role-based access control
   - Create custom compliance rules
   - Add monitoring and alerting

---

## 📚 Additional Resources

- **API Documentation:** http://localhost:8000/api/docs
- **Integration Examples:** See `integration_examples.py`
- **Test Suite:** Run `python test_api.py`
- **Interactive Demo:** Run `python demo.py`

---

## ✅ Verification Checklist

- [ ] Virtual environment activated
- [ ] Dependencies installed
- [ ] .env file created with required keys
- [ ] Backend starts successfully (port 8000)
- [ ] Frontend accessible (port 3000)
- [ ] Health check returns "healthy"
- [ ] Compliance toggle works
- [ ] Process endpoint returns results
- [ ] Frontend connects to backend
- [ ] PII masking works when compliance enabled
- [ ] Bypass works when compliance disabled

---

**You're all set! 🎉**

Your Compliance AI system is ready to enforce GDPR, HIPAA, PCI-DSS, and AI Act compliance!
