# ⚡ LOCAL MCP SETUP - QUICK START

## 3-Step Setup

### Step 1: Install (one-time)
```bash
cd COMPLIANCE_AI
pip install -r requirements.txt
```

### Step 2: Start
```bash
python local_setup.py
```

### Step 3: Open Browser
```
http://127.0.0.1:8501
```

---

## What You Get

| Component | URL | Port | Purpose |
|-----------|-----|------|---------|
| **Streamlit UI** | http://127.0.0.1:8501 | 8501 | Clinical triage, audit logs |
| **Backend API** | http://127.0.0.1:8000 | 8000 | Compliance engine |
| **API Docs** | http://127.0.0.1:8000/docs | 8000 | Interactive API explorer |
| **MCP Server** | local process | - | LLM/AI integration (optional) |

---

## System Components

```
┌─────────────────────────────────────────┐
│       Streamlit Frontend (8501)         │
│    • Clinical Triage                    │
│    • Compliance Dashboard               │
│    • Audit Trail                        │
│    • Settings                           │
└──────────────┬──────────────────────────┘
               │
         ┌─────▼─────┐
         │   HTTP    │
         └─────┬─────┘
               │
┌──────────────▼──────────────────────────┐
│       FastAPI Backend (8000)            │
│    • Enforcement Plans                  │
│    • Access Control                     │
│    • PII Masking                        │
│    • Output Sanitization                │
│    • Compliance Logging                 │
└──────────────┬──────────────────────────┘
               │
         ┌─────▼─────┐
         │ SQLite DB │  ← All local, no cloud
         └───────────┘
```

---

## Usage Examples

### Example 1: Web Interface
1. Open http://127.0.0.1:8501
2. Click "Clinical Triage"
3. Enter patient info:
   ```
   User ID: dr_smith
   Role: clinician
   Patient: patient_123
   Request: "Patient has high fever"
   Type: triage
   ```
4. Click "Process Request"
5. See compliance checks pass/fail in real-time

### Example 2: Test MCP Tools
```bash
# In another terminal
cd COMPLIANCE_AI
python test_mcp_local.py
```

### Example 3: API Direct Access
```bash
# Get regulations for triage
curl "http://127.0.0.1:8000/api/enforcement-plan?request_type=triage"

# Check if user can access patient
curl -X POST "http://127.0.0.1:8000/api/check-access" \
  -H "Content-Type: application/json" \
  -d '{
    "user_id": "dr_smith",
    "user_role": "clinician", 
    "patient_id": "patient_123",
    "resource_type": "ehr"
  }'

# Mask sensitive data
curl -X POST "http://127.0.0.1:8000/api/mask-pii" \
  -H "Content-Type: application/json" \
  -d '{"text": "Patient John Doe (SSN: 123-45-6789)"}'
```

### Example 4: Python Client
```python
import asyncio
from mcp_client import create_mcp_client

async def test():
    client = create_mcp_client()
    
    # Get regulations
    plan = await client.get_enforcement_plan("triage")
    print(f"Regulations: {plan['regulations']}")
    
    # Mask PII
    result = await client.mask_pii("Patient John Doe (SSN: 123-45-6789)")
    print(f"Masked: {result['masked_text']}")

asyncio.run(test())
```

---

## 5 Compliance Tools (Local MCP)

### 1. get_enforcement_plan(request_type)
Returns regulations for a request type
```json
{
  "request_type": "triage",
  "regulations": ["HIPAA", "GDPR"],
  "agents": ["AccessControl", "Privacy", "OutputGuard"]
}
```

### 2. check_access(user_id, user_role, patient_id, resource_type)
Verifies user access to patient data
```json
{
  "access_granted": true,
  "reason": "Clinician has HIPAA clearance"
}
```

### 3. mask_pii(text)
Detects and masks sensitive information
```json
{
  "masked_text": "Patient [NAME] (SSN: [SSN])",
  "pii_detected": [
    {"type": "NAME", "original_count": 1},
    {"type": "SSN", "original_count": 1}
  ]
}
```

### 4. sanitize_output(text)
Ensures LLM output has no PII
```json
{
  "sanitized_text": "Patient has fever symptoms",
  "safe_to_store": true,
  "pii_removed": 0
}
```

### 5. log_compliance_action(...)
Records compliance events in audit log
```json
{
  "audit_id": "550e8400-e29b-41d4-a716-446655440000",
  "timestamp": "2025-12-17T10:30:00Z",
  "regulations_logged": ["HIPAA"]
}
```

---

## Stop Services

Press `Ctrl+C` in the terminal running `local_setup.py`

Services shut down cleanly. No cleanup needed.

---

## Troubleshooting

| Problem | Solution |
|---------|----------|
| Port 8000 in use | `kill -9 $(lsof -t -i :8000)` |
| Port 8501 in use | `kill -9 $(lsof -t -i :8501)` |
| Backend won't start | Check `python -m uvicorn app.main:app --host 127.0.0.1 --port 8000` |
| Frontend won't start | Check `streamlit run ui/app.py` |
| Missing packages | Run `pip install -r requirements.txt` |
| "Cannot connect to backend" | Verify backend running: `curl http://127.0.0.1:8000/docs` |

---

## Database (Local)

All data stored in local SQLite:
- **File**: `compliance_frontend.db`
- **Tables**: 
  - `audit_log` - All compliance actions
  - `clinical_decision` - Triage decisions
  - `patient_ehr` - Medical records
  - `compliance_event` - Violations

No cloud. No syncing. Pure local.

---

## Architecture Decisions

✅ **Local Only**
- Backend: 127.0.0.1:8000
- Frontend: 127.0.0.1:8501
- Database: SQLite (local file)
- MCP: Local process

✅ **No Hosting**
- No deployment required
- No Docker
- No cloud providers
- No external dependencies

✅ **Simple Setup**
- Single Python script
- Automatic port management
- One-command startup
- Clean shutdown

---

## Next Steps

1. **START**: `python local_setup.py`
2. **OPEN**: http://127.0.0.1:8501
3. **TEST**: Enter triage request with sample patient data
4. **MONITOR**: Check Audit Trail for logged compliance actions
5. **EXPLORE**: View API docs at http://127.0.0.1:8000/docs

---

## Advanced

### Connect to Remote Backend
```python
client = LocalMCPClient(backend_url="http://your-server:8000")
```

### Custom Ports
Edit `local_setup.py` to change port numbers

### Run Components Separately
```bash
# Terminal 1
python -m uvicorn app.main:app --host 127.0.0.1 --port 8000

# Terminal 2  
streamlit run ui/app.py --server.port=8501

# Terminal 3
python test_mcp_local.py
```

### Claude Integration (Optional)
See [MCP_INTEGRATION.md](MCP_INTEGRATION.md) for full Claude setup

---

## Performance

All local means:
- ⚡ **Fast**: <100ms per tool call
- 🔒 **Secure**: No internet required
- 🆓 **Free**: No API costs
- 📊 **Full Control**: Local data only

---

**Ready?**

```bash
python local_setup.py
```

Then open http://127.0.0.1:8501 🚀
