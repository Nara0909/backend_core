"""
Model Context Protocol (MCP) Server for Healthcare Compliance

Exposes compliance tools and audit resources via MCP standard protocol.
Allows Claude and other AI systems to directly interact with compliance infrastructure.

MCP Tools:
- get_enforcement_plan: Get applicable regulations for a request type
- check_access: Verify user access to resources
- mask_pii: Detect and mask sensitive data
- sanitize_output: Remove PII from LLM output
- log_compliance_action: Create audit record

MCP Resources:
- audit_log: Query audit trail
- compliance_violations: Get compliance violations
- patient_ehr: Get patient health records
- enforcement_plans: List all enforcement plans
"""

from mcp.server.models import InitializationOptions
from mcp.server import Server, NotImplementedError
from mcp.types import (
    Tool,
    TextContent,
    Image,
    EmbeddedResource,
    Resource,
    ResourceTemplate,
)
import json
import asyncio
from typing import Any
import requests
from datetime import datetime

# Initialize MCP Server
mcp = Server("healthcare-compliance-mcp")

# Backend configuration
BACKEND_URL = "http://localhost:8000"


# ============ TOOL IMPLEMENTATIONS ============

@mcp.tool()
async def get_enforcement_plan(request_type: str) -> str:
    """
    Get the enforcement plan - which regulations and agents apply to a request type.
    
    Args:
        request_type: Type of request (triage, scheduling, referral, diagnosis, monitoring)
    
    Returns:
        JSON enforcement plan with applicable regulations and agents
    """
    try:
        response = requests.get(
            f"{BACKEND_URL}/api/enforcement-plan",
            params={"request_type": request_type},
            timeout=30
        )
        response.raise_for_status()
        result = response.json()
        return json.dumps({
            "status": "success",
            "enforcement_plan": result,
            "regulations": result.get("regulations", []),
            "agents": result.get("agents", [])
        }, indent=2)
    except Exception as e:
        return json.dumps({
            "status": "error",
            "error": str(e)
        })


@mcp.tool()
async def check_access(
    user_id: str,
    user_role: str,
    patient_id: str,
    resource_type: str = "patient_data"
) -> str:
    """
    Check if a user has access to a resource.
    
    Args:
        user_id: User identifier
        user_role: User role (clinician, specialist, admin, nurse, patient)
        patient_id: Patient identifier
        resource_type: Type of resource being accessed
    
    Returns:
        JSON with access decision and reasoning
    """
    try:
        payload = {
            "user_id": user_id,
            "user_role": user_role,
            "patient_id": patient_id,
            "resource_type": resource_type
        }
        response = requests.post(
            f"{BACKEND_URL}/api/check-access",
            json=payload,
            timeout=30
        )
        response.raise_for_status()
        result = response.json()
        return json.dumps({
            "status": "success",
            "access_granted": result.get("access_granted", False),
            "reason": result.get("reason", ""),
            "regulations": result.get("regulations", [])
        }, indent=2)
    except Exception as e:
        return json.dumps({
            "status": "error",
            "error": str(e)
        })


@mcp.tool()
async def mask_pii(text: str) -> str:
    """
    Detect and mask PII (Personally Identifiable Information) in text.
    
    Detects: SSN, EMAIL, PHONE, NAME patterns
    Masks: Replaces with [SSN], [EMAIL], [PHONE], [NAME] tokens
    
    Args:
        text: Input text potentially containing PII
    
    Returns:
        JSON with masked text and list of detected PII
    """
    try:
        payload = {"text": text}
        response = requests.post(
            f"{BACKEND_URL}/api/mask-pii",
            json=payload,
            timeout=30
        )
        response.raise_for_status()
        result = response.json()
        return json.dumps({
            "status": "success",
            "masked_text": result.get("masked_text", ""),
            "pii_detected": result.get("pii_detected", []),
            "pii_count": len(result.get("pii_detected", []))
        }, indent=2)
    except Exception as e:
        return json.dumps({
            "status": "error",
            "error": str(e)
        })


@mcp.tool()
async def sanitize_output(text: str) -> str:
    """
    Sanitize LLM output - ensure no PII leakage.
    
    Checks output for any residual PII patterns that might have leaked from the LLM.
    
    Args:
        text: LLM output text to sanitize
    
    Returns:
        JSON with sanitized text, safety status, and any PII found
    """
    try:
        payload = {"text": text}
        response = requests.post(
            f"{BACKEND_URL}/api/sanitize-output",
            json=payload,
            timeout=30
        )
        response.raise_for_status()
        result = response.json()
        return json.dumps({
            "status": "success",
            "sanitized_text": result.get("sanitized_text", ""),
            "safe_to_store": result.get("safe_to_store", False),
            "pii_detected": result.get("pii_detected", []),
            "pii_found": len(result.get("pii_detected", [])) > 0
        }, indent=2)
    except Exception as e:
        return json.dumps({
            "status": "error",
            "error": str(e)
        })


@mcp.tool()
async def log_compliance_action(
    user_id: str,
    action: str,
    resource: str,
    outcome: str,
    details: str = ""
) -> str:
    """
    Log a compliance action to the audit trail.
    
    Args:
        user_id: User performing the action
        action: Action performed (triage_decision, access_check, etc.)
        resource: Resource affected (patient, patient_data, etc.)
        outcome: Outcome of action (success, denied, error)
        details: Additional context (JSON string)
    
    Returns:
        JSON with audit record ID and timestamp
    """
    try:
        payload = {
            "user_id": user_id,
            "action": action,
            "resource": resource,
            "outcome": outcome,
            "details": json.loads(details) if details else {}
        }
        response = requests.post(
            f"{BACKEND_URL}/api/log-compliance-action",
            json=payload,
            timeout=30
        )
        response.raise_for_status()
        result = response.json()
        return json.dumps({
            "status": "success",
            "audit_id": result.get("audit_id", ""),
            "timestamp": result.get("timestamp", ""),
            "regulations_logged": result.get("regulations_logged", [])
        }, indent=2)
    except Exception as e:
        return json.dumps({
            "status": "error",
            "error": str(e)
        })


# ============ RESOURCE IMPLEMENTATIONS ============

@mcp.resource("audit_log://user/{user_id}")
async def get_user_audit_logs(uri: str) -> str:
    """
    Get audit logs for a specific user.
    
    Resource URI: audit_log://user/{user_id}
    Example: audit_log://user/clinician_001
    """
    user_id = uri.split("/")[-1]
    try:
        # In a real implementation, this would query your database
        # For now, we'll provide a template
        return json.dumps({
            "user_id": user_id,
            "audit_logs": [
                {
                    "timestamp": datetime.utcnow().isoformat(),
                    "action": "triage_decision",
                    "patient_id": "P12345",
                    "outcome": "success",
                    "regulations": ["HIPAA", "GDPR"]
                }
            ],
            "note": "Connect to frontend database for full audit trail"
        }, indent=2)
    except Exception as e:
        return json.dumps({"error": str(e)})


@mcp.resource("audit_log://patient/{patient_id}")
async def get_patient_audit_logs(uri: str) -> str:
    """
    Get all audit logs for a specific patient.
    
    Resource URI: audit_log://patient/{patient_id}
    Example: audit_log://patient/P12345
    """
    patient_id = uri.split("/")[-1]
    try:
        return json.dumps({
            "patient_id": patient_id,
            "total_accesses": 0,
            "audit_logs": [],
            "note": "Connect to frontend database for full patient audit trail"
        }, indent=2)
    except Exception as e:
        return json.dumps({"error": str(e)})


@mcp.resource("compliance_violations://")
async def get_compliance_violations(uri: str) -> str:
    """
    Get all recent compliance violations.
    
    Resource URI: compliance_violations://
    """
    try:
        return json.dumps({
            "violations": [],
            "total": 0,
            "last_24h": 0,
            "note": "Connect to frontend database for full violation history"
        }, indent=2)
    except Exception as e:
        return json.dumps({"error": str(e)})


@mcp.resource("patient_ehr://{patient_id}")
async def get_patient_ehr(uri: str) -> str:
    """
    Get patient EHR (Electronic Health Record).
    
    Resource URI: patient_ehr://{patient_id}
    Example: patient_ehr://P12345
    """
    patient_id = uri.split("://")[-1]
    try:
        return json.dumps({
            "patient_id": patient_id,
            "medical_conditions": [],
            "medications": [],
            "allergies": [],
            "recent_visits": [],
            "access_restrictions": ["HIPAA", "GDPR"],
            "note": "Connect to frontend database for full EHR data"
        }, indent=2)
    except Exception as e:
        return json.dumps({"error": str(e)})


@mcp.resource("enforcement_plans://")
async def list_enforcement_plans(uri: str) -> str:
    """
    List all available enforcement plans.
    
    Resource URI: enforcement_plans://
    """
    try:
        return json.dumps({
            "plans": [
                {
                    "request_type": "triage",
                    "regulations": ["HIPAA", "GDPR"],
                    "agents": ["AccessControl", "Privacy", "OutputGuard"]
                },
                {
                    "request_type": "scheduling",
                    "regulations": ["HIPAA", "GDPR", "CCPA"],
                    "agents": ["AccessControl", "Privacy", "DataMinimization"]
                },
                {
                    "request_type": "referral",
                    "regulations": ["HIPAA"],
                    "agents": ["AccessControl", "Privacy"]
                }
            ]
        }, indent=2)
    except Exception as e:
        return json.dumps({"error": str(e)})


# ============ SERVER INITIALIZATION ============

async def startup():
    """Server initialization"""
    print("🚀 Healthcare Compliance MCP Server starting...")
    print(f"Backend URL: {BACKEND_URL}")
    print("\nAvailable MCP Tools:")
    print("  - get_enforcement_plan(request_type)")
    print("  - check_access(user_id, user_role, patient_id, resource_type)")
    print("  - mask_pii(text)")
    print("  - sanitize_output(text)")
    print("  - log_compliance_action(user_id, action, resource, outcome, details)")
    print("\nAvailable MCP Resources:")
    print("  - audit_log://user/{user_id}")
    print("  - audit_log://patient/{patient_id}")
    print("  - compliance_violations://")
    print("  - patient_ehr://{patient_id}")
    print("  - enforcement_plans://")


if __name__ == "__main__":
    # Run with: python -m mcp.cli run mcp_server.py
    # Or use in Claude: Configure in Claude settings to call this server
    print("Healthcare Compliance MCP Server")
    print("=" * 50)
    print("\nTo use this MCP server:")
    print("1. In Claude: Add MCP server in settings")
    print("2. Server path: python mcp_server.py")
    print("3. Claude will have access to all compliance tools")
