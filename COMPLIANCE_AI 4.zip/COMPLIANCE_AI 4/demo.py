"""
Quick Demo Script - Compliance AI System

This script demonstrates the key difference between 
compliance ENABLED vs DISABLED modes.
"""

import requests
import json

BASE_URL = "http://localhost:8000/api"

# Sample patient data with PII
SAMPLE_INPUT = """
Patient: John Doe
DOB: 1985-03-15
SSN: 123-45-6789
Email: john.doe@hospital.com
Phone: 555-0123

Chief Complaint: Patient reports chest pain and shortness of breath.
Medical History: Diabetes, Hypertension
Current Medications: Metformin, Lisinopril
"""

def print_section(title):
    print("\n" + "=" * 70)
    print(f"  {title}")
    print("=" * 70)

def demo_with_compliance():
    """Demo with compliance ENABLED"""
    print_section("🔒 DEMO 1: COMPLIANCE ENABLED (Secure Mode)")
    
    # Enable compliance
    print("\n1️⃣  Enabling compliance enforcement...")
    resp = requests.post(f"{BASE_URL}/compliance/enable")
    status = resp.json()
    print(f"   ✅ Compliance: {status['enabled']}")
    print(f"   📋 Active Regulations: {', '.join(status['enforced_regulations'])}")
    
    # Process request
    print("\n2️⃣  Processing patient data with compliance controls...")
    payload = {
        "input_text": SAMPLE_INPUT,
        "request_type": "patient_triage",
        "user_role": "clinician",
        "regulations": ["HIPAA", "GDPR"]
    }
    
    resp = requests.post(f"{BASE_URL}/process", json=payload)
    result = resp.json()
    
    print("\n3️⃣  Results:")
    print(f"\n   📝 ORIGINAL INPUT (first 100 chars):")
    print(f"   {result['original_input'][:100]}...")
    
    if result.get('masked_input'):
        print(f"\n   🔐 PRIVACY-MASKED INPUT (first 100 chars):")
        print(f"   {result['masked_input'][:100]}...")
    
    print(f"\n   📤 FINAL OUTPUT:")
    print(f"   {result['processed_output'][:150]}...")
    
    print(f"\n   🛡️  COMPLIANCE MEASURES APPLIED:")
    print(f"   - Agents Executed: {len(result.get('execution_path', []))}")
    print(f"   - Execution Path: {' → '.join(result.get('execution_path', [])[:4])}...")
    print(f"   - Audit Log Entries: {len(result.get('audit_log', []))}")
    print(f"   - Policies Enforced: {len(result.get('policies_applied', []))}")
    
    print("\n   ✅ PII/PHI was MASKED and ENCRYPTED")
    print("   ✅ Full audit trail generated")
    print("   ✅ Regulatory compliance maintained")

def demo_without_compliance():
    """Demo with compliance DISABLED"""
    print_section("⚠️  DEMO 2: COMPLIANCE DISABLED (Bypass Mode)")
    
    # Disable compliance
    print("\n1️⃣  Disabling compliance enforcement...")
    resp = requests.post(f"{BASE_URL}/compliance/disable")
    status = resp.json()
    print(f"   ❌ Compliance: {status['enabled']}")
    print(f"   ⚠️  WARNING: All privacy controls are OFF")
    
    # Process request
    print("\n2️⃣  Processing same patient data WITHOUT compliance...")
    payload = {
        "input_text": SAMPLE_INPUT,
        "request_type": "patient_triage",
        "user_role": "clinician"
    }
    
    resp = requests.post(f"{BASE_URL}/process", json=payload)
    result = resp.json()
    
    print("\n3️⃣  Results:")
    print(f"\n   📝 INPUT:")
    print(f"   {result['original_input'][:100]}...")
    
    print(f"\n   📤 OUTPUT (Direct, No Masking):")
    print(f"   {result['processed_output'][:150]}...")
    
    print(f"\n   ⚠️  COMPLIANCE MEASURES:")
    print(f"   - Agents Executed: {len(result.get('execution_path', []))}")
    print(f"   - Execution Path: {result.get('execution_path', [])}")
    print(f"   - Audit Log Entries: {len(result.get('audit_log', []))}")
    
    print("\n   ❌ NO PII/PHI masking")
    print("   ❌ NO encryption")
    print("   ❌ NO audit trail")
    print("   ❌ NOT compliant with HIPAA/GDPR")

def compare_modes():
    """Show side-by-side comparison"""
    print_section("📊 COMPARISON: Compliance ON vs OFF")
    
    print("\n┌─────────────────────────┬─────────────────┬─────────────────┐")
    print("│ Feature                 │ Compliance ON   │ Compliance OFF  │")
    print("├─────────────────────────┼─────────────────┼─────────────────┤")
    print("│ PII/PHI Masking         │ ✅ Yes          │ ❌ No           │")
    print("│ Data Encryption         │ ✅ Yes          │ ❌ No           │")
    print("│ Access Control          │ ✅ Enforced     │ ❌ Bypassed     │")
    print("│ Audit Logging           │ ✅ Full Trail   │ ❌ None         │")
    print("│ Policy Enforcement      │ ✅ Active       │ ❌ Disabled     │")
    print("│ HIPAA Compliance        │ ✅ Compliant    │ ❌ Non-Compliant│")
    print("│ GDPR Compliance         │ ✅ Compliant    │ ❌ Non-Compliant│")
    print("│ Processing Speed        │ ⚡ Normal       │ ⚡⚡ Faster      │")
    print("│ Production Ready        │ ✅ Yes          │ ❌ Testing Only │")
    print("└─────────────────────────┴─────────────────┴─────────────────┘")

def main():
    print("\n" + "🏥" * 30)
    print("  COMPLIANCE AI SYSTEM - INTERACTIVE DEMO")
    print("🏥" * 30)
    
    print("\nThis demo shows how compliance toggle affects data processing.")
    print("The same patient data is processed in two modes:\n")
    print("  1. ✅ Compliance ENABLED (Secure, Compliant)")
    print("  2. ❌ Compliance DISABLED (Fast, Non-Compliant)\n")
    
    input("Press ENTER to start demo...")
    
    try:
        # Demo 1: With compliance
        demo_with_compliance()
        input("\n\nPress ENTER to continue to next demo...")
        
        # Demo 2: Without compliance
        demo_without_compliance()
        input("\n\nPress ENTER to see comparison...")
        
        # Comparison
        compare_modes()
        
        # Re-enable compliance
        print_section("🔒 Restoring Secure Mode")
        requests.post(f"{BASE_URL}/compliance/enable")
        print("\n✅ Compliance has been RE-ENABLED for safety")
        
        print("\n" + "=" * 70)
        print("  DEMO COMPLETE!")
        print("=" * 70)
        print("\n📚 Next steps:")
        print("   - Open frontend: http://localhost:3000")
        print("   - View API docs: http://localhost:8000/api/docs")
        print("   - Try toggling compliance in the UI")
        print("\n")
        
    except requests.exceptions.ConnectionError:
        print("\n❌ ERROR: Cannot connect to backend!")
        print("Please start the backend first:")
        print("   ./start_backend.sh")
    except KeyboardInterrupt:
        print("\n\n⚠️  Demo interrupted")

if __name__ == "__main__":
    main()
