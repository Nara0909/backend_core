import logging
from security.logging_filter import setup_secure_logging

_logger = None


def _get_logger() -> logging.Logger:
    global _logger
    if _logger is None:
        setup_secure_logging()
        _logger = logging.getLogger("audit")
    return _logger


def audit_log(event: dict) -> None:
    logger = _get_logger()
    logger.info(f"AUDIT EVENT: {event}")
