#!/usr/bin/env python3
"""
Quick test to verify enable/disable functionality
"""
import requests
import time

API_URL = "http://127.0.0.1:8000/api"

def test_enable_disable():
    print("🧪 Testing Compliance Enable/Disable Functionality\n")
    
    # Test 1: Get initial status
    print("1️⃣ Checking initial status...")
    response = requests.get(f"{API_URL}/compliance/status")
    status = response.json()
    print(f"   Status: {'ENABLED' if status['enabled'] else 'DISABLED'}")
    print(f"   Active agents: {len(status.get('active_agents', []))}")
    print()
    
    # Test 2: Disable compliance
    print("2️⃣ Disabling compliance...")
    response = requests.post(f"{API_URL}/compliance/disable")
    result = response.json()
    print(f"   ✅ Success! Status: {'ENABLED' if result['enabled'] else 'DISABLED'}")
    print(f"   Active agents: {len(result.get('active_agents', []))}")
    print()
    
    time.sleep(0.5)
    
    # Test 3: Enable compliance
    print("3️⃣ Enabling compliance...")
    response = requests.post(f"{API_URL}/compliance/enable")
    result = response.json()
    print(f"   ✅ Success! Status: {'ENABLED' if result['enabled'] else 'DISABLED'}")
    print(f"   Active agents: {len(result.get('active_agents', []))}")
    print()
    
    # Test 4: Process request with PII
    print("4️⃣ Testing request processing with PII...")
    test_data = {
        "input_text": "Patient John Doe, SSN: 123-45-6789, Email: john@example.com",
        "request_type": "patient_triage",
        "user_role": "clinician"
    }
    
    response = requests.post(f"{API_URL}/process", json=test_data, timeout=30)
    result = response.json()
    
    if result.get("success"):
        print(f"   ✅ Request processed successfully!")
        print(f"   Compliance applied: {result.get('compliance_applied', False)}")
        print(f"   PII detected: {len(result.get('pii_detected', []))} entities")
        if result.get('pii_detected'):
            for pii in result['pii_detected'][:3]:
                print(f"      - {pii['type']}: {pii['value']}")
    else:
        print(f"   ⚠️ Processing result: {result}")
    print()
    
    print("✅ All tests completed!")
    print(f"\n🌐 Access the Streamlit UI at: http://localhost:8501")

if __name__ == "__main__":
    try:
        test_enable_disable()
    except requests.exceptions.ConnectionError:
        print("❌ Error: Cannot connect to backend at http://127.0.0.1:8000")
        print("   Make sure the backend is running: ./start_backend.sh")
    except Exception as e:
        print(f"❌ Error: {e}")
