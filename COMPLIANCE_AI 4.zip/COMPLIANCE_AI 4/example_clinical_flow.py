"""
Example Clinical Triage Flow

Demonstrates end-to-end compliance-orchestrated clinical decision making using LangGraph
"""

import sys
import os
from datetime import datetime

# Add parent directory to path
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from frontend import create_compliance_agent, create_db_client


def run_clinical_triage_example():
    """Run example clinical triage with compliance"""
    
    print("\n" + "="*70)
    print("🏥 HEALTHCARE COMPLIANCE AI - CLINICAL TRIAGE EXAMPLE")
    print("="*70 + "\n")
    
    # Initialize components
    db_client = create_db_client()
    agent = create_compliance_agent(db_client=db_client)
    
    # Example 1: Successful triage with PII
    print("\n📋 EXAMPLE 1: Patient Triage with PII Detection\n")
    
    result1 = agent.process_clinical_request(
        user_id="clinician_001",
        user_role="clinician",
        patient_id="P12345",
        input_text="""
        Patient: Jane Smith
        DOB: 1985-03-15
        SSN: 123-45-6789
        Email: jane.smith@email.com
        Phone: 555-123-4567
        
        Chief Complaint: Acute chest pain for 2 hours
        Severity: 8/10
        Associated Symptoms: Shortness of breath, diaphoresis, anxiety
        Vital Signs: BP 145/92, HR 102, RR 22, O2Sat 94%
        Cardiac Risk Factors: Smoking, hypertension, family history of CAD
        Recent Medical History: Viral illness 1 week ago
        Medications: Lisinopril, Aspirin
        Allergies: NKDA
        """,
        request_type="triage"
    )
    
    print("\n✅ RESULT 1:")
    print(f"  Status: {'PASSED ✅' if result1['compliance_passed'] else 'FAILED ❌'}")
    print(f"  PII Detected: {len(result1.get('pii_detected', []))} elements")
    print(f"  Access Granted: {result1['audit_record'].get('access_granted', False)}")
    print(f"  Audit ID: {result1['audit_id']}")
    print(f"  Violations: {len(result1.get('violations', []))}")
    
    if result1['compliance_passed']:
        print(f"\n  📝 Clinical Decision:")
        print(f"  {result1['sanitized_output'][:200]}...")
    
    # Example 2: Access denied scenario
    print("\n\n📋 EXAMPLE 2: Access Denied (Patient User Role)\n")
    
    result2 = agent.process_clinical_request(
        user_id="patient_001",
        user_role="patient",  # Patients shouldn't have triage access
        patient_id="P12346",
        input_text="Patient reports symptoms...",
        request_type="triage"
    )
    
    print("\n✅ RESULT 2:")
    print(f"  Status: {'PASSED ✅' if result2['compliance_passed'] else 'FAILED ❌'}")
    print(f"  Violations: {len(result2.get('violations', []))} violations")
    for v in result2.get('violations', []):
        print(f"    - {v.get('type')}: {v.get('reason', '')}")
    
    # Example 3: Specialist referral
    print("\n\n📋 EXAMPLE 3: Specialist Referral (Cardiology)\n")
    
    result3 = agent.process_clinical_request(
        user_id="specialist_cardio",
        user_role="specialist",
        patient_id="P12345",
        input_text="""
        Patient ECG shows ST elevation in leads II, III, aVF
        Troponin: 2.5 ng/mL (elevated)
        Clinical presentation consistent with acute MI
        Recommend immediate cardiology consultation and catheterization lab activation
        """,
        request_type="referral"
    )
    
    print("\n✅ RESULT 3:")
    print(f"  Status: {'PASSED ✅' if result3['compliance_passed'] else 'FAILED ❌'}")
    print(f"  Request Type: {result3['audit_record'].get('request_type', 'unknown')}")
    print(f"  Regulations Applied: {', '.join(result3['audit_record'].get('applicable_regulations', []))}")
    
    # Example 4: Query audit trail
    print("\n\n📋 EXAMPLE 4: Query Audit Trail\n")
    
    audits = db_client.get_audit_logs_by_user("clinician_001", limit=10)
    print(f"Found {len(audits)} audit records for clinician_001:")
    for i, audit in enumerate(audits[:3], 1):
        print(f"\n  Record {i}:")
        print(f"    Timestamp: {audit.get('timestamp', 'Unknown')}")
        print(f"    Request Type: {audit.get('request_type', 'Unknown')}")
        print(f"    Compliance: {'PASSED ✅' if audit.get('compliance_passed') else 'FAILED ❌'}")
        print(f"    Patient: {audit.get('patient_id', 'Unknown')}")
    
    # Example 5: Compliance statistics
    print("\n\n📋 EXAMPLE 5: System Compliance Statistics\n")
    
    try:
        violations = db_client.get_compliance_violations(limit=1000)
        total = len(violations)
        passed = len([v for v in violations if v.get('event_type') == 'success'])
        failed = len([v for v in violations if v.get('event_type') == 'violation'])
        pass_rate = (passed / (passed + failed) * 100) if (passed + failed) > 0 else 0
        
        print(f"  Total Operations: {total}")
        print(f"  Passed Compliance: {passed}")
        print(f"  Failed Compliance: {failed}")
        print(f"  Pass Rate: {pass_rate:.1f}%")
    except Exception as e:
        print(f"  (Database not yet populated: {e})")
    
    print("\n" + "="*70)
    print("✅ EXAMPLE COMPLETED")
    print("="*70 + "\n")


if __name__ == "__main__":
    run_clinical_triage_example()
