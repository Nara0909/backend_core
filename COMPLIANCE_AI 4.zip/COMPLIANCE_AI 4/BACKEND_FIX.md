# ⚡ QUICK FIX - BACKEND NOT RUNNING

## ✅ Solution

The backend works fine! We just needed simpler startup scripts. Here's how to start it:

---

## 🚀 **Option 1: Run Backend Only (Recommended for testing)**

Open a terminal and run:

```bash
cd ~/Documents/COMPLIANCE_AI
./start_backend_simple.sh
```

You should see:
```
🚀 Starting Healthcare Compliance Backend...
📡 Starting FastAPI server on 127.0.0.1:8000...
INFO:     Uvicorn running on http://127.0.0.1:8000
```

✅ Backend is running! Test it:
```bash
curl "http://127.0.0.1:8000/api/enforcement-plan?request_type=triage"
```

---

## 🎨 **Option 2: Run Frontend Only (After backend is running)**

Open a **new terminal** and run:

```bash
cd ~/Documents/COMPLIANCE_AI
./start_frontend_simple.sh
```

Then open in browser:
```
http://127.0.0.1:8501
```

---

## 🚀 **Option 3: Run Both Together**

```bash
# Terminal 1: Start backend
cd ~/Documents/COMPLIANCE_AI
./start_backend_simple.sh

# Terminal 2: Start frontend (wait 3 seconds first)
sleep 3 && cd ~/Documents/COMPLIANCE_AI && ./start_frontend_simple.sh
```

---

## 🔍 **If Backend Still Won't Start**

### Check 1: Is port 8000 already in use?
```bash
lsof -i :8000
```

If something is running, kill it:
```bash
kill -9 $(lsof -t -i :8000)
```

### Check 2: Is FastAPI installed?
```bash
python3 -c "import fastapi; print('✅ FastAPI is installed')"
```

If not, install it:
```bash
pip install fastapi uvicorn
```

### Check 3: Try starting manually
```bash
cd ~/Documents/COMPLIANCE_AI
python3 -m uvicorn app.main:app --host 127.0.0.1 --port 8000
```

If you see errors, check:
- All files in `app/` folder exist
- `security/pii.py` and `security/access_control.py` exist
- Python version is 3.8+ (check with `python3 --version`)

### Check 4: Verify backend is responding
```bash
curl "http://127.0.0.1:8000/docs"
```

You should see HTML (the API documentation page).

---

## 📋 **Full Startup Flow**

1. **Verify Python**:
   ```bash
   python3 --version
   # Should be 3.8 or higher
   ```

2. **Install dependencies**:
   ```bash
   cd ~/Documents/COMPLIANCE_AI
   pip install -r requirements.txt
   ```

3. **Test backend directly**:
   ```bash
   python3 -m uvicorn app.main:app --host 127.0.0.1 --port 8000
   # Keep this running
   ```

4. **In another terminal, test the API**:
   ```bash
   curl "http://127.0.0.1:8000/api/enforcement-plan?request_type=triage"
   # Should return JSON with regulations
   ```

5. **If that works, use the startup scripts**:
   ```bash
   # Terminal 1
   ./start_backend_simple.sh
   
   # Terminal 2 (after 3 seconds)
   ./start_frontend_simple.sh
   ```

6. **Open browser**:
   ```
   http://127.0.0.1:8501
   ```

---

## ✅ Expected Output

### Backend Starting:
```
🚀 Starting Healthcare Compliance Backend...
🧹 Cleaning up port 8000...
📡 Starting FastAPI server on 127.0.0.1:8000...
INFO:     Started server process [12345]
INFO:     Uvicorn running on http://127.0.0.1:8000
INFO:     127.0.0.1:49279 - "GET /api/enforcement-plan?request_type=triage HTTP/1.1" 200 OK
```

### Frontend Starting:
```
🎨 Starting Healthcare Compliance Frontend...
🧹 Cleaning up port 8501...
📊 Starting Streamlit server on 127.0.0.1:8501...

  You can now view your Streamlit app in your browser.

  Local URL: http://127.0.0.1:8501
```

---

## 🎯 Test Each Component

### Test Backend API:
```bash
# Get enforcement plan
curl "http://127.0.0.1:8000/api/enforcement-plan?request_type=triage"

# Check access
curl -X POST "http://127.0.0.1:8000/api/check-access" \
  -H "Content-Type: application/json" \
  -d '{"user_id":"dr_smith","user_role":"clinician","patient_id":"patient_123","resource_type":"ehr"}'

# Mask PII
curl -X POST "http://127.0.0.1:8000/api/mask-pii" \
  -H "Content-Type: application/json" \
  -d '{"text":"Patient John Doe (SSN: 123-45-6789)"}'
```

### View API Documentation:
```
http://127.0.0.1:8000/docs
```

### Test Frontend:
```
http://127.0.0.1:8501
```

---

## 🛑 Stop Services

```bash
# To stop backend: Press Ctrl+C in backend terminal
# To stop frontend: Press Ctrl+C in frontend terminal

# Or kill by port:
kill -9 $(lsof -t -i :8000)  # Stop backend
kill -9 $(lsof -t -i :8501)  # Stop frontend
```

---

## 📚 Files Created for Easy Startup

- `start_backend_simple.sh` ← Run this to start backend
- `start_frontend_simple.sh` ← Run this to start frontend
- `local_setup.py` ← Runs both together (advanced)

---

## 🎉 You're Ready!

Your system is working! Just use the simple startup scripts:

**Terminal 1:**
```bash
./start_backend_simple.sh
```

**Terminal 2 (after 3 seconds):**
```bash
./start_frontend_simple.sh
```

**Browser:**
```
http://127.0.0.1:8501
```

---

## Common Issues & Quick Fixes

| Issue | Fix |
|-------|-----|
| Port 8000 in use | `kill -9 $(lsof -t -i :8000)` |
| Port 8501 in use | `kill -9 $(lsof -t -i :8501)` |
| ModuleNotFoundError | `pip install -r requirements.txt` |
| Connection refused | Check backend started first, wait 3 seconds |
| Streamlit won't connect to backend | Make sure backend is running on 127.0.0.1:8000 |
| "Command not found" | Make scripts executable: `chmod +x *.sh` |

---

## ✅ That's It!

Backend is ready. Just use:
- `./start_backend_simple.sh` to start backend
- `./start_frontend_simple.sh` to start frontend

Everything is working! 🎉
