#!/bin/bash

# Backend Startup Script for Compliance AI System

echo "🚀 Starting Compliance AI Backend Server..."
echo ""

# Check if virtual environment exists
if [ ! -d ".venv" ]; then
    echo "❌ Virtual environment not found!"
    echo "Please run: python -m venv .venv"
    exit 1
fi

# Activate virtual environment
echo "📦 Activating virtual environment..."
source .venv/bin/activate

# Check if dependencies are installed
if ! python -c "import fastapi" 2>/dev/null; then
    echo "📥 Installing dependencies..."
    pip install -r requirements.txt
fi

# Set environment variables if .env exists
if [ -f ".env" ]; then
    echo "🔑 Loading environment variables from .env..."
    # Use grep to filter out comments and empty lines
    export $(grep -v '^#' .env | grep -v '^$' | xargs)
fi

# Create necessary directories
mkdir -p app

echo ""
echo "✅ Environment ready!"
echo ""
echo "🌐 Starting FastAPI server on http://localhost:8000"
echo "📚 API Documentation: http://localhost:8000/api/docs"
echo "🔒 Interactive API: http://localhost:8000/api/redoc"
echo ""
echo "Press CTRL+C to stop the server"
echo ""

# Start the server
cd "$(dirname "$0")"
python -m uvicorn app.main:app --reload --host 0.0.0.0 --port 8000
