
from nlp.pii_detector import detect_pii



class IngressPrivacyAgent:

    def run(self, state):

        pii_entities = detect_pii(state.raw_input)

        state.context["pii_entities"] = pii_entities

        return state

