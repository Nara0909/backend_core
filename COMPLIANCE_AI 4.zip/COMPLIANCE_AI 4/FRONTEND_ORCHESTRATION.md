# 🎯 Frontend-Driven Compliance Orchestration

## Architecture

**Frontend orchestrates compliance based on enforcement plan from backend.**

> **Flexibility**: Frontend can use any suitable implementation approach:
> - **Manual Orchestration** (React/Streamlit with direct API calls)
> - **Agentic Framework** (LangGraph, AutoGen, Crew.ai, etc.)
> - **Hybrid** (Agent framework for healthcare logic + direct API calls for compliance)
> 
> The backend endpoints remain the same regardless of frontend implementation approach.

```
┌────────────────────────────────────────────────────────────────┐
│                   FRONTEND (React/Vue)                         │
│              Healthcare AI + Compliance Orchestrator             │
│                                                                 │
│  1. Get Enforcement Plan                                       │
│     GET /api/enforcement-plan?request_type=triage              │
│     ↓ Response: Which agents/tools to call                    │
│                                                                 │
│  2. Execute Compliance Chain (based on plan)                   │
│     ├─ POST /api/check-access (AccessControl)                │
│     ├─ POST /api/mask-pii (Privacy)                          │
│     ├─ Call LLM with masked input                            │
│     ├─ POST /api/sanitize-output (OutputGuard)               │
│     └─ POST /api/log-compliance-action (Audit)               │
│                                                                 │
│  3. Store in Frontend DB                                       │
│     ├─ Audit logs (input, output, decisions)                 │
│     ├─ Clinical decisions                                    │
│     ├─ Patient EHR                                           │
│     └─ Full enforcement plan trace                           │
│                                                                 │
│  ┌──────────────────────────────────────────────────┐         │
│  │     FRONTEND DATABASE (PostgreSQL/MongoDB)       │         │
│  ├──────────────────────────────────────────────────┤         │
│  │ • audit_log (all actions with full trace)       │         │
│  │ • clinical_decision (triage, scheduling)        │         │
│  │ • patient_ehr (medical history)                 │         │
│  │ • enforcement_plan_execution (regulations)      │         │
│  └──────────────────────────────────────────────────┘         │
└────────────────────────────────────────────────────────────────┘
                              ↕
            [REST API - Compliance Middleware]
                              ↕
┌────────────────────────────────────────────────────────────────┐
│                BACKEND (FastAPI - No LangGraph)                │
│                 Stateless Compliance Tools                      │
│                                                                 │
│  /api/enforcement-plan          → Get applicable plan         │
│  /api/check-access              → Verify user role            │
│  /api/mask-pii                  → Detect & mask PII           │
│  /api/sanitize-output           → Remove PII from output      │
│  /api/log-compliance-action     → Create audit reference      │
└────────────────────────────────────────────────────────────────┘
```

---

## Frontend Flow: Clinical Triage Example

### Step 1: Get Enforcement Plan

```javascript
// Frontend fetches the enforcement plan for this request type
const plan = await fetch('/api/enforcement-plan?request_type=triage')
  .then(r => r.json());

// Now frontend knows:
// - Which regulations apply: ["GDPR", "HIPAA", "PCI-DSS"]
// - Which agents needed: [AccessControl, Privacy, OutputGuard, Audit]
// - What each does and which endpoint to call
// - Policy trace (GDPR articles, HIPAA sections, etc.)

console.log(plan);
/*
{
  request_type: "triage",
  regulations: ["GDPR", "HIPAA", "PCI-DSS"],
  enforcement_steps: [
    {
      agent: "AccessControlAgent",
      endpoint: "/api/check-access",
      actions: ["check_role_permissions"],
      policy_trace: ["GDPR Article 32", "HIPAA 164.312"],
      description: "Verify user has access..."
    },
    {
      agent: "PrivacyAgent",
      endpoint: "/api/mask-pii",
      actions: ["mask_phi", "detect_pii"],
      policy_trace: ["HIPAA 164.502", "GDPR Article 32"],
      description: "Detect and mask PII..."
    },
    // ... more steps
  ]
}
*/
```

### Step 2: Execute Compliance Chain

```javascript
// Frontend orchestrates the compliance chain

const userInput = "Patient John Doe (SSN: 123-45-6789) with fever";
const auditTrail = [];

// Step 1: Check Access (based on plan)
const accessResult = await fetch('/api/check-access', {
  method: 'POST',
  body: JSON.stringify({
    user_role: "clinician",
    request_type: "triage"
  })
}).then(r => r.json());

if (!accessResult.access_granted) {
  console.error("Access denied");
  return;
}

auditTrail.push({
  agent: "AccessControlAgent",
  action: "check_role_permissions",
  status: "PASSED",
  timestamp: new Date()
});

// Step 2: Mask PII (based on plan)
const privacyResult = await fetch('/api/mask-pii', {
  method: 'POST',
  body: JSON.stringify({
    input_text: userInput
  })
}).then(r => r.json());

const maskedInput = privacyResult.masked_text;
const piiDetected = privacyResult.pii_detected;

auditTrail.push({
  agent: "PrivacyAgent",
  action: "mask_pii",
  pii_detected: piiDetected,
  status: "COMPLETED",
  timestamp: new Date()
});

// Step 3: Process with LLM (Frontend logic)
const llmOutput = await openai.createChatCompletion({
  messages: [
    {role: "system", content: "You are clinical triage system"},
    {role: "user", content: maskedInput}  // Using MASKED input only
  ]
});

const triageDecision = llmOutput.choices[0].message.content;

auditTrail.push({
  agent: "LLM",
  action: "triage_decision",
  input: maskedInput,
  output: triageDecision,
  status: "COMPLETED",
  timestamp: new Date()
});

// Step 4: Sanitize Output (based on plan)
const sanitizeResult = await fetch('/api/sanitize-output', {
  method: 'POST',
  body: JSON.stringify({
    output_text: triageDecision
  })
}).then(r => r.json());

if (!sanitizeResult.safe_to_store) {
  console.error("Output contains PII, cannot store");
  return;
}

auditTrail.push({
  agent: "OutputGuardAgent",
  action: "sanitize_output",
  pii_detected: sanitizeResult.pii_detected_in_output,
  status: "PASSED",
  timestamp: new Date()
});

// Step 5: Log Compliance Action (based on plan)
const logResult = await fetch('/api/log-compliance-action', {
  method: 'POST',
  body: JSON.stringify({
    actions: auditTrail,
    regulations: plan.regulations
  })
}).then(r => r.json());

auditTrail.push({
  agent: "AuditAgent",
  action: "log_compliance_action",
  audit_id: logResult.audit_id,
  status: "COMPLETED",
  timestamp: new Date()
});
```

### Step 3: Store in Frontend Database

```javascript
// Frontend stores EVERYTHING in its database

// Insert audit log (complete trace)
await db.insert('audit_log', {
  action_id: logResult.audit_id,
  plan_id: plan.request_type,
  regulations: plan.regulations,
  enforcement_steps: plan.enforcement_steps,
  audit_trail: auditTrail,
  original_input: userInput,
  masked_input: maskedInput,
  pii_detected: piiDetected,
  llm_input: maskedInput,
  llm_output: triageDecision,
  sanitized_output: sanitizeResult.sanitized_output,
  compliance_status: "PASS",
  timestamp: new Date(),
  user_role: "clinician"
});

// Insert clinical decision
await db.insert('clinical_decision', {
  decision_id: logResult.audit_id,
  patient_id: patientId,
  request_type: "triage",
  triage_level: extractTriageLevel(triageDecision),
  reasoning: triageDecision,
  created_by: clinicianId,
  timestamp: new Date()
});

// Insert/Update patient EHR
await db.insert('patient_ehr', {
  patient_id: patientId,
  latest_triage: triageDecision,
  last_updated: new Date(),
  last_updated_by: clinicianId,
  decision_id: logResult.audit_id
});
```

---

## Backend Endpoints

### 1. Get Enforcement Plan

```bash
GET /api/enforcement-plan?request_type=triage
```

**Response:**
```json
{
  "request_type": "triage",
  "regulations": ["GDPR", "HIPAA", "PCI-DSS"],
  "enforcement_steps": [
    {
      "agent": "AccessControlAgent",
      "endpoint": "/api/check-access",
      "actions": ["check_role_permissions"],
      "policy_trace": ["GDPR Article 32", "HIPAA 164.312"],
      "description": "Verify user has access to patient data"
    },
    {
      "agent": "PrivacyAgent",
      "endpoint": "/api/mask-pii",
      "actions": ["mask_phi", "detect_pii"],
      "policy_trace": ["HIPAA 164.502", "GDPR Article 32"],
      "description": "Detect and mask PII before LLM"
    },
    {
      "agent": "OutputGuardAgent",
      "endpoint": "/api/sanitize-output",
      "actions": ["redact_pii"],
      "policy_trace": ["GDPR Article 25", "HIPAA 164.514"],
      "description": "Remove PII from output"
    },
    {
      "agent": "AuditAgent",
      "endpoint": "/api/log-compliance-action",
      "actions": ["log_decision"],
      "policy_trace": ["GDPR Article 30", "HIPAA 164.308"],
      "description": "Log compliance action"
    }
  ]
}
```

### 2. Check Access

```bash
POST /api/check-access
{
  "user_role": "clinician",
  "request_type": "triage"
}
```

**Response:**
```json
{
  "success": true,
  "access_granted": true,
  "user_role": "clinician",
  "message": "Access control check completed"
}
```

### 3. Mask PII

```bash
POST /api/mask-pii
{
  "input_text": "Patient John Doe (SSN: 123-45-6789) with fever"
}
```

**Response:**
```json
{
  "success": true,
  "original_text": "Patient John Doe (SSN: 123-45-6789) with fever",
  "masked_text": "Patient [NAME] (SSN: [SSN]) with fever",
  "pii_detected": [
    {"type": "NAME", "value": "John Doe"},
    {"type": "SSN", "value": "123-45-6789"}
  ],
  "pii_count": 2
}
```

### 4. Sanitize Output

```bash
POST /api/sanitize-output
{
  "output_text": "Patient [NAME] with infection. Recommend urgent care."
}
```

**Response:**
```json
{
  "success": true,
  "original_output": "Patient [NAME] with infection. Recommend urgent care.",
  "sanitized_output": "Patient [NAME] with infection. Recommend urgent care.",
  "pii_detected_in_output": [],
  "safe_to_store": true
}
```

### 5. Log Compliance Action

```bash
POST /api/log-compliance-action
{
  "actions": [...],
  "regulations": ["GDPR", "HIPAA"]
}
```

**Response:**
```json
{
  "success": true,
  "audit_id": "AUDIT-20251217-103456-1234",
  "timestamp": "2025-12-17T10:34:56Z"
}
```

---

## Benefits

### ✅ Frontend Control
- Frontend knows exactly what compliance checks are needed
- Can visualize enforcement plan to user
- Can retry/repeat checks as needed

### ✅ Complete Visibility
- Frontend sees all compliance decisions
- Can audit why something was approved/rejected
- Full transparency to user

### ✅ Flexible Orchestration
- Frontend can call tools in different order if needed
- Can add custom checks between compliance steps
- Can handle edge cases

### ✅ Database Completeness
- Frontend stores EVERYTHING in its DB
- Full audit trail available for queries
- Can correlate decisions with regulations

### ✅ No Backend Coupling
- Backend is truly stateless
- No LangGraph complexity
- Easy to scale, cache, or replace tools

---

## Frontend Implementation Checklist

- [ ] Fetch enforcement plan before processing
- [ ] Call /api/check-access with user role
- [ ] Call /api/mask-pii with user input
- [ ] Validate access_granted and pii_detected
- [ ] Call LLM with masked input ONLY
- [ ] Call /api/sanitize-output with LLM result
- [ ] Validate safe_to_store before proceeding
- [ ] Call /api/log-compliance-action
- [ ] Store complete audit trail in frontend DB
- [ ] Store clinical decision in frontend DB
- [ ] Store/update patient EHR

---

## Using Agentic Frameworks in Frontend

If using an agentic framework (LangGraph, AutoGen, Crew.ai, etc.), the pattern is the same:

### Option 1: LangGraph Frontend Agent

```python
# Frontend agent with compliance middleware calls
from langgraph.graph import StateGraph, END
from typing import TypedDict

class FrontendState(TypedDict):
    enforcement_plan: dict
    user_role: str
    input_text: str
    pii_detected: list
    access_granted: bool
    masked_text: str
    llm_output: str
    safe_output: str
    audit_trace: dict
    clinical_decision: dict

def get_enforcement_plan_node(state):
    """Get applicable compliance plan from backend"""
    plan = requests.get("/api/enforcement-plan", 
                       params={"request_type": "triage"}).json()
    state["enforcement_plan"] = plan
    return state

def check_access_node(state):
    """Call backend access control"""
    response = requests.post("/api/check-access", json={
        "user_role": state["user_role"],
        "resource": "patient_data"
    }).json()
    state["access_granted"] = response["access_granted"]
    return state

def mask_pii_node(state):
    """Call backend PII masking"""
    response = requests.post("/api/mask-pii", json={
        "text": state["input_text"]
    }).json()
    state["masked_text"] = response["masked_text"]
    state["pii_detected"] = response["pii_detected"]
    return state

def llm_node(state):
    """Healthcare LLM processing (ONLY with masked input)"""
    response = openai.ChatCompletion.create(
        model="gpt-4",
        messages=[{"role": "user", "content": state["masked_text"]}]
    )
    state["llm_output"] = response.choices[0].message.content
    return state

def sanitize_output_node(state):
    """Call backend output sanitization"""
    response = requests.post("/api/sanitize-output", json={
        "text": state["llm_output"]
    }).json()
    state["safe_output"] = response["sanitized_text"]
    return state

def store_decision_node(state):
    """Store in frontend database"""
    # Frontend DB stores audit trace + decision + regulations
    audit_record = {
        "input": state["input_text"],
        "masked_input": state["masked_text"],
        "llm_output": state["llm_output"],
        "sanitized_output": state["safe_output"],
        "pii_detected": state["pii_detected"],
        "access_granted": state["access_granted"],
        "enforcement_plan": state["enforcement_plan"],
        "timestamp": datetime.now()
    }
    db.audit_log.insert_one(audit_record)
    return state

# Build graph
graph = StateGraph(FrontendState)
graph.add_node("get_plan", get_enforcement_plan_node)
graph.add_node("check_access", check_access_node)
graph.add_node("mask_pii", mask_pii_node)
graph.add_node("llm", llm_node)
graph.add_node("sanitize", sanitize_output_node)
graph.add_node("store", store_decision_node)

graph.add_edge("get_plan", "check_access")
graph.add_edge("check_access", "mask_pii")
graph.add_edge("mask_pii", "llm")
graph.add_edge("llm", "sanitize")
graph.add_edge("sanitize", "store")
graph.add_edge("store", END)

graph.set_entry_point("get_plan")
agent = graph.compile()

# Execute
result = agent.invoke({
    "user_role": "clinician",
    "input_text": "Patient John Doe with fever"
})
```

### Option 2: AutoGen Frontend Multi-Agent System

```python
from autogen import AssistantAgent, UserProxyAgent

# Backend compliance tool wrapper
def call_backend_compliance(endpoint: str, data: dict) -> dict:
    """Wrapper around backend compliance middleware"""
    return requests.post(f"/api/{endpoint}", json=data).json()

# Define compliance tools
compliance_tools = [
    {
        "name": "check_access",
        "description": "Check user access to resources",
        "func": lambda role, resource: call_backend_compliance("check-access", 
                                       {"user_role": role, "resource": resource})
    },
    {
        "name": "mask_pii",
        "description": "Mask PII from text",
        "func": lambda text: call_backend_compliance("mask-pii", {"text": text})
    },
    {
        "name": "sanitize_output",
        "description": "Sanitize LLM output",
        "func": lambda text: call_backend_compliance("sanitize-output", {"text": text})
    }
]

# Frontend orchestrator agent
orchestrator = AssistantAgent(
    name="ComplianceOrchestrator",
    system_message="You are a compliance orchestrator that ensures all healthcare AI operations are compliant. Always check access, mask PII, call LLM with masked data, and sanitize output.",
    tools=compliance_tools
)

# Clinical LLM agent
clinician_agent = AssistantAgent(
    name="ClinicalAI",
    system_message="You are a clinical decision support AI. You receive ONLY masked patient data. Never process raw PII.",
)

# User proxy (frontend application)
user_proxy = UserProxyAgent(
    name="Frontend",
    human_input_mode="NEVER"
)

# Initiate conversation
user_proxy.initiate_chat(
    orchestrator,
    message="Process triage for patient with symptoms matching HIPAA requirements"
)
```

### Option 3: Backend Remains Compliance Middleware

**Key Insight**: Regardless of frontend framework choice, the backend endpoints stay the same:

```
Frontend Implementation      →  Backend Compliance Middleware
─────────────────────────        ─────────────────────────────
LangGraph Agent            →  /api/enforcement-plan
AutoGen Multi-Agent        →  /api/check-access
Crew.ai Framework          →  /api/mask-pii
Custom Orchestration       →  /api/sanitize-output
                               /api/log-compliance-action
```

### Recommended Approaches

| Framework | Use Case | Pros | Cons |
|-----------|----------|------|------|
| **LangGraph** | Complex healthcare workflows | Native state management, good for chains | Learning curve |
| **AutoGen** | Multi-specialty decision making | Multi-agent collaboration, flexible | More setup |
| **Crew.ai** | Structured role-based agents | Simple role definitions | Limited to role pattern |
| **Manual Orchestration** | Simple triage/scheduling | Fast to implement, transparent | More code |
| **Hybrid** | Most healthcare systems | Best of both, flexible | Complexity management |

### Implementation Pattern (Any Framework)

Regardless of frontend approach:

1. **Get Enforcement Plan** from backend
2. **Check Access** via backend
3. **Mask PII** via backend
4. **Call LLM** (internal to frontend, masked data only)
5. **Sanitize Output** via backend
6. **Store Audit Trail** in frontend DB with regulations

The backend compliance calls are non-negotiable. The orchestration logic can be implemented however best suits your healthcare AI system.
- [ ] Create compliance dashboard showing audit trail
- [ ] Create report showing regulations applied

---

**Status**: ✅ Ready for frontend implementation
