"""
Local MCP Client - No Hosting Required
For testing MCP tools without Claude integration
"""

import asyncio
import json
from typing import Any
import sys
from pathlib import Path

# Add workspace to path
sys.path.insert(0, str(Path(__file__).parent))

class LocalMCPClient:
    """Standalone MCP client for local testing"""
    
    def __init__(self, backend_url: str = "http://127.0.0.1:8000"):
        self.backend_url = backend_url
        self.tools = [
            "get_enforcement_plan",
            "check_access",
            "mask_pii",
            "sanitize_output",
            "log_compliance_action"
        ]
    
    async def call_tool(self, tool_name: str, **kwargs) -> dict:
        """Call a compliance tool directly"""
        import requests
        
        try:
            if tool_name == "get_enforcement_plan":
                response = requests.get(
                    f"{self.backend_url}/api/enforcement-plan",
                    params=kwargs
                )
            
            elif tool_name == "check_access":
                response = requests.post(
                    f"{self.backend_url}/api/check-access",
                    json=kwargs
                )
            
            elif tool_name == "mask_pii":
                response = requests.post(
                    f"{self.backend_url}/api/mask-pii",
                    json=kwargs
                )
            
            elif tool_name == "sanitize_output":
                response = requests.post(
                    f"{self.backend_url}/api/sanitize-output",
                    json=kwargs
                )
            
            elif tool_name == "log_compliance_action":
                response = requests.post(
                    f"{self.backend_url}/api/log-compliance-action",
                    json=kwargs
                )
            
            else:
                return {"error": f"Unknown tool: {tool_name}"}
            
            return response.json()
        
        except Exception as e:
            return {"error": str(e)}
    
    async def test_tools(self):
        """Test all MCP tools"""
        print("\n" + "="*60)
        print("LOCAL MCP TOOL TESTING")
        print("="*60)
        
        # Test 1: Get enforcement plan
        print("\n1️⃣  Testing get_enforcement_plan...")
        result = await self.call_tool(
            "get_enforcement_plan",
            request_type="triage"
        )
        print(f"   Result: {json.dumps(result, indent=2)}")
        
        # Test 2: Check access
        print("\n2️⃣  Testing check_access...")
        result = await self.call_tool(
            "check_access",
            user_id="dr_smith",
            user_role="clinician",
            patient_id="patient_123",
            resource_type="ehr"
        )
        print(f"   Result: {json.dumps(result, indent=2)}")
        
        # Test 3: Mask PII
        print("\n3️⃣  Testing mask_pii...")
        result = await self.call_tool(
            "mask_pii",
            text="Patient John Doe (SSN: 123-45-6789) has pneumonia"
        )
        print(f"   Result: {json.dumps(result, indent=2)}")
        
        # Test 4: Sanitize output
        print("\n4️⃣  Testing sanitize_output...")
        result = await self.call_tool(
            "sanitize_output",
            text="Patient has respiratory symptoms and needs follow-up"
        )
        print(f"   Result: {json.dumps(result, indent=2)}")
        
        # Test 5: Log compliance action
        print("\n5️⃣  Testing log_compliance_action...")
        result = await self.call_tool(
            "log_compliance_action",
            user_id="dr_smith",
            action="triage",
            resource="patient_123",
            outcome="success",
            audit_id="test_audit_123"
        )
        print(f"   Result: {json.dumps(result, indent=2)}")
        
        print("\n" + "="*60)
        print("✅ Tool testing complete!")
        print("="*60 + "\n")


async def main():
    """Test local MCP client"""
    client = LocalMCPClient()
    await client.test_tools()


if __name__ == "__main__":
    asyncio.run(main())
