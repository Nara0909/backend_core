#!/usr/bin/env python3
"""
Local MCP Setup - No Hosting Required
Starts backend, frontend, and MCP server all locally
"""

import subprocess
import sys
import time
import os
from pathlib import Path

class LocalSetup:
    def __init__(self):
        self.workspace = Path(__file__).parent
        self.backend_process = None
        self.frontend_process = None
        self.mcp_process = None
        
    def run_command(self, cmd, name, cwd=None):
        """Run a command and return process"""
        try:
            print(f"\n📦 Starting {name}...")
            process = subprocess.Popen(
                cmd,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                text=True,
                cwd=cwd or self.workspace,
                preexec_fn=os.setsid  # Allow killing process group
            )
            print(f"✅ {name} started (PID: {process.pid})")
            return process
        except Exception as e:
            print(f"❌ Failed to start {name}: {e}")
            return None
    
    def start_local_system(self):
        """Start all components locally"""
        
        print("\n" + "="*60)
        print("LOCAL MCP HEALTHCARE COMPLIANCE SYSTEM")
        print("="*60)
        print("\nStarting all services locally (no hosting)...")
        
        # Start backend
        backend_cmd = [
            sys.executable, "-m", "uvicorn",
            "app.main:app",
            "--host", "127.0.0.1",
            "--port", "8000",
            "--reload"
        ]
        self.backend_process = self.run_command(
            backend_cmd,
            "Backend API (port 8000)"
        )
        
        if not self.backend_process:
            print("❌ Failed to start backend")
            return False
        
        time.sleep(3)  # Wait for backend to start
        
        # Start frontend (Streamlit)
        frontend_cmd = [
            sys.executable, "-m", "streamlit", "run",
            "ui/app.py",
            "--server.port=8501",
            "--server.address=127.0.0.1"
        ]
        self.frontend_process = self.run_command(
            frontend_cmd,
            "Frontend UI (port 8501)"
        )
        
        if not self.frontend_process:
            print("❌ Failed to start frontend")
            self.cleanup()
            return False
        
        time.sleep(2)
        
        # Start MCP server
        mcp_cmd = [sys.executable, "mcp_server.py"]
        self.mcp_process = self.run_command(
            mcp_cmd,
            "MCP Server (local)"
        )
        
        if not self.mcp_process:
            print("⚠️  MCP server optional, continuing without it")
        
        time.sleep(1)
        
        # Print status
        self.print_status()
        
        return True
    
    def print_status(self):
        """Print system status"""
        print("\n" + "="*60)
        print("SYSTEM STATUS")
        print("="*60)
        
        backends_running = self.backend_process and self.backend_process.poll() is None
        frontend_running = self.frontend_process and self.frontend_process.poll() is None
        mcp_running = self.mcp_process and self.mcp_process.poll() is None
        
        print(f"Backend API:   {'✅ Running' if backends_running else '❌ Not running'} (127.0.0.1:8000)")
        print(f"Frontend UI:   {'✅ Running' if frontend_running else '❌ Not running'} (127.0.0.1:8501)")
        print(f"MCP Server:    {'✅ Running' if mcp_running else '❌ Not running'} (local)")
        
        print("\n" + "-"*60)
        print("ACCESS POINTS:")
        print("-"*60)
        print("🌐 Streamlit UI:     http://127.0.0.1:8501")
        print("📡 Backend API:      http://127.0.0.1:8000")
        print("📡 API Docs:         http://127.0.0.1:8000/docs")
        
        print("\n" + "-"*60)
        print("NEXT STEPS:")
        print("-"*60)
        print("1. Open http://127.0.0.1:8501 in your browser")
        print("2. Use the Clinical Triage tab to process requests")
        print("3. View Audit Trail tab to see logged actions")
        print("4. Use Compliance Dashboard for statistics")
        
        print("\n" + "-"*60)
        print("MCP SETUP (Optional - for Claude):")
        print("-"*60)
        print("Run in another terminal:")
        print("  python mcp_client.py")
        print("\nOr configure Claude Desktop:")
        print("  1. Settings → Developer → MCP")
        print("  2. Add MCP Server")
        print("  3. Command: python")
        print("  4. Args: /path/to/mcp_server.py")
        
        print("\n" + "="*60)
        print("Press Ctrl+C to stop all services")
        print("="*60 + "\n")
    
    def cleanup(self):
        """Stop all processes"""
        print("\n\n🛑 Stopping all services...")
        
        try:
            if self.backend_process and self.backend_process.poll() is None:
                self.backend_process.terminate()
                time.sleep(1)
                if self.backend_process.poll() is None:
                    self.backend_process.kill()
                print("✅ Backend stopped")
        except:
            pass
        
        try:
            if self.frontend_process and self.frontend_process.poll() is None:
                self.frontend_process.terminate()
                time.sleep(1)
                if self.frontend_process.poll() is None:
                    self.frontend_process.kill()
                print("✅ Frontend stopped")
        except:
            pass
        
        try:
            if self.mcp_process and self.mcp_process.poll() is None:
                self.mcp_process.terminate()
                time.sleep(1)
                if self.mcp_process.poll() is None:
                    self.mcp_process.kill()
                print("✅ MCP stopped")
        except:
            pass
        
        print("\n✅ All services stopped\n")
    
    def run(self):
        """Main entry point"""
        try:
            os.chdir(self.workspace)
            
            if not self.start_local_system():
                self.cleanup()
                sys.exit(1)
            
            # Keep running until interrupted
            while True:
                time.sleep(1)
                
                # Check if any process died
                if self.backend_process and self.backend_process.poll() is not None:
                    print("⚠️  Backend process died")
                    break
                
                if self.frontend_process and self.frontend_process.poll() is not None:
                    print("⚠️  Frontend process died")
                    break
        
        except KeyboardInterrupt:
            pass
        finally:
            self.cleanup()

if __name__ == "__main__":
    setup = LocalSetup()
    setup.run()
