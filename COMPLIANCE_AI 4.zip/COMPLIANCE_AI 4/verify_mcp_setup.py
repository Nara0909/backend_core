#!/usr/bin/env python3
"""
MCP Setup Verification Script
Checks all components are installed and configured correctly
"""

import os
import sys
import subprocess
import json
from pathlib import Path

class MCASetupVerifier:
    def __init__(self):
        self.workspace = Path(__file__).parent
        self.checks = []
        self.passed = 0
        self.failed = 0
        
    def check(self, name, condition, details=""):
        """Record a check result"""
        status = "✅ PASS" if condition else "❌ FAIL"
        self.checks.append({
            "name": name,
            "status": status,
            "passed": condition,
            "details": details
        })
        if condition:
            self.passed += 1
        else:
            self.failed += 1
        print(f"{status}: {name}")
        if details:
            print(f"     {details}")
    
    def verify_python(self):
        """Check Python version"""
        version = sys.version_info
        self.check(
            "Python Version",
            version.major >= 3 and version.minor >= 8,
            f"Python {version.major}.{version.minor}.{version.micro}"
        )
    
    def verify_dependencies(self):
        """Check required packages"""
        required = [
            "fastapi",
            "uvicorn",
            "pydantic",
            "langgraph",
            "langchain",
            "sqlalchemy",
            "mcp"
        ]
        
        try:
            result = subprocess.run(
                [sys.executable, "-m", "pip", "list", "--format=json"],
                capture_output=True,
                text=True,
                timeout=10
            )
            installed = {pkg["name"].lower(): pkg["version"] for pkg in json.loads(result.stdout)}
            
            for pkg in required:
                is_installed = pkg.lower() in installed
                version = installed.get(pkg.lower(), "not installed")
                self.check(
                    f"Package: {pkg}",
                    is_installed,
                    f"Version {version}" if is_installed else "Not installed"
                )
        except Exception as e:
            self.check("Dependency Check", False, str(e))
    
    def verify_backend_files(self):
        """Check backend files exist"""
        backend_files = [
            "app/main.py",
            "app/api_models.py",
            "security/pii.py",
            "security/access_control.py"
        ]
        
        for file in backend_files:
            path = self.workspace / file
            self.check(f"Backend: {file}", path.exists(), str(path))
    
    def verify_frontend_files(self):
        """Check frontend files exist"""
        frontend_files = [
            "frontend/healthcare_compliance_agent.py",
            "frontend/backend_client.py",
            "frontend/database.py",
            "frontend/__init__.py"
        ]
        
        for file in frontend_files:
            path = self.workspace / file
            self.check(f"Frontend: {file}", path.exists(), str(path))
    
    def verify_mcp_files(self):
        """Check MCP files exist"""
        mcp_files = [
            "mcp_server.py",
            "mcp_client.py",
            "MCP_INTEGRATION.md",
            "MCP_SUMMARY.md",
            "MCP_QUICK_REFERENCE.md",
            "mcp_config.json"
        ]
        
        for file in mcp_files:
            path = self.workspace / file
            self.check(f"MCP: {file}", path.exists(), str(path))
    
    def verify_scripts(self):
        """Check startup scripts"""
        scripts = [
            "start_backend.sh",
            "start_frontend.sh",
            "start_all.sh",
            "start_mcp.sh"
        ]
        
        for script in scripts:
            path = self.workspace / script
            exists = path.exists()
            executable = os.access(path, os.X_OK) if exists else False
            self.check(
                f"Script: {script}",
                exists and executable,
                f"Executable: {executable}" if exists else "File not found"
            )
    
    def verify_documentation(self):
        """Check documentation files"""
        docs = [
            "README.md",
            "frontend/README.md",
            "MCP_DEPLOYMENT.md",
            "FRONTEND_AI_ARCHITECTURE.md",
            "FRONTEND_ORCHESTRATION.md"
        ]
        
        for doc in docs:
            path = self.workspace / doc
            self.check(f"Documentation: {doc}", path.exists(), str(path))
    
    def verify_requirements(self):
        """Check requirements.txt is properly configured"""
        req_file = self.workspace / "requirements.txt"
        self.check("requirements.txt exists", req_file.exists())
        
        if req_file.exists():
            content = req_file.read_text()
            required_packages = ["fastapi", "langgraph", "sqlalchemy", "mcp"]
            
            for pkg in required_packages:
                self.check(
                    f"requirements.txt: {pkg}",
                    pkg in content.lower(),
                    f"{pkg} listed in requirements"
                )
    
    def verify_backend_connectivity(self):
        """Try to detect if backend can start"""
        main_file = self.workspace / "app" / "main.py"
        if main_file.exists():
            try:
                result = subprocess.run(
                    [sys.executable, "-m", "py_compile", str(main_file)],
                    capture_output=True,
                    timeout=5
                )
                self.check(
                    "Backend: Syntax Check",
                    result.returncode == 0,
                    "No syntax errors detected"
                )
            except Exception as e:
                self.check("Backend: Syntax Check", False, str(e))
    
    def verify_frontend_connectivity(self):
        """Try to detect if frontend can start"""
        agent_file = self.workspace / "frontend" / "healthcare_compliance_agent.py"
        if agent_file.exists():
            try:
                result = subprocess.run(
                    [sys.executable, "-m", "py_compile", str(agent_file)],
                    capture_output=True,
                    timeout=5
                )
                self.check(
                    "Frontend: Syntax Check",
                    result.returncode == 0,
                    "No syntax errors detected"
                )
            except Exception as e:
                self.check("Frontend: Syntax Check", False, str(e))
    
    def verify_mcp_connectivity(self):
        """Try to detect if MCP can start"""
        mcp_file = self.workspace / "mcp_server.py"
        if mcp_file.exists():
            try:
                result = subprocess.run(
                    [sys.executable, "-m", "py_compile", str(mcp_file)],
                    capture_output=True,
                    timeout=5
                )
                self.check(
                    "MCP: Syntax Check",
                    result.returncode == 0,
                    "No syntax errors detected"
                )
            except Exception as e:
                self.check("MCP: Syntax Check", False, str(e))
    
    def run_all_checks(self):
        """Run all verification checks"""
        print("\n" + "="*60)
        print("MCP HEALTHCARE COMPLIANCE - SETUP VERIFICATION")
        print("="*60 + "\n")
        
        print("1. ENVIRONMENT")
        print("-" * 60)
        self.verify_python()
        
        print("\n2. DEPENDENCIES")
        print("-" * 60)
        self.verify_dependencies()
        
        print("\n3. BACKEND FILES")
        print("-" * 60)
        self.verify_backend_files()
        
        print("\n4. FRONTEND FILES")
        print("-" * 60)
        self.verify_frontend_files()
        
        print("\n5. MCP FILES")
        print("-" * 60)
        self.verify_mcp_files()
        
        print("\n6. SCRIPTS")
        print("-" * 60)
        self.verify_scripts()
        
        print("\n7. DOCUMENTATION")
        print("-" * 60)
        self.verify_documentation()
        
        print("\n8. CONFIGURATION")
        print("-" * 60)
        self.verify_requirements()
        
        print("\n9. BACKEND CONNECTIVITY")
        print("-" * 60)
        self.verify_backend_connectivity()
        
        print("\n10. FRONTEND CONNECTIVITY")
        print("-" * 60)
        self.verify_frontend_connectivity()
        
        print("\n11. MCP CONNECTIVITY")
        print("-" * 60)
        self.verify_mcp_connectivity()
        
        # Summary
        print("\n" + "="*60)
        print("VERIFICATION SUMMARY")
        print("="*60)
        print(f"✅ Passed: {self.passed}")
        print(f"❌ Failed: {self.failed}")
        print(f"📊 Total:  {self.passed + self.failed}")
        
        if self.failed == 0:
            print("\n🎉 All checks passed! System is ready for deployment.")
            print("\nNext steps:")
            print("1. Start backend: ./start_backend.sh")
            print("2. Start frontend: ./start_frontend.sh")
            print("3. Configure MCP: ./start_mcp.sh")
            print("4. Test in Claude: Ask for compliance tools")
        else:
            print(f"\n⚠️  {self.failed} check(s) failed. Review above for details.")
            print("\nRun this script again after fixing issues:")
            print(f"   python {__file__}")
        
        print("="*60 + "\n")
        return self.failed == 0

if __name__ == "__main__":
    verifier = MCASetupVerifier()
    success = verifier.run_all_checks()
    sys.exit(0 if success else 1)
