# 🏗️ New Architecture: Frontend-Driven with Backend Compliance Middleware

## Core Principle

**Backend = Compliance Middleware** (not application logic)
**Frontend = Healthcare AI System + Database** (all business logic + auditing + any agentic framework)

> **Frontend Flexibility**: Frontend can use any suitable approach:
> - Agentic Framework (LangGraph, AutoGen, Crew.ai)
> - Custom orchestration
> - Hybrid approach
> 
> Backend remains stateless compliance middleware regardless of frontend implementation.

```
Frontend ↔ Backend Compliance Middleware ↔ Frontend
  (AI/Agents)  (Input/Output Check)      (Database)
```

---

## Data Flow: Every Action Through Compliance

```
┌──────────────────────────────────────────────────────────────────┐
│                    FRONTEND (React/Streamlit)                     │
│         Healthcare AI System + Audit Database                     │
│                                                                   │
│  1. User Input → /api/check-input (compliance)                  │
│                      ↓                                            │
│  2. Get: Access ✓, PII masked ✓, Audit ID                      │
│                      ↓                                            │
│  3. Call LLM with masked input                                  │
│                      ↓                                            │
│  4. LLM Output → /api/check-output (compliance)                │
│                      ↓                                            │
│  5. Get: Output sanitized ✓, Audit Info                        │
│                      ↓                                            │
│  6. Store in Frontend DB: Input, Output, Audit, Regulations   │
│                                                                   │
│  ┌────────────────────────────────────────────────────┐         │
│  │          FRONTEND DATABASE (PostgreSQL/MongoDB)     │         │
│  ├────────────────────────────────────────────────────┤         │
│  │ • Patient Data (EHR)                               │         │
│  │ • Audit Logs (Input/Output/Decisions)             │         │
│  │ • Compliance Traces (Regulations Applied)         │         │
│  │ • User Actions (Who did what, when, why)         │         │
│  └────────────────────────────────────────────────────┘         │
└──────────────────────────────────────────────────────────────────┘
                            ↕
            [Compliance Checks - Every Action]
                            ↕
┌──────────────────────────────────────────────────────────────────┐
│                 BACKEND (FastAPI)                                 │
│            Compliance Middleware (Stateless)                      │
│                                                                   │
│  /api/check-input:  Verify access + Mask PII                    │
│  /api/check-output: Sanitize output + Validate                  │
│  /api/log-action:   Create audit entry (no storage)            │
│                                                                   │
│  Each returns: compliance_status, audit_id, regulations          │
└──────────────────────────────────────────────────────────────────┘
```

---

## Request/Response Flow

### Step 1: Frontend → Check Input

**Request:**
```bash
POST /api/check-input
{
  "input_text": "Patient John Doe (SSN: 123-45-6789) with fever",
  "request_type": "triage",
  "user_role": "clinician",
  "action": "prepare_for_llm"
}
```

**Response:**
```json
{
  "compliance_status": "PASS",
  "access_granted": true,
  "pii_detected": [
    {"type": "NAME", "value": "John Doe"},
    {"type": "SSN", "value": "123-45-6789"}
  ],
  "masked_input": "Patient [NAME] (SSN: [SSN]) with fever",
  "audit_id": "AUDIT-20251217-103456",
  "regulations": ["GDPR", "HIPAA", "PCI-DSS"],
  "policy_trace": {
    "AccessControlAgent": ["GDPR Article 32", "HIPAA 164.312"],
    "PrivacyAgent": ["HIPAA 164.502", "GDPR Article 32"]
  }
}
```

### Step 2: Frontend Calls LLM

Frontend stores input audit:
```javascript
// Frontend storage (pseudo)
await db.insert('audit_log', {
  action_id: audit_id,
  action_type: 'LLM_INPUT',
  original_input: "Patient John Doe (SSN: 123-45-6789) with fever",
  masked_input: "Patient [NAME] (SSN: [SSN]) with fever",
  pii_detected: [{type: "NAME", value: "John Doe"}, ...],
  timestamp: new Date(),
  user_role: "clinician",
  request_type: "triage"
});

// Call LLM with masked input
const llmOutput = await openai.createChatCompletion({
  messages: [{role: "user", content: "Patient [NAME] (SSN: [SSN]) with fever"}]
});
```

### Step 3: Frontend → Check Output

**Request:**
```bash
POST /api/check-output
{
  "audit_id": "AUDIT-20251217-103456",
  "output_text": "Patient requires urgent care evaluation. Possible infection.",
  "request_type": "triage",
  "user_role": "clinician"
}
```

**Response:**
```json
{
  "compliance_status": "PASS",
  "sanitized_output": "Patient requires urgent care evaluation. Possible infection.",
  "pii_detected_in_output": [],
  "audit_id": "AUDIT-20251217-103456",
  "regulations_applied": ["GDPR", "HIPAA", "PCI-DSS"],
  "safe_to_store": true
}
```

### Step 4: Frontend Stores Complete Audit

Frontend stores everything in its database:
```javascript
await db.insert('audit_log', {
  action_id: audit_id,
  action_type: 'LLM_OUTPUT',
  llm_output: "Patient requires urgent care evaluation. Possible infection.",
  sanitized_output: "Patient requires urgent care evaluation. Possible infection.",
  pii_detected: [],
  compliance_status: "PASS",
  regulations: ["GDPR", "HIPAA", "PCI-DSS"],
  timestamp: new Date(),
  user_role: "clinician"
});

await db.insert('clinical_decision', {
  patient_id: patientId,
  triage_level: "URGENT",
  reasoning: "Fever + symptoms suggest infection",
  decision_id: audit_id,
  created_by: "clinician_id",
  timestamp: new Date()
});
```

---

## Backend Endpoints (Compliance Middleware Only)

### 1. Check Input

```python
@app.post("/api/check-input")
async def check_input(request):
    """
    Compliance check on user input before LLM processing.
    
    Returns: masked_input, access_status, pii_detected, audit_id
    """
    # Run AccessControlAgent + PrivacyAgent
    # Return compliance info (NO STORAGE)
```

### 2. Check Output

```python
@app.post("/api/check-output")
async def check_output(request):
    """
    Compliance check on LLM output before storage.
    
    Returns: sanitized_output, pii_detected, safe_to_store
    """
    # Run OutputGuardAgent + AuditAgent
    # Return compliance validation (NO STORAGE)
```

### 3. Log Action (Optional)

```python
@app.post("/api/log-action")
async def log_action(request):
    """
    Create compliance log entry (audit trail reference).
    
    Frontend still stores full audit, backend creates compliance record.
    """
    # Create audit log entry in COMPLIANCE system
    # Links to audit_id from frontend
    # NO business logic storage
```

---

## Frontend Database Schema

### Audit Log Table

```sql
CREATE TABLE audit_log (
  id UUID PRIMARY KEY,
  action_id VARCHAR UNIQUE,           -- AUDIT-20251217-103456
  action_type VARCHAR,                -- LLM_INPUT, LLM_OUTPUT, DECISION, STORAGE
  user_id UUID,
  user_role VARCHAR,
  original_input TEXT,
  masked_input TEXT,
  pii_detected JSONB,
  llm_input TEXT,
  llm_output TEXT,
  sanitized_output TEXT,
  compliance_status VARCHAR,          -- PASS, FAIL, WARN
  regulations JSONB,                  -- ["GDPR", "HIPAA", "PCI-DSS"]
  policy_trace JSONB,                 -- Compliance agent details
  backend_audit_id VARCHAR,           -- Reference to backend audit
  timestamp TIMESTAMP,
  request_type VARCHAR,               -- triage, scheduling, clinical_decision
  
  INDEX (action_id),
  INDEX (user_id),
  INDEX (timestamp)
);
```

### Clinical Decision Table

```sql
CREATE TABLE clinical_decision (
  id UUID PRIMARY KEY,
  patient_id UUID,
  decision_type VARCHAR,              -- triage, scheduling, recommendation
  triage_level VARCHAR,               -- URGENT, HIGH, MEDIUM, LOW
  recommendation TEXT,
  reasoning TEXT,
  decision_id VARCHAR,                -- Links to audit_log.action_id
  created_by UUID,
  timestamp TIMESTAMP,
  
  FOREIGN KEY (patient_id) REFERENCES patient(id),
  INDEX (patient_id),
  INDEX (timestamp)
);
```

### Patient EHR Table

```sql
CREATE TABLE patient_ehr (
  id UUID PRIMARY KEY,
  patient_id UUID,
  medical_history TEXT,
  allergies JSONB,
  medications JSONB,
  recent_visits JSONB,
  lab_results JSONB,
  updated_by UUID,
  updated_at TIMESTAMP,
  
  FOREIGN KEY (patient_id) REFERENCES patient(id),
  INDEX (patient_id)
);
```

---

## Complete Clinical Triage Example

```
┌─────────────────────────────────────────────────────────────┐
│ 1. User (Clinician) inputs: "Patient John Doe with fever"  │
└─────────────────────────────────────────────────────────────┘
                        ↓
┌─────────────────────────────────────────────────────────────┐
│ 2. Frontend → Backend: POST /api/check-input                │
│    Response:                                                 │
│    • access_granted: true                                   │
│    • masked_input: "Patient [NAME] with fever"             │
│    • audit_id: "AUDIT-001"                                 │
└─────────────────────────────────────────────────────────────┘
                        ↓
┌─────────────────────────────────────────────────────────────┐
│ 3. Frontend → Database: Store input audit                   │
│    audit_log:                                                │
│    • action_id: "AUDIT-001"                                │
│    • action_type: "LLM_INPUT"                              │
│    • original_input: "Patient John Doe with fever"        │
│    • masked_input: "Patient [NAME] with fever"            │
│    • pii_detected: [{type: "NAME", value: "John Doe"}]   │
│    • compliance_status: "PASS"                             │
└─────────────────────────────────────────────────────────────┘
                        ↓
┌─────────────────────────────────────────────────────────────┐
│ 4. Frontend → LLM: Process with masked input                │
│    LLM Output: "Fever suggests infection. Urgent eval."    │
└─────────────────────────────────────────────────────────────┘
                        ↓
┌─────────────────────────────────────────────────────────────┐
│ 5. Frontend → Backend: POST /api/check-output               │
│    Response:                                                 │
│    • sanitized_output: "Fever suggests infection. Eval."   │
│    • pii_detected: [] (none)                               │
│    • safe_to_store: true                                   │
└─────────────────────────────────────────────────────────────┘
                        ↓
┌─────────────────────────────────────────────────────────────┐
│ 6. Frontend → Database: Store complete audit + decision     │
│    audit_log:                                                │
│    • action_id: "AUDIT-001"                                │
│    • action_type: "LLM_OUTPUT"                             │
│    • llm_output: "Fever suggests infection. Urgent eval."  │
│    • sanitized_output: (same)                              │
│    • compliance_status: "PASS"                             │
│                                                              │
│    clinical_decision:                                       │
│    • decision_id: "AUDIT-001"                              │
│    • triage_level: "URGENT"                                │
│    • reasoning: "Fever + symptoms"                         │
│    • created_by: "clinician_id"                            │
└─────────────────────────────────────────────────────────────┘
                        ↓
              ✅ Complete Audit Trail
         (All stored in Frontend DB with full traceability)
```

---

## Key Principles

| Principle | Implementation |
|-----------|-----------------|
| **Backend = Middleware** | Only compliance checks, no business logic storage |
| **Frontend = Application** | All AI logic, EHR, audit storage |
| **Every LLM Action** | Input check → LLM → Output check |
| **Audit Trail** | Complete in Frontend DB, linked to Backend compliance |
| **Regulations** | Applied at each step (input, output, storage) |
| **PII Protection** | Masked before LLM, validated in output |

---

## Implementation Checklist

- [ ] Create Frontend Database (PostgreSQL/MongoDB)
- [ ] Create audit_log table schema
- [ ] Create clinical_decision table schema
- [ ] Create patient_ehr table schema
- [ ] Update Frontend to call /api/check-input before LLM
- [ ] Update Frontend to call /api/check-output after LLM
- [ ] Update Frontend to store all audits in database
- [ ] Add LLM integration (OpenAI/Claude/Local)
- [ ] Test complete flow with audit validation
- [ ] Implement audit query/reporting endpoints
- [ ] Add compliance dashboard to Frontend

---

**Architecture Status**: ✅ Ready for Frontend Development

