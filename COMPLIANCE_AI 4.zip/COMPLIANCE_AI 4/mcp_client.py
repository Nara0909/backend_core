"""
MCP Client for Healthcare Compliance

Provides a client interface to interact with the MCP server.
Can be used by LangGraph agent or other applications.
"""

import json
from typing import Dict, List, Any, Optional
import subprocess
import sys
import os


class MCPClient:
    """Client for MCP compliance tools and resources"""
    
    def __init__(self, mcp_server_path: str = None):
        """
        Initialize MCP client
        
        Args:
            mcp_server_path: Path to mcp_server.py (default: ./mcp_server.py)
        """
        self.mcp_server_path = mcp_server_path or os.path.join(
            os.path.dirname(__file__), "mcp_server.py"
        )
        self.process = None
        self.is_running = False
    
    def start_server(self) -> bool:
        """Start the MCP server"""
        try:
            self.process = subprocess.Popen(
                [sys.executable, self.mcp_server_path],
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE
            )
            self.is_running = True
            print(f"✅ MCP server started (PID: {self.process.pid})")
            return True
        except Exception as e:
            print(f"❌ Failed to start MCP server: {e}")
            return False
    
    def stop_server(self) -> bool:
        """Stop the MCP server"""
        try:
            if self.process:
                self.process.terminate()
                self.process.wait(timeout=5)
                self.is_running = False
                print("✅ MCP server stopped")
                return True
        except Exception as e:
            print(f"❌ Failed to stop MCP server: {e}")
            if self.process:
                self.process.kill()
            return False
    
    # ============ TOOL WRAPPERS ============
    
    async def get_enforcement_plan(self, request_type: str) -> Dict[str, Any]:
        """Get enforcement plan for request type"""
        # In a real MCP client, this would call the MCP server via stdio
        # For now, we provide a template
        return {
            "status": "success",
            "request_type": request_type,
            "regulations": ["HIPAA", "GDPR"],
            "agents": ["AccessControl", "Privacy", "OutputGuard"],
            "note": "Connect to actual MCP server for live data"
        }
    
    async def check_access(
        self,
        user_id: str,
        user_role: str,
        patient_id: str,
        resource_type: str = "patient_data"
    ) -> Dict[str, Any]:
        """Check user access"""
        return {
            "status": "success",
            "access_granted": user_role in ["clinician", "specialist", "admin"],
            "reason": f"{user_role} role has access",
            "regulations": ["HIPAA"]
        }
    
    async def mask_pii(self, text: str) -> Dict[str, Any]:
        """Mask PII in text"""
        import re
        
        masked_text = text
        pii_detected = []
        
        # SSN pattern
        ssn_pattern = r'\d{3}-\d{2}-\d{4}'
        if re.search(ssn_pattern, text):
            masked_text = re.sub(ssn_pattern, '[SSN]', masked_text)
            pii_detected.append({"type": "SSN", "masked_as": "[SSN]"})
        
        # Email pattern
        email_pattern = r'[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}'
        if re.search(email_pattern, text):
            masked_text = re.sub(email_pattern, '[EMAIL]', masked_text)
            pii_detected.append({"type": "EMAIL", "masked_as": "[EMAIL]"})
        
        # Phone pattern
        phone_pattern = r'\b\d{3}[-.]?\d{3}[-.]?\d{4}\b'
        if re.search(phone_pattern, text):
            masked_text = re.sub(phone_pattern, '[PHONE]', masked_text)
            pii_detected.append({"type": "PHONE", "masked_as": "[PHONE]"})
        
        return {
            "status": "success",
            "masked_text": masked_text,
            "pii_detected": pii_detected,
            "pii_count": len(pii_detected)
        }
    
    async def sanitize_output(self, text: str) -> Dict[str, Any]:
        """Sanitize LLM output"""
        import re
        
        # Check for PII patterns
        pii_detected = []
        
        if re.search(r'\d{3}-\d{2}-\d{4}', text):
            pii_detected.append({"type": "SSN"})
        
        if re.search(r'[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}', text):
            pii_detected.append({"type": "EMAIL"})
        
        return {
            "status": "success",
            "sanitized_text": text,
            "safe_to_store": len(pii_detected) == 0,
            "pii_detected": pii_detected
        }
    
    async def log_compliance_action(
        self,
        user_id: str,
        action: str,
        resource: str,
        outcome: str,
        details: Optional[Dict] = None
    ) -> Dict[str, Any]:
        """Log compliance action"""
        from datetime import datetime
        import uuid
        
        return {
            "status": "success",
            "audit_id": str(uuid.uuid4()),
            "timestamp": datetime.utcnow().isoformat(),
            "user_id": user_id,
            "action": action,
            "outcome": outcome,
            "regulations_logged": ["HIPAA", "GDPR"]
        }
    
    # ============ RESOURCE WRAPPERS ============
    
    async def get_user_audit_logs(self, user_id: str) -> Dict[str, Any]:
        """Get audit logs for user"""
        return {
            "user_id": user_id,
            "audit_logs": [],
            "total": 0
        }
    
    async def get_patient_audit_logs(self, patient_id: str) -> Dict[str, Any]:
        """Get audit logs for patient"""
        return {
            "patient_id": patient_id,
            "audit_logs": [],
            "total": 0
        }
    
    async def get_compliance_violations(self) -> Dict[str, Any]:
        """Get compliance violations"""
        return {
            "violations": [],
            "total": 0
        }
    
    async def get_patient_ehr(self, patient_id: str) -> Dict[str, Any]:
        """Get patient EHR"""
        return {
            "patient_id": patient_id,
            "medical_conditions": [],
            "medications": [],
            "allergies": []
        }
    
    async def list_enforcement_plans(self) -> Dict[str, Any]:
        """List enforcement plans"""
        return {
            "plans": [
                {
                    "request_type": "triage",
                    "regulations": ["HIPAA", "GDPR"]
                },
                {
                    "request_type": "scheduling",
                    "regulations": ["HIPAA", "GDPR", "CCPA"]
                },
                {
                    "request_type": "referral",
                    "regulations": ["HIPAA"]
                }
            ]
        }


def create_mcp_client(server_path: str = None) -> MCPClient:
    """Create and return MCP client"""
    return MCPClient(server_path)
