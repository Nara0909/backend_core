#!/usr/bin/env bash

# Simple Frontend Startup Script
# Starts Streamlit frontend on localhost:8501

echo "🎨 Starting Healthcare Compliance Frontend..."
echo ""

# Change to project directory
cd "$(dirname "$0")" || exit 1

# Kill any existing process on port 8501
echo "🧹 Cleaning up port 8501..."
lsof -ti :8501 | xargs kill -9 2>/dev/null || true

sleep 1

# Start frontend
echo "📊 Starting Streamlit server on 127.0.0.1:8501..."
streamlit run ui/app.py --server.port=8501 --server.address=127.0.0.1

# If we get here, server stopped
echo ""
echo "❌ Frontend stopped"
