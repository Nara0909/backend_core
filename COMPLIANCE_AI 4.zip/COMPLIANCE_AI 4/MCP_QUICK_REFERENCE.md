# Quick Reference: MCP Integration

## 🚀 Start Here

### 1-Minute Setup
```bash
# Install MCP
pip install mcp

# Configure Claude
./start_mcp.sh

# Done! Claude now has compliance tools
```

## 📋 Available Tools

| Tool | Purpose | Parameters | Returns |
|------|---------|-----------|---------|
| `get_enforcement_plan` | Get regulations | `request_type` | Regulations, agents |
| `check_access` | Verify permissions | `user_id, user_role, patient_id` | Access granted/denied |
| `mask_pii` | Mask sensitive data | `text` | Masked text, PII list |
| `sanitize_output` | Check for PII | `text` | Safe/unsafe, PII found |
| `log_compliance_action` | Create audit | `user_id, action, resource, outcome` | Audit ID |

## 🎯 Common Tasks

### Get Compliance Requirements
```python
result = await mcp_client.get_enforcement_plan("triage")
# → Returns: regulations, agents, enforcement plan
```

### Verify Access
```python
result = await mcp_client.check_access(
    "clinician_001", "clinician", "P12345"
)
# → Returns: access_granted, reason
```

### Protect Patient Data
```python
masked = await mcp_client.mask_pii(patient_input)
# → masked['masked_text'] is safe for LLM
```

### Verify Output Safety
```python
safe = await mcp_client.sanitize_output(llm_response)
if safe['safe_to_store']:
    store_result(llm_response)
```

### Create Audit Record
```python
audit = await mcp_client.log_compliance_action(
    "clinician_001", "triage_decision", "patient", "success"
)
# → Returns: audit_id for tracking
```

## 📊 Available Resources

| Resource | Query | Returns |
|----------|-------|---------|
| `audit_log://user/{user_id}` | User's actions | Audit logs |
| `audit_log://patient/{patient_id}` | Patient access | Access history |
| `compliance_violations://` | Violations | Recent violations |
| `patient_ehr://{patient_id}` | Patient record | Medical data |
| `enforcement_plans://` | Configurations | All plans |

## 💬 Claude Examples

### Ask Claude
```
"Check what regulations apply to patient triage 
and mask this patient data"

Claude will:
1. Call get_enforcement_plan("triage")
2. Call mask_pii(patient_data)
3. Return masked data with regulations
```

### Ask Claude
```
"Show me who accessed patient P12345's data 
and any compliance violations"

Claude will:
1. Query audit_log://patient/P12345
2. Query compliance_violations://
3. Provide access history and violations
```

## 🔧 Configuration

### Claude Settings
```
Settings → Developer → Model Context Protocol
Add Server:
- Name: Healthcare Compliance
- Command: python
- Path: /path/to/mcp_server.py
```

### Python Code
```python
from mcp_client import create_mcp_client

client = create_mcp_client()
result = await client.get_enforcement_plan("triage")
```

## ✅ Verification

### Test 1: Server Running
```bash
python mcp_server.py
# Should show: Healthcare Compliance MCP Server
```

### Test 2: Tools Available
```python
from mcp_client import create_mcp_client
client = create_mcp_client()
# client should have all 5 tool methods
```

### Test 3: Claude Integration
In Claude, ask: "What tools do you have access to?"
Should see all 5 compliance tools listed.

## 🚨 Troubleshooting

| Problem | Solution |
|---------|----------|
| Claude doesn't see tools | Restart Claude, check path in settings |
| MCP server timeout | Ensure backend running on port 8000 |
| Tools return errors | Check backend logs for API errors |
| Permission denied | Ensure mcp_server.py is executable |

## 📚 Documentation

- **Full Guide**: See `MCP_INTEGRATION.md`
- **Architecture**: See `MCP_SUMMARY.md`
- **Examples**: See `example_clinical_flow.py`
- **LangGraph**: See `MCP_LANGRAPH_INTEGRATION.md`

## 🎯 Next Steps

1. ✅ Install MCP: `pip install mcp`
2. ✅ Run setup: `./start_mcp.sh`
3. ✅ Configure Claude (follow prompts)
4. ✅ Restart Claude
5. ✅ Start using compliance tools!

## 🔐 Security Notes

- All tool calls are audited
- PII is masked before LLM processing
- Access control is enforced
- Regulations are tracked
- Violations are logged

## 💡 Pro Tips

1. **Always mask PII first** before sending to LLM
2. **Check access** before accessing patient data
3. **Sanitize output** before storing results
4. **Log actions** for audit trail
5. **Use Claude** for complex compliance workflows

---

**More Info**: `MCP_INTEGRATION.md` | **Examples**: `example_clinical_flow.py`
