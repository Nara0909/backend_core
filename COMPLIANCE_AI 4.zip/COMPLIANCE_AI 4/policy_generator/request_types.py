def list_request_types():
    return list(REQUEST_TYPES.keys())


REQUEST_TYPES = {
    "PatientTriage": {
        "regulations": [
            "HIPAA",
            "GDPR",
            "CCPA",
            "EU_AI_ACT"
        ],
        "principles": [
            "Privacy",
            "Access Control",
            "Data Minimization",
            "Security",
            "Governance and Accountability"
        ],
        "keywords": [
            "chest pain",
            "shortness of breath",
            "fever",
            "emergency",
            "triage",
            "vital signs"
        ],
        "exemplars": [
            "Patient with chest pain and shortness of breath",
            "Emergency triage assessment",
            "Collect vital signs for triage"
        ]
    },

    "ClinicalDecisionSupport": {
        "regulations": [
            "HIPAA",
            "GDPR",
            "EU_AI_ACT"
        ],
        "principles": [
            "Privacy",
            "Access Control",
            "Explainability",
            "Governance and Accountability",
            "Security"
        ],
        "keywords": [
            "diagnosis",
            "treatment",
            "medication",
            "drug interaction",
            "dosage"
        ],
        "exemplars": [
            "Recommend medication dosage",
            "Check drug interactions",
            "Suggest treatment options based on diagnosis"
        ]
    },

    "BillingAndClaims": {
        "regulations": [
            "HIPAA",
            "PCI_DSS",
            "GDPR",
            "CCPA"
        ],
        "principles": [
            "Access Control",
            "Data Minimization",
            "Retention",
            "Security"
        ],
        "keywords": [
            "billing",
            "insurance",
            "CPT code",
            "ICD-10",
            "payment"
        ],
        "exemplars": [
            "Insurance claim submission",
            "ICD-10 and CPT billing",
            "Process payment for medical services"
        ]
    }
}
