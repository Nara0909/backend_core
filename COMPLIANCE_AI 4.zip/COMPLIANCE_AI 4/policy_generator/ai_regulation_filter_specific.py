import truststore
truststore.inject_into_ssl()

import json
from pathlib import Path
from dotenv import load_dotenv
from config.config import client, MODEL

# -----------------------------
# CONFIG
# -----------------------------
load_dotenv()

BASE_DIR = Path(__file__).resolve().parent
INPUT_DIR = BASE_DIR / "output_policies_general"
OUTPUT_DIR = BASE_DIR / "output_policies_AI"
FILTER_PROMPT_FILE = BASE_DIR / "prompts" / "filter_ai_relevant_from_json.txt"
SCOPE_PROMPT_FILE = BASE_DIR / "prompts" / "classify_ai_scope.txt"

OUTPUT_DIR.mkdir(parents=True, exist_ok=True)

FILTER_PROMPT = FILTER_PROMPT_FILE.read_text(encoding="utf-8")
SCOPE_PROMPT = SCOPE_PROMPT_FILE.read_text(encoding="utf-8")

# -----------------------------
# SINGLE FILE MODE
# -----------------------------
SINGLE_FILE_NAME = "gdpr.json"
# set to None to process all files

# -----------------------------
# CANONICAL PRINCIPLES
# -----------------------------
PRINCIPLE_MAP = {
    "data minimization": "Data Minimization",
    "privacy": "Privacy",
    "security": "Security",
    "access control": "Access Control",
    "retention": "Retention",
    "governance and accountability": "Governance and Accountability",
}

ALLOWED_AI_SCOPES = {
    "AI_Privacy_Control",
    "AI_Access_Control",
    "AI_Governance",
    "AI_Explainability",
    "General_Governance",
}

# -----------------------------
# NORMALIZATION
# -----------------------------
def normalize_principle(rule: dict) -> dict:
    raw = rule.get("principle", "")
    rule["principle"] = PRINCIPLE_MAP.get(raw.strip().lower(), raw)
    return rule


def normalize_actor_language(rule: dict) -> dict:
    text = rule.get("requirement", "")
    lower = text.lower()

    prefixes = [
        "businesses must ",
        "a business must ",
        "service providers must ",
        "contractors must ",
        "covered entities must ",
    ]

    for p in prefixes:
        if lower.startswith(p):
            rule["requirement"] = text[len(p):].capitalize()
            break

    return rule

# -----------------------------
# HEURISTIC CLASSIFIER (PRIMARY)
# -----------------------------
def heuristic_ai_scope(rule: dict) -> tuple[str, str]:
    text = f"{rule.get('principle','')} {rule.get('requirement','')}".lower()

    if any(k in text for k in ["phi", "pii", "personal data", "privacy", "de-identif", "anonym"]):
        return "AI_Privacy_Control", "Heuristic keyword match: privacy/PII"

    if any(k in text for k in ["access", "authorize", "role", "permission"]):
        return "AI_Access_Control", "Heuristic keyword match: access control"

    if any(k in text for k in ["audit", "log", "monitor", "oversight"]):
        return "AI_Governance", "Heuristic keyword match: audit/governance"

    if any(k in text for k in ["automated", "algorithm", "explain", "logic"]):
        return "AI_Explainability", "Heuristic keyword match: explainability"

    return "General_Governance", "No heuristic match"

# -----------------------------
# LLM CLASSIFIER (SECONDARY)
# -----------------------------
def classify_ai_scope_llm_batch(rules: list) -> list:
    print(f"   LLM classifying {len(rules)} unresolved rules")

    messages = [
        {"role": "system", "content": SCOPE_PROMPT},
        {"role": "user", "content": json.dumps(rules, indent=2)},
    ]

    try:
        response = client.chat.completions.create(
            model=MODEL,
            messages=messages,
            temperature=0.0,
        )
        raw = json.loads(response.choices[0].message.content)
    except Exception as e:
        print(f"   LLM scope classification failed: {e}")
        return rules

    results = raw.get("results", raw) if isinstance(raw, dict) else raw
    if not isinstance(results, list):
        return rules

    for i, rule in enumerate(rules):
        classified = results[i] if i < len(results) else {}
        ai_scope = classified.get("ai_scope")

        if ai_scope in ALLOWED_AI_SCOPES:
            rule["ai_scope"] = ai_scope
            rule["ai_scope_reason"] = "LLM classification"
        else:
            rule["ai_scope"] = "General_Governance"
            rule["ai_scope_reason"] = "LLM failed → fallback"

    return rules

# -----------------------------
# AI RELEVANCE FILTER
# -----------------------------
def filter_with_llm(rules: list) -> list:
    print(f"   Filtering AI relevance from {len(rules)} rules")

    messages = [
        {"role": "system", "content": FILTER_PROMPT},
        {"role": "user", "content": json.dumps(rules, indent=2)},
    ]

    try:
        response = client.chat.completions.create(
            model=MODEL,
            messages=messages,
            temperature=0.0,
        )
        return json.loads(response.choices[0].message.content)
    except Exception as e:
        print(f"   AI relevance filtering failed: {e}")
        return []

# -----------------------------
# MAIN PIPELINE
# -----------------------------
def process_all_files():
    if SINGLE_FILE_NAME:
        json_file = INPUT_DIR / SINGLE_FILE_NAME
        if not json_file.exists():
            raise FileNotFoundError(f"{SINGLE_FILE_NAME} not found in {INPUT_DIR}")
        files = [json_file]
        print(f"Running in SINGLE FILE mode → {SINGLE_FILE_NAME}")
    else:
        files = list(INPUT_DIR.glob("*.json"))
        print(f"Processing {len(files)} policy files")

    for idx, json_file in enumerate(files, start=1):
        print(f"\n[{idx}/{len(files)}] Processing {json_file.name}")

        rules = json.loads(json_file.read_text(encoding="utf-8"))
        print(f"   Loaded {len(rules)} raw rules")

        resolved, unresolved = [], []

        for r in rules:
            r = normalize_principle(r)
            r = normalize_actor_language(r)

            scope, reason = heuristic_ai_scope(r)
            r["ai_scope"] = scope
            r["ai_scope_reason"] = reason

            if scope == "General_Governance":
                unresolved.append(r)
            else:
                resolved.append(r)

        print(f"   Heuristic resolved: {len(resolved)}")
        print(f"   LLM required: {len(unresolved)}")

        if unresolved:
            unresolved = classify_ai_scope_llm_batch(unresolved)

        combined = resolved + unresolved

        ai_rules = filter_with_llm(combined)

        output_path = OUTPUT_DIR / json_file.name
        output_path.write_text(json.dumps(ai_rules, indent=2), encoding="utf-8")

        print(f"   Saved {len(ai_rules)} AI rules → {output_path.name}")

    print("\nAI policy extraction completed successfully")

# -----------------------------
# ENTRY POINT
# -----------------------------
if __name__ == "__main__":
    process_all_files()
