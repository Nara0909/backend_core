import os
import sys
import json
import networkx as nx
from pathlib import Path
import pickle


# Ensure project root on sys.path when run as a script
def _ensure_project_root():
    p = Path(__file__).resolve().parent
    for _ in range(6):
        if (p / 'policy_generator').exists() or (p / 'requirements.txt').exists():
            root = str(p)
            if root not in sys.path:
                sys.path.insert(0, root)
            return
        p = p.parent


_ensure_project_root()

from policy_generator.request_types import REQUEST_TYPES

# -----------------------------
# CONFIG
# -----------------------------
BASE_DIR = Path(__file__).resolve().parent.parent

POLICY_DIR = BASE_DIR / "output_policies_AI"
GRAPH_OUTPUT = BASE_DIR / "policy_graph" / "policy_graph.pkl"

GRAPH_OUTPUT.parent.mkdir(parents=True, exist_ok=True)

# -----------------------------
# AI Scope → Agent mapping
# -----------------------------
AI_SCOPE_TO_AGENT = {
    "AI_Privacy_Control": "PrivacyAgent",
    "AI_Access_Control": "AccessControlAgent",
    "AI_Governance": "AuditAgent",
    "AI_Explainability": "OutputGuardAgent",
    "General_Governance": "PolicyAgent",
}

# -----------------------------
# Canonical Principles
# -----------------------------
CANONICAL_PRINCIPLES = {
    "Privacy",
    "Security",
    "Data Minimization",
    "Access Control",
    "Retention",
    "Governance and Accountability",
}

# -----------------------------
# Principle → AI Scope semantics
# -----------------------------
PRINCIPLE_TO_AI_SCOPE = {
    "Privacy": {
        "AI_Privacy_Control",
        "AI_Access_Control",
    },
    "Security": {
        "AI_Governance",
        "AI_Access_Control",
    },
    "Data Minimization": {
        "AI_Privacy_Control",
    },
    "Access Control": {
        "AI_Access_Control",
    },
    "Retention": {
        "AI_Governance",
    },
    "Governance and Accountability": {
        "AI_Governance",
    },
}

# -----------------------------
# BUILD POLICY GRAPH
# -----------------------------
def build_policy_graph():
    G = nx.DiGraph()

    # -------------------------------------------------
    # 1️⃣ RequestType Nodes
    # -------------------------------------------------
    for request_type, meta in REQUEST_TYPES.items():
        G.add_node(
            request_type,
            node_type="RequestType",
            label=request_type
        )

    # -------------------------------------------------
    # 2️⃣ Regulation + Policy Rules
    # -------------------------------------------------
    for json_file in POLICY_DIR.glob("*.json"):
        regulation_name = json_file.stem.upper()

        # Regulation node
        G.add_node(
            regulation_name,
            node_type="Regulation",
            label=regulation_name
        )

        # Link RequestType → Regulation
        for request_type, meta in REQUEST_TYPES.items():
            if regulation_name in meta.get("regulations", []):
                G.add_edge(
                    request_type,
                    regulation_name,
                    relation="TRIGGERS_REGULATION"
                )

        with open(json_file, "r", encoding="utf-8") as f:
            rules = json.load(f)

        for idx, rule in enumerate(rules):
            rule_id = f"{regulation_name}:{rule.get('article_or_section')}:{idx}"

            principle = rule.get("principle")
            ai_scope = rule.get("ai_scope", "General_Governance")

            # -----------------------------
            # Policy Rule Node
            # -----------------------------
            G.add_node(
                rule_id,
                node_type="PolicyRule",
                requirement=rule.get("requirement"),
                principle=principle,
                ai_scope=ai_scope
            )

            # Regulation → Rule
            G.add_edge(regulation_name, rule_id, relation="HAS_RULE")

            # -----------------------------
            # Principle Node
            # -----------------------------
            if principle in CANONICAL_PRINCIPLES:
                G.add_node(
                    principle,
                    node_type="Principle",
                    label=principle
                )

                G.add_edge(rule_id, principle, relation="ALIGNS_WITH")
                G.add_edge(regulation_name, principle, relation="GOVERNS")

            # -----------------------------
            # AI Scope Node
            # -----------------------------
            G.add_node(
                ai_scope,
                node_type="AI_Scope",
                label=ai_scope
            )

            G.add_edge(rule_id, ai_scope, relation="APPLIES_TO")

            # Semantic Principle → AI Scope
            if (
                principle in PRINCIPLE_TO_AI_SCOPE
                and ai_scope in PRINCIPLE_TO_AI_SCOPE[principle]
            ):
                G.add_edge(
                    principle,
                    ai_scope,
                    relation="ENFORCED_VIA"
                )

            # -----------------------------
            # Agent Node
            # -----------------------------
            agent = AI_SCOPE_TO_AGENT.get(ai_scope, "PolicyAgent")

            G.add_node(
                agent,
                node_type="Agent",
                label=agent
            )

            G.add_edge(ai_scope, agent, relation="ENFORCED_BY")

    # -------------------------------------------------
    # 3️⃣ Global PolicyAgent fallback (CRITICAL)
    # -------------------------------------------------
    G.add_node("PolicyAgent", node_type="Agent", label="PolicyAgent")

    for principle in CANONICAL_PRINCIPLES:
        G.add_edge(
            principle,
            "PolicyAgent",
            relation="OVERRIDDEN_BY"
        )

    return G

# -----------------------------
# MAIN
# -----------------------------
if __name__ == "__main__":
    graph = build_policy_graph()

    with open(GRAPH_OUTPUT, "wb") as f:
        pickle.dump(graph, f)

    print("✅ Policy Knowledge Graph created (RequestType + Semantic + Canonical)")
    print(f"Nodes: {graph.number_of_nodes()}")
    print(f"Edges: {graph.number_of_edges()}")
    print(f"Saved to: {GRAPH_OUTPUT}")
