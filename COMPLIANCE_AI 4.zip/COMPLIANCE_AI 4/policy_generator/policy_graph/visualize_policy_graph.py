import pickle
import networkx as nx
import matplotlib.pyplot as plt
from pathlib import Path
from collections import defaultdict

# -----------------------------
# LOAD GRAPH
# -----------------------------
BASE_DIR = Path(__file__).resolve().parent
GRAPH_PATH = BASE_DIR / "policy_graph.pkl"
OUTPUT_PNG = BASE_DIR / "policy_graph_clean.png"

with open(GRAPH_PATH, "rb") as f:
    G = pickle.load(f)

# -----------------------------
# GROUP NODES BY TYPE
# -----------------------------
nodes_by_type = defaultdict(list)

for n, d in G.nodes(data=True):
    node_type = d.get("node_type")
    if node_type:
        nodes_by_type[node_type].append(n)

regulations = nodes_by_type["Regulation"]
principles = nodes_by_type["Principle"]
ai_scopes = nodes_by_type["AI_Scope"]
agents = nodes_by_type["Agent"]
policy_rules = nodes_by_type["PolicyRule"]

# -----------------------------
# BUILD VISUAL GRAPH (PATH-AWARE)
# -----------------------------
VG = nx.DiGraph()

# Add high-level nodes only
for n in regulations + principles + ai_scopes + agents:
    VG.add_node(n, node_type=G.nodes[n]["node_type"])

# ------------------------------------------------
# DERIVE EDGES VIA EXPLICIT RULE SEMANTICS (FIXED)
# ------------------------------------------------
for rule in policy_rules:

    # Regulation(s) for this rule
    regs = [
        u for u in G.predecessors(rule)
        if G.nodes[u]["node_type"] == "Regulation"
    ]

    # Principle(s) for this rule
    pris = [
        v for v in G.successors(rule)
        if G.nodes[v]["node_type"] == "Principle"
    ]

    # AI Scope(s) for this rule
    scopes = [
        v for v in G.successors(rule)
        if G.nodes[v]["node_type"] == "AI_Scope"
    ]

    # Regulation → Principle
    for r in regs:
        for p in pris:
            if r in VG and p in VG:
                VG.add_edge(r, p)

    # Principle → AI Scope  ✅ ONLY VALID ALIGNMENT
    for p in pris:
        for s in scopes:
            if p in VG and s in VG:
                VG.add_edge(p, s)


# -----------------------------
# MANUAL LAYERED POSITIONS
# -----------------------------
pos = {}

def layer_positions(nodes, x, y_start=0, y_gap=1.5):
    for i, n in enumerate(nodes):
        pos[n] = (x, y_start - i * y_gap)

layer_positions(regulations, x=0)
layer_positions(principles, x=3)
layer_positions(ai_scopes, x=6)
layer_positions(agents, x=9)

# -----------------------------
# DRAW HELPERS
# -----------------------------
def draw_layer(node_type, color, shape):
    ns = [n for n, d in VG.nodes(data=True) if d["node_type"] == node_type]
    nx.draw_networkx_nodes(
        VG,
        pos,
        nodelist=ns,
        node_color=color,
        node_shape=shape,
        node_size=2200,
        alpha=0.95
    )

plt.figure(figsize=(18, 10))

draw_layer("Regulation", "#AED6F1", "s")
draw_layer("Principle", "#ABEBC6", "o")
draw_layer("AI_Scope", "#F9E79F", "D")
draw_layer("Agent", "#F5B7B1", "h")

nx.draw_networkx_edges(
    VG,
    pos,
    arrows=True,
    arrowstyle="->",
    width=1.5,
    alpha=0.6
)

nx.draw_networkx_labels(
    VG,
    pos,
    font_size=9
)

# -----------------------------
# LEGEND
# -----------------------------
legend = [
    plt.Line2D([0], [0], marker="s", color="w", label="Regulation",
               markerfacecolor="#AED6F1", markersize=12),
    plt.Line2D([0], [0], marker="o", color="w", label="Principle",
               markerfacecolor="#ABEBC6", markersize=12),
    plt.Line2D([0], [0], marker="D", color="w", label="AI Scope",
               markerfacecolor="#F9E79F", markersize=12),
    plt.Line2D([0], [0], marker="h", color="w", label="Agent",
               markerfacecolor="#F5B7B1", markersize=12),
]

plt.legend(handles=legend, loc="upper center", ncol=4)
plt.title(
    "Policy Knowledge Graph – Agentic AI Governance (Clean View)",
    fontsize=14
)
plt.axis("off")
plt.tight_layout()
plt.savefig(OUTPUT_PNG, dpi=300)
plt.close()

print(f"Clean policy graph saved to: {OUTPUT_PNG}")
print(f"Nodes visualized: {VG.number_of_nodes()}")
print(f"Edges visualized (derived): {VG.number_of_edges()}")
