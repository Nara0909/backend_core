import pickle
from pathlib import Path

# -----------------------------
# LOAD GRAPH
# -----------------------------
BASE_DIR = Path(__file__).resolve().parent.parent.parent
GRAPH_PATH = BASE_DIR / "policy_graph" / "policy_graph.pkl"

with open(GRAPH_PATH, "rb") as f:
    G = pickle.load(f)

# -----------------------------
# AI Scope → Agent mapping
# -----------------------------
AI_SCOPE_TO_AGENT = {
    "AI_Privacy_Control": "PrivacyAgent",
    "AI_Access_Control": "AccessControlAgent",
    "AI_Governance": "AuditAgent",
    "AI_Explainability": "OutputGuardAgent",
    "General_Governance": "PolicyAgent",
}

# -----------------------------
# CORE QUERIES
# -----------------------------
def get_principles_for_regulation(regulation: str):
    return [
        n for n in G.successors(regulation)
        if G.nodes[n].get("node_type") == "Principle"
    ]


def get_ai_scopes_for_principle(principle: str):
    return [
        n for n in G.successors(principle)
        if G.nodes[n].get("node_type") == "AI_Scope"
    ]


def get_agents_for_scope(scope: str):
    return [
        n for n in G.successors(scope)
        if G.nodes[n].get("node_type") == "Agent"
    ]


def get_enforcing_agents(regulation: str):
    """
    Returns a list of agents enforcing a regulation
    """
    agents = set()

    for principle in get_principles_for_regulation(regulation):
        for scope in get_ai_scopes_for_principle(principle):
            for agent in get_agents_for_scope(scope):
                agents.add(agent)

    return sorted(agents)


def get_enforcing_agents_with_policies(regulation: str):
    """
    Returns:
    {
        agent_name: [
            {
                regulation,
                article,
                principle,
                requirement,
                policy_rule_id
            }
        ]
    }
    """
    agent_policy_map = {}

    for node, data in G.nodes(data=True):
        if data.get("node_type") != "PolicyRule":
            continue

        # Ensure this rule belongs to the regulation
        parents = list(G.predecessors(node))
        if regulation not in parents:
            continue

        ai_scope = data.get("ai_scope", "General_Governance")
        agent = AI_SCOPE_TO_AGENT.get(ai_scope, "PolicyAgent")

        agent_policy_map.setdefault(agent, []).append({
            "policy_rule_id": node,
            "regulation": regulation,
            "article": node.split(":")[1],
            "principle": data.get("principle"),
            "requirement": data.get("requirement"),
            # include region applicability from policy node (may be None)
            "region_applicability": data.get("region_applicability"),
        })

    return agent_policy_map
