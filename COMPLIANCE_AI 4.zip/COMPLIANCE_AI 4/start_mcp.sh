#!/bin/bash

# MCP Server Quick Start

echo "🚀 Healthcare Compliance AI - MCP Server Quick Start"
echo "=================================================="
echo ""

# Check if Python is installed
if ! command -v python &> /dev/null; then
    echo "❌ Python is not installed. Please install Python 3.8+"
    exit 1
fi

echo "✅ Python found"
echo ""

# Check if mcp package is installed
python -c "import mcp" 2>/dev/null
if [ $? -ne 0 ]; then
    echo "📦 Installing MCP package..."
    pip install mcp
    echo "✅ MCP package installed"
else
    echo "✅ MCP package already installed"
fi

echo ""
echo "📋 MCP Server Configuration for Claude:"
echo "========================================"
echo ""
echo "1. Open Claude (desktop or web app)"
echo "2. Go to: Settings → Developer → Model Context Protocol"
echo "3. Click: Add MCP Server"
echo "4. Fill in:"
echo "   Name: Healthcare Compliance"
echo "   Type: Command"
echo "   Command: python"
echo "   Args: $(pwd)/mcp_server.py"
echo ""
echo "5. Click: Add"
echo "6. Restart Claude"
echo ""

echo "✅ Configuration complete!"
echo ""
echo "🔗 You can now ask Claude questions like:"
echo "   'Check what regulations apply to patient triage'"
echo "   'Mask PII from this patient information'"
echo "   'Show me compliance violations for user clinician_001'"
echo ""

# Optional: Test the MCP server
read -p "Would you like to test the MCP server now? (y/n) " -n 1 -r
echo
if [[ $REPLY =~ ^[Yy]$ ]]; then
    echo ""
    echo "🧪 Testing MCP Server..."
    echo "================================"
    python mcp_server.py
fi
