# MCP Deployment Guide

## System Requirements

- Python 3.8+
- FastAPI backend running on port 8000
- Claude (desktop or web)
- 512MB RAM minimum

## Installation Steps

### 1. Install Dependencies
```bash
cd COMPLIANCE_AI
pip install -r requirements.txt
```

### 2. Start Backend
```bash
./start_backend.sh
# Backend runs on http://localhost:8000
# Verify: curl http://localhost:8000/api/health
```

### 3. Configure Claude (One-time Setup)

**Desktop Claude:**
1. Click user profile (top-left)
2. Settings → Developer → Model Context Protocol
3. Click "Add MCP Server"
4. Enter:
   - Name: `Healthcare Compliance`
   - Type: `Command`
   - Command: `python`
   - Args: `/path/to/COMPLIANCE_AI/mcp_server.py`
5. Click "Add"
6. Restart Claude

**Web Claude:**
1. Settings → Developer (if available)
2. Follow same steps as Desktop
3. Refresh page

### 4. Verify Installation

In Claude, type:
```
What compliance tools are available to you?
```

You should see:
- ✅ get_enforcement_plan
- ✅ check_access
- ✅ mask_pii
- ✅ sanitize_output
- ✅ log_compliance_action

## Usage

### Via Claude (Recommended)
```
User: I need to process patient data safely. 
Can you help with triage?

Claude will automatically:
1. Check regulations (get_enforcement_plan)
2. Verify your access (check_access)
3. Mask patient PII (mask_pii)
4. Process safely
5. Verify output (sanitize_output)
6. Log action (log_compliance_action)
```

### Via Python
```python
import asyncio
from mcp_client import create_mcp_client

async def main():
    client = create_mcp_client()
    plan = await client.get_enforcement_plan("triage")
    print(f"Regulations: {plan['regulations']}")

asyncio.run(main())
```

### Via Streamlit Frontend
```bash
./start_frontend.sh
# Opens http://localhost:8501
# Can use compliance tools through UI
```

## Architecture

```
Claude/AI ←→ MCP Server ←→ Backend API ←→ Compliance Tools
(stdio)          (mcp_server.py)    (REST)      (security/)
```

## Compliance Flow

1. **Request** → MCP Tool
2. **Tool** → Backend API
3. **Backend** → Security Function
4. **Result** → MCP Response
5. **Claude** → Uses result safely

## Tools Available

### get_enforcement_plan(request_type)
Returns applicable regulations for request type

```json
{
  "request_type": "triage",
  "regulations": ["HIPAA", "GDPR"],
  "agents": ["AccessControl", "Privacy", "OutputGuard"]
}
```

### check_access(user_id, user_role, patient_id, resource_type)
Verifies user has access to resource

```json
{
  "access_granted": true,
  "reason": "Clinician has permission",
  "regulations": ["HIPAA"]
}
```

### mask_pii(text)
Detects and masks sensitive information

```json
{
  "masked_text": "Patient [NAME] SSN [SSN]",
  "pii_detected": [
    {"type": "NAME", "masked_as": "[NAME]"},
    {"type": "SSN", "masked_as": "[SSN]"}
  ]
}
```

### sanitize_output(text)
Ensures no PII in LLM output

```json
{
  "sanitized_text": "Patient has respiratory symptoms",
  "safe_to_store": true,
  "pii_detected": []
}
```

### log_compliance_action(user_id, action, resource, outcome, details)
Creates audit record

```json
{
  "audit_id": "550e8400-e29b-41d4-a716-446655440000",
  "timestamp": "2025-12-17T10:30:00Z",
  "regulations_logged": ["HIPAA"]
}
```

## Security Considerations

- ✅ All tools enforce access control
- ✅ All calls are audited
- ✅ PII never reaches Claude unmasked
- ✅ Regulations are enforced
- ✅ Violations are logged

## Troubleshooting

### Issue: Claude doesn't see MCP server
**Solution:**
1. Verify path in Claude settings
2. Test command: `python /path/to/mcp_server.py`
3. Restart Claude
4. Check Claude console for errors

### Issue: Tools timeout
**Solution:**
1. Verify backend running: `curl http://localhost:8000/api/health`
2. Check network connectivity
3. Verify port 8000 is accessible

### Issue: Permission denied
**Solution:**
1. Make script executable: `chmod +x mcp_server.py`
2. Check Python permissions
3. Verify Python path in Claude settings

### Issue: Backend errors
**Solution:**
1. Check backend logs: `tail -f backend.log`
2. Verify compliance endpoints: `curl http://localhost:8000/api/enforcement-plan?request_type=triage`
3. Ensure security modules are available

## Monitoring

### Check MCP Server Health
```bash
# Terminal window
python mcp_server.py
# Should show: Healthcare Compliance MCP Server starting...
```

### Check Backend Health
```bash
curl http://localhost:8000/api/enforcement-plan?request_type=triage
# Should return JSON with regulations
```

### Check Claude Connection
In Claude: "What tools do you have access to?"
Should list all 5 compliance tools

## Performance

- Tool calls: ~100-500ms (depends on backend)
- No caching (each call fresh)
- No rate limiting (configure as needed)
- Async/await ready

## Scaling

For multiple Claude instances:
1. Single MCP server handles multiple connections
2. Backend automatically load-balanced
3. Database connection pooling ready
4. Audit logging scales linearly

## Maintenance

### Daily
- Monitor compliance violations
- Review audit logs
- Check backend health

### Weekly
- Verify all tools working
- Test Claude integration
- Review policy updates

### Monthly
- Audit tool usage
- Performance analysis
- Security review

## Backup & Recovery

### Database Backup
```bash
# Backup audit logs
sqlite3 compliance_frontend.db ".backup backup.db"

# Or with PostgreSQL
pg_dump compliance_db > backup.sql
```

### Configuration Backup
```bash
# Backup MCP config
cp mcp_config.json mcp_config.backup.json

# Backup Claude settings (manual)
Export from Claude settings
```

## Disaster Recovery

If MCP server crashes:
1. Restart: `python mcp_server.py`
2. Check backend still running
3. Verify in Claude

If backend crashes:
1. Restart: `./start_backend.sh`
2. Verify: `curl http://localhost:8000/api/health`
3. MCP will reconnect automatically

## Cost Estimation

- Server: Free (self-hosted)
- Storage: ~10MB/month (audit logs)
- Bandwidth: <1MB/month (internal)
- Claude: Standard API pricing

## Future Enhancements

- [ ] Real-time compliance alerts
- [ ] Policy hot-swapping
- [ ] Performance monitoring dashboard
- [ ] Automated policy updates
- [ ] Multi-region deployment
- [ ] Advanced audit analytics

## Support

For issues:
1. Check MCP_QUICK_REFERENCE.md
2. Review MCP_INTEGRATION.md
3. Check backend logs
4. Verify Claude settings

---

**Ready to deploy?** Follow the installation steps above!
