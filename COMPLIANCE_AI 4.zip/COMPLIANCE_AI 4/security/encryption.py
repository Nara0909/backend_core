import os
from typing import Optional
from cryptography.fernet import Fernet, InvalidToken

ENV_KEY = "APP_ENCRYPTION_KEY"  # base64 urlsafe key; generate via Fernet.generate_key()


def get_fernet() -> Fernet:
    key = os.getenv(ENV_KEY)
    if not key:
        raise RuntimeError(f"Missing encryption key env: {ENV_KEY}")
    return Fernet(key.encode() if not key.startswith("gAAAA") else key)


def encrypt_bytes(data: bytes) -> bytes:
    return get_fernet().encrypt(data)


def decrypt_bytes(token: bytes) -> bytes:
    return get_fernet().decrypt(token)


def encrypt_text(text: str) -> str:
    return encrypt_bytes(text.encode()).decode()


def decrypt_text(token: str) -> str:
    return decrypt_bytes(token.encode()).decode()


def try_decrypt_text(token: str) -> Optional[str]:
    try:
        return decrypt_text(token)
    except (InvalidToken, Exception):
        return None
