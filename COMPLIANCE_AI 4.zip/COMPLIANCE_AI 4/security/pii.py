import re
from typing import List, Dict, Any, Tuple

EMAIL_RE = re.compile(r"[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}")

# Common North American phone formats (very simple)
PHONE_RE = re.compile(r"(?:(?:\+?1[\s.-]?)?(?:\(\d{3}\)|\d{3})[\s.-]?\d{3}[\s.-]?\d{4})")

# Very simple SSN pattern (US)
SSN_RE = re.compile(r"\b\d{3}-\d{2}-\d{4}\b")

# Name patterns - detect common name formats
NAME_PATTERNS = [
    re.compile(r'(?:Patient|Dr\.|Doctor|Mr\.|Mrs\.|Ms\.)\s+([A-Z][a-z]+(?:\s+[A-Z][a-z]+)+)'),
    re.compile(r'\b([A-Z][a-z]+\s+[A-Z][a-z]+)\b(?=\s*,|\s*\(|\s+DOB|\s+SSN)')
]


def detect_pii(text: str) -> List[Dict[str, Any]]:
    """
    Detect PII entities in text and return detailed information.
    
    Returns:
        List of dictionaries with 'type', 'value', and 'masked' keys
    """
    if not isinstance(text, str) or not text:
        return []
    
    pii_found = []
    
    # Detect SSN
    for match in SSN_RE.finditer(text):
        pii_found.append({
            "type": "SSN",
            "value": match.group(),
            "masked": "[SSN]"
        })
    
    # Detect Email
    for match in EMAIL_RE.finditer(text):
        pii_found.append({
            "type": "EMAIL",
            "value": match.group(),
            "masked": "[EMAIL]"
        })
    
    # Detect Phone
    for match in PHONE_RE.finditer(text):
        pii_found.append({
            "type": "PHONE",
            "value": match.group(),
            "masked": "[PHONE]"
        })
    
    # Detect Names
    for pattern in NAME_PATTERNS:
        for match in pattern.finditer(text):
            name = match.group(1) if match.groups() else match.group()
            # Only add if it's a full name (at least 2 words)
            if len(name.split()) >= 2:
                # Avoid duplicates
                if not any(pii['value'] == name for pii in pii_found):
                    pii_found.append({
                        "type": "NAME",
                        "value": name,
                        "masked": "[NAME]"
                    })
    
    return pii_found


def redact_text(text: str) -> str:
    """Best-effort deterministic redaction for common PII tokens.

    Replaces:
    - Emails with [EMAIL]
    - Phone numbers with [PHONE]
    - SSN patterns with [SSN]
    - Names with [NAME]

    Note: This is a baseline; extend with NLP where needed.
    """
    if not isinstance(text, str) or not text:
        return text

    out = text
    
    # Get all PII detected
    pii_entities = detect_pii(text)
    
    # Replace each PII with its masked version
    for pii in pii_entities:
        out = out.replace(pii['value'], pii['masked'])
    
    return out


def redact_and_detect(text: str) -> Tuple[str, List[Dict[str, Any]]]:
    """
    Redact PII and return both the redacted text and list of detected PII.
    
    Returns:
        Tuple of (redacted_text, pii_detected_list)
    """
    if not isinstance(text, str) or not text:
        return text, []
    
    pii_entities = detect_pii(text)
    redacted = text
    
    for pii in pii_entities:
        redacted = redacted.replace(pii['value'], pii['masked'])
    
    return redacted, pii_entities
