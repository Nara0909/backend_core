from .pii import redact_text


def tokenize_text(text: str) -> str:
    """Placeholder: In this project, tokenization step applies de-identification.
    Extend to perform true tokenization if needed.
    """
    return redact_text(text)
