#!/usr/bin/env bash

# Simple Backend Startup Script
# Starts FastAPI backend on localhost:8000

echo "🚀 Starting Healthcare Compliance Backend..."
echo ""

# Change to project directory
cd "$(dirname "$0")" || exit 1

# Kill any existing process on port 8000
echo "🧹 Cleaning up port 8000..."
lsof -ti :8000 | xargs kill -9 2>/dev/null || true

sleep 1

# Start backend
echo "📡 Starting FastAPI server on 127.0.0.1:8000..."
python3 -m uvicorn app.main:app --host 127.0.0.1 --port 8000 --reload

# If we get here, server stopped
echo ""
echo "❌ Backend stopped"
