# Model Context Protocol (MCP) Integration

## Overview

The Healthcare Compliance AI system is integrated with **Model Context Protocol (MCP)**, enabling Claude and other AI systems to directly interact with compliance infrastructure.

## Architecture

```
┌─────────────────────────────────────────────────────┐
│  Claude or other AI System                          │
│  (with MCP client configured)                       │
└──────────────────┬──────────────────────────────────┘
                   │
                   │ MCP Protocol (stdio)
                   │
┌──────────────────▼──────────────────────────────────┐
│  MCP Server (mcp_server.py)                         │
│  - Exposes compliance tools                         │
│  - Exposes audit resources                          │
│  - Handles protocol communication                   │
└──────────────────┬──────────────────────────────────┘
                   │
                   │ HTTP REST API
                   │
┌──────────────────▼──────────────────────────────────┐
│  Backend Compliance Middleware (FastAPI)            │
│  - Access control, PII masking, output guard        │
└─────────────────────────────────────────────────────┘
```

## MCP Tools

AI systems can call these compliance tools:

### 1. `get_enforcement_plan`
Get applicable regulations and agents for a request type.

**Parameters:**
- `request_type` (string): "triage", "scheduling", "referral", "diagnosis", "monitoring"

**Returns:**
```json
{
  "regulations": ["HIPAA", "GDPR"],
  "agents": ["AccessControl", "Privacy", "OutputGuard"],
  "enforcement_plan": {...}
}
```

**Example Usage in Claude:**
```
I need to process a patient triage request. Let me first check what regulations apply.
→ Uses: get_enforcement_plan("triage")
→ Gets: HIPAA and GDPR regulations apply
```

### 2. `check_access`
Verify if a user has access to a resource.

**Parameters:**
- `user_id` (string): User identifier
- `user_role` (string): "clinician", "specialist", "admin", "nurse", "patient"
- `patient_id` (string): Patient identifier
- `resource_type` (string, optional): "patient_data", "ehr", "billing"

**Returns:**
```json
{
  "access_granted": true,
  "reason": "Clinician has permission",
  "regulations": ["HIPAA"]
}
```

**Example Usage in Claude:**
```
Before processing patient data, I should verify Dr. Smith has access.
→ Uses: check_access("dr_smith", "clinician", "P12345", "patient_data")
→ Gets: Access granted ✅
```

### 3. `mask_pii`
Detect and mask PII (SSN, email, phone, names) in text.

**Parameters:**
- `text` (string): Input text to mask

**Returns:**
```json
{
  "masked_text": "Patient [NAME] with SSN [SSN] has fever",
  "pii_detected": [
    {"type": "NAME", "masked_as": "[NAME]"},
    {"type": "SSN", "masked_as": "[SSN]"}
  ],
  "pii_count": 2
}
```

**Example Usage in Claude:**
```
I need to prepare patient data for LLM processing. Let me mask PII first.
→ Uses: mask_pii("Patient Jane Doe SSN 123-45-6789 with fever")
→ Gets: Masked text with PII replaced
→ Never sends PII to LLM
```

### 4. `sanitize_output`
Ensure LLM output doesn't contain PII.

**Parameters:**
- `text` (string): LLM output to sanitize

**Returns:**
```json
{
  "sanitized_text": "Patient presents with respiratory symptoms",
  "safe_to_store": true,
  "pii_detected": [],
  "pii_found": false
}
```

**Example Usage in Claude:**
```
Before storing the LLM response, I should check for any PII leakage.
→ Uses: sanitize_output(llm_response)
→ Gets: safe_to_store = true
→ Can store in database
```

### 5. `log_compliance_action`
Create an audit record for compliance actions.

**Parameters:**
- `user_id` (string): User performing action
- `action` (string): "triage_decision", "access_check", "pii_masking"
- `resource` (string): "patient", "patient_data", "ehr"
- `outcome` (string): "success", "denied", "error"
- `details` (string, optional): Additional context as JSON string

**Returns:**
```json
{
  "audit_id": "550e8400-e29b-41d4-a716-446655440000",
  "timestamp": "2025-12-17T10:30:00Z",
  "regulations_logged": ["HIPAA", "GDPR"]
}
```

**Example Usage in Claude:**
```
After processing the request successfully, log the compliance action.
→ Uses: log_compliance_action("clinician_001", "triage_decision", "patient", "success", "{\"confidence\": 0.95}")
→ Gets: Audit record created
```

## MCP Resources

AI systems can query these resources:

### `audit_log://user/{user_id}`
Get audit logs for a specific user.

```
claude> I need to see what actions Dr. Smith has performed.
→ Queries: audit_log://user/dr_smith
→ Returns: All audit records for this user
```

### `audit_log://patient/{patient_id}`
Get all access to a patient's data.

```
claude> Show me who has accessed patient P12345's data.
→ Queries: audit_log://patient/P12345
→ Returns: Complete access audit trail
```

### `compliance_violations://`
Get recent compliance violations.

```
claude> Are there any compliance violations I should know about?
→ Queries: compliance_violations://
→ Returns: List of violations with details
```

### `patient_ehr://{patient_id}`
Get patient's electronic health record.

```
claude> What's the medical history for patient P12345?
→ Queries: patient_ehr://P12345
→ Returns: Medical conditions, medications, allergies (access-controlled)
```

### `enforcement_plans://`
List all available enforcement plans.

```
claude> What enforcement plans are configured?
→ Queries: enforcement_plans://
→ Returns: All request types and their regulations
```

## Integration with Claude

### Step 1: Configure MCP Server in Claude

1. Open Claude settings
2. Go to "Developer" → "Model Context Protocol"
3. Add new MCP server:
   - **Name:** Healthcare Compliance
   - **Type:** Command
   - **Command:** `python /path/to/mcp_server.py`

### Step 2: Verify Connection

In Claude, you should see compliance tools available:

```
You have access to the following MCP tools:
- get_enforcement_plan
- check_access
- mask_pii
- sanitize_output
- log_compliance_action
```

### Step 3: Use in Conversations

```
claude> I need to help with a patient triage decision.

Before I proceed, let me verify compliance requirements:
1. Get the enforcement plan
2. Check your access
3. Mask the patient data
4. Generate the decision
5. Sanitize the output
6. Log the action

[Claude will automatically call the appropriate MCP tools]
```

## Usage Examples

### Example 1: Clinical Triage with Compliance

```
Claude: I need to help with patient triage.

Workflow:
1. get_enforcement_plan("triage")
   → Regulations: HIPAA, GDPR
   
2. check_access("clinician_001", "clinician", "P12345", "patient_data")
   → Access: Granted ✅
   
3. mask_pii("Patient Jane Doe, SSN 123-45-6789, fever for 3 days")
   → Result: "Patient [NAME], SSN [SSN], fever for 3 days"
   
4. [Process with LLM using masked data]
   
5. sanitize_output(llm_response)
   → Safety: Safe to store ✅
   
6. log_compliance_action(...)
   → Audit: Logged ✅

Result: Compliant clinical decision with full audit trail
```

### Example 2: Audit Investigation

```
Claude: Show me all compliance violations in the last week.

1. compliance_violations://
   → Returns: List of violations
   
2. For each violation:
   audit_log://user/{user_id}
   audit_log://patient/{patient_id}
   → Returns: Detailed access patterns

Analysis: Can identify compliance issues and patterns
```

### Example 3: Patient Data Access

```
Claude: What's the medical history for patient P12345?

1. patient_ehr://P12345
   [Access controlled based on user role]
   → Returns: Medical conditions, medications, allergies
   
2. audit_log://patient/P12345
   → Returns: Who accessed this patient's data and when

Analysis: Patient EHR with complete audit trail
```

## Using MCP Client Programmatically

```python
from mcp_client import create_mcp_client

client = create_mcp_client()

# Check enforcement plan
plan = await client.get_enforcement_plan("triage")
print(f"Applicable regulations: {plan['regulations']}")

# Check access
access = await client.check_access("clinician_001", "clinician", "P12345")
if access['access_granted']:
    # Mask PII
    masked = await client.mask_pii(patient_input)
    print(f"Masked text: {masked['masked_text']}")
    
    # Process with LLM
    llm_output = generate_decision(masked['masked_text'])
    
    # Sanitize output
    sanitized = await client.sanitize_output(llm_output)
    if sanitized['safe_to_store']:
        # Log action
        await client.log_compliance_action(
            "clinician_001",
            "triage_decision",
            "patient",
            "success"
        )
```

## Integrating MCP with LangGraph

In `frontend/healthcare_compliance_agent.py`, you can use MCP tools:

```python
# Instead of direct HTTP calls:
result = self.backend.mask_pii(text)

# Use MCP:
result = await self.mcp_client.mask_pii(text)
```

This provides:
- Standardized tool interface
- Better error handling
- Resource-based data access
- Integration with other MCP servers

## Security Considerations

1. **Tool Authorization**: Only expose tools based on user role
2. **Resource Access Control**: Filter resources by user permissions
3. **Audit Logging**: All MCP tool calls are logged
4. **Data Minimization**: Never expose more data than necessary
5. **Protocol Security**: Use authenticated transport (HTTPS/TLS) in production

## Troubleshooting

### MCP Server Not Starting
```bash
# Check if Python and mcp_server.py are correct
python mcp_server.py

# Should print:
# Healthcare Compliance MCP Server
# Available MCP Tools: ...
```

### Claude Can't See Tools
1. Verify MCP server path in Claude settings
2. Check command runs successfully: `python /path/to/mcp_server.py`
3. Restart Claude
4. Check Claude console for MCP errors

### Tools Timing Out
1. Ensure backend is running: `python -m uvicorn app.main:app --port 8000`
2. Check network connectivity
3. Increase timeout in mcp_server.py if needed

## Future Enhancements

1. **Multi-Regulation Support**: Tools aware of different regulation contexts
2. **Decision Recording**: Store AI-generated decisions in HIPAA-compliant database
3. **Real-time Alerts**: MCP resources for active compliance violations
4. **Policy Updates**: Push policy changes to AI systems via MCP
5. **Multi-Agent Collaboration**: MCP servers coordinating multiple AI agents
6. **Custom Tool Development**: Allow healthcare applications to add MCP tools

## References

- [Model Context Protocol Specification](https://spec.modelcontextprotocol.io/)
- [Claude MCP Documentation](https://docs.anthropic.com/en/docs/model-context-protocol/overview)
- [Healthcare Compliance Architecture](./FRONTEND_AI_ARCHITECTURE.md)
- [LangGraph Integration](./frontend/README.md)
