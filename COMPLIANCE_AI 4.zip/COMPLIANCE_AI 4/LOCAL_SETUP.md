# LOCAL MCP SETUP - NO HOSTING REQUIRED

## Quick Start (30 seconds)

```bash
cd COMPLIANCE_AI
python local_setup.py
```

That's it! All services run locally at:
- 🌐 **Streamlit UI**: http://127.0.0.1:8501
- 📡 **Backend API**: http://127.0.0.1:8000
- 📡 **API Docs**: http://127.0.0.1:8000/docs

## What Gets Started

### 1. Backend API (Port 8000)
- FastAPI compliance middleware
- 5 REST endpoints for compliance operations
- Stateless - no database required for backend
- Health check: `curl http://127.0.0.1:8000/api/enforcement-plan?request_type=triage`

### 2. Frontend UI (Port 8501)
- Streamlit interface
- LangGraph orchestration
- SQLite database for audit logs (local)
- 4 tabs: Triage, Dashboard, Audit, Settings

### 3. MCP Server (Local)
- Model Context Protocol for AI integration
- 5 compliance tools available
- Runs in local process (not a service)
- Optional - can test without it

## System Architecture

```
Local Machine
├── Backend (127.0.0.1:8000)
│   ├── app/main.py
│   ├── security/pii.py
│   └── security/access_control.py
│
├── Frontend (127.0.0.1:8501)
│   ├── ui/app.py
│   ├── frontend/healthcare_compliance_agent.py
│   ├── frontend/backend_client.py
│   └── compliance_frontend.db (local SQLite)
│
└── MCP Server (local process)
    ├── mcp_server.py
    └── 5 tools available
```

## Usage

### 1. Using Web UI

1. Open http://127.0.0.1:8501
2. Go to **Clinical Triage** tab
3. Enter patient info:
   - User ID: `dr_smith`
   - User Role: `clinician`
   - Patient ID: `patient_123`
   - Request: `Patient has fever and cough`
   - Type: `triage`
4. Click "Process Request"
5. See compliance checks in real-time

### 2. Testing MCP Tools

Open another terminal:

```bash
cd COMPLIANCE_AI
python test_mcp_local.py
```

This tests all 5 tools without Claude.

### 3. Manual API Calls

```bash
# Get enforcement plan
curl "http://127.0.0.1:8000/api/enforcement-plan?request_type=triage"

# Check access
curl -X POST "http://127.0.0.1:8000/api/check-access" \
  -H "Content-Type: application/json" \
  -d '{
    "user_id": "dr_smith",
    "user_role": "clinician",
    "patient_id": "patient_123",
    "resource_type": "ehr"
  }'

# Mask PII
curl -X POST "http://127.0.0.1:8000/api/mask-pii" \
  -H "Content-Type: application/json" \
  -d '{
    "text": "Patient John Doe (SSN: 123-45-6789) has pneumonia"
  }'

# View API Docs
open http://127.0.0.1:8000/docs
```

### 4. Using Python Client

```python
import asyncio
from mcp_client import create_mcp_client

async def main():
    # Create client (connects to local backend)
    client = create_mcp_client()
    
    # Call a tool
    plan = await client.get_enforcement_plan("triage")
    print(f"Regulations: {plan['regulations']}")
    
    # Check access
    access = await client.check_access(
        user_id="dr_smith",
        user_role="clinician",
        patient_id="patient_123",
        resource_type="ehr"
    )
    print(f"Access granted: {access['access_granted']}")

asyncio.run(main())
```

## File Locations

```
COMPLIANCE_AI/
├── app/main.py                          # Backend API
├── ui/app.py                            # Frontend UI
├── frontend/
│   ├── healthcare_compliance_agent.py   # LangGraph orchestration
│   ├── backend_client.py                # HTTP client
│   └── database.py                      # SQLAlchemy models
├── security/
│   ├── pii.py                          # PII detection
│   └── access_control.py               # Access checks
├── mcp_server.py                        # MCP server
├── mcp_client.py                        # MCP client
├── local_setup.py                       # Local startup script
└── test_mcp_local.py                    # Tool testing script
```

## Database (Local SQLite)

Frontend uses local SQLite database:
- Location: `compliance_frontend.db`
- Tables:
  - `audit_log`: All compliance actions
  - `clinical_decision`: Triage decisions
  - `patient_ehr`: Medical records
  - `compliance_event`: Violations/warnings

All stored locally, no cloud required.

## Requirements

Just install once:

```bash
pip install -r requirements.txt
```

Required packages:
- `fastapi` - Backend API
- `uvicorn` - Backend server
- `streamlit` - Frontend UI
- `langgraph` - Workflow orchestration
- `langchain` - LLM integration
- `sqlalchemy` - Database ORM
- `mcp` - Model Context Protocol
- `pydantic` - Data validation

## Troubleshooting

### Port Already in Use

If port 8000 or 8501 is already in use:

```bash
# Check what's running
lsof -i :8000
lsof -i :8501

# Kill process on port 8000
kill -9 $(lsof -t -i :8000)

# Or modify local_setup.py to use different ports
```

### Backend won't start

```bash
# Test manually
cd COMPLIANCE_AI
python -m uvicorn app.main:app --host 127.0.0.1 --port 8000

# Check for errors in output
# Common: missing imports, PYTHONPATH issues
```

### Frontend won't start

```bash
# Test manually
cd COMPLIANCE_AI
streamlit run ui/app.py --server.port=8501 --server.address=127.0.0.1

# Check for errors in output
# Common: database connection, missing modules
```

### MCP tools not responding

```bash
# Verify backend is running
curl http://127.0.0.1:8000/api/health

# Test a tool directly
python test_mcp_local.py

# Check logs in both terminals
```

## Performance

All local, so:
- ⚡ Fast (no network latency)
- 🔒 Secure (no internet required)
- 🆓 Free (no API costs)
- 📊 Full control (local data)

Typical performance:
- Tool calls: 10-100ms
- UI response: <1 second
- Database queries: <50ms

## Next Steps

1. **Test Backend**: `curl http://127.0.0.1:8000/docs`
2. **Test Frontend**: Open http://127.0.0.1:8501
3. **Test Tools**: `python test_mcp_local.py`
4. **Use in Claude**: Follow MCP_INTEGRATION.md (optional)

## Stopping Services

Press `Ctrl+C` in the terminal where `local_setup.py` is running.

All processes will be cleanly terminated.

## Advanced Usage

### Using Different Backend

If you want to connect to a remote backend:

```python
# In test_mcp_local.py or frontend code
client = LocalMCPClient(backend_url="http://your-server:8000")
```

### Custom Ports

Edit `local_setup.py` to change ports:

```python
backend_cmd = [
    sys.executable, "-m", "uvicorn",
    "app.main:app",
    "--host", "127.0.0.1",
    "--port", "9000"  # Changed from 8000
]
```

### Running Components Separately

```bash
# Terminal 1: Backend only
python -m uvicorn app.main:app --host 127.0.0.1 --port 8000

# Terminal 2: Frontend only
streamlit run ui/app.py --server.port=8501

# Terminal 3: Test tools
python test_mcp_local.py
```

## Integration with Claude

To use MCP tools in Claude (optional):

1. Save `mcp_server.py` path
2. Open Claude Desktop
3. Settings → Developer → MCP Servers
4. Add server:
   - Name: `Healthcare Compliance`
   - Command: `python`
   - Args: `/full/path/to/mcp_server.py`
5. Restart Claude
6. Test: "What compliance tools do you have?"

## Production Deployment

For production, see [MCP_DEPLOYMENT.md](MCP_DEPLOYMENT.md).

For now, local setup is perfect for:
- Development
- Testing
- Demonstrations
- Learning

---

**Ready to start?**

```bash
python local_setup.py
```

Then open http://127.0.0.1:8501 🚀
