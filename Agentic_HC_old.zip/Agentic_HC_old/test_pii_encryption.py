#!/usr/bin/env python3
"""
Test script to verify PII encryption implementation
Run this to validate that encryption/decryption works correctly
"""

import sys
import os

# Add SyntheticDataGenerator to path
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "SyntheticDataGenerator"))

from user_db import encrypt_pii, decrypt_pii, get_or_create_encryption_key

def test_encryption():
    """Test PII encryption and decryption"""
    
    print("=" * 60)
    print("PII ENCRYPTION TEST SUITE")
    print("=" * 60)
    
    # Test 1: Key loading
    print("\n[TEST 1] Encryption Key Loading")
    print("-" * 60)
    try:
        key = get_or_create_encryption_key()
        print(f"✅ Key loaded successfully")
        print(f"   Key length: {len(key)} bytes")
        print(f"   Key type: {type(key)}")
    except Exception as e:
        print(f"❌ Key loading failed: {e}")
        return False
    
    # Test 2: Email encryption
    print("\n[TEST 2] Email Encryption")
    print("-" * 60)
    test_email = "john.doe@example.com"
    try:
        encrypted_email = encrypt_pii(test_email)
        print(f"✅ Email encrypted successfully")
        print(f"   Original: {test_email}")
        print(f"   Encrypted: {encrypted_email[:40]}...")
        print(f"   Encrypted length: {len(encrypted_email)} chars")
    except Exception as e:
        print(f"❌ Email encryption failed: {e}")
        return False
    
    # Test 3: Email decryption
    print("\n[TEST 3] Email Decryption")
    print("-" * 60)
    try:
        decrypted_email = decrypt_pii(encrypted_email)
        print(f"✅ Email decrypted successfully")
        print(f"   Encrypted: {encrypted_email[:40]}...")
        print(f"   Decrypted: {decrypted_email}")
        
        if decrypted_email == test_email:
            print(f"   ✅ Decryption matches original!")
        else:
            print(f"   ❌ Decryption does NOT match original!")
            return False
    except Exception as e:
        print(f"❌ Email decryption failed: {e}")
        return False
    
    # Test 4: Phone encryption
    print("\n[TEST 4] Phone Encryption")
    print("-" * 60)
    test_phone = "555-0123"
    try:
        encrypted_phone = encrypt_pii(test_phone)
        print(f"✅ Phone encrypted successfully")
        print(f"   Original: {test_phone}")
        print(f"   Encrypted: {encrypted_phone[:40]}...")
    except Exception as e:
        print(f"❌ Phone encryption failed: {e}")
        return False
    
    # Test 5: Phone decryption
    print("\n[TEST 5] Phone Decryption")
    print("-" * 60)
    try:
        decrypted_phone = decrypt_pii(encrypted_phone)
        print(f"✅ Phone decrypted successfully")
        print(f"   Encrypted: {encrypted_phone[:40]}...")
        print(f"   Decrypted: {decrypted_phone}")
        
        if decrypted_phone == test_phone:
            print(f"   ✅ Decryption matches original!")
        else:
            print(f"   ❌ Decryption does NOT match original!")
            return False
    except Exception as e:
        print(f"❌ Phone decryption failed: {e}")
        return False
    
    # Test 6: None/empty handling
    print("\n[TEST 6] None/Empty Value Handling")
    print("-" * 60)
    try:
        none_result = decrypt_pii(None)
        empty_result = decrypt_pii("")
        print(f"✅ None/empty values handled correctly")
        print(f"   None result: {none_result}")
        print(f"   Empty result: {empty_result}")
    except Exception as e:
        print(f"❌ None/empty handling failed: {e}")
        return False
    
    # Test 7: Invalid data handling
    print("\n[TEST 7] Invalid Encrypted Data Handling")
    print("-" * 60)
    try:
        invalid_result = decrypt_pii("invalid-base64-data-xyz123")
        print(f"✅ Invalid data handled gracefully")
        print(f"   Result: {invalid_result}")
    except Exception as e:
        print(f"❌ Invalid data handling failed: {e}")
        return False
    
    print("\n" + "=" * 60)
    print("✅ ALL TESTS PASSED")
    print("=" * 60)
    print("\nImplementation Status:")
    print("  ✅ Encryption working correctly")
    print("  ✅ Decryption working correctly")
    print("  ✅ Key management working correctly")
    print("  ✅ Error handling working correctly")
    print("\nNext Steps:")
    print("  1. Restart the Streamlit app")
    print("  2. Register a new visitor account")
    print("  3. Verify PII is encrypted in database")
    print("  4. Schedule an appointment")
    print("  5. Test PII access via compliance API")
    
    return True

if __name__ == "__main__":
    success = test_encryption()
    sys.exit(0 if success else 1)
