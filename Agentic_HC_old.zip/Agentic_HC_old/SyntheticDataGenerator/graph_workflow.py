"""
LangGraph multi-agent workflow over the synthetic cardiology datasets.
Now extended with a RAG agent and allergy/alternative checks.
"""

from typing import TypedDict, Dict, Any, Optional, List

from langgraph.graph import StateGraph, END

from clinical_data import ClinicalDataStore
from agents import (
    ClinicalQueryAgent,
    DrugInteractionAgent,
    GuidelineAgent,
    SummaryAgent,
    RiskPredictionAgent,
    RagAgent,
)


class ClinicalState(TypedDict, total=False):
    query: str
    patient_id: Optional[str]

    # filled by query agent
    query_analysis: Dict[str, Any]
    intent: str

    # filled by specialist agents
    interaction_result: Dict[str, Any]
    guideline_result: Dict[str, Any]
    risk_prediction_result: Dict[str, Any]
    rag_result: Dict[str, Any]

    # final
    final_answer: str
    debug_info: Dict[str, Any]


query_agent = ClinicalQueryAgent()
interaction_agent = DrugInteractionAgent()
guideline_agent = GuidelineAgent()
risk_prediction_agent = RiskPredictionAgent()
rag_agent = RagAgent()
summary_agent = SummaryAgent()


# ---------- Nodes ----------

def query_node(state: ClinicalState) -> ClinicalState:
    """First node: understand query + infer intent."""
    patient_id = state.get("patient_id")
    ctx = ClinicalDataStore.get_patient_context(patient_id) if patient_id else None

    qa = query_agent.analyze(state["query"], ctx)
    state["query_analysis"] = qa
    state["intent"] = qa.get("intent", "general")

    if "debug_info" not in state:
        state["debug_info"] = {}
    state["debug_info"]["patient_context_present"] = bool(ctx)

    return state


def interaction_node(state: ClinicalState) -> ClinicalState:
    """
    Call the drug interaction agent for this patient
    AND add allergy conflicts + alternative suggestions
    AND a structured medication_safety assessment for proposed drugs.
    """
    patient_id = state.get("patient_id")
    if not patient_id:
        state["interaction_result"] = {"error": "No patient_id provided"}
        return state

    # 1) Get interaction-based assessment from your existing agent
    result = interaction_agent.evaluate_for_patient(patient_id)

    # 2) Figure out which drugs are being considered in this query
    qa = state.get("query_analysis", {}) or {}
    # Depending on your ClinicalQueryAgent, adjust these keys:
    candidate_drugs: List[str] = (
        qa.get("candidate_drugs")
        or qa.get("mentioned_drugs")
        or qa.get("medications")
        or []
    )

    # 3) Allergy conflicts for those candidate drugs
    allergy_conflicts = ClinicalDataStore.find_allergy_conflicts(
        patient_id=patient_id,
        drug_names_or_ids=candidate_drugs,
    )

    # 4) Suggest alternatives for offending drugs
    offending_inputs = [c.get("drug_input") for c in allergy_conflicts]
    offending_inputs = [d for d in offending_inputs if d]  # remove None/empty

    alternative_suggestions = ClinicalDataStore.suggest_alternative_drugs(
        patient_id=patient_id,
        offending_drugs=offending_inputs,
        max_suggestions_per_drug=3,
    )

    # 5) Structured safety assessment for "can I prescribe X?"
    medication_safety = _evaluate_medication_safety(
        patient_id=patient_id,
        candidate_drugs=candidate_drugs,
    )

    # 6) Attach everything into interaction_result so SummaryAgent can see it
    result["candidate_drugs"] = candidate_drugs
    result["allergy_conflicts"] = allergy_conflicts
    result["alternative_suggestions"] = alternative_suggestions
    result["medication_safety"] = medication_safety

    state["interaction_result"] = result
    return state


def guideline_node(state: ClinicalState) -> ClinicalState:
    """Call the guideline agent for this patient."""
    patient_id = state.get("patient_id")
    if not patient_id:
        state["guideline_result"] = {"error": "No patient_id provided"}
        return state

    result = guideline_agent.summarize_for_patient(patient_id)
    state["guideline_result"] = result
    return state


def risk_prediction_node(state: ClinicalState) -> ClinicalState:
    """Call the risk prediction agent for this patient."""
    patient_id = state.get("patient_id")
    if not patient_id:
        state["risk_prediction_result"] = {"error": "No patient_id provided"}
        return state

    # For now, using a default risk topic. This could be extracted from the query.
    risk_topic = "1-year major adverse cardiovascular event (MACE)"
    result = risk_prediction_agent.predict_risk(patient_id, risk_topic)
    state["risk_prediction_result"] = result
    return state


def rag_node(state: ClinicalState) -> ClinicalState:
    """
    Generic RAG node: uses the RagAgent over the synthetic cardiology corpus.
    This is used mainly for 'general' queries that are not clearly
    interaction/guideline.
    """
    result = rag_agent.answer(state["query"])
    state["rag_result"] = result
    return state


def _build_safety_appendix(state: ClinicalState) -> str:
    """
    Build Markdown appendix with allergy conflicts and alternative suggestions,
    to be appended to the final answer.

    IMPORTANT: If a drug has an allergy conflict, this appendix explicitly
    states that it MUST NOT be used, even if earlier guideline logic suggests it.
    """
    interaction_result = state.get("interaction_result", {}) or {}
    allergy_conflicts = interaction_result.get("allergy_conflicts", []) or []
    alternative_suggestions = interaction_result.get("alternative_suggestions", []) or []

    lines: List[str] = []

    if allergy_conflicts:
        # List unique conflicting drugs
        conflict_drugs = []
        for c in allergy_conflicts:
            name = c.get("generic_name") or c.get("drug_input") or "Unknown drug"
            did = c.get("drug_id") or "N/A"
            conflict_drugs.append((name, did))
        # dedupe
        seen = set()
        unique_conflict_drugs = []
        for name, did in conflict_drugs:
            key = (name, did)
            if key not in seen:
                seen.add(key)
                unique_conflict_drugs.append((name, did))

        lines.append("\n\n---\n\n⚠️ **Allergy Safety Override**\n")
        lines.append(
            "The following drugs are **contraindicated** for this patient "
            "because of documented allergies. They should **NOT** be used, "
            "even if other parts of the analysis or general guidelines say "
            "they may be appropriate:"
        )
        for name, did in unique_conflict_drugs:
            lines.append(f"- **{name}** (ID: `{did}`)")

        lines.append("\nDetails of the allergy matches:\n")
        for c in allergy_conflicts:
            drug_name = c.get("generic_name") or c.get("drug_input") or "Unknown drug"
            did = c.get("drug_id") or "N/A"
            matched = ", ".join(c.get("matched_allergies", []))
            lines.append(
                f"- **{drug_name}** (ID: `{did}`) conflicts with documented allergies: {matched}"
            )

    if alternative_suggestions:
        lines.append("\n\n✅ **Potential alternative options** *(synthetic demo, not real medical advice)*:\n")
        for s in alternative_suggestions:
            off_name = s.get("offending_generic_name") or s.get("offending_input")
            off_id = s.get("offending_drug_id") or "N/A"
            alt_name = s.get("alternative_generic_name") or "Unknown"
            alt_id = s.get("alternative_drug_id") or "N/A"
            reason = s.get("reason", "")
            lines.append(
                f"- Instead of **{off_name}** (ID: `{off_id}`), "
                f"consider **{alt_name}** (ID: `{alt_id}`) – {reason}"
            )

    return "\n".join(lines) if lines else ""


def _evaluate_medication_safety(
    patient_id: str,
    candidate_drugs: List[str],
) -> Dict[str, Any]:
    """
    Combine:
    - patient history (conditions + current meds)
    - proposed drugs from the query
    - allergy conflicts
    - drug-drug interactions

    into a single safety assessment structure that SummaryAgent can use.
    """
    assessment: Dict[str, Any] = {
        "patient_id": patient_id,
        "proposed_drugs": candidate_drugs,
        "per_drug": [],
    }

    if not candidate_drugs:
        assessment["any_allergy_conflict"] = False
        assessment["any_interaction"] = False
        return assessment

    # Get full patient context
    ctx = ClinicalDataStore.get_patient_context(patient_id)
    current_meds = ctx.get("medications", []) if ctx else []

    # Collect current med drug_ids (if present in your schema)
    current_drug_ids: List[str] = []
    for m in current_meds:
        did = m.get("drug_id") or m.get("med_drug_id") or ""
        if did:
            current_drug_ids.append(str(did))

    # Allergy conflicts using your existing helper
    allergy_conflicts = ClinicalDataStore.find_allergy_conflicts(
        patient_id=patient_id,
        drug_names_or_ids=candidate_drugs,
    )

    # Index allergy conflicts by drug_input / generic_name for quick lookup
    allergy_by_key: Dict[str, List[Dict[str, Any]]] = {}
    for c in allergy_conflicts:
        keys = [
            str(c.get("drug_input") or "").lower(),
            str(c.get("generic_name") or "").lower(),
        ]
        for k in keys:
            if k:
                allergy_by_key.setdefault(k, []).append(c)

    # For each proposed drug, check:
    # - mapped drug_id
    # - interactions with current meds
    for raw in candidate_drugs:
        name_or_id = str(raw or "").strip()
        if not name_or_id:
            continue

        info = ClinicalDataStore.get_drug_info(name_or_id) or {}
        drug_id = str(info.get("drug_id", name_or_id))
        generic = str(info.get("generic_name", name_or_id))

        key1 = name_or_id.lower()
        key2 = generic.lower()

        per_drug_allergy_conflicts: List[Dict[str, Any]] = []
        if key1 in allergy_by_key:
            per_drug_allergy_conflicts.extend(allergy_by_key[key1])
        if key2 in allergy_by_key and allergy_by_key[key2] is not allergy_by_key.get(key1):
            per_drug_allergy_conflicts.extend(allergy_by_key[key2])

        # Interactions between this proposed drug and current meds
        interaction_findings: List[Dict[str, Any]] = []
        if drug_id and current_drug_ids:
            ids_to_check = list(set(current_drug_ids + [drug_id]))
            interaction_findings = ClinicalDataStore.check_interactions(ids_to_check)

        item = {
            "input_name": name_or_id,
            "drug_id": drug_id,
            "generic_name": generic,
            "has_allergy_conflict": bool(per_drug_allergy_conflicts),
            "allergy_conflicts": per_drug_allergy_conflicts,
            "interaction_findings": interaction_findings,
        }

        assessment["per_drug"].append(item)

    # High-level flags for summary
    assessment["any_allergy_conflict"] = any(
        d["has_allergy_conflict"] for d in assessment["per_drug"]
    )
    assessment["any_interaction"] = any(
        bool(d["interaction_findings"]) for d in assessment["per_drug"]
    )

    return assessment



def summary_node(state: ClinicalState) -> ClinicalState:
    """
    Final node: combine all partial results into one answer.
    We call the SummaryAgent and then append a safety appendix
    with allergy conflicts and alternative suggestions.
    """
    partial = {
        "query_analysis": state.get("query_analysis"),
        "interaction_result": state.get("interaction_result"),
        "guideline_result": state.get("guideline_result"),
        "risk_prediction_result": state.get("risk_prediction_result"),
        "rag_result": state.get("rag_result"),
    }
    base_answer = summary_agent.summarize(state["query"], partial)

    safety_appendix = _build_safety_appendix(state)

    state["final_answer"] = base_answer + safety_appendix
    return state


# ---------- Routing ----------

def route_after_query(state: ClinicalState) -> str:
    """
    Decide where to go after the query agent:
    - drug_interaction / medication_safety -> interaction_node
    - risk_prediction                     -> risk_prediction_node
    - clinical_guideline                  -> guideline_node
    - general/other                       -> rag_node
    """
    intent = state.get("intent", "general")
    if intent in ("drug_interaction", "medication_safety"):
        return "drug_interaction"
    elif intent == "risk_prediction":
        return "risk_prediction"
    elif intent == "clinical_guideline":
        return "guideline"
    else:
        return "rag"


# ---------- Build graph ----------

builder = StateGraph(ClinicalState)

builder.add_node("query", query_node)
builder.add_node("drug_interaction", interaction_node)
builder.add_node("guideline", guideline_node)
builder.add_node("risk_prediction", risk_prediction_node)
builder.add_node("rag", rag_node)
builder.add_node("summary", summary_node)

builder.set_entry_point("query")

builder.add_conditional_edges(
    "query",
    route_after_query,
    {
        "drug_interaction": "drug_interaction",
        "risk_prediction": "risk_prediction",
        "guideline": "guideline",
        "rag": "rag",
    },
)

builder.add_edge("drug_interaction", "summary")
builder.add_edge("risk_prediction", "summary")
builder.add_edge("guideline", "summary")
builder.add_edge("rag", "summary")

graph = builder.compile()


def run_workflow(query: str, patient_id: Optional[str]) -> Dict[str, Any]:
    """
    Helper for UI: runs the graph and returns the final state as a dict.
    """
    initial_state: ClinicalState = {"query": query}
    if patient_id:
        initial_state["patient_id"] = patient_id

    final_state = graph.invoke(initial_state)
    return dict(final_state)
