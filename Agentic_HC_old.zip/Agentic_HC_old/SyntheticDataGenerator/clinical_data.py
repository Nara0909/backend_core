"""
clinical_data.py

Utility class to read/write synthetic cardiology CSV datasets and provide
patient-centric helpers for the LangGraph clinical app.
"""

from __future__ import annotations

import os
from typing import Dict, Any, List, Optional

import pandas as pd

# Base folder where CSVs live: ./data_agent/...
BASE_DIR = os.path.join(os.path.dirname(__file__), "data_agent")


def _csv_path(*parts: str) -> str:
    """Build a path under data_agent/."""
    return os.path.join(BASE_DIR, *parts)


def _read_csv(path: str) -> pd.DataFrame:
    """Read CSV, return empty DataFrame if file is missing."""
    if not os.path.exists(path):
        return pd.DataFrame()
    return pd.read_csv(path, dtype=str).fillna("")


def _write_csv(df: pd.DataFrame, path: str) -> None:
    """Write DataFrame back to CSV (creating folders if needed)."""
    os.makedirs(os.path.dirname(path), exist_ok=True)
    df.to_csv(path, index=False)


class ClinicalDataStore:
    """
    Static helpers for working with the synthetic CSVs.
    No imports from gradio_app / graph_workflow / agents here
    (to avoid circular imports).
    """

    # ------------- BASIC LOADERS -----------------

    @staticmethod
    def load_patients() -> pd.DataFrame:
        return _read_csv(_csv_path("patients", "patients.csv"))

    @staticmethod
    def load_medical_history() -> pd.DataFrame:
        return _read_csv(_csv_path("patients", "medical_history.csv"))

    @staticmethod
    def load_allergies() -> pd.DataFrame:
        return _read_csv(_csv_path("patients", "allergies.csv"))

    @staticmethod
    def load_current_meds() -> pd.DataFrame:
        return _read_csv(_csv_path("patients", "current_medications.csv"))

    @staticmethod
    def load_adverse_events() -> pd.DataFrame:
        return _read_csv(_csv_path("patients", "adverse_events.csv"))

    @staticmethod
    def load_drugs() -> pd.DataFrame:
        return _read_csv(_csv_path("drugs", "drugs.csv"))

    @staticmethod
    def load_drug_interactions() -> pd.DataFrame:
        return _read_csv(_csv_path("drugs", "drug_interactions.csv"))

    @staticmethod
    def load_clinical_rules() -> pd.DataFrame:
        return _read_csv(_csv_path("guidelines", "clinical_rules.csv"))

    # ------------- PATIENT LOOKUPS -----------------

    @staticmethod
    def list_patient_ids() -> List[str]:
        """Return sorted list of patient_ids from patients.csv."""
        df = ClinicalDataStore.load_patients()
        if "patient_id" not in df.columns:
            return []
        return sorted(df["patient_id"].astype(str).unique().tolist())

    @staticmethod
    def get_patient_row(patient_id: str) -> Optional[Dict[str, Any]]:
        """Return a single patient row as dict, or None if not found."""
        if not patient_id:
            return None
        df = ClinicalDataStore.load_patients()
        if df.empty or "patient_id" not in df.columns:
            return None

        sub = df[df["patient_id"].astype(str) == str(patient_id)]
        if sub.empty:
            return None
        row = sub.iloc[0].to_dict()
        return row

    @staticmethod
    def upsert_patient(patient_data: Dict[str, Any]) -> None:
        """
        Insert or update a patient row in patients.csv.
        patient_data must contain at least 'patient_id'.
        """
        pid = str(patient_data.get("patient_id", "")).strip()
        if not pid:
            raise ValueError("patient_data must contain patient_id")

        # --- 1. Upsert the main patient row in patients.csv ---
        df = ClinicalDataStore.load_patients()

        if df.empty:
            # create new DataFrame with all keys
            df = pd.DataFrame([patient_data])
        else:
            df["patient_id"] = df["patient_id"].astype(str)
            mask = df["patient_id"] == pid
            if mask.any():
                # update existing row
                for k, v in patient_data.items():
                    if k not in df.columns:
                        df[k] = ""
                    df.loc[mask, k] = str(v)
            else:
                # append new row
                new_row = {col: "" for col in df.columns}
                for k, v in patient_data.items():
                    if k not in new_row:
                        df[k] = ""  # ensure column exists
                        new_row[k] = ""
                    new_row[k] = str(v)
                df = pd.concat([df, pd.DataFrame([new_row])], ignore_index=True)

        _write_csv(df, _csv_path("patients", "patients.csv"))

        # --- 2. Upsert related data into their respective CSVs ---
        # This is the crucial fix: parse the comma-separated strings and
        # create/update rows in the other tables.

        # Helper to update related tables
        def _update_related_df(
            file_path: str, key_col: str, new_items: List[str], other_cols: Dict[str, str]
        ):
            df_rel = _read_csv(file_path)
            # Remove all existing entries for this patient
            if not df_rel.empty and "patient_id" in df_rel.columns:
                df_rel = df_rel[df_rel["patient_id"] != pid]

            # Add new entries
            new_rows = []
            for item in new_items:
                if not item:
                    continue
                row = {"patient_id": pid, key_col: item}
                row.update(other_cols)
                new_rows.append(row)

            if new_rows:
                df_new = pd.DataFrame(new_rows)
                df_rel = pd.concat([df_rel, df_new], ignore_index=True)

            _write_csv(df_rel, file_path)

        # Update allergies.csv
        allergies_str = patient_data.get("allergies", "")
        allergies_list = [s.strip() for s in allergies_str.split(",") if s.strip()]
        _update_related_df(
            _csv_path("patients", "allergies.csv"),
            "allergen",
            allergies_list,
            {"reaction_type": "unknown", "severity": "unknown"},
        )

        # Update medical_history.csv
        conditions_str = patient_data.get("conditions", "")
        conditions_list = [s.strip() for s in conditions_str.split(",") if s.strip()]
        _update_related_df(
            _csv_path("patients", "medical_history.csv"), "condition_name", conditions_list, {}
        )

        # Update current_medications.csv
        meds_str = patient_data.get("medications", "")
        meds_list = [s.strip() for s in meds_str.split(",") if s.strip()]
        _update_related_df(_csv_path("patients", "current_medications.csv"), "drug_name", meds_list, {})


    @staticmethod
    def rename_patient_id(old_id: str, new_id: str) -> None:
        """
        Rename patient_id across all patient-related CSVs.
        """

        def _rename_in_file(path: str) -> None:
            df = _read_csv(path)
            if df.empty or "patient_id" not in df.columns:
                return
            df["patient_id"] = df["patient_id"].astype(str)
            df.loc[df["patient_id"] == str(old_id), "patient_id"] = str(new_id)
            _write_csv(df, path)

        for rel in [
            ("patients", "patients.csv"),
            ("patients", "medical_history.csv"),
            ("patients", "allergies.csv"),
            ("patients", "current_medications.csv"),
            ("patients", "adverse_events.csv"),
        ]:
            _rename_in_file(_csv_path(*rel))

    # ------------- CONTEXT FOR AGENTS -----------------

    @staticmethod
    def get_patient_context(patient_id: str) -> Optional[Dict[str, Any]]:
        """
        Aggregate a patient's core data + meds + conditions into a single dict.
        Used by agents & workflow.
        """
        patient = ClinicalDataStore.get_patient_row(patient_id)
        if not patient:
            return None

        mh = ClinicalDataStore.load_medical_history()
        meds = ClinicalDataStore.load_current_meds()
        allergies = ClinicalDataStore.load_allergies()
        adverse = ClinicalDataStore.load_adverse_events()

        def _filter(df: pd.DataFrame) -> List[Dict[str, Any]]:
            if df.empty or "patient_id" not in df.columns:
                return []
            sub = df[df["patient_id"].astype(str) == str(patient_id)]
            return sub.to_dict(orient="records")

        conditions = _filter(mh)
        medications = _filter(meds)
        allergy_list = _filter(allergies)
        adverse_events = _filter(adverse)

        return {
            "patient": patient,
            "conditions": conditions,
            "medications": medications,
            "allergies": allergy_list,
            "adverse_events": adverse_events,
        }

    @staticmethod
    def get_rules_for_patient(patient_id: str) -> List[Dict[str, Any]]:
        """
        Fetch guideline-style rules relevant to the patient's conditions.
        """
        ctx = ClinicalDataStore.get_patient_context(patient_id)
        if not ctx:
            return []

        cond_codes = {
            c.get("condition_code", "")
            for c in ctx.get("conditions", [])
            if c.get("condition_code")
        }

        rules_df = ClinicalDataStore.load_clinical_rules()
        if rules_df.empty or "condition_code" not in rules_df.columns:
            return []

        sub = rules_df[rules_df["condition_code"].isin(cond_codes)]
        return sub.to_dict(orient="records")

    # ------------- DRUG / GUIDELINE LOOKUPS -----------------

    @classmethod
    def get_drug_info(cls, drug_name_or_id: str) -> Optional[Dict[str, Any]]:
        """
        Look up a drug by generic_name OR drug_id (case-insensitive).
        """
        name = (drug_name_or_id or "").strip().lower()
        if not name:
            return None

        df = cls.load_drugs()
        if df.empty:
            return None

        if "drug_id" in df.columns:
            df["drug_id"] = df["drug_id"].astype(str)
        if "generic_name" in df.columns:
            df["generic_name"] = df["generic_name"].astype(str)

        mask = False
        if "drug_id" in df.columns:
            mask = mask | df["drug_id"].str.lower().eq(name)
        if "generic_name" in df.columns:
            mask = mask | df["generic_name"].str.lower().eq(name)

        if mask.any():
            return df[mask].iloc[0].to_dict()
        return None

    @classmethod
    def get_guideline_for_condition(cls, condition: str) -> List[Dict[str, Any]]:
        """
        Fetch synthetic guideline rules for a condition from clinical_rules.csv.
        """
        cond = (condition or "").strip().lower()
        if not cond:
            return []

        df = cls.load_clinical_rules()
        if df.empty:
            return []

        if "condition_code" in df.columns:
            df["condition_code"] = df["condition_code"].astype(str)
        if "condition_name" in df.columns:
            df["condition_name"] = df["condition_name"].astype(str)

        mask = False
        if "condition_code" in df.columns:
            mask = mask | df["condition_code"].str.lower().eq(cond)
        if "condition_name" in df.columns:
            mask = mask | df["condition_name"].str.lower().str.contains(cond)

        sub = df[mask]
        return sub.to_dict(orient="records")

    # ------------- INTERACTION LOOKUP -----------------

    @staticmethod
    def check_interactions(drug_ids: List[str]) -> List[Dict[str, Any]]:
        """
        Given a list of drug_id values, return matching interactions
        from drug_interactions.csv
        """
        if not drug_ids:
            return []

        ids = [str(d) for d in drug_ids]
        df = ClinicalDataStore.load_drug_interactions()
        if df.empty:
            return []

        if not {"drug_a_id", "drug_b_id"}.issubset(df.columns):
            return []

        sub = df[
            (df["drug_a_id"].isin(ids)) & (df["drug_b_id"].isin(ids))
            & (df["drug_a_id"] != df["drug_b_id"])
        ]

        return sub.to_dict(orient="records")

    @classmethod
    def check_interactions_for_list(cls, meds: List[str]) -> List[Dict[str, Any]]:
        """Wrapper that routes to check_interactions()."""
        return cls.check_interactions(meds or [])

    # ------------- ALLERGY HELPERS -----------------

    @staticmethod
    def get_patient_allergy_strings(patient_id: str) -> List[str]:
        """
        Return a list of allergy strings for a patient from:
        - patients.csv 'allergies' column (comma-separated)
        - allergies.csv rows for that patient
        """
        if not patient_id:
            return []

        allergy_terms: List[str] = []

        # 1) from patients.csv
        patient = ClinicalDataStore.get_patient_row(patient_id)
        if patient:
            raw = str(patient.get("allergies", "")).strip()
            if raw:
                for part in raw.split(","):
                    term = part.strip()
                    if term:
                        allergy_terms.append(term)

        # 2) from allergies.csv
        df_all = ClinicalDataStore.load_allergies()
        if not df_all.empty and "patient_id" in df_all.columns:
            df_all["patient_id"] = df_all["patient_id"].astype(str)
            sub = df_all[df_all["patient_id"] == str(patient_id)]
            for _, row in sub.iterrows():
                # adjust column names depending on your schema
                for col in ["allergen", "allergy", "allergy_name"]:
                    if col in row and str(row[col]).strip():
                        allergy_terms.append(str(row[col]).strip())

        uniq = sorted({a.strip() for a in allergy_terms if a.strip()})
        return uniq

    @classmethod
    def find_allergy_conflicts(
        cls,
        patient_id: str,
        drug_names_or_ids: List[str],
    ) -> List[Dict[str, Any]]:
        """
        Check if any of the provided drugs conflict with the patient's allergies.
        Simple heuristic: substring matching between allergy terms and
        drug_id/generic_name.
        """
        allergies = [a.lower() for a in cls.get_patient_allergy_strings(patient_id)]
        if not allergies or not drug_names_or_ids:
            return []

        conflicts: List[Dict[str, Any]] = []

        for raw_drug in drug_names_or_ids:
            d = str(raw_drug or "").strip()
            if not d:
                continue

            info = cls.get_drug_info(d) or {}
            generic = str(info.get("generic_name", d)).lower()
            drug_id = str(info.get("drug_id", "")).lower()

            matched_allergies = []
            for allergen in allergies:
                if allergen in generic or allergen in drug_id or generic in allergen:
                    matched_allergies.append(allergen)

            if matched_allergies:
                conflicts.append(
                    {
                        "patient_id": patient_id,
                        "drug_input": d,
                        "drug_id": info.get("drug_id"),
                        "generic_name": info.get("generic_name"),
                        "matched_allergies": matched_allergies,
                    }
                )

        return conflicts

    # ------------- ALTERNATIVE DRUG SUGGESTION -----------------

    @classmethod
    def suggest_alternative_drugs(
        cls,
        patient_id: Optional[str],
        offending_drugs: List[str],
        max_suggestions_per_drug: int = 3,
    ) -> List[Dict[str, Any]]:
        """
        Given a patient_id and a list of offending drug names/ids,
        suggest alternative drugs that:
        - are in (roughly) the same class/indication
        - do NOT obviously conflict with the patient's allergies
        - best-effort avoid direct interactions with current meds
        """
        df_drugs = cls.load_drugs()
        if df_drugs.empty:
            return []
