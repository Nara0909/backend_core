import requests
from typing import Optional, Dict, Any, List
import streamlit as st
import io
import tempfile
from openai import OpenAI
import httpx
import json
import base64
import requests
import os
from datetime import datetime, timedelta
import uuid
import pandas as pd
import  clinical_decision
# Assuming these are defined in your project structure:
from clinical_data import ClinicalDataStore
from agents import classify_triage_with_llm_simple
from user_db import (
    init_db,
    verify_user,
    list_users,
    create_user,
    add_audit_log_entry,
    get_audit_logs,
    get_audit_log_count,
    delete_user,
    get_user_by_id,
    update_user,
    register_visitor,
    create_appointment,
    get_visitor_appointments,
    get_all_appointments,
    update_appointment_status,
)
from config import client as openai_client
from graph_workflow import run_workflow, risk_prediction_agent
import re

def set_bg(local_image_path):
    try:
        with open(local_image_path, "rb") as f:
            encoded_string = base64.b64encode(f.read()).decode()

        page_bg_img = f"""
        <style>
        [data-testid="stAppViewContainer"] {{
            /* Lower alpha => less white => more vivid image */
            background-image:
                linear-gradient(rgba(255,255,255,0.75), rgba(255,255,255,0.75)),
                url("data:image/jpg;base64,{encoded_string}");
            background-size: cover;
            background-position: center;
            background-repeat: no-repeat;
            background-attachment: fixed;
            background-blend-mode: normal;
        }}

        [data-testid="stHeader"] {{
            background: rgba(0,0,0,0);
        }}
        </style>
        """
        st.markdown(page_bg_img, unsafe_allow_html=True)
    except FileNotFoundError:
        # Background image not available - continue without it
        pass
    except Exception as e:
        print(f"⚠️  Could not set background image: {e}")


# Try to set background, but don't fail if image not found
try:
    set_bg(r"C:\Users\GenAICHNSIRUSR66\Downloads\AiDoctor6.jpg")
except:
    pass


# Configuration
COMPLIANCE_API_URL = os.environ.get("COMPLIANCE_API_URL", "http://localhost:8000")

# =====================================================================
# COMPLIANCE API INTEGRATION
# =====================================================================

def call_compliance_api(query: str, user_role: str = "clinician", request_type: str = "clinical_decision") -> Dict[str, Any]:
    """
    Call the Compliance AI System API to process the clinical question.
    
    Returns:
        {
            "success": bool,
            "compliance_report": dict,
            "pii_detected": list,
            "access_granted": bool,
            "masked_input": str,
            "audit_log": list,
            ...
        }
    """
    try:
        endpoint = f"{COMPLIANCE_API_URL}/api/process"
        payload = {
            "input_text": str(query) if query else "No input provided",
            "user_role": str(user_role).lower().strip() if user_role else "visitor",
            "request_type": str(request_type).lower().strip() if request_type else "appointment_scheduling",
        }
        
        print(f"📡 Calling Compliance API: {endpoint}")
        print(f"   Payload: {payload}")
        
        response = requests.post(endpoint, json=payload, timeout=30)
        response.raise_for_status()
        
        result = response.json()
        print(f"✅ Compliance API Response: {result.get('message', 'Success')}")
        
        return result
    
    except requests.exceptions.HTTPError as e:
        print(f"❌ Compliance API HTTP error: {e}")
        if e.response is not None:
            print(f"   Status: {e.response.status_code}")
            print(f"   Response: {e.response.text[:200]}")
        return {
            "success": False,
            "error": f"API Error: {e}",
            "access_granted": False,
            "compliance_available": False
        }
    except requests.exceptions.ConnectionError:
        print(f"⚠️  Backend server is down. Bypassing compliance checks...")
        print(f"   Could not connect to Compliance API at {COMPLIANCE_API_URL}")
        # Return bypass response allowing access without compliance
        return {
            "success": True,
            "bypass_mode": True,
            "message": "⚠️ Backend unavailable - proceeding without compliance verification",
            "access_granted": True,
            "compliance_available": False,
            "request_type": request_type,
            "user_role": user_role,
            "pii_detected": [],
            "audit_log": [{
                "agent": "System",
                "action": "Bypass mode activated - backend server is down",
                "timestamp": str(pd.Timestamp.now())
            }],
            "regulatory_compliance": {
                "regulations_applied": ["HIPAA (Bypassed)", "GDPR (Bypassed)"],
                "agents_executed": ["BypassAgent"],
                "status": "BYPASS_MODE_ACTIVE"
            }
        }
    except requests.exceptions.Timeout:
        print(f"⚠️  Compliance API timeout. Bypassing compliance checks...")
        # Return bypass response on timeout
        return {
            "success": True,
            "bypass_mode": True,
            "message": "⚠️ API timeout - proceeding without compliance verification",
            "access_granted": True,
            "compliance_available": False,
            "request_type": request_type,
            "user_role": user_role,
            "pii_detected": [],
            "audit_log": [{
                "agent": "System",
                "action": "Bypass mode activated - API timeout",
                "timestamp": str(pd.Timestamp.now())
            }],
            "regulatory_compliance": {
                "regulations_applied": ["HIPAA (Bypassed)", "GDPR (Bypassed)"],
                "agents_executed": ["BypassAgent"],
                "status": "BYPASS_MODE_ACTIVE"
            }
        }
    except Exception as e:
        print(f"❌ Compliance API error: {e}")
        import traceback
        traceback.print_exc()
        return {
            "success": False,
            "error": str(e),
            "access_granted": False,
            "compliance_available": False
        }


# =====================================================================
# ROLE-BASED ACCESS MANAGEMENT
# =====================================================================



# =====================================================================
# WORKFLOW EXECUTION WITH COMPLIANCE
# =====================================================================

def run_clinical_workflow(query: str, patient_id: Optional[str], username: str, user_role: str = "clinician") -> Dict[str, Any]:
    """
    Runs the complete clinical workflow:
    1. Query Compliance API for policy enforcement, PII masking, access control
    2. Get masked input from compliance system
    3. Run clinical LLM workflow on masked data
    4. Sanitize and return both compliance report + LLM response
    
    Returns:
        {
            "llm_response": str,
            "compliance_report": dict,
            "pii_detected": list,
            "access_granted": bool,
            "compliance_enabled": bool,
            ...
        }
    """
    if not query.strip():
        return {
            "error": "Please enter a clinical question.",
            "llm_response": "",
            "compliance_report": {}
        }

    # Step 1: Call Compliance API
    print(f"\n{'='*70}")
    print(f"🏥 CLINICAL QUERY PROCESSING")
    print(f"{'='*70}")
    print(f"Query: {query[:100]}...")
    print(f"Patient ID: {patient_id}")
    print(f"User: {username} (Role: {user_role})")
    
    compliance_result = call_compliance_api(query, user_role, "clinical_decision")
    
    # Check if API is available and access was granted
    compliance_available = compliance_result.get("compliance_available", True)
    compliance_enabled = compliance_result.get("compliance_enabled", True)
    access_granted = compliance_result.get("access_granted", True)
    
    if not compliance_available:
        print(f"⚠️ Compliance API not available - proceeding with local workflow only")
    
    if not access_granted:
        return {
            "error": f"Access denied: {compliance_result.get('deny_reason', 'Unknown reason')}",
            "llm_response": "",
            "compliance_report": compliance_result,
            "access_granted": False,
            "compliance_enabled": compliance_enabled,
        }
    
    # Step 2: Use masked input from compliance system for LLM processing
    input_for_llm = compliance_result.get("masked_input", query) or query
    
    print(f"\n🔍 Compliance Check Results:")
    print(f"   ✅ Access Granted: {access_granted}")
    print(f"   📊 PII Detected: {len(compliance_result.get('pii_detected', []))}")
    print(f"   🔐 Encryption Applied: {compliance_result.get('encryption_applied', False)}")
    
    if compliance_result.get("pii_detected"):
        pii_types = [p.get("type") for p in compliance_result.get("pii_detected", [])]
        print(f"   📝 PII Types: {pii_types}")
    
    # Step 3: Run clinical workflow on masked data
    print(f"\n🧠 Running Clinical Analysis...")
    try:
        state: Dict[str, Any] = run_workflow(input_for_llm, patient_id or None)
        final_answer = state.get(
            "final_answer",
            "No final answer produced. Please check backend / logs.",
        )
    except Exception as e:
        print(f"❌ Error running clinical workflow: {e}")
        final_answer = f"Error processing clinical question: {str(e)}"
    
    # Step 4: Log to database
    add_audit_log_entry(
        username=username,
        patient_id=patient_id,
        query=query,
        final_answer=final_answer,
    )
    
    # Step 5: Return both compliance report and LLM response
    return {
        "success": True,
        "llm_response": final_answer,
        "compliance_report": compliance_result,
        "pii_detected": compliance_result.get("pii_detected", []),
        "access_granted": access_granted,
        "compliance_enabled": compliance_enabled,
        "policies_applied": compliance_result.get("regulations_applied", []),
        "audit_log": compliance_result.get("audit_log", []),
        "masked_input": input_for_llm,
        "original_input": query,
    }


def transcribe_audio(audio_bytes: bytes) -> str:
    """
    Transcribes audio bytes using OpenAI's Whisper model.
    """
    try:
        http_client = httpx.Client(verify=False)

        client = OpenAI(
            base_url="https://genailab.tcs.in",  # NOTE: no /v1 here to start with
            api_key="sk-pqqb7gbAXKU2ph-5nBUueQ",
            http_client=http_client,
        )
        # Save bytes -> temp wav file
        with tempfile.NamedTemporaryFile(suffix=".wav", delete=False) as tmp:
            tmp.write(audio_bytes)
            tmp_path = tmp.name

        with open(tmp_path, "rb") as f:
            # This will call POST https://genailab.tcs.in/audio/transcriptions
            transcript = client.audio.transcriptions.create(
                model="azure/genailab-maas-whisper",  # use the exact model id they gave
                file=f,
            )

        text = getattr(transcript, "text", None) or transcript.get("text", "")
        return text.strip()
    except Exception as e:
        print("Transcription error:", e)
        # Log to Streamlit UI to inform the user
        st.error(f"Audio transcription failed: {e}")
        return ""


# -------------------------------------------------------------
# PATIENT FORM HELPERS
# -------------------------------------------------------------
def load_patient_for_edit(selected_id: Optional[str]) -> List[str]:
    """
    Load an existing patient into the edit form.
    Returns 6 fields in order:
    [patient_id, age, gender, allergies, conditions, medications]
    """
    if not selected_id:
        return ["", "", "", "", "", ""]

    # Fetch the full context to get all related data
    ctx = ClinicalDataStore.get_patient_context(selected_id) or {}
    row = ctx.get("patient", {})

    # Extract and format lists as comma-separated strings for the form
    allergies_list = [
        a.get("allergen", "") for a in ctx.get("allergies", []) if a.get("allergen")
    ]
    conditions_list = [
        c.get("condition_name", "")
        for c in ctx.get("conditions", [])
        if c.get("condition_name")
    ]
    meds_list = [
        m.get("drug_name", "")
        for m in ctx.get("medications", [])
        if m.get("drug_name")
    ]

    allergies_str = ", ".join(filter(None, allergies_list))
    conditions_str = ", ".join(filter(None, conditions_list))
    meds_str = ", ".join(filter(None, meds_list))

    return [
        row.get("patient_id", selected_id),
        str(row.get("age", "")),
        row.get("gender", ""),
        allergies_str,
        conditions_str,
        meds_str,
    ]


def on_patient_dropdown_change(selected_id: Optional[str]):
    """
    When user selects a patient:
    - load details into the form
    - update current patient badges
    - keep the original id for rename cascade
    - Returns blank string to clear the analysis output.
    """
    (
        pid,
        age,
        gender,
        allergies,
        conditions,
        meds,
    ) = load_patient_for_edit(selected_id)

    if selected_id:
        badge_main = f"Demo Patient: **{selected_id}**"
        badge_workspace = f"Current Patient: **{selected_id}**"
    else:
        badge_main = "Demo Patient: –"
        badge_workspace = "Current Patient: –"

    original_id = selected_id or ""

    # 6 form fields + header badge + workspace badge + hidden original id + CLEAR OUTPUT
    return (
        pid,
        age,
        gender,
        allergies,
        conditions,
        meds,
        badge_main,
        badge_workspace,
        original_id,
        "",  # Clear final answer
    )


def save_patient(
    original_patient_id: str,
    patient_id: str,
    age: str,
    gender: str,
    allergies: str,
    conditions: str,
    medications: str,
):
    """
    Upsert patient into patients.csv.
    Returns same semantics as before but adapted for Streamlit:
    (status, ids_list, badge_main, badge_workspace, new_original_id, cleared_output)
    """
    if not patient_id.strip():
        return (
            "❌ Patient ID is required.",
            ClinicalDataStore.list_patient_ids(),  # keep dropdown choices as-is
            "Demo Patient: –",
            "Current Patient: –",
            original_patient_id,
            "",  # Clear output on error
        )

    new_id = patient_id.strip()
    orig_id = (original_patient_id or "").strip()

    # 1) Rename cascade if needed
    if orig_id and orig_id != new_id:
        ClinicalDataStore.rename_patient_id(orig_id, new_id)

    # 2) Upsert patient row
    ClinicalDataStore.upsert_patient(
        {
            "patient_id": new_id,
            "age": age.strip(),
            "gender": gender.strip(),
            "allergies": allergies.strip(),
            "conditions": conditions.strip(),
            "medications": medications.strip(),
        }
    )

    # 3) Refresh dropdown
    ids = ClinicalDataStore.list_patient_ids()

    badge_main = f"Demo Patient: **{new_id}**"
    badge_workspace = f"Current Patient: **{new_id}**"

    return (
        "✅ Patient saved/updated.",
        ids,
        badge_main,
        badge_workspace,
        new_id,  # new original id
        "",  # Clear output on save
    )


def clear_query_and_output():
    """Returns empty strings to clear the query box and the output box."""
    return "", ""


# -------------------------------------------------------------
# VISITOR APPOINTMENT FUNCTIONS
# -------------------------------------------------------------
def render_appointment_chatbot():
    """Enhanced appointment scheduling with triage classification and consent management"""
    st.markdown("### 🤖 Appointment Scheduling Chatbot")
    st.markdown("""
        <div style='background: rgba(30, 41, 59, 0.85); padding: 1rem; border-radius: 15px; margin-bottom: 1rem; border: 1px solid rgba(148, 163, 184, 0.3); box-shadow: 0 10px 30px rgba(0, 0, 0, 0.4), inset 0 1px 0 rgba(255, 255, 255, 0.1); backdrop-filter: blur(20px); color: #cbd5e1; font-size: 0.95rem; line-height: 1.6;'>
    Welcome! I'll help you schedule an appointment. Please provide your information and reason for visit.
</div>
    """, unsafe_allow_html=True)
    
    # Step 1: Collect appointment details
    with st.form("appointment_form"):
        st.markdown("#### 👤 Patient Information")
        
        patient_name = st.text_input(
            "Patient Full Name*",
            value=st.session_state.user_info.get("name", ""),
            help="Enter the patient's full name"
        )
        
        col1, col2 = st.columns(2)
        with col1:
            phone = st.text_input(
                "Contact Phone*",
                value=st.session_state.user_info.get("phone", ""),
                placeholder="555-123-4567"
            )
        with col2:
            email = st.text_input(
                "Email Address*",
                value=st.session_state.user_info.get("email", ""),
                placeholder="patient@email.com"
            )
        
        st.markdown("#### 📋 Reason for Visit")
        
        reason = st.text_area(
            "Reason for Visit*",
            placeholder="e.g., Annual checkup, Follow-up consultation, New patient visit, Urgent care needed",
            height=120,
            help="Briefly describe the reason for your appointment and any symptoms"
        )
        
        st.markdown("#### 📅 Preferred Appointment")
        
        col3, col4 = st.columns(2)
        with col3:
            min_date = datetime.now().date()
            max_date = (datetime.now() + timedelta(days=90)).date()
            appointment_date = st.date_input(
                "Preferred Date*",
                min_value=min_date,
                max_value=max_date,
                help="Select a date within the next 90 days"
            )
        with col4:
            appointment_time = st.time_input(
                "Preferred Time*",
                value=datetime.strptime("09:00", "%H:%M").time(),
                help="Select your preferred appointment time"
            )
        
        st.markdown("---")
        
        # Submit for triage analysis
        submit_for_analysis = st.form_submit_button("🔍 Analyze for Triage", use_container_width=True)
        
        if submit_for_analysis:
            # Validate all fields
            if not all([patient_name, phone, email, reason]):
                st.error("❌ Please fill in all required fields")
            else:
                # Store form data in session
                st.session_state.pending_appointment = {
                    "patient_name": patient_name,
                    "phone": phone,
                    "email": email,
                    "reason": reason,
                    "appointment_date": str(appointment_date),
                    "appointment_time": str(appointment_time),
                }
                st.session_state.show_triage_analysis = True
                st.rerun()
    
    # Step 2: Display triage analysis - MOVED INSIDE SO appt_data IS DEFINED
    if st.session_state.get("show_triage_analysis") and st.session_state.get("pending_appointment"):
        appt_data = st.session_state.pending_appointment
        
        st.markdown("---")
        st.markdown("#### 🏥 Triage Analysis")
        
        with st.spinner("🔄 Analyzing reason for visit and classifying triage level..."):
            compliance_result = call_compliance_api(
                query=appt_data["reason"],
                user_role="visitor",
                request_type="appointment_scheduling"
            )
            
        # ✅ COMPLIANCE-SAFE reason (ONLY this can be persisted)
        safe_reason = compliance_result.get(
            "processed_output",
            compliance_result.get("masked_input", "")
        )

        
        if compliance_result.get("bypass_mode"):
            st.warning("⚠️ **BYPASS MODE ACTIVE** - Backend server is unavailable.")
        
        if compliance_result.get("access_granted"):
            with st.spinner("🧠 Analyzing urgency with AI..."):
                triage_result = classify_triage_with_llm_simple(
                    reason_for_visit=appt_data["reason"],
                )

            # ✅ Extract ALL results
            triage_level = triage_result.get("triage_level")
            confidence = triage_result.get("confidence")
            clinical_reasoning = triage_result.get("clinical_reasoning")
            red_flags = triage_result.get("red_flags")
            method = triage_result.get("method", "unknown")
            
            st.session_state.triage_level = triage_level
            
            triage_colors = {
                "high": "#dc3545",
                "medium": "#FFA500",
                "low": "#28a745"
            }
            
            triage_emoji = {
                "high": "🔴 HIGH PRIORITY",
                "medium": "🟡 STANDARD",
                "low": "🟢 LOW PRIORITY"
            }
            
            color = triage_colors.get(triage_level, "#FFA500")
            emoji_label = triage_emoji.get(triage_level, "🟡 STANDARD")
            
            # ✅ Enhanced display with all results
            st.markdown(f"""
                <div style='background: {color}; color: white; padding: 1.5rem; border-radius: 10px; margin: 1rem 0;'>
                    <h3 style='color: white; margin-top: 0;'>{emoji_label}</h3>
                    <p><strong>Classification:</strong> {triage_level.upper()}</p>
                    <p><strong>AI Confidence:</strong> {confidence:.0%}</p>
                    <p><strong>Analysis Method:</strong> {method.replace('_', ' ').title()}</p>
                    <p style='margin-bottom: 0; font-size: 0.9rem; font-style: italic;'>{clinical_reasoning}</p>
                </div>
            """, unsafe_allow_html=True)
            
            # ✅ Low confidence warning
            if confidence < 0.7:
                st.warning(f"⚠️ **LOW CONFIDENCE ({confidence:.0%})** - Manual review recommended")
            
            # ✅ Red flags alert
            if red_flags:
                st.error(f"🚨 **RED FLAGS DETECTED**\n" + "\n".join([f"• {flag}" for flag in red_flags]))
            
            st.markdown("---")
            
            # Show appointment availability
            if triage_level == "high":
                st.success("✅ **HIGH PRIORITY** - Same day available")
                st.session_state.appointment_available = "same_day"
            elif triage_level == "medium":
                st.info("ℹ️ **STANDARD CARE** - Within one week")
                st.session_state.appointment_available = "one_week"
            else:
                st.warning("⏳ **LOW PRIORITY** - Queue scheduling")
                st.session_state.appointment_available = "queue"
            
            # ✅ Detailed analysis expandable
            with st.expander("📊 **Detailed AI Analysis Report**"):
                col1, col2, col3 = st.columns(3)
                with col1:
                    st.metric("Level", triage_level.upper())
                with col2:
                    st.metric("Confidence", f"{confidence:.0%}")
                with col3:
                    st.metric("Red Flags", len(red_flags) if red_flags else 0)
                
                st.markdown("**Clinical Reasoning:**")
                st.markdown(f"> {clinical_reasoning}")
                
                if red_flags:
                    st.markdown("**Identified Risk Factors:**")
                    for i, flag in enumerate(red_flags, 1):
                        st.markdown(f"{i}. **{flag}**")
                
                st.markdown("**Analysis Method:**")
                st.markdown(f"- **Method:** {method.replace('_', ' ').title()}")
                
                with st.expander("🔧 Raw JSON (debugging)"):
                    st.json(triage_result)
            
            # Compliance report
            with st.expander("📊 Compliance & Analysis Details"):
                st.markdown("**Compliance Analysis:**")
                
                col1, col2, col3 = st.columns(3)
                with col1:
                    st.metric("Request Type", compliance_result.get("request_type") or "appointment_scheduling")
                with col2:
                    st.metric("Access Granted", "✅ Yes" if compliance_result.get("access_granted") else "❌ No")
                with col3:
                    pii_count = len(compliance_result.get("pii_detected", []))
                    st.metric("PII Detected", pii_count)
                
                st.markdown("**Regulations Applied:**")
                regulatory_data = compliance_result.get("regulatory_compliance", {})
                regulations = regulatory_data.get("regulations_applied", [])
                if regulations:
                    for reg in regulations:
                        st.write(f"✓ {reg}")
                else:
                    st.write("HIPAA, GDPR")
                
                st.markdown("**Agents Executed:**")
                agents = regulatory_data.get("agents_executed", [])
                if agents:
                    for agent in agents:
                        st.write(f"• {agent}")
                else:
                    st.write("AccessControlAgent, PrivacyAgent, AuditAgent")
                
                st.markdown("**Full Compliance Report:**")
                st.json(compliance_result)
            
            # ✅ Step 3: Consent and Confirmation - NOW INSIDE THE IF BLOCK
            st.markdown("---")
            st.markdown("#### ✅ Consent & Confirmation")
            
            st.markdown("""
                <div style='background: rgba(30, 41, 59, 0.85); padding: 1rem; border-radius:  15px; border-left:  4px solid #14b8a6; border-top: 1px solid rgba(148, 163, 184, 0.3); border-right: 1px solid rgba(148, 163, 184, 0.3); border-bottom: 1px solid rgba(148, 163, 184, 0.3); box-shadow: 0 10px 30px rgba(0, 0, 0, 0.4), 0 0 20px rgba(20, 184, 166, 0.15), inset 0 1px 0 rgba(255, 255, 255, 0.1); backdrop-filter: blur(20px); margin:  1rem 0;'>
    <p style='color: #e2e8f0; margin:  0 0 0.5rem 0;'><strong style='color: #5eead4;'>🔐 Data Processing Notice:</strong></p>
    <p style='color: #cbd5e1; font-size: 0.95rem; line-height: 1.6; margin: 0;'>To provide you with the best clinical decision support, we may use your health information with our LLM-based Clinical Decision Support (CDS) system. 
    This is optional and does not affect your appointment scheduling.</p>
</div>
            """, unsafe_allow_html=True)
            
            cds_consent = st.checkbox(
                "✅ I consent to process my health details with LLM for Clinical Decision Support (CDS) and other medical analysis",
                value=False
            )
            
            if cds_consent:
                st.success("✅ You've provided consent for CDS processing")
            else:
                st.info("ℹ️ CDS is optional - your appointment will still be scheduled")
            
            st.markdown("#### 📋 Appointment Summary")
            
            summary_html = f"""
                <div style='background: rgba(30, 41, 59, 0.85); padding: 1.2rem; border-radius: 15px; border: 1px solid rgba(148, 163, 184, 0.3); box-shadow: 0 10px 30px rgba(0, 0, 0, 0.4), inset 0 1px 0 rgba(255, 255, 255, 0.1); backdrop-filter: blur(20px);'>
    <p style='color: #cbd5e1; margin: 0. 5rem 0;'><strong style='color: #5eead4;'>Patient:</strong> {appt_data['patient_name']}</p>
    <p style='color:  #cbd5e1; margin: 0.5rem 0;'><strong style='color:  #5eead4;'>Preferred Date:</strong> {appt_data['appointment_date']}</p>
    <p style='color: #cbd5e1; margin: 0.5rem 0;'><strong style='color: #5eead4;'>Preferred Time:</strong> {appt_data['appointment_time']}</p>
    <p style='color: #cbd5e1; margin: 0.5rem 0;'><strong style='color: #5eead4;'>Reason:</strong> {appt_data['reason']}</p>
    <p style='color: #cbd5e1; margin: 0.5rem 0;'><strong style='color:  #5eead4;'>Triage Level:</strong> <span style='color: {triage_colors.get(triage_level, "#FFA500")}; font-weight: 600; padding: 0.2rem 0.6rem; background: rgba(0, 0, 0, 0.3); border-radius: 6px; border:  1px solid {triage_colors.get(triage_level, "#FFA500")}50;'>{triage_level.upper()}</span></p>
    <p style='color: #cbd5e1; margin: 0.5rem 0;'><strong style='color: #5eead4;'>CDS Consent:</strong> {'✅ Provided' if cds_consent else '❌ Not provided'}</p>
</div>
            """
            st.markdown(summary_html, unsafe_allow_html=True)
            
            col_confirm, col_cancel = st.columns(2)
            
            with col_confirm:
                if st.button("✅ Confirm Appointment", use_container_width=True, type="primary"):
                    if not cds_consent:
                        st.warning("⚠️ Please check the consent box to confirm")
                    else:
                        with st.spinner("📅 Confirming appointment..."):
                            appointment_id = create_appointment(
                                visitor_username=st.session_state.user_info["username"],
                                patient_name=appt_data["patient_name"],
                                phone=appt_data["phone"],
                                email=appt_data["email"],
                                appointment_date=appt_data["appointment_date"],
                                appointment_time=appt_data["appointment_time"],
                                reason=safe_reason,
                                triage_level=triage_level,
                                cds_consent=1 if cds_consent else 0,
                                audit_notes=f"Triage: {triage_level} | Confidence: {confidence:.0%} | CDS Consent: {cds_consent}"
                            )
                            
                            if appointment_id:
                                st.success(f"✅ Appointment Confirmed Successfully!")
                                
                                appointment_display = f"""
                                    <div style='background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); 
                                                padding: 1.5rem; border-radius: 15px; color: white; margin: 1rem 0;'>
                                        <h3 style='color: white; margin-top: 0;'>📋 Appointment Confirmed</h3>
                                        <p><strong>Appointment ID:</strong> {appointment_id}</p>
                                        <p><strong>Patient:</strong> {appt_data['patient_name']}</p>
                                        <p><strong>Date:</strong> {appt_data['appointment_date']}</p>
                                        <p><strong>Time:</strong> {appt_data['appointment_time']}</p>
                                        <p><strong>Triage Level:</strong> <span style='font-weight: 600;'>{triage_level.upper()}</span></p>
                                        <p><strong>CDS Processing:</strong> {'✅ Enabled' if cds_consent else '❌ Not enabled'}</p>
                                        <p style='margin-bottom: 0; font-size: 0.9rem;'>We'll send a confirmation to {appt_data['email']}</p>
                                    </div>
                                """
                                st.markdown(appointment_display, unsafe_allow_html=True)
                                
                                st.session_state.show_triage_analysis = False
                                st.session_state.pending_appointment = None
                                
                                st.balloons()
                            else:
                                st.error("❌ Failed to confirm appointment. Please try again.")
            
            with col_cancel:
                if st.button("❌ Cancel", use_container_width=True):
                    st.session_state.show_triage_analysis = False
                    st.session_state.pending_appointment = None
                    st.rerun()
        else:
            st.error("❌ Access Denied or API Error")
            error_msg = compliance_result.get("error", compliance_result.get("message", "Unknown error"))
            st.warning(f"⚠️ Reason: {error_msg}")
            
            if st.checkbox("Show debug details"):
                st.json(compliance_result)

def render_visitor_appointments():
    """Show visitor's appointment history with encrypted PII display and compliance check"""
    st.markdown("### 📅 My Appointments")
    st.info("🔐 **Privacy Notice:** Your PII (phone, email) is encrypted and can only be decrypted with compliance verification.")
    
    appointments = get_visitor_appointments(st.session_state.user_info["username"])
    
    if not appointments:
        st.info("You don't have any appointments yet. Schedule one using the form above!")
    else:
        st.markdown(f"**Total Appointments:** {len(appointments)}")
        
        for appt in appointments:
            appt_dict = dict(appt)
            appt_id = appt_dict.get("id")
            patient_name = appt_dict.get("patient_name")
            phone = appt_dict.get("phone")
            email = appt_dict.get("email")
            date = appt_dict.get("appointment_date")
            time = appt_dict.get("appointment_time")
            reason = appt_dict.get("reason")
            status = appt_dict.get("status", "pending")
            created = appt_dict.get("created_at")
            
            status_color = {
                'pending': '#FFA500',
                'confirmed': '#28a745',
                'cancelled': '#dc3545',
                'completed': '#6c757d'
            }.get(status, '#6c757d')
            
            # Show only lock icon for encrypted values - don't show actual data
            phone_display = "🔒 [Encrypted]"
            email_display = "🔒 [Encrypted]"
            
            with st.expander(f"🗓️ Appointment {appt_id} - {date} at {time}"):
                st.markdown(f"""
                    <div style='background: rgba(30, 41, 59, 0.85); padding: 1.2rem; border-radius: 15px; border-left: 4px solid {status_color}; border-top: 1px solid rgba(148, 163, 184, 0.3); border-right: 1px solid rgba(148, 163, 184, 0.3); border-bottom: 1px solid rgba(148, 163, 184, 0.3); box-shadow: 0 10px 30px rgba(0, 0, 0, 0.4), 0 0 15px {status_color}20, inset 0 1px 0 rgba(255, 255, 255, 0.1); backdrop-filter: blur(20px);'>
    <p style='color: #e2e8f0; margin:  0.5rem 0;'><strong style='color: #5eead4; font-weight:  600;'>Patient:</strong> <span style='color: #f1f5f9; margin-left: 0.5rem;'>{patient_name}</span></p>
    <p style='color: #e2e8f0; margin: 0.5rem 0;'><strong style='color: #5eead4; font-weight: 600;'>Date & Time:</strong> <span style='color: #f1f5f9; margin-left: 0.5rem;'>{date} at {time}</span></p>
    <p style='color: #e2e8f0; margin: 0.5rem 0;'><strong style='color: #5eead4; font-weight: 600;'>Contact (Encrypted):</strong> <span style='color: #f1f5f9; margin-left: 0.5rem;'>{phone_display} | {email_display}</span></p>
    <p style='color: #e2e8f0; margin: 0.5rem 0;'><strong style='color: #5eead4; font-weight: 600;'>Reason:</strong> <span style='color: #f1f5f9; margin-left: 0.5rem;'>{reason}</span></p>
    <p style='color: #e2e8f0; margin: 0.5rem 0;'><strong style='color:  #5eead4; font-weight: 600;'>Status: </strong> <span style='color:  {status_color}; font-weight: 600; padding: 0.25rem 0.7rem; background: rgba(0, 0, 0, 0.4); border-radius: 8px; border: 1px solid {status_color}; box-shadow: 0 0 12px {status_color}40; margin-left: 0.5rem; display: inline-block;'>{status.upper()}</span></p>
    <p style='font-size: 0.8rem; color: #94a3b8; margin: 0.8rem 0 0 0; padding-top: 0.5rem; border-top: 1px solid rgba(148, 163, 184, 0.2);'>Created: {created}</p>
</div>
                """, unsafe_allow_html=True)
                
                # Add compliance check button to decrypt PII
                col1, col2 = st.columns(2)
                with col1:
                    if st.button("🔓 Request PII Access via Compliance", key=f"decrypt_{appt_id}"):
                        # Call compliance API to verify access
                        user_role = st.session_state.user_info.get("role", "visitor")
                        
                        with st.spinner("🔄 Verifying access through compliance system..."):
                            compliance_result = call_compliance_api(
                                query=f"View PII for appointment {appt_id}",
                                user_role=user_role.lower(),
                                request_type="patient_lookup"
                            )
                        
                        # Show bypass mode warning if applicable
                        if compliance_result.get("bypass_mode"):
                            st.warning("⚠️ **BYPASS MODE** - Backend server unavailable. Showing PII without compliance verification.")
                        
                        if compliance_result.get("access_granted"):
                            st.success("✅ Access Granted! PII decrypted:")
                            st.markdown(f"""
                                <div style='background: rgba(34, 197, 94, 0.15); padding: 1rem; border-radius: 12px; border-left: 4px solid #22c55e; border-top: 1px solid rgba(34, 197, 94, 0.3); border-right: 1px solid rgba(34, 197, 94, 0.3); border-bottom: 1px solid rgba(34, 197, 94, 0.3); box-shadow: 0 10px 30px rgba(0, 0, 0, 0.4), 0 0 20px rgba(34, 197, 94, 0.2), inset 0 1px 0 rgba(255, 255, 255, 0.1); backdrop-filter: blur(20px);'>
    <p style='color: #e2e8f0; margin:  0.5rem 0;'><strong style='color: #4ade80; font-weight: 600;'>Phone:</strong> <code style='background: rgba(15, 23, 42, 0.8); color: #5eead4; padding: 0.3rem 0.6rem; border-radius: 6px; border: 1px solid rgba(34, 197, 94, 0.3); font-size: 0.88rem; margin-left: 0.5rem;'>{phone}</code></p>
    <p style='color: #e2e8f0; margin: 0.5rem 0;'><strong style='color:  #4ade80; font-weight: 600;'>Email: </strong> <code style='background:  rgba(15, 23, 42, 0.8); color: #5eead4; padding: 0.3rem 0.6rem; border-radius: 6px; border: 1px solid rgba(34, 197, 94, 0.3); font-size: 0.88rem; margin-left: 0.5rem;'>{email}</code></p>
    <p style='font-size: 0.82rem; color: #86efac; margin: 0.7rem 0 0 0; padding-top:  0.5rem; border-top: 1px solid rgba(34, 197, 94, 0.2);'>✓ Compliance verified | Audit logged</p>
</div>
                            """, unsafe_allow_html=True)
                            
                            # Show compliance details with structured display
                            with st.expander("📋 Compliance Report"):
                                st.markdown("**Access Verification Details:**")
                                
                                col1, col2, col3 = st.columns(3)
                                with col1:
                                    st.metric("Access Status", "✅ Granted")
                                with col2:
                                    st.metric("Request Type", compliance_result.get("request_type", "patient_lookup"))
                                with col3:
                                    st.metric("User Role", compliance_result.get("user_role", "visitor"))
                                
                                st.markdown("**Regulations Applied:**")
                                regulatory_data = compliance_result.get("regulatory_compliance", {})
                                regulations = regulatory_data.get("regulations_applied", []) or compliance_result.get("regulations", [])
                                if regulations:
                                    for reg in regulations:
                                        st.write(f"✓ {reg}")
                                else:
                                    st.write("✓ HIPAA, GDPR, PCI-DSS")
                                
                                st.markdown("**Agents Executed:**")
                                agents = regulatory_data.get("agents_executed", []) or compliance_result.get("agents", [])
                                if agents:
                                    for agent in agents:
                                        st.write(f"• {agent}")
                                else:
                                    st.write("• AccessControlAgent\n• PrivacyAgent\n• DecryptionAgent\n• AuditAgent")
                                
                                st.markdown("**Full Compliance Response:**")
                                st.json(compliance_result)
                            
                            # Show audit trail
                            if compliance_result.get("audit_log"):
                                st.markdown("**Compliance Audit Trail:**")
                                for entry in compliance_result.get("audit_log", []):
                                    st.write(f"- {entry.get('agent', 'System')}: {entry.get('action', 'N/A')}")
                        else:
                            st.error("❌ Access Denied")
                            st.warning(f"⚠️ Reason: {compliance_result.get('error', 'Access denied by compliance policy')}")
                            
                            # Show denial reason with structured display
                            with st.expander("📋 Compliance Details"):
                                st.markdown("**Access Denial Analysis:**")
                                
                                col1, col2 = st.columns(2)
                                with col1:
                                    st.metric("Access Status", "❌ Denied")
                                with col2:
                                    st.metric("Request Type", compliance_result.get("request_type", "patient_lookup"))
                                
                                if compliance_result.get("message"):
                                    st.info(compliance_result.get("message"))
                                
                                st.markdown("**Full Response:**")
                                st.json(compliance_result)


# -------------------------------------------------------------
# CUSTOM CSS
# -------------------------------------------------------------
CUSTOM_CSS = """
@import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap');

/* =========================================================
   GLOBAL BASE - DARK THEME
   ========================================================= */
html, body, . stApp {
    font-family: 'Inter', sans-serif;
    color: #e2e8f0;
    background:  linear-gradient(135deg, #0f172a 0%, #1e293b 50%, #0f172a 100%) ! important;

}

. stApp {
    background: linear-gradient(135deg, #0f172a 0%, #1e293b 50%, #0f172a 100%) !important;
    position: relative;
}

/* Animated gradient background */
.stApp::before {
    content: '';
    position: fixed;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    background: 
        radial-gradient(circle at 20% 50%, rgba(20, 184, 166, 0.15) 0%, transparent 50%),
        radial-gradient(circle at 80% 80%, rgba(99, 102, 241, 0.15) 0%, transparent 50%),
        radial-gradient(circle at 40% 20%, rgba(236, 72, 153, 0.1) 0%, transparent 50%);
    z-index: 0;
    pointer-events: none;
    animation: gradientShift 15s ease infinite;
}



@keyframes gradientShift {
    0%, 100% { opacity: 1; }
    50% { opacity: 0.8; }
}

. block-container {
    max-width: 1320px;
    padding-top: 1. 8rem;
    padding-bottom: 2.5rem;
    position: relative;
    z-index: 1;
}

/* =========================================================
   HEADERS & TEXT
   ========================================================= */
h1 {
    font-size: 2.5rem;
    font-weight: 800;
    background: linear-gradient(135deg, #14b8a6 0%, #06b6d4 50%, #6366f1 100%);
    -webkit-background-clip: text;
    -webkit-text-fill-color: transparent;
    background-clip: text;
    text-shadow: 0 0 40px rgba(20, 184, 166, 0.3);
    animation: titleGlow 3s ease-in-out infinite;
}

@keyframes titleGlow {
    0%, 100% { filter: brightness(1); }
    50% { filter:  brightness(1.2); }
}

h2 {
    font-size: 1.6rem;
    font-weight:  700;
    color: #f1f5f9;
    text-shadow: 0 2px 10px rgba(241, 245, 249, 0.1);
}

h3 {
    font-size: 1.25rem;
    font-weight:  600;
    color: #cbd5e1;
}

p, label, span, li {
    font-size: 0.95rem;
    color: #cbd5e1;
}

/* =========================================================
   GLASS MORPHISM CARD CONTAINERS
   ========================================================= */
.glass-card {
    background: rgba(30, 41, 59, 0.7);
    border-radius: 20px;
    padding: 1.5rem 1.8rem;
    border: 1px solid rgba(148, 163, 184, 0.2);
    box-shadow: 
        0 20px 50px rgba(0, 0, 0, 0.5),
        inset 0 1px 0 rgba(255, 255, 255, 0.1);
    backdrop-filter: blur(20px);
    margin-bottom: 1.2rem;
    position: relative;
    overflow: hidden;
    transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
}

.glass-card:: before {
    content: '';
    position: absolute;
    top: 0;
    left:  -100%;
    width: 100%;
    height: 100%;
    background: linear-gradient(90deg, transparent, rgba(255, 255, 255, 0.05), transparent);
    transition: left 0.5s;
}

.glass-card:hover {
    transform: translateY(-5px);
    border-color: rgba(20, 184, 166, 0.5);
    box-shadow: 
        0 25px 60px rgba(0, 0, 0, 0.6),
        0 0 30px rgba(20, 184, 166, 0.3),
        inset 0 1px 0 rgba(255, 255, 255, 0.15);
}

.glass-card: hover::before {
    left:  100%;
}

/* =========================================================
   BADGES WITH GLOW
   ========================================================= */
.badge-row {
    display: flex;
    justify-content: flex-end;
    gap: 0.8rem;
    margin-bottom:  1.2rem;
}

.badge-pill {
    background: linear-gradient(135deg, rgba(20, 184, 166, 0.2), rgba(99, 102, 241, 0.2));
    border-radius: 999px;
    padding: 0.4rem 1.1rem;
    border: 1px solid rgba(20, 184, 166, 0.4);
    font-size: 0.8rem;
    font-weight:  600;
    color: #5eead4;
    box-shadow:  
        0 4px 15px rgba(20, 184, 166, 0.25),
        inset 0 1px 0 rgba(255, 255, 255, 0.1);
    transition: all 0.3s ease;
    position: relative;
    overflow: hidden;
}

.badge-pill::before {
    content: '';
    position: absolute;
    top: -50%;
    left: -50%;
    width: 200%;
    height: 200%;
    background: radial-gradient(circle, rgba(255, 255, 255, 0.2) 0%, transparent 70%);
    opacity: 0;
    transition:  opacity 0.3s;
}

.badge-pill:hover {
    transform: scale(1.05);
    box-shadow: 
        0 6px 25px rgba(20, 184, 166, 0.4),
        inset 0 1px 0 rgba(255, 255, 255, 0.2);
}

.badge-pill:hover::before {
    opacity: 1;
}

/* =========================================================
   INPUTS WITH NEON GLOW
   ========================================================= */
div.stTextInput input,
div.stSelectbox select,
div.stTextArea textarea {
    border-radius: 12px;
    border: 1px solid rgba(148, 163, 184, 0.3);
    background: rgba(15, 23, 42, 0.6);
    color: #f1f5f9;
    font-size: 0.92rem;
    padding: 0.75rem 1rem;
    transition: all 0.3s ease;
    box-shadow: inset 0 2px 4px rgba(0, 0, 0, 0.3);
}

div.stTextInput input:focus,
div.stSelectbox select:focus,
div.stTextArea textarea:focus {
    border-color: #14b8a6;
    background: rgba(15, 23, 42, 0.8);
    box-shadow: 
        0 0 0 3px rgba(20, 184, 166, 0.3),
        0 0 20px rgba(20, 184, 166, 0.5),
        inset 0 2px 4px rgba(0, 0, 0, 0.3);
    outline: none;
}

div.stTextInput input:: placeholder,
div.stTextArea textarea::placeholder {
    color: #64748b;
}

/* =========================================================
   BUTTONS WITH ANIMATED GRADIENT
   ========================================================= */
.stButton > button {
    border-radius: 999px;
    padding: 0.6rem 1.8rem;
    background: linear-gradient(135deg, #14b8a6, #06b6d4, #6366f1);
    background-size: 200% 200%;
    color: #ffffff;
    font-size: 0.92rem;
    font-weight:  600;
    border: none;
    box-shadow: 
        0 8px 25px rgba(20, 184, 166, 0.4),
        inset 0 1px 0 rgba(255, 255, 255, 0.2);
    transition: all 0.4s cubic-bezier(0.4, 0, 0.2, 1);
    position: relative;
    overflow: hidden;
    animation: gradientAnimation 3s ease infinite;
}

@keyframes gradientAnimation {
    0%, 100% { background-position: 0% 50%; }
    50% { background-position: 100% 50%; }
}

.stButton > button:: before {
    content: '';
    position: absolute;
    top: 50%;
    left: 50%;
    width: 0;
    height: 0;
    border-radius: 50%;
    background: rgba(255, 255, 255, 0.3);
    transform: translate(-50%, -50%);
    transition: width 0.6s, height 0.6s;
}

.stButton > button:hover {
    transform: translateY(-3px) scale(1.02);
    box-shadow: 
        0 15px 40px rgba(20, 184, 166, 0.6),
        0 0 30px rgba(99, 102, 241, 0.5),
        inset 0 1px 0 rgba(255, 255, 255, 0.3);
}

.stButton > button:hover::before {
    width: 300px;
    height: 300px;
}

. stButton > button:active {
    transform: translateY(-1px) scale(1);
}

/* Secondary Button */
.stButton > button[kind="secondary"] {
    background: rgba(51, 65, 85, 0.6);
    color: #cbd5e1;
    border: 1px solid rgba(148, 163, 184, 0.3);
    box-shadow: 
        0 4px 15px rgba(0, 0, 0, 0.3),
        inset 0 1px 0 rgba(255, 255, 255, 0.1);
    animation: none;
}

.stButton > button[kind="secondary"]:hover {
    background: rgba(71, 85, 105, 0.8);
    border-color: rgba(148, 163, 184, 0.5);
}

/* =========================================================
   EXPANDERS
   ========================================================= */
. stExpander {
    border-radius: 16px !important;
    border:  1px solid rgba(148, 163, 184, 0.2) !important;
    background:  rgba(30, 41, 59, 0.6) !important;
    backdrop-filter: blur(10px);
    box-shadow: 0 10px 30px rgba(0, 0, 0, 0.4);
    transition: all 0.3s ease;
}

.stExpander:hover {
    border-color: rgba(20, 184, 166, 0.4) !important;
    box-shadow: 0 15px 40px rgba(0, 0, 0, 0.5);
}

.stExpander summary {
    font-weight: 600;
    font-size: 0.95rem;
    color: #cbd5e1;
}

. stExpander[open] {
    border-color: rgba(20, 184, 166, 0.5) !important;
}

/* =========================================================
   FINAL ANSWER BOX WITH GRADIENT BORDER
   ========================================================= */
#final_answer_markdown {
    max-height: 480px;
    overflow-y:  auto;
    background: rgba(15, 23, 42, 0.8);
    border: 2px solid transparent;
    background-clip: padding-box;
    padding: 1.5rem 1.6rem;
    border-radius:  16px;
    color: #e2e8f0;
    position: relative;
    box-shadow: 
        0 20px 50px rgba(0, 0, 0, 0.5),
        inset 0 1px 0 rgba(255, 255, 255, 0.1);
}

#final_answer_markdown:: before {
    content: '';
    position: absolute;
    inset: 0;
    border-radius: 16px;
    padding: 2px;
    background: linear-gradient(135deg, #14b8a6, #6366f1, #ec4899);
    -webkit-mask: linear-gradient(#fff 0 0) content-box, linear-gradient(#fff 0 0);
    -webkit-mask-composite: xor;
    mask-composite:  exclude;
    pointer-events: none;
    animation: borderRotate 3s linear infinite;
}

@keyframes borderRotate {
    0%, 100% { filter: hue-rotate(0deg); }
    50% { filter: hue-rotate(45deg); }
}

#final_answer_markdown h3 {
    color: #5eead4;
    border-bottom: 2px solid rgba(20, 184, 166, 0.3);
    padding-bottom: 0.5rem;
    text-shadow: 0 0 10px rgba(94, 234, 212, 0.3);
}

/* Custom scrollbar */
#final_answer_markdown::-webkit-scrollbar {
    width: 8px;
}

#final_answer_markdown::-webkit-scrollbar-track {
    background: rgba(15, 23, 42, 0.5);
    border-radius: 10px;
}

#final_answer_markdown::-webkit-scrollbar-thumb {
    background:  linear-gradient(180deg, #14b8a6, #6366f1);
    border-radius: 10px;
}

#final_answer_markdown::-webkit-scrollbar-thumb:hover {
    background: linear-gradient(180deg, #0d9488, #4f46e5);
}

/* =========================================================
   LOGIN / FORMS WITH PREMIUM LOOK
   ========================================================= */
[data-testid="stForm"] {
    background: rgba(30, 41, 59, 0.85);
    border-radius: 24px;
    padding: 2rem 2.2rem;
    border: 1px solid rgba(148, 163, 184, 0.3);
    box-shadow: 
        0 30px 60px rgba(0, 0, 0, 0.6),
        0 0 50px rgba(20, 184, 166, 0.1),
        inset 0 1px 0 rgba(255, 255, 255, 0.1);
    backdrop-filter: blur(20px);
    position: relative;
    overflow: hidden;
}

[data-testid="stForm"]::before {
    content: '';
    position: absolute;
    top: -50%;
    left: -50%;
    width: 200%;
    height: 200%;
    background: radial-gradient(circle, rgba(20, 184, 166, 0.1) 0%, transparent 70%);
    animation: formGlow 4s ease-in-out infinite;
}

@keyframes formGlow {
    0%, 100% { opacity: 0. 5; transform: rotate(0deg); }
    50% { opacity: 1; transform: rotate(180deg); }
}

/* =========================================================
   TABS WITH MODERN DESIGN
   ========================================================= */
.stTabs [data-baseweb="tab-list"] {
    gap: 0.5rem;
    background: transparent;
}

.stTabs [data-baseweb="tab"] {
    border-radius: 12px;
    background: rgba(30, 41, 59, 0.6);
    font-size: 0.9rem;
    color: #94a3b8;
    border:  1px solid rgba(148, 163, 184, 0.2);
    padding: 0.6rem 1.2rem;
    transition: all 0.3s ease;
}

.stTabs [data-baseweb="tab"]:hover {
    background: rgba(51, 65, 85, 0.8);
    color: #cbd5e1;
}

. stTabs [aria-selected="true"] {
    background: linear-gradient(135deg, rgba(20, 184, 166, 0.3), rgba(99, 102, 241, 0.3)) !important;
    color: #5eead4 !important;
    font-weight: 600;
    border:  1px solid rgba(20, 184, 166, 0.5) !important;
    box-shadow: 
        0 4px 15px rgba(20, 184, 166, 0.3),
        inset 0 1px 0 rgba(255, 255, 255, 0.1);
}

/* =========================================================
   PII HIGHLIGHTING WITH DARK THEME
   ========================================================= */
.pii-highlight {
    padding: 3px 8px;
    border-radius:  6px;
    font-weight: 600;
    box-shadow: 0 2px 8px rgba(0, 0, 0, 0.3);
}

.pii-person { 
    background: rgba(251, 191, 36, 0.3);
    color: #fbbf24;
    border: 1px solid rgba(251, 191, 36, 0.5);
}

.pii-email { 
    background: rgba(34, 197, 94, 0.3);
    color: #4ade80;
    border: 1px solid rgba(34, 197, 94, 0.5);
}

.pii-phone { 
    background:  rgba(59, 130, 246, 0.3);
    color: #60a5fa;
    border:  1px solid rgba(59, 130, 246, 0.5);
}

.pii-ssn { 
    background: rgba(239, 68, 68, 0.3);
    color: #f87171;
    border: 1px solid rgba(239, 68, 68, 0.5);
}

.pii-location { 
    background: rgba(168, 85, 247, 0.3);
    color: #c084fc;
    border: 1px solid rgba(168, 85, 247, 0.5);
}

/* =========================================================
   ADDITIONAL POLISH
   ========================================================= */
/* Selection color */
:: selection {
    background: rgba(20, 184, 166, 0.3);
    color: #5eead4;
}

/* Links */
a {
    color: #5eead4;
    text-decoration: none;
    transition:  all 0.3s ease;
    position: relative;
}

a:: after {
    content: '';
    position: absolute;
    bottom:  -2px;
    left:  0;
    width: 0;
    height: 2px;
    background: linear-gradient(90deg, #14b8a6, #6366f1);
    transition: width 0.3s ease;
}

a:hover::after {
    width: 100%;
}

a:hover {
    color: #2dd4bf;
    text-shadow: 0 0 10px rgba(20, 184, 166, 0.5);
}

/* Dividers */
hr {
    border: none;
    height: 1px;
    background: linear-gradient(90deg, transparent, rgba(148, 163, 184, 0.3), transparent);
    margin: 1. 5rem 0;
}

/* Code blocks */
code {
    background: rgba(15, 23, 42, 0.8);
    color: #5eead4;
    padding:  0.2rem 0.5rem;
    border-radius:  6px;
    border: 1px solid rgba(20, 184, 166, 0.3);
    font-size: 0.85rem;
}

pre {
    background: rgba(15, 23, 42, 0.9) !important;
    border:  1px solid rgba(148, 163, 184, 0.2);
    border-radius: 12px;
    padding: 1rem;
    box-shadow: inset 0 2px 8px rgba(0, 0, 0, 0.4);
}
"""


def render_login_page():
    """Enhanced login page with visitor registration"""
    st.markdown(f"<style>{CUSTOM_CSS}</style>", unsafe_allow_html=True)

    st.markdown(
        "<h1 style='text-align: center; color:#5eead4;'>Healthcare Compliance AI</h1>",
        unsafe_allow_html=True,
    )

    col1, col2, col3 = st.columns([1, 2, 1])
    
    with col2:
        # Tab selection
        tab1, tab2 = st.tabs(["🔐 Login", "📝 Visitor Registration"])
        
        with tab1:
            with st.form(key=f"login_form_{st.session_state.get('user_info')}", clear_on_submit=False):
                st.markdown("### Sign In to Your Account")
                username = st.text_input("Username", key="login_username")
                password = st.text_input("Password", type="password", key="login_password")
                submitted = st.form_submit_button("Login", use_container_width=True)

                if submitted:
                    user = verify_user(username, password)
                    if user:
                        st.session_state.user_info = {
                            "username": username,
                            "name": user["name"],
                            "role": user["role"],
                            "email": user.get("email", ""),
                            "phone": user.get("phone", "")
                        }
                        st.success(f"Welcome back, {user['name']}!")
                        st.rerun()
                    else:
                        st.error("Invalid username or password")
        
        with tab2:
            with st.form(key="visitor_registration_form", clear_on_submit=True):
                st.markdown("### Register as a Visitor")
                st.info("✅ Register to schedule appointments and access our healthcare chatbot. Your PII will be encrypted for security.")
                
                reg_username = st.text_input("Choose a Username*", key="reg_username")
                reg_password = st.text_input("Password*", type="password", key="reg_password")
                reg_password_confirm = st.text_input("Confirm Password*", type="password", key="reg_password_confirm")
                reg_name = st.text_input("Full Name*", key="reg_name")
                reg_email = st.text_input("Email Address*", key="reg_email", help="Will be encrypted in database")
                reg_phone = st.text_input("Phone Number*", key="reg_phone", help="Will be encrypted in database")
                
                st.markdown("""
                    <div style='background: #f0f9ff; padding: 0.8rem; border-radius: 8px; border-left: 4px solid #0ea5e9; margin: 0.5rem 0;'>
                        <p style='margin: 0; font-size: 0.8rem; color: #0369a1;'>
                            🔐 <strong>Security Notice:</strong> Your email and phone number will be encrypted using Fernet encryption 
                            and stored securely in our database. You can only access decrypted values after compliance verification.
                        </p>
                    </div>
                """, unsafe_allow_html=True)
                
                reg_submitted = st.form_submit_button("Register", use_container_width=True)
                
                if reg_submitted:
                    # Validation
                    if not all([reg_username, reg_password, reg_name, reg_email, reg_phone]):
                        st.error("❌ All fields are required")
                    elif reg_password != reg_password_confirm:
                        st.error("❌ Passwords do not match")
                    elif len(reg_password) < 8:
                        st.error("❌ Password must be at least 8 characters long")
                    elif not re.search(r'[!@#$%^&*(),.?":{}|<>]', reg_password):
                        st.error("❌ Password must contain at least one special character (!@#$%^&*...)")
                    else:
                        result = register_visitor(reg_username, reg_password, reg_name, reg_email, reg_phone)
                        if "✅" in result:
                            st.success(result)
                            st.markdown("""
                                <div style='background: #f0fdf4; padding: 1rem; border-radius: 10px; border-left: 4px solid #22c55e; margin: 1rem 0;'>
                                    <p><strong>✅ Registration Successful!</strong></p>
                                    <p>Your PII (email and phone) has been encrypted and saved to our secure database.</p>
                                    <p>Please go to the <strong>Login</strong> tab to sign in.</p>
                                    <p style='font-size: 0.8rem; color: #16a34a; margin-bottom: 0;'>
                                        🔒 All your data is protected under HIPAA and GDPR compliance.
                                    </p>
                                </div>
                            """, unsafe_allow_html=True)
                        else:
                            st.error(result)


def render_main_app():
    """Main application UI for logged-in users"""
    
    # Apply CSS
    st.markdown(f"<style>{CUSTOM_CSS}</style>", unsafe_allow_html=True)
    
    # Check if user is a visitor
    if st.session_state.user_info["role"] == "Visitor":
        # Initialize visitor session state
        if "show_triage_analysis" not in st.session_state:
            st.session_state.show_triage_analysis = False
        if "pending_appointment" not in st.session_state:
            st.session_state.pending_appointment = None
        if "triage_level" not in st.session_state:
            st.session_state.triage_level = None
        if "appointment_available" not in st.session_state:
            st.session_state.appointment_available = None
        
        # Show visitor appointments UI
        logo_col, title_col = st.columns([1, 10])
        with logo_col:
            st.markdown(
                """
                <svg width="60" height="60" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <path d="M12 21.35L10.55 20.03C5.4 15.36 2 12.28 2 8.5C2 5.42 4.42 3 7.5 3C9.24 3 10.91 3.81 12 5.09C13.09 3.81 14.76 3 16.5 3C19.58 3 22 5.42 22 8.5C22 12.28 18.6 15.36 13.45 20.04L12 21.35Z" fill="#5eead4" fill-opacity="0.3"/>
                    <path d="M4 12H7L9 9L11 15L13 11L15 13H20" stroke="#5eead4" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                </svg>
            """,
                unsafe_allow_html=True,
            )
        with title_col:
            st.markdown(
                """
                <h1 style="color:#5eead4; margin-top: -10px;">Healthcare Compliance AI</h1>
                """,
                unsafe_allow_html=True,
            )
        
        # User badge and logout
        st.markdown('<div class="badge-row">', unsafe_allow_html=True)
        col_b1, col_b2, col_b3, col_b4 = st.columns([2, 2, 2, 1])
        with col_b1:
            st.markdown(
                f'<div class="badge-pill">👤 Welcome, <strong>{st.session_state.user_info["name"]}</strong></div>',
                unsafe_allow_html=True,
            )
        with col_b4:
            if st.button("Logout", key="logout_button"):
                st.session_state.user_info = None
                st.session_state.clear()
                st.rerun()
        st.markdown("</div>", unsafe_allow_html=True)
        
        st.markdown("""
            <div style='background: rgba(30, 41, 59, 0.85); padding: 1.5rem; border-radius: 20px; margin: 1rem 0; border: 1px solid rgba(148, 163, 184, 0.3); box-shadow: 0 20px 50px rgba(0, 0, 0, 0.5), inset 0 1px 0 rgba(255, 255, 255, 0.1); backdrop-filter: blur(20px);'>
    <h2 style='background: linear-gradient(135deg, #14b8a6 0%, #06b6d4 50%, #6366f1 100%); -webkit-background-clip: text; -webkit-text-fill-color: transparent; background-clip: text; margin-top: 0; font-weight: 700;'>🏥 Welcome to Healthcare Portal</h2>
    <p style='color: #cbd5e1; font-size: 0.95rem; line-height: 1.6;'>All your data is protected under HIPAA and GDPR compliance.  Access is verified for each action.</p>
</div>
        """, unsafe_allow_html=True)
        
        # Visitor tabs
        tab1, tab2 = st.tabs(["📅 Schedule Appointment", "📋 My Appointments"])
        
        with tab1:
            render_appointment_chatbot()
        
        with tab2:
            render_visitor_appointments()
    
    else:
        # Clinical workspace for non-visitor users (Admin, Clinician, etc.)
        
        # Recompute patient IDs each run (reflects any new saves)
        patient_ids = ClinicalDataStore.list_patient_ids()
        
        # ------------- INITIAL SESSION STATE (MUST BE FIRST) -------------
        app_state_keys = [
            "selected_patient_id",
            "patient_action",
            "next_selected_patient_id",
            "risk_prediction_result",
            "last_selected_patient_id",
            "patient_id",
            "age",
            "gender",
            "allergies",
            "conditions",
            "medications",
            "original_patient_id",
            "demo_patient_badge",
            "current_patient_badge",
            "log_page_number",
            "editing_user_id",
            "final_answer",
            "save_status",
            "query",
            "mic_recorder",
            "processed_audio_hash",
            "display_patient_details",
            "last_display_id",
        ]
        for key in app_state_keys:
            if key not in st.session_state:
                st.session_state[key] = None  # generic default

        # ✅ Make sure pagination index is always an int
        if st.session_state.log_page_number is None:
            st.session_state.log_page_number = 0

        if (
            "selected_patient_id" not in st.session_state
            or st.session_state.selected_patient_id is None
        ):
            st.session_state.selected_patient_id = patient_ids[0] if patient_ids else ""

        if "patient_action" not in st.session_state or st.session_state.patient_action is None:
            st.session_state.patient_action = "Select Existing Patient"

        if st.session_state.get("next_selected_patient_id"):
            # Set the main state variable BEFORE the widget is instantiated
            st.session_state.selected_patient_id = st.session_state.next_selected_patient_id
            st.session_state.next_selected_patient_id = None  # Clear the temporary variable

        # Initialize form fields from the current selected patient at first load
        if st.session_state.patient_id is None:
            (
                pid,
                age,
                gender,
                allergies,
                conditions,
                meds,
                badge_main,
                badge_workspace,
                original_id,
                cleared,
            ) = on_patient_dropdown_change(st.session_state.selected_patient_id or None)
            st.session_state.patient_id = pid
            st.session_state.age = age
            st.session_state.gender = gender
            st.session_state.allergies = allergies
            st.session_state.conditions = conditions
            st.session_state.medications = meds
            st.session_state.original_patient_id = original_id
            st.session_state.demo_patient_badge = badge_main
            st.session_state.current_patient_badge = badge_workspace
            st.session_state.final_answer = cleared
            st.session_state.save_status = ""
            st.session_state.query = ""
            st.session_state.risk_prediction_result = None

        # ---------------- HEADER ----------------
        logo_col, title_col = st.columns([1, 10])
        with logo_col:
            # A simple SVG logo embedded as a data URI
            st.markdown(
                """
                <svg width="60" height="60" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <path d="M12 21.35L10.55 20.03C5.4 15.36 2 12.28 2 8.5C2 5.42 4.42 3 7.5 3C9.24 3 10.91 3.81 12 5.09C13.09 3.81 14.76 3 16.5 3C19.58 3 22 5.42 22 8.5C22 12.28 18.6 15.36 13.45 20.04L12 21.35Z" fill="#5eead4" fill-opacity="0.3"/>
                    <path d="M4 12H7L9 9L11 15L13 11L15 13H20" stroke="#5eead4" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                </svg>
            """,
                unsafe_allow_html=True,
            )
        with title_col:
            st.markdown(
                """
                <h1 style="color:#5eead4; margin-top: -10px;">Clinical AI Assistant</h1>
                """,
                unsafe_allow_html=True,
            )

        st.markdown(
            """
            <p style="font-size:0.9rem; color:#94a3b8;">
            ⚠ This system uses <strong>synthetic/LLM-generated reasoning</strong> and data. It is for demonstration and learning only — <strong>not real medical advice</strong>.
            </p>
        """,
            unsafe_allow_html=True,
        )

        st.markdown('<div class="badge-row">', unsafe_allow_html=True)
        col_b1, col_b2, col_b3, col_b4 = st.columns([2, 2, 2, 1])
        with col_b1:
            st.markdown(
                f'<div class="badge-pill">👤 Welcome, <strong>{st.session_state.user_info["name"]}</strong> ({st.session_state.user_info["role"]})</div>',
                unsafe_allow_html=True,
            )
        with col_b2:
            st.markdown(
                f'<div class="badge-pill">{st.session_state.get("demo_patient_badge", "Demo Patient: –")}</div>',
                unsafe_allow_html=True,
            )
        with col_b3:
            st.markdown(
                '<div class="badge-pill">🟡 <strong>Simulation Mode</strong></div>',
                unsafe_allow_html=True,
            )
        with col_b4:
            if st.button("Logout", key="logout_button"):
                st.session_state.user_info = None
                st.session_state.clear()
                st.rerun()
        st.markdown("</div>", unsafe_allow_html=True)

        # --- TABS FOR MAIN APP AND ADMIN VIEW ---
        main_tab_list = ["Clinical Workspace"]
        is_admin = st.session_state.user_info["role"] == "Admin"

        if is_admin:
            main_tab_list.append("Admin Panel")

        tab1, *admin_tabs = st.tabs(main_tab_list)

        with tab1:
            # ------------- TOP: CONTEXT + WORKSPACE -------------
            col_left, col_right = st.columns([1, 2])

            # LEFT: Patient Context
            with col_left:
                st.markdown("### 👤 Patient Context")

                # Action selection
                st.radio(
                    "Patient Management",
                    ["Select Existing Patient", "Create / Update Patient"],
                    key="patient_action",
                )

                st.markdown("---")

                if st.session_state.patient_action == "Select Existing Patient":
                    st.markdown("#### Select Patient to View Details")

                    current_display_id = st.session_state.get("display_patient_id", "")
                    options_with_empty = [""] + patient_ids
                    default_index = (
                        options_with_empty.index(current_display_id)
                        if current_display_id in options_with_empty
                        else 0
                    )

                    selected_id_display = st.selectbox(
                        "Select Patient ID",
                        options=options_with_empty,
                        index=default_index,
                        key="display_patient_id",
                    )

                    if selected_id_display != st.session_state.get("last_display_id", None):
                        st.session_state.last_display_id = selected_id_display

                        if selected_id_display:
                            ctx = ClinicalDataStore.get_patient_context(
                                selected_id_display
                            )
                            if ctx:
                                patient_row = ctx.get("patient", {})
                                allergies_list = [
                                    a.get("allergen", "")
                                    for a in ctx.get("allergies", [])
                                    if a.get("allergen")
                                ]
                                conditions_list = [
                                    c.get("condition_name", "")
                                    for c in ctx.get("conditions", [])
                                    if c.get("condition_name")
                                ]
                                meds_list = [
                                    m.get("drug_name", "")
                                    for m in ctx.get("medications", [])
                                    if m.get("drug_name")
                                ]

                                allergies_str = (
                                    ", ".join(filter(None, allergies_list)) or "None"
                                )
                                conditions_str = (
                                    ", ".join(filter(None, conditions_list)) or "None"
                                )
                                meds_str = ", ".join(filter(None, meds_list)) or "None"

                                st.session_state.current_patient_badge = (
                                    f"Current Patient: **{selected_id_display}**"
                                )

                                st.session_state.display_patient_details = {
                                    "id": patient_row.get("patient_id", "N/A"),
                                    "age": patient_row.get("age", "N/A"),
                                    "gender": patient_row.get("gender", "N/A"),
                                    "allergies": allergies_str,
                                    "conditions": conditions_str,
                                    "medications": meds_str,
                                }
                            else:
                                st.session_state.display_patient_details = None
                                st.session_state.current_patient_badge = (
                                    "Current Patient: –"
                                )
                        else:
                            st.session_state.display_patient_details = None
                            st.session_state.current_patient_badge = "Current Patient: –"

                        st.session_state.final_answer = ""
                        st.rerun()

                    if st.session_state.get("display_patient_details"):
                        details = st.session_state.display_patient_details
                        st.markdown(f"**Patient ID:** `{details.get('id', 'N/A')}`")
                        st.markdown(f"**Age:** {details.get('age', 'N/A')}")
                        st.markdown(f"**Gender:** {details.get('gender', 'N/A')}")
                        st.markdown("**Known Allergies:**")
                        st.markdown(f"> {details.get('allergies')}")
                        st.markdown("**Medical Conditions:**")
                        st.markdown(f"> {details.get('conditions')}")
                        st.markdown("**Current Medications:**")
                        st.markdown(f"> {details.get('medications')}")
                    else:
                        st.info("Select a patient to view their clinical data.")

                elif st.session_state.patient_action == "Create / Update Patient":
                    st.markdown("#### Create or Edit Patient Details")

                    current_edit_id = st.session_state.get("selected_patient_id", "")
                    options_with_empty = [""] + patient_ids
                    default_edit_index = (
                        options_with_empty.index(current_edit_id)
                        if current_edit_id in options_with_empty
                        else 0
                    )

                    st.selectbox(
                        "Load Existing Patient to Edit (optional)",
                        options=options_with_empty,
                        index=default_edit_index,
                        key="selected_patient_id",
                    )

                    if st.session_state.selected_patient_id != st.session_state.get(
                        "last_selected_patient_id"
                    ):
                        (
                            pid,
                            age,
                            gender,
                            allergies,
                            conditions,
                            meds,
                            badge_main,
                            badge_workspace,
                            original_id,
                            cleared,
                        ) = on_patient_dropdown_change(
                            st.session_state.selected_patient_id or None
                        )

                        st.session_state.patient_id = pid
                        st.session_state.age = age
                        st.session_state.gender = gender
                        st.session_state.allergies = allergies
                        st.session_state.conditions = conditions
                        st.session_state.medications = meds
                        st.session_state.original_patient_id = original_id
                        st.session_state.demo_patient_badge = badge_main
                        st.session_state.current_patient_badge = badge_workspace
                        st.session_state.final_answer = cleared
                        st.session_state.save_status = ""
                        st.session_state.last_selected_patient_id = (
                            st.session_state.selected_patient_id
                        )
                        st.rerun()

                    with st.form("patient_edit_form"):
                        col_pid, col_age = st.columns(2)
                        with col_pid:
                            st.text_input(
                                "Patient ID*",
                                value=st.session_state.patient_id,
                                key="patient_id_input",
                            )
                        with col_age:
                            st.text_input(
                                "Age",
                                value=st.session_state.age,
                                key="age_input",
                            )

                        st.selectbox(
                            "Gender",
                            options=["Male", "Female", "Other"],
                            index=[
                                "Male",
                                "Female",
                                "Other",
                            ].index(st.session_state.gender)
                            if st.session_state.gender in ["Male", "Female", "Other"]
                            else 0,
                            key="gender_input",
                        )

                        st.text_input(
                            "Known Allergies",
                            value=st.session_state.allergies,
                            placeholder="e.g., Penicillin, Sulfa",
                            key="allergies_input",
                        )
                        st.text_input(
                            "Medical Conditions",
                            value=st.session_state.conditions,
                            placeholder="e.g., Hypertension, Diabetes",
                            key="conditions_input",
                        )
                        st.text_input(
                            "Current Medications",
                            value=st.session_state.medications,
                            placeholder="e.g., Aspirin, Metformin",
                            key="medications_input",
                        )

                        if st.form_submit_button("Save / Update Patient"):
                            st.session_state.patient_id = st.session_state.patient_id_input
                            st.session_state.age = st.session_state.age_input
                            st.session_state.gender = st.session_state.gender_input
                            st.session_state.allergies = st.session_state.allergies_input
                            st.session_state.conditions = st.session_state.conditions_input
                            st.session_state.medications = (
                                st.session_state.medications_input
                            )

                            (
                                status_msg,
                                ids_after,
                                badge_main,
                                badge_workspace,
                                new_orig_id,
                                cleared,
                            ) = save_patient(
                                st.session_state.original_patient_id,
                                st.session_state.patient_id,
                                st.session_state.age,
                                st.session_state.gender,
                                st.session_state.allergies,
                                st.session_state.conditions,
                                st.session_state.medications,
                            )
                            st.session_state.save_status = status_msg
                            st.session_state.next_selected_patient_id = new_orig_id
                            st.session_state.original_patient_id = new_orig_id
                            st.session_state.demo_patient_badge = badge_main
                            st.session_state.current_patient_badge = badge_workspace
                            st.session_state.final_answer = cleared
                            st.rerun()

                    if st.session_state.save_status:
                        st.markdown(st.session_state.save_status)

                st.markdown("---")
                st.markdown("#### 📈 Predictive Risk Models")

                risk_model_options = [
                    "1-year major adverse cardiovascular event (MACE)",
                    "5-year risk of developing Type 2 Diabetes",
                    "ML-based Health Risk Score",
                    "30-day hospital readmission risk",
                ]
                selected_risk_model = st.selectbox(
                    "Select a Synthetic Risk Model",
                    options=risk_model_options,
                    index=0,
                )

                if st.button("Calculate Risk"):
                    patient_to_assess = st.session_state.get(
                        "display_patient_id"
                    ) or st.session_state.get("selected_patient_id")
                    if patient_to_assess and patient_to_assess != "":
                        with st.spinner("Calculating risk..."):
                            if selected_risk_model == "ML-based Health Risk Score":
                                result = risk_prediction_agent.predict_risk_ml(
                                    patient_to_assess
                                )
                            else:
                                result = risk_prediction_agent.predict_risk(
                                    patient_to_assess, selected_risk_model
                                )
                        st.session_state.risk_prediction_result = result
                    else:
                        st.warning("Please select a patient first.")

                    st.rerun()

                if st.session_state.risk_prediction_result:
                    res = st.session_state.risk_prediction_result
                    if "error" in res:
                        st.error(f"Error calculating risk: {res['error']}")
                    else:
                        qual_risk = res.get("qualitative_risk", "N/A")
                        quant_risk = res.get("quantitative_risk_percent", "N/A")
                        st.metric(
                            label=f"Qualitative Risk ({res.get('risk_topic')})",
                            value=qual_risk,
                        )
                        st.progress(
                            float(quant_risk) / 100.0
                            if isinstance(quant_risk, (int, float))
                            else 0.0,
                            text=f"{quant_risk}%",
                        )

                        with st.expander("View Risk Factors and Explanation"):
                            st.markdown("**Key Contributing Risk Factors:**")
                            factors = res.get("key_risk_factors", [])
                            for factor in factors:
                                st.markdown(f"- {factor}")
                            st.markdown("**Explanation:**")
                            st.markdown(
                                f"> {res.get('explanation', 'No explanation provided.')}"
                            )

            # RIGHT: Patient Triage
            # with col_right:
            #     st.markdown("### 🩺 Patient Triage")
            #     st.markdown(
            #         st.session_state.get(
            #             "current_patient_badge", "Current Patient: –"
            #         )
            #     )
            with col_right:
                #render_clinical_workspace_right_column() 

                st.markdown(
                    "Route your free-text clinical question to the multi-agent workflow. "
                    "Agents will use patient context plus synthetic data."
                )

                # --- Voice Query Input ---
                st.markdown("##### Voice Query (hands-free)")
                
                try:
                    from streamlit_mic_recorder import mic_recorder
                    
                    audio_info = mic_recorder(
                        start_prompt="🎤 Start Recording",
                        stop_prompt="⏹️ Stop Recording",
                        key="mic_recorder",
                    )

                    if audio_info and audio_info.get("bytes"):
                        current_audio_hash = hash(audio_info["bytes"])

                        if current_audio_hash != st.session_state.get(
                            "processed_audio_hash"
                        ):
                            with st.spinner("Transcribing audio..."):
                                transcribed_text = transcribe_audio(audio_info["bytes"])

                            st.session_state.processed_audio_hash = current_audio_hash

                            if transcribed_text:
                                st.session_state.query = transcribed_text
                                patient_id_for_workflow = (
                                    st.session_state.get("display_patient_id")
                                    or st.session_state.get("selected_patient_id")
                                    or None
                                )
                                with st.spinner(
                                    "Running analysis on transcribed query..."
                                ):
                                    answer = run_clinical_workflow(
                                        st.session_state.query,
                                        patient_id_for_workflow,
                                        st.session_state.user_info["username"],
                                    )
                                    st.session_state.final_answer = answer

                                st.rerun()
                
                except ImportError:
                    st.warning("🎤 Voice input not available. Please update dependencies.")

                if "processed_audio_hash" not in st.session_state:
                    st.session_state.processed_audio_hash = None

                st.text_area(
                    "Clinical Question",
                    placeholder='e.g., "Can I safely combine warfarin and aspirin for this patient?"',
                    key="query",
                    height=120,
                )

                col_run, col_clear = st.columns(2)
                with col_run:
                    if st.button("Analyze Query"):
                        patient_id_for_workflow = (
                            st.session_state.get("display_patient_id")
                            or st.session_state.get("selected_patient_id")
                            or None
                        )
                        user_role = st.session_state.user_info.get("role", "clinician")
                        
                        with st.spinner("🔄 Processing through Compliance System..."):
                            result = run_clinical_workflow(
                                st.session_state.query,
                                patient_id_for_workflow,
                                st.session_state.user_info["username"],
                                user_role=user_role,
                            )
                        
                        st.session_state.final_answer = result
                        st.session_state.show_compliance_report = True

                st.markdown("---")

                st.markdown("### 📋 Clinical Analysis Result")

                st.warning(
                    "**Disclaimer:** The following analysis is generated by an AI model using "
                    "synthetic data. It is for demonstration purposes only and is **not** a substitute for professional medical advice."
                )

                if st.session_state.final_answer:
                    result_data = st.session_state.final_answer
                    
                    # Display error if any
                    if isinstance(result_data, dict) and result_data.get("error"):
                        st.error(f"❌ Error: {result_data.get('error')}")
                    
                    # Display compliance report if available
                    if isinstance(result_data, dict) and result_data.get("compliance_enabled", True):
                        with st.expander("🔐 **Compliance Report** (Click to expand)", expanded=False):
                            compliance_report = result_data.get("compliance_report", {})
                            
                            col1, col2, col3 = st.columns(3)
                            with col1:
                                st.metric("Access Granted", "✅ Yes" if result_data.get("access_granted") else "❌ No")
                            with col2:
                                pii_count = len(result_data.get("pii_detected", []))
                                st.metric("PII Detected", pii_count)
                            with col3:
                                st.metric("Encryption Applied", "✅ Yes" if compliance_report.get("encryption_applied") else "❌ No")
                            
                            # Show PII details
                            if result_data.get("pii_detected"):
                                st.markdown("**Detected PII:**")
                                for pii in result_data.get("pii_detected", []):
                                    st.write(f"- Type: `{pii.get('type')}` | Location: {pii.get('start')}-{pii.get('end')}")
                            
                            # Show applied regulations
                            if result_data.get("policies_applied"):
                                st.markdown("**Applied Policies/Regulations:**")
                                for policy in result_data.get("policies_applied", []):
                                    st.write(f"✓ {policy}")
                            
                            # Show audit log
                            if result_data.get("audit_log"):
                                st.markdown("**Audit Trail:**")
                                for entry in result_data.get("audit_log", []):
                                    st.write(f"- **{entry.get('agent', 'Unknown')}**: {entry.get('action', 'N/A')}")
                            
                            st.json(compliance_report, expanded=False)
                    
                    # Display LLM response
                    llm_response = result_data.get("llm_response", "") if isinstance(result_data, dict) else result_data
                    
                    if llm_response:
                        st.markdown("### 🧠 **Clinical Analysis (LLM Response)**")
                        st.markdown(
                            f"<div id='final_answer_markdown'>{llm_response}</div>",
                            unsafe_allow_html=True,
                        )
                    else:
                        st.info("No clinical analysis available.")
                else:
                    st.info(
                        "Analysis results will appear here after clicking **Analyze Query**."
                    )

        if is_admin:
            with admin_tabs[0]:
                admin_tab_log, admin_tab_users, admin_tab_appointments = st.tabs(
                    ["Audit Log", "User Management", "Appointment Management"]
                )

                with admin_tab_log:
                    st.markdown("### 📝 Audit Log")
                    st.markdown(
                        "This log shows all clinical queries and their final summarized responses from the database."
                    )

                    LOGS_PER_PAGE = 10
                    total_logs = get_audit_log_count()
                    total_pages = (total_logs + LOGS_PER_PAGE - 1) // LOGS_PER_PAGE

                    # Extra guard
                    if st.session_state.log_page_number is None:
                        st.session_state.log_page_number = 0

                    if total_logs == 0:
                        st.info("No queries have been logged in the database yet.")
                    else:
                        page_no = st.session_state.log_page_number or 0

                        col1, col2, col3 = st.columns([1, 2, 1])
                        with col1:
                            if st.button(
                                "⬅️ Previous", disabled=(page_no == 0)
                            ):
                                st.session_state.log_page_number = max(0, page_no - 1)
                                st.rerun()
                        with col2:
                            st.write(f"Page {page_no + 1} of {total_pages}")
                        with col3:
                            if st.button(
                                "Next ➡️",
                                disabled=(page_no >= total_pages - 1),
                            ):
                                st.session_state.log_page_number = min(
                                    total_pages - 1, page_no + 1
                                )
                                st.rerun()

                        offset = page_no * LOGS_PER_PAGE
                        log_entries = get_audit_logs(
                            limit=LOGS_PER_PAGE, offset=offset
                        )

                        for entry in log_entries:
                            with st.expander(
                                f"Log ID {entry['id']} @ {entry['timestamp']} by {entry['username']} (Patient: {entry.get('patient_id', 'N/A')})"
                            ):
                                st.markdown(f"**Query:**\n\n> {entry['query']}")
                                st.markdown(
                                    f"**Summarized Response:**\n\n> {entry['final_answer']}"
                                )

                with admin_tab_users:
                    st.markdown("### 👥 User Management")
                    st.markdown("View, create, edit, or delete users.")

                    st.subheader("Existing Users")
                    all_users = list_users()

                    cols = st.columns([1, 2, 3, 2, 3])
                    cols[0].write("**ID**")
                    cols[1].write("**Username**")
                    cols[2].write("**Name**")
                    cols[3].write("**Role**")
                    cols[4].write("**Actions**")
                    st.markdown("---")

                    for user in all_users:
                        user_id, username, name, role = (
                            user["id"],
                            user["username"],
                            user["name"],
                            user["role"],
                        )
                        cols = st.columns([1, 2, 3, 2, 3])
                        cols[0].write(user_id)
                        cols[1].write(username)
                        cols[2].write(name)
                        cols[3].write(role)

                        action_col = cols[4]
                        is_self = (
                            user["username"]
                            == st.session_state.user_info["username"]
                        )

                        if action_col.button("Edit", key=f"edit_{user_id}"):
                            st.session_state.editing_user_id = user_id
                            st.rerun()

                        if action_col.button(
                            "Delete", key=f"delete_{user_id}", disabled=is_self
                        ):
                            delete_status = delete_user(user_id)
                            st.toast(delete_status)
                            st.rerun()

                    st.markdown("---")

                    if st.session_state.editing_user_id:
                        user_to_edit = get_user_by_id(
                            st.session_state.editing_user_id
                        )
                        if user_to_edit:
                            st.subheader(
                                f"Edit User: {user_to_edit['username']} (ID: {user_to_edit['id']})"
                            )
                            with st.form(
                                f"edit_user_form_{user_to_edit['id']}"
                            ):
                                edit_name = st.text_input(
                                    "Full Name", value=user_to_edit["name"]
                                )
                                edit_role = st.selectbox(
                                    "Role",
                                    ["Clinician", "Admin", "Visitor"],
                                    index=["Clinician", "Admin", "Visitor"].index(
                                        user_to_edit["role"]
                                    ) if user_to_edit["role"] in ["Clinician", "Admin", "Visitor"] else 0,
                                )
                                edit_email = st.text_input(
                                    "Email",
                                    value=user_to_edit.get("email", "")
                                )
                                edit_phone = st.text_input(
                                    "Phone",
                                    value=user_to_edit.get("phone", "")
                                )
                                edit_password = st.text_input(
                                    "New Password (optional)",
                                    type="password",
                                    placeholder="Leave blank to keep current password",
                                )

                                save_col, cancel_col = st.columns(2)
                                if save_col.form_submit_button("Save Changes"):
                                    status = update_user(
                                        user_to_edit["id"],
                                        edit_name,
                                        edit_role,
                                        edit_password or None,
                                        edit_email,
                                        edit_phone,
                                    )
                                    st.toast(status)
                                    st.session_state.editing_user_id = None
                                    st.rerun()
                                if cancel_col.form_submit_button(
                                    "Cancel", type="secondary"
                                ):
                                    st.session_state.editing_user_id = None
                                    st.rerun()
                    else:
                        st.subheader("Create New User")
                        with st.form("create_user_form", clear_on_submit=True):
                            new_username = st.text_input("Username")
                            new_password = st.text_input(
                                "Password", type="password"
                            )
                            new_name = st.text_input("Full Name")
                            new_role = st.selectbox("Role", ["Clinician", "Admin", "Visitor"])
                            new_email = st.text_input("Email (optional)")
                            new_phone = st.text_input("Phone (optional)")
                            create_submitted = st.form_submit_button("Create User")

                            if create_submitted:
                                status_message = create_user(
                                    new_username,
                                    new_password,
                                    new_name,
                                    new_role,
                                    new_email,
                                    new_phone,
                                )
                                st.toast(status_message)
                                st.rerun()
                
                with admin_tab_appointments:
                    st.markdown("### 📅 Appointment Management")
                    st.markdown("View and manage all appointments in the system.")
                    
                    all_appointments = get_all_appointments()
                    
                    if not all_appointments:
                        st.info("No appointments found in the system.")
                    else:
                        st.markdown(f"**Total Appointments:** {len(all_appointments)}")
                        
                        # Filter options
                        col1, col2 = st.columns(2)
                        with col1:
                            status_filter = st.selectbox(
                                "Filter by Status",
                                ["All", "pending", "confirmed", "cancelled", "completed"]
                            )
                        
                        # Apply filter
                        filtered_appointments = all_appointments
                        if status_filter != "All":
                            filtered_appointments = [
                                a for a in all_appointments 
                                if dict(a).get("status") == status_filter
                            ]
                        
                        for appt in filtered_appointments:
                            appt_dict = dict(appt)
                            appt_id = appt_dict.get("id")
                            visitor_username = appt_dict.get("visitor_username")
                            patient_name = appt_dict.get("patient_name")
                            phone = appt_dict.get("phone")
                            email = appt_dict.get("email")
                            date = appt_dict.get("appointment_date")
                            time = appt_dict.get("appointment_time")
                            reason = appt_dict.get("reason")
                            status = appt_dict.get("status", "pending")
                            created = appt_dict.get("created_at")
                            
                            status_color = {
                                'pending': '#FFA500',
                                'confirmed': '#28a745',
                                'cancelled': '#dc3545',
                                'completed': '#6c757d'
                            }.get(status, '#6c757d')
                            
                            with st.expander(f"🗓️ {appt_id} - {patient_name} ({date} at {time})"):
                                st.markdown(f"""
                                    <div style='background: rgba(30, 41, 59, 0.85); padding: 1.2rem; border-radius: 15px; border-left: 4px solid {status_color}; border-top: 1px solid rgba(148, 163, 184, 0.3); border-right: 1px solid rgba(148, 163, 184, 0.3); border-bottom: 1px solid rgba(148, 163, 184, 0.3); box-shadow: 0 10px 30px rgba(0, 0, 0, 0.4), 0 0 15px {status_color}20, inset 0 1px 0 rgba(255, 255, 255, 0.1); backdrop-filter: blur(20px);'>
    <p style='color: #e2e8f0; margin:  0.5rem 0;'><strong style='color: #5eead4; font-weight: 600;'>Visitor:</strong> <span style='color: #f1f5f9; margin-left: 0.5rem;'>{visitor_username}</span></p>
    <p style='color: #e2e8f0; margin: 0.5rem 0;'><strong style='color: #5eead4; font-weight: 600;'>Patient:</strong> <span style='color: #f1f5f9; margin-left: 0.5rem;'>{patient_name}</span></p>
    <p style='color: #e2e8f0; margin: 0.5rem 0;'><strong style='color:  #5eead4; font-weight: 600;'>Date & Time:</strong> <span style='color: #f1f5f9; margin-left: 0.5rem;'>{date} at {time}</span></p>
    <p style='color:  #e2e8f0; margin: 0.5rem 0;'><strong style='color: #5eead4; font-weight: 600;'>Contact:</strong> <span style='color: #f1f5f9; margin-left: 0.5rem;'>{phone} | {email}</span></p>
    <p style='color: #e2e8f0; margin: 0.5rem 0;'><strong style='color: #5eead4; font-weight: 600;'>Reason:</strong> <span style='color: #f1f5f9; margin-left: 0.5rem;'>{reason}</span></p>
    <p style='color: #e2e8f0; margin: 0.5rem 0;'><strong style='color: #5eead4; font-weight: 600;'>Status:</strong> <span style='color: {status_color}; font-weight: 600; padding: 0.25rem 0.7rem; background:  rgba(0, 0, 0, 0.4); border-radius: 8px; border: 1px solid {status_color}; box-shadow: 0 0 12px {status_color}40; margin-left: 0.5rem; display: inline-block;'>{status.upper()}</span></p>
    <p style='font-size: 0.8rem; color: #94a3b8; margin: 0.8rem 0 0 0; padding-top:  0.5rem; border-top: 1px solid rgba(148, 163, 184, 0.2);'>Created: {created}</p>
</div>
                                """, unsafe_allow_html=True)
                                
                                st.markdown("**Update Status:**")
                                col1, col2, col3, col4 = st.columns(4)
                                
                                if col1.button("✅ Confirm", key=f"confirm_{appt_id}"):
                                    result = update_appointment_status(appt_id, "confirmed")
                                    st.toast(result)
                                    st.rerun()
                                
                                if col2.button("❌ Cancel", key=f"cancel_{appt_id}"):
                                    result = update_appointment_status(appt_id, "cancelled")
                                    st.toast(result)
                                    st.rerun()
                                
                                if col3.button("✔️ Complete", key=f"complete_{appt_id}"):
                                    result = update_appointment_status(appt_id, "completed")
                                    st.toast(result)
                                    st.rerun()
                                
                                if col4.button("⏳ Pending", key=f"pending_{appt_id}"):
                                    result = update_appointment_status(appt_id, "pending")
                                    st.toast(result)
                                    st.rerun()





def render_admin_role_management():
    pass  # Function removed - rolled back to original


# -------------------------------------------------------------
# STREAMLIT APP
# -------------------------------------------------------------
def main():
    # Initialize the user database on first run
    init_db()

    # Initialize user_info early for the config check
    if "user_info" not in st.session_state:
        st.session_state.user_info = None

    if st.session_state.get("user_info") is None:
        st.set_page_config(page_title="Clinical AI Login", layout="centered")
    else:
        st.set_page_config(page_title="AI compliant healthcare", layout="wide")

    if st.session_state.user_info is None:
        render_login_page()
    else:
        render_main_app()


# -------------------------------------------------------------
# LAUNCH
# -------------------------------------------------------------
if __name__ == "__main__":
    main()