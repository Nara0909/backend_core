"""
fix_duplicate_ids.py

A utility script to fix duplicate primary keys (patient_id, drug_id) in the
synthetically generated CSV datasets.

The synthetic_agent_generator.py script had a bug where it would generate
the same IDs (e.g., P00001) in different batches, leading to non-unique
primary keys in the final CSVs.

This script will:
1. Read the primary tables (patients.csv, drugs.csv).
2. For each row, assign a new, guaranteed-unique ID.
3. Create a mapping from the old (potentially duplicate) ID to a list of
   new unique IDs.
4. For all other tables that reference these IDs, it will update them by
   distributing the new unique IDs.

USAGE:
  Run this script from within the SyntheticDataGenerator directory.
  It will create backups of your original files before modifying them.
"""

import os
import pandas as pd
import shutil


def fix_ids(
    primary_file: str,
    id_column: str,
    id_prefix: str,
    related_files: dict[str, list[str]],
    base_dir: str = "data_agent",
):
    """
    A generic function to fix duplicate IDs for a given entity (e.g., patient, drug).

    Args:
        primary_file: The main CSV file for the entity (e.g., 'patients/patients.csv').
        id_column: The name of the ID column (e.g., 'patient_id').
        id_prefix: The prefix for new IDs (e.g., 'P').
        related_files: A dict mapping filenames to columns that need updating.
        base_dir: The root directory of the data.
    """
    primary_path = os.path.join(base_dir, primary_file)
    if not os.path.exists(primary_path):
        print(f"SKIPPING: Primary file not found at {primary_path}")
        return

    print(f"\n--- Processing {id_column} duplicates in {primary_file} ---")

    # Create backup
    backup_path = primary_path + ".bak"
    shutil.copy(primary_path, backup_path)
    print(f"  -> Backup created at {backup_path}")

    df_primary = pd.read_csv(primary_path, dtype=str).fillna("")

    if not df_primary[id_column].duplicated().any():
        print(f"  -> No duplicates found for {id_column}. No changes needed.")
        os.remove(backup_path) # Clean up backup
        return

    # Create a mapping from old ID to a list of new, unique IDs
    id_map = {}
    new_ids = []
    for i, old_id in enumerate(df_primary[id_column]):
        new_id = f"{id_prefix}{i+1:05d}"
        new_ids.append(new_id)
        if old_id not in id_map:
            id_map[old_id] = []
        id_map[old_id].append(new_id)

    # Update the primary file with new unique IDs
    df_primary[id_column] = new_ids
    df_primary.to_csv(primary_path, index=False)
    print(f"  -> Fixed {primary_file} with {len(df_primary)} unique IDs.")

    # Update related files
    for rel_file, rel_cols in related_files.items():
        rel_path = os.path.join(base_dir, rel_file)
        if not os.path.exists(rel_path):
            print(f"  -> SKIPPING related file (not found): {rel_path}")
            continue

        # Create backup for related file
        rel_backup_path = rel_path + ".bak"
        shutil.copy(rel_path, rel_backup_path)
        print(f"  -> Backing up and processing related file: {rel_file}")

        df_rel = pd.read_csv(rel_path, dtype=str).fillna("")

        for col in rel_cols:
            if col not in df_rel.columns:
                continue

            # This logic assumes a one-to-many relationship and distributes the new IDs.
            # It's a best-effort fix for the generated data.
            new_col_vals = []
            counters = {k: 0 for k in id_map}
            for old_id in df_rel[col]:
                if old_id in id_map:
                    new_id_list = id_map[old_id]
                    # Cycle through the available new IDs for this old ID
                    new_id = new_id_list[counters[old_id] % len(new_id_list)]
                    new_col_vals.append(new_id)
                    counters[old_id] += 1
                else:
                    new_col_vals.append(old_id) # Keep if not in map

            df_rel[col] = new_col_vals

        df_rel.to_csv(rel_path, index=False)
        print(f"    ... Updated {len(rel_cols)} column(s) in {rel_file}")


def main():
    print("Starting data cleaning process for duplicate IDs...")

    # 1. Fix Patient IDs
    patient_related_files = {
        "patients/medical_history.csv": ["patient_id"],
        "patients/allergies.csv": ["patient_id"],
        "patients/current_medications.csv": ["patient_id"],
        "patients/adverse_events.csv": ["patient_id"],
    }
    fix_ids("patients/patients.csv", "patient_id", "P", patient_related_files)

    # 2. Fix Drug IDs
    drug_related_files = {
        "patients/current_medications.csv": ["drug_id"],
        "patients/adverse_events.csv": ["drug_id"],
        "drugs/drug_interactions.csv": ["drug_a_id", "drug_b_id"],
        "drugs/contraindications.csv": ["drug_id"],
        "drugs/alternative_drugs.csv": ["drug_id", "alternative_drug_id"],
        "multilingual/drug_info_multilingual.csv": ["drug_id"],
    }
    fix_ids("drugs/drugs.csv", "drug_id", "DRUG", drug_related_files)

    print("\n✅ Data cleaning process complete.")
    print("Please check the CSV files in the 'data_agent' directory.")
    print("Original files have been saved with a '.bak' extension.")


if __name__ == "__main__":
    main()