# """
# user_db.py

# Handles user authentication and management using a local SQLite database.
# Passwords are securely hashed using bcrypt.
# Enhanced with visitor registration and appointment management.
# """

# import sqlite3
# import bcrypt
# import os
# import uuid
# from typing import Dict, Optional, List
# from datetime import datetime

# DB_PATH = os.path.join(os.path.dirname(os.path.dirname(__file__)), "users.db")
# APPOINTMENTS_DB_PATH = os.path.join(os.path.dirname(os.path.dirname(__file__)), "appointments.db")


# def get_db_connection():
#     """Creates a database connection."""
#     conn = sqlite3.connect(DB_PATH)
#     conn.row_factory = sqlite3.Row
#     return conn


# def get_appointments_db_connection():
#     """Creates a database connection for appointments."""
#     conn = sqlite3.connect(APPOINTMENTS_DB_PATH)
#     conn.row_factory = sqlite3.Row
#     return conn


# def hash_password(password: str) -> bytes:
#     """Hashes a password for storing."""
#     return bcrypt.hashpw(password.encode("utf-8"), bcrypt.gensalt())


# def check_password(password: str, hashed_password: bytes) -> bool:
#     """Checks a password against a stored hash."""
#     return bcrypt.checkpw(password.encode("utf-8"), hashed_password)


# def migrate_database():
#     """Migrates the database schema to add new columns if they don't exist."""
#     conn = get_db_connection()
#     cursor = conn.cursor()
    
#     # Check if email column exists
#     cursor.execute("PRAGMA table_info(users)")
#     columns = [column[1] for column in cursor.fetchall()]
    
#     # Add email column if it doesn't exist
#     if 'email' not in columns:
#         print("Adding 'email' column to users table...")
#         cursor.execute("ALTER TABLE users ADD COLUMN email TEXT")
#         conn.commit()
    
#     # Add phone column if it doesn't exist
#     if 'phone' not in columns:
#         print("Adding 'phone' column to users table...")
#         cursor.execute("ALTER TABLE users ADD COLUMN phone TEXT")
#         conn.commit()
    
#     # Add created_at column if it doesn't exist
#     if 'created_at' not in columns:
#         print("Adding 'created_at' column to users table...")
#         cursor.execute("ALTER TABLE users ADD COLUMN created_at TEXT")
#         conn.commit()
    
#     conn.close()
#     print("Database migration completed.")


# def init_db():
#     """Initializes the database and creates the users table if it doesn't exist."""
#     conn = get_db_connection()
#     cursor = conn.cursor()

#     # Create users table with additional fields for visitors
#     cursor.execute(
#         """
#         CREATE TABLE IF NOT EXISTS users (
#             id INTEGER PRIMARY KEY AUTOINCREMENT,
#             username TEXT UNIQUE NOT NULL,
#             password_hash BLOB NOT NULL,
#             name TEXT NOT NULL,
#             role TEXT NOT NULL,
#             email TEXT,
#             phone TEXT,
#             created_at TEXT
#         )
#     """
#     )

#     cursor.execute(
#         """
#         CREATE TABLE IF NOT EXISTS audit_log (
#             id INTEGER PRIMARY KEY AUTOINCREMENT,
#             timestamp TEXT NOT NULL,
#             username TEXT NOT NULL,
#             patient_id TEXT,
#             query TEXT NOT NULL,
#             final_answer TEXT NOT NULL
#         )
#         """
#     )

#     conn.commit()
#     conn.close()
    
#     # Run migration to add new columns to existing databases
#     migrate_database()
    
#     # Re-open connection after migration
#     conn = get_db_connection()
#     cursor = conn.cursor()

#     # Check if any users exist
#     cursor.execute("SELECT COUNT(*) FROM users")
#     user_count = cursor.fetchone()[0]

#     # If no users, populate with default users
#     if user_count == 0:
#         print("Database is empty. Populating with default users...")
#         default_users = [
#             ("clinician1", "password123", "Dr. Evelyn Reed", "Clinician", "evelyn.reed@hospital.com", "555-0101"),
#             ("admin1", "adminpass", "Admin User", "Admin", "admin@hospital.com", "555-0100"),
#         ]
#         for username, password, name, role, email, phone in default_users:
#             cursor.execute(
#                 """INSERT INTO users (username, password_hash, name, role, email, phone, created_at) 
#                    VALUES (?, ?, ?, ?, ?, ?, ?)""",
#                 (username, hash_password(password), name, role, email, phone, datetime.now().isoformat()),
#             )
#         print("Default users created.")

#     conn.commit()
#     conn.close()
    
#     # Initialize appointments database
#     init_appointments_db()


# def init_appointments_db():
#     """Initializes the appointments database."""
#     conn = get_appointments_db_connection()
#     cursor = conn.cursor()
    
#     cursor.execute("""
#         CREATE TABLE IF NOT EXISTS appointments (
#             id TEXT PRIMARY KEY,
#             visitor_username TEXT NOT NULL,
#             patient_name TEXT NOT NULL,
#             phone TEXT NOT NULL,
#             email TEXT NOT NULL,
#             appointment_date TEXT NOT NULL,
#             appointment_time TEXT NOT NULL,
#             reason TEXT NOT NULL,
#             status TEXT DEFAULT 'pending',
#             created_at TEXT NOT NULL,
#             FOREIGN KEY (visitor_username) REFERENCES users(username)
#         )
#     """)
    
#     conn.commit()
#     conn.close()


# def verify_user(username: str, password: str) -> Optional[Dict]:
#     """Verifies user credentials against the database."""
#     conn = get_db_connection()
#     cursor = conn.cursor()
#     cursor.execute("SELECT * FROM users WHERE username = ?", (username,))
#     user_row = cursor.fetchone()
#     conn.close()

#     if user_row and check_password(password, user_row["password_hash"]):
#         return dict(user_row)

#     return None


# def register_visitor(username: str, password: str, name: str, email: str, phone: str) -> str:
#     """Register a new visitor user."""
#     if not all([username, password, name, email, phone]):
#         return "❌ All fields are required."
    
#     conn = get_db_connection()
#     cursor = conn.cursor()
    
#     # Check if username exists
#     cursor.execute("SELECT * FROM users WHERE username = ?", (username,))
#     if cursor.fetchone():
#         conn.close()
#         return "❌ Username already exists. Please choose a different username."
    
#     try:
#         # Insert new visitor
#         cursor.execute(
#             """INSERT INTO users (username, password_hash, name, role, email, phone, created_at) 
#                VALUES (?, ?, ?, 'Visitor', ?, ?, ?)""",
#             (username, hash_password(password), name, email, phone, datetime.now().isoformat())
#         )
#         conn.commit()
#         message = "✅ Registration successful! You can now login."
#     except sqlite3.Error as e:
#         message = f"❌ Database error: {e}"
#     finally:
#         conn.close()
    
#     return message


# def create_appointment(visitor_username: str, patient_name: str, phone: str, email: str, 
#                       appointment_date: str, appointment_time: str, reason: str) -> str:
#     """Create an appointment in the database."""
#     conn = get_appointments_db_connection()
#     cursor = conn.cursor()
    
#     appointment_id = str(uuid.uuid4())[:8].upper()
    
#     try:
#         cursor.execute(
#             """INSERT INTO appointments 
#                (id, visitor_username, patient_name, phone, email, appointment_date, appointment_time, reason, created_at)
#                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)""",
#             (appointment_id, visitor_username, patient_name, phone, email, 
#              appointment_date, appointment_time, reason, datetime.now().isoformat())
#         )
#         conn.commit()
#     except sqlite3.Error as e:
#         print(f"Error creating appointment: {e}")
#         appointment_id = None
#     finally:
#         conn.close()
    
#     return appointment_id


# def get_visitor_appointments(visitor_username: str) -> List[Dict]:
#     """Get all appointments for a visitor."""
#     conn = get_appointments_db_connection()
#     cursor = conn.cursor()
#     cursor.execute(
#         "SELECT * FROM appointments WHERE visitor_username = ? ORDER BY created_at DESC",
#         (visitor_username,)
#     )
#     appointments = [dict(row) for row in cursor.fetchall()]
#     conn.close()
#     return appointments


# def get_all_appointments() -> List[Dict]:
#     """Get all appointments (for admin/clinician view)."""
#     conn = get_appointments_db_connection()
#     cursor = conn.cursor()
#     cursor.execute("SELECT * FROM appointments ORDER BY created_at DESC")
#     appointments = [dict(row) for row in cursor.fetchall()]
#     conn.close()
#     return appointments


# def update_appointment_status(appointment_id: str, status: str) -> str:
#     """Update appointment status."""
#     valid_statuses = ['pending', 'confirmed', 'cancelled', 'completed']
#     if status not in valid_statuses:
#         return f"Error: Invalid status. Must be one of {valid_statuses}"
    
#     conn = get_appointments_db_connection()
#     cursor = conn.cursor()
    
#     try:
#         cursor.execute(
#             "UPDATE appointments SET status = ? WHERE id = ?",
#             (status, appointment_id)
#         )
#         conn.commit()
#         if cursor.rowcount > 0:
#             message = f"Success: Appointment {appointment_id} status updated to {status}."
#         else:
#             message = f"Error: No appointment found with ID {appointment_id}."
#     except sqlite3.Error as e:
#         message = f"Database error: {e}"
#     finally:
#         conn.close()
    
#     return message


# def create_user(username: str, password: str, name: str, role: str, 
#                 email: str = None, phone: str = None) -> str:
#     """Creates a new user in the database. Returns a status message."""
#     if not all([username, password, name, role]):
#         return "Error: All fields are required."

#     conn = get_db_connection()
#     cursor = conn.cursor()

#     # Check if username already exists
#     cursor.execute("SELECT id FROM users WHERE username = ?", (username,))
#     if cursor.fetchone():
#         conn.close()
#         return f"Error: Username '{username}' already exists."

#     try:
#         cursor.execute(
#             """INSERT INTO users (username, password_hash, name, role, email, phone, created_at) 
#                VALUES (?, ?, ?, ?, ?, ?, ?)""",
#             (username, hash_password(password), name, role, email, phone, datetime.now().isoformat()),
#         )
#         conn.commit()
#         message = f"Success: User '{username}' created."
#     except sqlite3.Error as e:
#         message = f"Database error: {e}"
#     finally:
#         conn.close()

#     return message


# def list_users() -> List[Dict]:
#     """Lists all users from the database, excluding password hash."""
#     conn = get_db_connection()
#     cursor = conn.cursor()
#     cursor.execute("SELECT id, username, name, role, email, phone, created_at FROM users")
#     users = [dict(row) for row in cursor.fetchall()]
#     conn.close()
#     return users


# def get_user_by_id(user_id: int) -> Optional[Dict]:
#     """Gets a single user by their ID."""
#     conn = get_db_connection()
#     cursor = conn.cursor()
#     cursor.execute("SELECT id, username, name, role, email, phone FROM users WHERE id = ?", (user_id,))
#     user_row = cursor.fetchone()
#     conn.close()
#     return dict(user_row) if user_row else None


# def update_user(user_id: int, name: str, role: str, password: Optional[str] = None,
#                 email: Optional[str] = None, phone: Optional[str] = None) -> str:
#     """Updates a user's name, role, and optionally their password, email, and phone."""
#     if not all([name, role]):
#         return "Error: Name and role fields are required."

#     conn = get_db_connection()
#     cursor = conn.cursor()

#     # Prevent changing the role of the last admin
#     cursor.execute("SELECT role FROM users WHERE id = ?", (user_id,))
#     current_user = cursor.fetchone()
#     if current_user and current_user["role"] == "Admin" and role != "Admin":
#         cursor.execute("SELECT COUNT(*) FROM users WHERE role = 'Admin'")
#         admin_count = cursor.fetchone()[0]
#         if admin_count <= 1:
#             conn.close()
#             return "Error: Cannot change the role of the last admin user."

#     try:
#         if password:
#             # Update with new password
#             password_hash = hash_password(password)
#             cursor.execute(
#                 """UPDATE users SET name = ?, role = ?, password_hash = ?, email = ?, phone = ? 
#                    WHERE id = ?""",
#                 (name, role, password_hash, email, phone, user_id)
#             )
#         else:
#             # Update without changing password
#             cursor.execute(
#                 "UPDATE users SET name = ?, role = ?, email = ?, phone = ? WHERE id = ?",
#                 (name, role, email, phone, user_id)
#             )
#         conn.commit()
#         message = f"Success: User ID {user_id} updated."
#     except sqlite3.Error as e:
#         message = f"Database error: {e}"
#     finally:
#         conn.close()
#     return message


# def add_audit_log_entry(username: str, patient_id: Optional[str], query: str, final_answer: str):
#     """Adds a new entry to the audit log."""
#     conn = get_db_connection()
#     cursor = conn.cursor()
#     try:
#         cursor.execute(
#             """
#             INSERT INTO audit_log (timestamp, username, patient_id, query, final_answer)
#             VALUES (?, ?, ?, ?, ?)
#             """,
#             (datetime.utcnow().isoformat(), username, patient_id, query, final_answer),
#         )
#         conn.commit()
#     except sqlite3.Error as e:
#         print(f"Database error while logging: {e}")
#     finally:
#         conn.close()


# def get_audit_logs(limit: int, offset: int) -> List[Dict]:
#     """Retrieves a page of audit log entries, most recent first."""
#     conn = get_db_connection()
#     cursor = conn.cursor()
#     cursor.execute("SELECT * FROM audit_log ORDER BY timestamp DESC LIMIT ? OFFSET ?", (limit, offset))
#     logs = [dict(row) for row in cursor.fetchall()]
#     conn.close()
#     return logs


# def delete_user(user_id: int) -> str:
#     """Deletes a user from the database by their ID."""
#     conn = get_db_connection()
#     cursor = conn.cursor()

#     # Prevent deleting the last admin
#     cursor.execute("SELECT role FROM users WHERE id = ?", (user_id,))
#     user_to_delete = cursor.fetchone()
#     if user_to_delete and user_to_delete["role"] == "Admin":
#         cursor.execute("SELECT COUNT(*) FROM users WHERE role = 'Admin'")
#         admin_count = cursor.fetchone()[0]
#         if admin_count <= 1:
#             conn.close()
#             return "Error: Cannot delete the last admin user."

#     try:
#         cursor.execute("DELETE FROM users WHERE id = ?", (user_id,))
#         conn.commit()
#         if cursor.rowcount > 0:
#             message = f"Success: User with ID {user_id} deleted."
#         else:
#             message = f"Error: No user found with ID {user_id}."
#     except sqlite3.Error as e:
#         message = f"Database error: {e}"
#     finally:
#         conn.close()

#     return message


# def get_audit_log_count() -> int:
#     """Returns the total number of audit log entries."""
#     conn = get_db_connection()
#     cursor = conn.cursor()
#     cursor.execute("SELECT COUNT(*) FROM audit_log")
#     count = cursor.fetchone()[0]
#     conn.close()
#     return count


"""
user_db.py

Enhanced user authentication with encryption for PII (email, phone)
Passwords are hashed with bcrypt, PII is encrypted with Fernet
"""

import sqlite3
import bcrypt
import os
from typing import Dict, Optional, List
from datetime import datetime
from cryptography.fernet import Fernet
import base64
from dotenv import load_dotenv

# Load environment variables from .env file
load_dotenv()

DB_PATH = os.path.join(os.path.dirname(os.path.dirname(__file__)), "users.db")
APPOINTMENTS_DB_PATH = os.path.join(os.path.dirname(os.path.dirname(__file__)), "appointments.db")

# ============================================================================
# ENCRYPTION KEY MANAGEMENT
# ============================================================================

ENCRYPTION_KEY_ENV = "USER_DB_ENCRYPTION_KEY"
ENCRYPTION_KEY_FILE = os.path.join(os.path.dirname(__file__), ".encryption_key")

def get_or_create_encryption_key() -> bytes:
    """Get encryption key from environment, file, or create new one"""
    # 1. Try environment variable first
    key_str = os.environ.get(ENCRYPTION_KEY_ENV)
    
    if key_str:
        try:
            # Fernet expects the base64-encoded string as bytes
            return key_str.encode() if isinstance(key_str, str) else key_str
        except Exception as e:
            print(f"⚠️ Invalid encryption key in environment: {e}")
    
    # 2. Try loading from file
    if os.path.exists(ENCRYPTION_KEY_FILE):
        try:
            with open(ENCRYPTION_KEY_FILE, 'r') as f:
                key_str = f.read().strip()
                return key_str.encode() if isinstance(key_str, str) else key_str
        except Exception as e:
            print(f"⚠️ Could not load encryption key from file: {e}")
    
    # 3. Generate new key and save to file
    key = Fernet.generate_key()
    try:
        with open(ENCRYPTION_KEY_FILE, 'w') as f:
            f.write(key.decode())
        os.chmod(ENCRYPTION_KEY_FILE, 0o600)  # Restrict to owner only
    except Exception as e:
        print(f"⚠️ Could not save encryption key to file: {e}")
    
    print(f"🔑 Generated new encryption key for user database")
    print(f"   Saved to: {ENCRYPTION_KEY_FILE}")
    print(f"   Environment variable: {ENCRYPTION_KEY_ENV}={key.decode()}")
    print(f"   ⚠️  IMPORTANT: This key is used to decrypt all stored PII!")
    
    return key

# Global cipher for PII encryption
ENCRYPTION_KEY = get_or_create_encryption_key()
cipher = Fernet(ENCRYPTION_KEY)


def encrypt_pii(data: str) -> str:
    """Encrypt PII data (email, phone) and return base64 string"""
    if not data:
        return None
    try:
        encrypted_bytes = cipher.encrypt(data.encode())
        return base64.urlsafe_b64encode(encrypted_bytes).decode()
    except Exception as e:
        print(f"❌ Encryption error: {e}")
        raise


def decrypt_pii(encrypted_data: str) -> str:
    """Decrypt PII data - returns masked value on decryption failure"""
    if not encrypted_data:
        return None
    try:
        encrypted_bytes = base64.urlsafe_b64decode(encrypted_data.encode())
        decrypted_bytes = cipher.decrypt(encrypted_bytes)
        return decrypted_bytes.decode()
    except Exception as e:
        # Silently handle decryption errors (old data with different key)
        # Return masked value instead of error message
        return "[Data encrypted with different key]"


# ============================================================================
# DATABASE CONNECTION
# ============================================================================

def get_db_connection():
    """Creates a database connection."""
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn


def get_appointments_db_connection():
    """Creates a database connection for appointments."""
    conn = sqlite3.connect(APPOINTMENTS_DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn


# ============================================================================
# PASSWORD HASHING (unchanged)
# ============================================================================

def hash_password(password: str) -> bytes:
    """Hashes a password for storing."""
    return bcrypt.hashpw(password.encode("utf-8"), bcrypt.gensalt())


def check_password(password: str, hashed_password: bytes) -> bool:
    """Checks a password against a stored hash."""
    return bcrypt.checkpw(password.encode("utf-8"), hashed_password)


# ============================================================================
# DATABASE MIGRATION
# ============================================================================

def migrate_database():
    """Migrates the database schema to add new columns if they don't exist."""
    conn = get_db_connection()
    cursor = conn.cursor()
    
    # Check if email column exists
    cursor.execute("PRAGMA table_info(users)")
    columns = [column[1] for column in cursor.fetchall()]
    
    # Add email column if it doesn't exist
    if 'email' not in columns:
        print("Adding 'email' column to users table...")
        cursor.execute("ALTER TABLE users ADD COLUMN email TEXT")
        conn.commit()
    
    # Add phone column if it doesn't exist
    if 'phone' not in columns:
        print("Adding 'phone' column to users table...")
        cursor.execute("ALTER TABLE users ADD COLUMN phone TEXT")
        conn.commit()
    
    # Add created_at column if it doesn't exist
    if 'created_at' not in columns:
        print("Adding 'created_at' column to users table...")
        cursor.execute("ALTER TABLE users ADD COLUMN created_at TEXT")
        conn.commit()
    
    conn.close()
    print("Database migration completed.")


def init_db():
    """Initializes the database and creates the users table if it doesn't exist."""
    conn = get_db_connection()
    cursor = conn.cursor()

    # Create users table with additional fields for visitors
    cursor.execute(
        """
        CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT UNIQUE NOT NULL,
            password_hash BLOB NOT NULL,
            name TEXT NOT NULL,
            role TEXT NOT NULL,
            email TEXT,
            phone TEXT,
            created_at TEXT
        )
    """
    )

    cursor.execute(
        """
        CREATE TABLE IF NOT EXISTS audit_log (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            timestamp TEXT NOT NULL,
            username TEXT NOT NULL,
            patient_id TEXT,
            query TEXT NOT NULL,
            final_answer TEXT NOT NULL
        )
        """
    )

    conn.commit()
    conn.close()
    
    # Run migration to add new columns to existing databases
    migrate_database()
    
    # Re-open connection after migration
    conn = get_db_connection()
    cursor = conn.cursor()

    # Check if any users exist
    cursor.execute("SELECT COUNT(*) FROM users")
    user_count = cursor.fetchone()[0]

    # If no users, populate with default users
    if user_count == 0:
        print("Database is empty. Populating with default users...")
        default_users = [
            ("clinician1", "password123", "Dr. Evelyn Reed", "Clinician", "evelyn.reed@hospital.com", "555-0101"),
            ("admin1", "adminpass", "Admin User", "Admin", "admin@hospital.com", "555-0100"),
        ]
        for username, password, name, role, email, phone in default_users:
            # Encrypt email and phone
            encrypted_email = encrypt_pii(email) if email else None
            encrypted_phone = encrypt_pii(phone) if phone else None
            
            cursor.execute(
                """INSERT INTO users (username, password_hash, name, role, email, phone, created_at) 
                   VALUES (?, ?, ?, ?, ?, ?, ?)""",
                (username, hash_password(password), name, role, encrypted_email, encrypted_phone, datetime.now().isoformat()),
            )
        print("Default users created with encrypted PII.")

    conn.commit()
    conn.close()
    
    # Initialize appointments database
    init_appointments_db()


def init_appointments_db():
    """Initializes the appointments database."""
    conn = get_appointments_db_connection()
    cursor = conn.cursor()
    
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS appointments (
            id TEXT PRIMARY KEY,
            visitor_username TEXT NOT NULL,
            patient_name TEXT NOT NULL,
            phone TEXT NOT NULL,
            email TEXT NOT NULL,
            appointment_date TEXT NOT NULL,
            appointment_time TEXT NOT NULL,
            reason TEXT NOT NULL,
            status TEXT DEFAULT 'pending',
            triage_level TEXT DEFAULT 'pending',
            cds_consent INTEGER DEFAULT 0,
            consent_given_at TEXT,
            audit_notes TEXT,
            created_at TEXT NOT NULL,
            FOREIGN KEY (visitor_username) REFERENCES users(username)
        )
    """)
    
    # Add new columns if they don't exist (for existing databases)
    try:
        cursor.execute("PRAGMA table_info(appointments)")
        columns = [column[1] for column in cursor.fetchall()]
        
        if 'triage_level' not in columns:
            cursor.execute("ALTER TABLE appointments ADD COLUMN triage_level TEXT DEFAULT 'pending'")
        if 'cds_consent' not in columns:
            cursor.execute("ALTER TABLE appointments ADD COLUMN cds_consent INTEGER DEFAULT 0")
        if 'consent_given_at' not in columns:
            cursor.execute("ALTER TABLE appointments ADD COLUMN consent_given_at TEXT")
        if 'audit_notes' not in columns:
            cursor.execute("ALTER TABLE appointments ADD COLUMN audit_notes TEXT")
        
        conn.commit()
    except Exception as e:
        print(f"Migration note: {e}")
    
    conn.close()


# ============================================================================
# USER VERIFICATION (with decryption)
# ============================================================================

def verify_user(username: str, password: str) -> Optional[Dict]:
    """Verifies user credentials and decrypts PII for session."""
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM users WHERE username = ?", (username,))
    user_row = cursor.fetchone()
    conn.close()

    if user_row and check_password(password, user_row["password_hash"]):
        user_dict = dict(user_row)
        
        # Decrypt email and phone for the session
        if user_dict.get("email"):
            user_dict["email"] = decrypt_pii(user_dict["email"])
        if user_dict.get("phone"):
            user_dict["phone"] = decrypt_pii(user_dict["phone"])
        
        return user_dict

    return None


# ============================================================================
# VISITOR REGISTRATION (with encryption)
# ============================================================================

def register_visitor(username: str, password: str, name: str, email: str, phone: str) -> str:
    """Register a new visitor user with encrypted PII."""
    if not all([username, password, name, email, phone]):
        return "❌ All fields are required."
    
    conn = get_db_connection()
    cursor = conn.cursor()
    
    # Check if username exists
    cursor.execute("SELECT * FROM users WHERE username = ?", (username,))
    if cursor.fetchone():
        conn.close()
        return "❌ Username already exists. Please choose a different username."
    
    try:
        # Encrypt email and phone before storing
        encrypted_email = encrypt_pii(email)
        encrypted_phone = encrypt_pii(phone)
        
        print(f"🔐 Encrypting visitor registration data:")
        print(f"   Email: {email} → {encrypted_email[:30]}...")
        print(f"   Phone: {phone} → {encrypted_phone[:30]}...")
        
        # Insert new visitor with encrypted PII
        cursor.execute(
            """INSERT INTO users (username, password_hash, name, role, email, phone, created_at) 
               VALUES (?, ?, ?, 'Visitor', ?, ?, ?)""",
            (username, hash_password(password), name, encrypted_email, encrypted_phone, datetime.now().isoformat())
        )
        conn.commit()
        message = "✅ Registration successful! You can now login."
    except Exception as e:
        message = f"❌ Registration error: {e}"
    finally:
        conn.close()
    
    return message


# ============================================================================
# APPOINTMENT MANAGEMENT (with encryption)
# ============================================================================

def create_appointment(visitor_username: str, patient_name: str, phone: str, email: str, 
                      appointment_date: str, appointment_time: str, reason: str,
                      triage_level: str = "pending", cds_consent: int = 0, 
                      audit_notes: str = None) -> str:
    """Create an appointment with encrypted PII, triage level, and consent tracking."""
    import uuid
    
    conn = get_appointments_db_connection()
    cursor = conn.cursor()
    
    appointment_id = str(uuid.uuid4())[:8].upper()
    
    try:
        # Encrypt phone and email before storing
        encrypted_phone = encrypt_pii(phone)
        encrypted_email = encrypt_pii(email)
        
        consent_given_at = datetime.now().isoformat() if cds_consent else None
        
        print(f"🔐 Encrypting appointment data:")
        print(f"   Phone: {phone} → {encrypted_phone[:30]}...")
        print(f"   Email: {email} → {encrypted_email[:30]}...")
        print(f"   Triage: {triage_level} | CDS Consent: {bool(cds_consent)}")
        
        cursor.execute(
            """INSERT INTO appointments 
               (id, visitor_username, patient_name, phone, email, appointment_date, appointment_time, 
                reason, triage_level, cds_consent, consent_given_at, audit_notes, created_at)
               VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
            (appointment_id, visitor_username, patient_name, encrypted_phone, encrypted_email, 
             appointment_date, appointment_time, reason, triage_level, cds_consent, 
             consent_given_at, audit_notes, datetime.now().isoformat())
        )
        conn.commit()
    except Exception as e:
        print(f"❌ Error creating appointment: {e}")
        appointment_id = None
    finally:
        conn.close()
    
    return appointment_id


def get_visitor_appointments(visitor_username: str) -> List[Dict]:
    """Get all appointments for a visitor with decrypted PII."""
    conn = get_appointments_db_connection()
    cursor = conn.cursor()
    cursor.execute(
        "SELECT * FROM appointments WHERE visitor_username = ? ORDER BY created_at DESC",
        (visitor_username,)
    )
    appointments = cursor.fetchall()
    conn.close()
    
    # Decrypt PII for display
    decrypted_appointments = []
    for appt in appointments:
        appt_dict = dict(appt)
        appt_dict["phone"] = decrypt_pii(appt_dict["phone"])
        appt_dict["email"] = decrypt_pii(appt_dict["email"])
        decrypted_appointments.append(appt_dict)
    
    return decrypted_appointments


def get_all_appointments() -> List[Dict]:
    """Get all appointments (for admin/clinician view) with decrypted PII."""
    conn = get_appointments_db_connection()
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM appointments ORDER BY created_at DESC")
    appointments = cursor.fetchall()
    conn.close()
    
    # Decrypt PII for authorized users
    decrypted_appointments = []
    for appt in appointments:
        appt_dict = dict(appt)
        appt_dict["phone"] = decrypt_pii(appt_dict["phone"])
        appt_dict["email"] = decrypt_pii(appt_dict["email"])
        decrypted_appointments.append(appt_dict)
    
    return decrypted_appointments


def update_appointment_status(appointment_id: str, status: str) -> str:
    """Update appointment status."""
    valid_statuses = ['pending', 'confirmed', 'cancelled', 'completed']
    if status not in valid_statuses:
        return f"Error: Invalid status. Must be one of {valid_statuses}"
    
    conn = get_appointments_db_connection()
    cursor = conn.cursor()
    
    try:
        cursor.execute(
            "UPDATE appointments SET status = ? WHERE id = ?",
            (status, appointment_id)
        )
        conn.commit()
        if cursor.rowcount > 0:
            message = f"Success: Appointment {appointment_id} status updated to {status}."
        else:
            message = f"Error: No appointment found with ID {appointment_id}."
    except sqlite3.Error as e:
        message = f"Database error: {e}"
    finally:
        conn.close()
    
    return message


# ============================================================================
# USER MANAGEMENT (with encryption)
# ============================================================================

def create_user(username: str, password: str, name: str, role: str, 
                email: str = None, phone: str = None) -> str:
    """Creates a new user with encrypted PII."""
    if not all([username, password, name, role]):
        return "Error: All fields are required."

    conn = get_db_connection()
    cursor = conn.cursor()

    # Check if username already exists
    cursor.execute("SELECT id FROM users WHERE username = ?", (username,))
    if cursor.fetchone():
        conn.close()
        return f"Error: Username '{username}' already exists."

    try:
        # Encrypt email and phone if provided
        encrypted_email = encrypt_pii(email) if email else None
        encrypted_phone = encrypt_pii(phone) if phone else None
        
        cursor.execute(
            """INSERT INTO users (username, password_hash, name, role, email, phone, created_at) 
               VALUES (?, ?, ?, ?, ?, ?, ?)""",
            (username, hash_password(password), name, role, encrypted_email, encrypted_phone, datetime.now().isoformat()),
        )
        conn.commit()
        message = f"Success: User '{username}' created."
    except sqlite3.Error as e:
        message = f"Database error: {e}"
    finally:
        conn.close()

    return message


def list_users() -> List[Dict]:
    """Lists all users with decrypted PII."""
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute("SELECT id, username, name, role, email, phone, created_at FROM users")
    users = cursor.fetchall()
    conn.close()
    
    # Decrypt PII for display
    decrypted_users = []
    for user in users:
        user_dict = dict(user)
        if user_dict.get("email"):
            user_dict["email"] = decrypt_pii(user_dict["email"])
        if user_dict.get("phone"):
            user_dict["phone"] = decrypt_pii(user_dict["phone"])
        decrypted_users.append(user_dict)
    
    return decrypted_users


def get_user_by_id(user_id: int) -> Optional[Dict]:
    """Gets a single user by their ID with decrypted PII."""
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute("SELECT id, username, name, role, email, phone FROM users WHERE id = ?", (user_id,))
    user_row = cursor.fetchone()
    conn.close()
    
    if user_row:
        user_dict = dict(user_row)
        # Decrypt PII
        if user_dict.get("email"):
            user_dict["email"] = decrypt_pii(user_dict["email"])
        if user_dict.get("phone"):
            user_dict["phone"] = decrypt_pii(user_dict["phone"])
        return user_dict
    
    return None


def update_user(user_id: int, name: str, role: str, password: Optional[str] = None,
                email: Optional[str] = None, phone: Optional[str] = None) -> str:
    """Updates a user with encrypted PII."""
    if not all([name, role]):
        return "Error: Name and role fields are required."

    conn = get_db_connection()
    cursor = conn.cursor()

    # Prevent changing the role of the last admin
    cursor.execute("SELECT role FROM users WHERE id = ?", (user_id,))
    current_user = cursor.fetchone()
    if current_user and current_user["role"] == "Admin" and role != "Admin":
        cursor.execute("SELECT COUNT(*) FROM users WHERE role = 'Admin'")
        admin_count = cursor.fetchone()[0]
        if admin_count <= 1:
            conn.close()
            return "Error: Cannot change the role of the last admin user."

    try:
        # Encrypt email and phone if provided
        encrypted_email = encrypt_pii(email) if email else None
        encrypted_phone = encrypt_pii(phone) if phone else None
        
        if password:
            # Update with new password
            password_hash = hash_password(password)
            cursor.execute(
                """UPDATE users SET name = ?, role = ?, password_hash = ?, email = ?, phone = ? 
                   WHERE id = ?""",
                (name, role, password_hash, encrypted_email, encrypted_phone, user_id)
            )
        else:
            # Update without changing password
            cursor.execute(
                "UPDATE users SET name = ?, role = ?, email = ?, phone = ? WHERE id = ?",
                (name, role, encrypted_email, encrypted_phone, user_id)
            )
        conn.commit()
        message = f"Success: User ID {user_id} updated."
    except sqlite3.Error as e:
        message = f"Database error: {e}"
    finally:
        conn.close()
    return message


# ============================================================================
# AUDIT LOG FUNCTIONS (unchanged)
# ============================================================================

def add_audit_log_entry(username: str, patient_id: Optional[str], query: str, final_answer: str):
    """Adds a new entry to the audit log."""
    conn = get_db_connection()
    cursor = conn.cursor()
    try:
        cursor.execute(
            """
            INSERT INTO audit_log (timestamp, username, patient_id, query, final_answer)
            VALUES (?, ?, ?, ?, ?)
            """,
            (datetime.utcnow().isoformat(), username, patient_id, query, final_answer),
        )
        conn.commit()
    except sqlite3.Error as e:
        print(f"Database error while logging: {e}")
    finally:
        conn.close()


def get_audit_logs(limit: int, offset: int) -> List[Dict]:
    """Retrieves a page of audit log entries, most recent first."""
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM audit_log ORDER BY timestamp DESC LIMIT ? OFFSET ?", (limit, offset))
    logs = [dict(row) for row in cursor.fetchall()]
    conn.close()
    return logs


def delete_user(user_id: int) -> str:
    """Deletes a user from the database by their ID."""
    conn = get_db_connection()
    cursor = conn.cursor()

    # Prevent deleting the last admin
    cursor.execute("SELECT role FROM users WHERE id = ?", (user_id,))
    user_to_delete = cursor.fetchone()
    if user_to_delete and user_to_delete["role"] == "Admin":
        cursor.execute("SELECT COUNT(*) FROM users WHERE role = 'Admin'")
        admin_count = cursor.fetchone()[0]
        if admin_count <= 1:
            conn.close()
            return "Error: Cannot delete the last admin user."

    try:
        cursor.execute("DELETE FROM users WHERE id = ?", (user_id,))
        conn.commit()
        if cursor.rowcount > 0:
            message = f"Success: User with ID {user_id} deleted."
        else:
            message = f"Error: No user found with ID {user_id}."
    except sqlite3.Error as e:
        message = f"Database error: {e}"
    finally:
        conn.close()

    return message


def get_audit_log_count() -> int:
    """Returns the total number of audit log entries."""
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute("SELECT COUNT(*) FROM audit_log")
    count = cursor.fetchone()[0]
    conn.close()
    return count
