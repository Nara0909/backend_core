"""
Updated Clinical Workspace Section for app.py
==============================================

This replaces the clinical workspace section in your streamlit app.
It adds API preprocessing before query analysis.
"""

import requests
import streamlit as st
from datetime import datetime

# API Configuration
COMPLIANCE_API_URL = "http://localhost:8000"

def preprocess_query_with_api(query_text: str, user_role: str) -> dict:
    """
    Send query to compliance API for PII detection and masking
    
    Returns:
        dict with masked_text, pii_detected, original_text, etc.
    """
    try:
        response = requests.post(
            f"{COMPLIANCE_API_URL}/api/process",
            params={"data_state": "process_allowed"},  # Allow processing for clinician
            json={
                "input_text": query_text,
                "user_role": user_role,
                "request_type": "clinical_decision"
            },
            timeout=10
        )
        
        if response.status_code == 200:
            return response.json()
        else:
            st.error(f"API Error: {response.status_code}")
            return None
            
    except requests.exceptions.ConnectionError:
        st.warning("⚠️ Compliance API not available. Running without PII detection.")
        return None
    except Exception as e:
        st.error(f"Error calling compliance API: {e}")
        return None


def highlight_pii_in_text(text: str, pii_list: list) -> str:
    """
    Create HTML with PII highlighted
    
    Args:
        text: Original text
        pii_list: List of PII entities with 'start', 'end', 'type', 'text'
    
    Returns:
        HTML string with highlighted PII
    """
    if not pii_list:
        return text
    
    # Sort PII by start position (reverse) to process from end to start
    sorted_pii = sorted(pii_list, key=lambda x: x.get('start', 0), reverse=True)
    
    result = text
    
    # Color mapping for different PII types
    pii_colors = {
        'PERSON': '#ffeb3b',
        'EMAIL_ADDRESS': '#81c784',
        'PHONE_NUMBER': '#64b5f6',
        'SSN': '#e57373',
        'CREDIT_CARD': '#ff8a65',
        'US_SSN': '#e57373',
        'LOCATION': '#ba68c8',
        'DATE_TIME': '#90caf9',
        'MEDICAL_LICENSE': '#ffb74d',
        'DEFAULT': '#ffd54f'
    }
    
    for pii in sorted_pii:
        start = pii.get('start', 0)
        end = pii.get('end', 0)
        pii_type = pii.get('type', 'UNKNOWN')
        pii_text = pii.get('text', '')
        
        # Get color for this PII type
        color = pii_colors.get(pii_type, pii_colors['DEFAULT'])
        
        # Create highlighted span
        highlighted = f'<span style="background-color: {color}; padding: 2px 4px; border-radius: 3px; font-weight: bold;" title="{pii_type}">{pii_text}</span>'
        
        # Replace in text
        result = result[:start] + highlighted + result[end:]
    
    return result


def display_pii_summary(pii_list: list):
    """Display summary of detected PII"""
    if not pii_list:
        st.success("✅ No PII/PHI detected in query")
        return
    
    st.warning(f"⚠️ Detected {len(pii_list)} PII/PHI entities")
    
    # Group by type
    pii_by_type = {}
    for pii in pii_list:
        pii_type = pii.get('type', 'UNKNOWN')
        if pii_type not in pii_by_type:
            pii_by_type[pii_type] = []
        pii_by_type[pii_type].append(pii.get('text', ''))
    
    # Display in columns
    cols = st.columns(min(len(pii_by_type), 3))
    for idx, (pii_type, texts) in enumerate(pii_by_type.items()):
        col_idx = idx % len(cols)
        with cols[col_idx]:
            st.markdown(f"**{pii_type}**")
            for text in set(texts):  # Use set to avoid duplicates
                st.markdown(f"- `{text}`")


# ==================================================
# UPDATED CLINICAL WORKSPACE (RIGHT COLUMN)
# ==================================================

def render_clinical_workspace_right_column():
    """
    Updated right column with API preprocessing
    Place this in your render_main_app() function
    """
    
    st.markdown("### 🩺 Patient Triage")
    st.markdown(
        st.session_state.get(
            "current_patient_badge", "Current Patient: –"
        )
    )

    st.markdown(
        "Route your free-text clinical question to the multi-agent workflow. "
        "Your query will be preprocessed for PII/PHI detection."
    )

    # --- Voice Query Input ---
    st.markdown("##### Voice Query (hands-free)")

    audio_info = mic_recorder(
        start_prompt="🎤 Start Recording",
        stop_prompt="⏹️ Stop Recording",
        key="mic_recorder",
    )

    if audio_info and audio_info.get("bytes"):
        current_audio_hash = hash(audio_info["bytes"])

        if current_audio_hash != st.session_state.get(
            "processed_audio_hash"
        ):
            with st.spinner("Transcribing audio..."):
                transcribed_text = transcribe_audio(audio_info["bytes"])

            st.session_state.processed_audio_hash = current_audio_hash

            if transcribed_text:
                st.session_state.query = transcribed_text
                st.rerun()

    if "processed_audio_hash" not in st.session_state:
        st.session_state.processed_audio_hash = None

    st.text_area(
        "Clinical Question",
        placeholder='e.g., "Can I safely combine warfarin and aspirin for patient John Smith, SSN 123-45-6789?"',
        key="query",
        height=120,
    )

    col_run, col_clear = st.columns(2)
    with col_run:
        if st.button("Analyze Query", key="analyze_button"):
            if not st.session_state.query:
                st.error("Please enter a clinical question")
            else:
                # Get patient ID
                patient_id_for_workflow = (
                    st.session_state.get("display_patient_id")
                    or st.session_state.get("selected_patient_id")
                    or None
                )
                
                user_role = st.session_state.user_info.get("role", "clinician").lower()
                
                # STEP 1: Preprocess with API
                with st.spinner("🔍 Checking for PII/PHI..."):
                    preprocessing_result = preprocess_query_with_api(
                        st.session_state.query,
                        user_role
                    )
                
                if preprocessing_result:
                    # Store preprocessing results
                    st.session_state.preprocessing_result = preprocessing_result
                    
                    # Use masked/processed input for workflow
                    processed_query = preprocessing_result.get('processed_output', st.session_state.query)
                else:
                    # If API fails, use original query
                    st.session_state.preprocessing_result = None
                    processed_query = st.session_state.query
                
                # STEP 2: Run clinical workflow
                with st.spinner("🤖 Analyzing query..."):
                    answer = run_clinical_workflow(
                        processed_query,
                        patient_id_for_workflow,
                        st.session_state.user_info["username"],
                    )
                    st.session_state.final_answer = answer
                
                st.rerun()

    st.markdown("---")

    # ==================================================
    # DISPLAY PREPROCESSING RESULTS
    # ==================================================
    
    if st.session_state.get("preprocessing_result"):
        preprocessing = st.session_state.preprocessing_result
        
        st.markdown("### 🔍 PII/PHI Detection Results")
        
        # Display PII summary
        pii_detected = preprocessing.get('pii_detected', [])
        display_pii_summary(pii_detected)
        
        if pii_detected:
            # Show original query with highlighted PII
            with st.expander("📋 View Original Query with Highlighted PII", expanded=True):
                original_text = preprocessing.get('original_input', '')
                highlighted_html = highlight_pii_in_text(original_text, pii_detected)
                
                st.markdown(
                    f'<div style="background: white; padding: 1rem; border-radius: 8px; border-left: 4px solid #ffc107;">'
                    f'{highlighted_html}'
                    f'</div>',
                    unsafe_allow_html=True
                )
                
                st.markdown("**Legend:**")
                st.markdown("🟡 Person Names | 🟢 Email | 🔵 Phone | 🔴 SSN | 🟣 Location | 🟠 Medical License")
            
            # Show masked version
            with st.expander("🎭 View Masked/Processed Query"):
                masked_text = preprocessing.get('masked_input', '')
                st.code(masked_text, language=None)
                
                st.info(
                    "ℹ️ This masked version was used for analysis to protect sensitive information."
                )
            
            # Show compliance info
            with st.expander("📊 Compliance Processing Details"):
                col1, col2, col3 = st.columns(3)
                
                with col1:
                    st.metric("PII Entities", len(pii_detected))
                
                with col2:
                    encrypted = preprocessing.get('encrypted', False)
                    st.metric("Encrypted", "Yes" if encrypted else "No")
                
                with col3:
                    access_granted = preprocessing.get('access_granted', False)
                    st.metric("Access", "Granted" if access_granted else "Denied")
                
                # Show regulations applied
                regulations = preprocessing.get('regulatory_compliance', {}).get('regulations_applied', [])
                if regulations:
                    st.markdown("**Regulations Applied:**")
                    for reg in regulations:
                        st.markdown(f"- {reg}")
                
                # Show execution path
                exec_path = preprocessing.get('execution_path', [])
                if exec_path:
                    st.markdown("**Processing Agents:**")
                    st.markdown(" → ".join(exec_path))
        
        st.markdown("---")

    # ==================================================
    # DISPLAY CLINICAL ANALYSIS
    # ==================================================
    
    st.markdown("### 📋 Clinical Analysis Result")

    st.warning(
        "**Disclaimer:** The following analysis is generated by an AI model using "
        "synthetic data. It is for demonstration purposes only and is **not** a substitute for professional medical advice."
    )

    if st.session_state.final_answer:
        # Show the analysis result
        st.markdown(
            f"<div id='final_answer_markdown'>{st.session_state.final_answer}</div>",
            unsafe_allow_html=True,
        )
        
        # Option to export
        col1, col2 = st.columns([3, 1])
        with col2:
            if st.button("📥 Export Report"):
                # Create report with preprocessing info
                report_content = f"""
CLINICAL ANALYSIS REPORT
========================
Generated: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}
Clinician: {st.session_state.user_info.get('name', 'Unknown')}
Patient: {st.session_state.get('display_patient_id', 'Not specified')}

ORIGINAL QUERY:
{st.session_state.query}

PII/PHI DETECTED:
{len(st.session_state.get('preprocessing_result', {}).get('pii_detected', []))} entities detected

PROCESSED QUERY:
{st.session_state.get('preprocessing_result', {}).get('masked_input', 'N/A')}

CLINICAL ANALYSIS:
{st.session_state.final_answer}

---
This report contains AI-generated content and is for demonstration purposes only.
"""
                st.download_button(
                    label="Download Report",
                    data=report_content,
                    file_name=f"clinical_report_{datetime.now().strftime('%Y%m%d_%H%M%S')}.txt",
                    mime="text/plain"
                )
    else:
        st.info(
            "Analysis results will appear here after clicking **Analyze Query**."
        )


# ==================================================
# CSS ADDITIONS FOR PII HIGHLIGHTING
# ==================================================

PII_HIGHLIGHT_CSS = """
<style>
/* PII Highlighting Styles */
#final_answer_markdown {
    max-height: 430px;
    overflow-y: auto;
    background-color: #FFFFFF;
    border: 1px solid #E5E7EB;
    padding: 0.9rem 1rem;
    border-radius: 10px;
    color: #111827;
}

.pii-highlight {
    padding: 2px 6px;
    border-radius: 4px;
    font-weight: 600;
    cursor: help;
    transition: all 0.2s;
}

.pii-highlight:hover {
    transform: scale(1.05);
    box-shadow: 0 2px 8px rgba(0,0,0,0.2);
}

.pii-person {
    background-color: #ffeb3b;
    color: #000;
}

.pii-email {
    background-color: #81c784;
    color: #fff;
}

.pii-phone {
    background-color: #64b5f6;
    color: #fff;
}

.pii-ssn {
    background-color: #e57373;
    color: #fff;
}

.pii-location {
    background-color: #ba68c8;
    color: #fff;
}

/* Preprocessing card */
.preprocessing-card {
    background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
    color: white;
    padding: 1.5rem;
    border-radius: 12px;
    margin: 1rem 0;
    box-shadow: 0 4px 12px rgba(0,0,0,0.1);
}

.preprocessing-card h4 {
    color: white;
    margin-top: 0;
}

.pii-legend {
    display: flex;
    flex-wrap: wrap;
    gap: 1rem;
    padding: 0.5rem;
    background: #f8f9fa;
    border-radius: 8px;
    margin: 0.5rem 0;
}

.pii-legend-item {
    display: flex;
    align-items: center;
    gap: 0.5rem;
    font-size: 0.85rem;
}

.pii-legend-box {
    width: 20px;
    height: 20px;
    border-radius: 4px;
}
</style>
"""