"""
FALLBACK TRIAGE CLASSIFICATION FUNCTION
========================================

This file provides the complete fallback_triage_classification() function
with exact line numbers and placement instructions for your app.py.

The fallback is used when:
1. LLM API is unavailable/down
2. LLM returns invalid JSON
3. Network timeout occurs
4. API key is invalid

It falls back to keyword matching (what your code currently does).
"""

# ============================================================================
# COMPLETE FALLBACK FUNCTION
# ============================================================================

def fallback_triage_classification(reason_for_visit: str) -> dict:
    """
    Fallback triage classification using keyword matching.
    
    This is used when the LLM is unavailable or fails.
    Falls back to keyword matching to keep the system running.
    
    Args:
        reason_for_visit: Patient's reported reason for visit
    
    Returns:
        dict with triage classification including:
        - triage_level: "high", "medium", or "low"
        - confidence: Float 0.0-1.0 (lower for fallback)
        - clinical_reasoning: String explanation
        - recommended_response_time: String
        - red_flags: List of flags
        - needs_urgent_assessment: Boolean
        - method: "keyword_fallback" (identifies fallback was used)
    """
    
    # Convert to lowercase for matching
    reason_lower = reason_for_visit.lower()
    
    # ========================================================================
    # HIGH PRIORITY KEYWORDS (Emergent/Life-threatening)
    # ========================================================================
    high_priority_keywords = [
        # Cardiac symptoms
        "chest pain",
        "chest discomfort",
        "heart attack",
        "myocardial infarction",
        "mi",
        "acute coronary",
        "acs",
        "angina",
        "arrhythmia",
        "palpitations with pain",
        
        # Respiratory symptoms
        "difficulty breathing",
        "shortness of breath",
        "dyspnea",
        "can't breathe",
        "trouble breathing",
        "respiratory distress",
        "severe cough",
        "pulmonary embolism",
        "pe",
        "asthma attack",
        "severe asthma",
        
        # Neurological symptoms
        "stroke",
        "cva",
        "cerebrovascular",
        "facial drooping",
        "arm weakness",
        "speech difficulty",
        "transient ischemic",
        "tia",
        "severe headache",
        "thunderclap headache",
        "loss of consciousness",
        "unconscious",
        "coma",
        "unresponsive",
        "seizure",
        "convulsion",
        "paralysis",
        
        # Bleeding/Hemorrhage
        "severe bleeding",
        "uncontrolled bleeding",
        "hemorrhage",
        "internal bleeding",
        "blood loss",
        "massive bleeding",
        "hemorrhagic shock",
        
        # Allergic reactions
        "anaphylaxis",
        "anaphylactic",
        "severe allergic reaction",
        "throat closing",
        "unable to swallow",
        "severe swelling",
        "hives all over",
        
        # Sepsis/Infection
        "sepsis",
        "septic shock",
        "severe infection",
        "meningitis",
        "fever with altered mental status",
        "high fever with confusion",
        
        # Trauma/Injury
        "major trauma",
        "severe injury",
        "broken bone",
        "multiple fractures",
        "head injury",
        "severe head trauma",
        "penetrating wound",
        "deep laceration",
        "crush injury",
        "severe burn",
        
        # Abdominal/GI
        "severe abdominal pain",
        "acute abdomen",
        "peritonitis",
        "ruptured",
        "abdominal aortic aneurysm",
        "aaa",
        "severe vomiting blood",
        "hematemesis",
        
        # Diabetic emergency
        "diabetic ketoacidosis",
        "dka",
        "hypoglycemic coma",
        "blood sugar critically",
        
        # General emergency terms
        "emergency",
        "life-threatening",
        "critical",
        "urgent",
        "severe",
        "acute",
        "immediately",
        "right now",
        "911",
        "call 911",
        "ambulance",
        "er",
        "emergency room",
        "icu",
        "intensive care",
    ]
    
    # ========================================================================
    # MEDIUM PRIORITY KEYWORDS (Urgent but stable)
    # ========================================================================
    medium_priority_keywords = [
        # Infection/Fever
        "fever",
        "infection",
        "infected",
        "bacterial",
        "viral",
        "flu symptoms",
        "influenza",
        "pneumonia",
        "bronchitis",
        "sore throat",
        "strep throat",
        "urinary tract infection",
        "uti",
        "bladder infection",
        "ear infection",
        "eye infection",
        "pink eye",
        "conjunctivitis",
        "skin infection",
        "abscess",
        "boil",
        
        # Moderate pain
        "moderate pain",
        "persistent pain",
        "severe pain",
        "uncontrolled pain",
        "back pain",
        "leg pain",
        "arm pain",
        "muscle pain",
        "joint pain",
        "abdominal pain",
        "stomach pain",
        "migraine",
        "severe headache",
        
        # Injuries (non-emergent)
        "sprain",
        "strain",
        "twisted ankle",
        "twisted knee",
        "minor fracture",
        "broken finger",
        "broken toe",
        "dislocated joint",
        "minor cut",
        "minor burn",
        "wound",
        "laceration",
        
        # GI symptoms
        "vomiting",
        "nausea",
        "diarrhea",
        "gastroenteritis",
        "food poisoning",
        "constipation",
        "severe constipation",
        "heartburn",
        "gerd",
        "acid reflux",
        
        # Eye/Ear/Nose
        "vision changes",
        "sudden vision loss",
        "blurred vision",
        "eye pain",
        "hearing loss",
        "tinnitus",
        "sinus infection",
        "sinusitis",
        "nasal congestion",
        "severe congestion",
        
        # Urinary symptoms
        "painful urination",
        "dysuria",
        "urinary retention",
        "inability to urinate",
        "blood in urine",
        "hematuria",
        
        # Pregnancy related
        "pregnant and",
        "pregnancy complication",
        "bleeding during pregnancy",
        "severe cramping pregnancy",
        "miscarriage",
        "premature labor",
        "vaginal bleeding",
        
        # Mental health crisis
        "suicidal",
        "suicide",
        "self harm",
        "severe depression",
        "severe anxiety",
        "panic attack",
        "mental health crisis",
        "psychiatric emergency",
        
        # Other urgent
        "swelling",
        "swollen",
        "rash",
        "skin changes",
        "chills",
        "weak",
        "weakness",
        "fainting",
        "fainting episode",
        "dizziness",
        "vertigo",
        "lightheaded",
    ]
    
    # ========================================================================
    # LOW PRIORITY KEYWORDS (Routine/Preventive)
    # ========================================================================
    low_priority_keywords = [
        # Routine visits
        "routine",
        "annual",
        "annual checkup",
        "annual exam",
        "yearly",
        "checkup",
        "check-up",
        "physical exam",
        "physical",
        "preventive",
        "preventive care",
        "wellness",
        "wellness visit",
        "well child visit",
        "well baby",
        
        # Vaccinations
        "vaccine",
        "vaccination",
        "immunization",
        "shot",
        "booster",
        "flu shot",
        "covid vaccine",
        
        # Routine visits for specific purposes
        "school physical",
        "sports physical",
        "camp physical",
        "work physical",
        "employment physical",
        "dmv exam",
        "insurance exam",
        
        # Refills/Renewals
        "refill",
        "medication refill",
        "prescription refill",
        "prescription renewal",
        "renew prescription",
        "regular medication",
        
        # Follow-ups
        "follow-up",
        "follow up",
        "followup",
        "post-appointment",
        "post appointment",
        "post-surgery check",
        "post surgery",
        
        # Consultation
        "consultation",
        "consult",
        "second opinion",
        "opinion",
        
        # Routine management
        "routine management",
        "regular visit",
        "regular appointment",
        "check blood pressure",
        "blood pressure check",
        "weight check",
        "blood work",
        "lab work",
        "routine lab",
        
        # Non-urgent issues
        "common cold",
        "cold",
        "minor cough",
        "mild cough",
        "sniffles",
        "runny nose",
        "nasal congestion",
        "common allergy",
        "allergies",
        "seasonal allergy",
        "hay fever",
        "minor rash",
        "acne",
        "wart",
        "mole check",
        "skin tag",
        "dandruff",
        
        # Other routine
        "education",
        "counseling",
        "advice",
        "general questions",
        "routine care",
    ]
    
    # ========================================================================
    # CLASSIFICATION LOGIC
    # ========================================================================
    
    # Check for high priority keywords
    high_priority_matches = [kw for kw in high_priority_keywords if kw in reason_lower]
    if high_priority_matches:
        return {
            "triage_level": "high",
            "confidence": 0.80,  # Lower confidence for fallback
            "clinical_reasoning": f"High-priority symptoms detected: {', '.join(high_priority_matches[:3])}. Immediate evaluation recommended.",
            "recommended_response_time": "same day",
            "red_flags": high_priority_matches,
            "needs_urgent_assessment": True,
            "method": "keyword_fallback",
            "keywords_matched": high_priority_matches
        }
    
    # Check for low priority keywords
    low_priority_matches = [kw for kw in low_priority_keywords if kw in reason_lower]
    if low_priority_matches:
        return {
            "triage_level": "low",
            "confidence": 0.80,  # Lower confidence for fallback
            "clinical_reasoning": f"Routine/preventive visit identified: {', '.join(low_priority_matches[:3])}. Standard scheduling available.",
            "recommended_response_time": "2-4 weeks",
            "red_flags": [],
            "needs_urgent_assessment": False,
            "method": "keyword_fallback",
            "keywords_matched": low_priority_matches
        }
    
    # Check for medium priority keywords
    medium_priority_matches = [kw for kw in medium_priority_keywords if kw in reason_lower]
    if medium_priority_matches:
        return {
            "triage_level": "medium",
            "confidence": 0.80,  # Lower confidence for fallback
            "clinical_reasoning": f"Urgent symptoms detected: {', '.join(medium_priority_matches[:3])}. Evaluation needed within 1-7 days.",
            "recommended_response_time": "1-7 days",
            "red_flags": medium_priority_matches,
            "needs_urgent_assessment": False,
            "method": "keyword_fallback",
            "keywords_matched": medium_priority_matches
        }
    
    # Default: No keywords matched, default to medium
    return {
        "triage_level": "medium",
        "confidence": 0.50,  # Very low confidence - no keywords matched
        "clinical_reasoning": "Non-specific symptoms reported. Recommend physician assessment to determine urgency.",
        "recommended_response_time": "1-7 days",
        "red_flags": [],
        "needs_urgent_assessment": False,
        "method": "keyword_fallback",
        "keywords_matched": [],
        "note": "No matching keywords - recommend manual review"
    }
