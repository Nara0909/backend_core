"""
rag_store.py

Simple in-memory RAG over synthetic cardiology CSV datasets,
with on-disk caching of embeddings so they are NOT recomputed on every run.

Corpus from:
- clinical_rules.csv
- drugs.csv
- drug_interactions.csv
"""

from pathlib import Path
from typing import List, Dict, Any
import json

import numpy as np
import pandas as pd

from config import client, EMBEDDING_MODEL

BASE_DIR = Path(__file__).resolve().parent
DATA_DIR = BASE_DIR / "data_agent"

DRUGS_DIR = DATA_DIR / "drugs"
GUIDELINES_DIR = DATA_DIR / "guidelines"

drugs_df = pd.read_csv(DRUGS_DIR / "drugs.csv")
drug_interactions_df = pd.read_csv(DRUGS_DIR / "drug_interactions.csv")
clinical_rules_df = pd.read_csv(GUIDELINES_DIR / "clinical_rules.csv")

# Cache folder for RAG embeddings
CACHE_DIR = DATA_DIR / "rag_cache"
CACHE_DIR.mkdir(parents=True, exist_ok=True)
CACHE_TEXTS = CACHE_DIR / "texts.json"
CACHE_META = CACHE_DIR / "metadata.json"
CACHE_EMB = CACHE_DIR / "embeddings.npy"


class RAGStore:
    def __init__(self):
        """
        On init:
        - Try to load docs + embeddings from disk cache
        - If not available, build corpus, embed all, and save cache
        """
        self.docs: List[Dict[str, Any]] = []

        if self._can_load_cache():
            self._load_cache()
        else:
            self._build_corpus()
            self._embed_all()
            self._save_cache()

    # ---------- Cache helpers ----------

    @staticmethod
    def _can_load_cache() -> bool:
        """
        Return True if all cache files exist.
        (Simple check; does not verify CSV changes.)
        """
        return CACHE_TEXTS.exists() and CACHE_META.exists() and CACHE_EMB.exists()

    def _load_cache(self) -> None:
        """
        Load texts, metadata, and embeddings from disk into self.docs
        """
        with open(CACHE_TEXTS, "r", encoding="utf-8") as f:
            texts: List[str] = json.load(f)
        with open(CACHE_META, "r", encoding="utf-8") as f:
            metadata_list: List[Dict[str, Any]] = json.load(f)

        emb_matrix = np.load(CACHE_EMB)

        self.docs = []
        for text, meta, emb in zip(texts, metadata_list, emb_matrix):
            self.docs.append(
                {
                    "text": text,
                    "metadata": meta,
                    "embedding": np.array(emb, dtype="float32"),
                }
            )

    def _save_cache(self) -> None:
        """
        Save texts, metadata, and embeddings from self.docs to disk.
        """
        texts: List[str] = [d["text"] for d in self.docs]
        metadata_list: List[Dict[str, Any]] = [d["metadata"] for d in self.docs]
        embeddings_matrix = np.stack([d["embedding"] for d in self.docs], axis=0)

        with open(CACHE_TEXTS, "w", encoding="utf-8") as f:
            json.dump(texts, f, ensure_ascii=False, indent=2)

        with open(CACHE_META, "w", encoding="utf-8") as f:
            json.dump(metadata_list, f, ensure_ascii=False, indent=2)

        np.save(CACHE_EMB, embeddings_matrix)

    # ---------- Corpus ----------

    def _build_corpus(self) -> None:
        """
        Build self.docs as a list of dicts:
        {
            "text": <natural-language chunk>,
            "metadata": {...},
            # "embedding": added later
        }
        """
        # 1) Clinical rules
        for _, row in clinical_rules_df.iterrows():
            text = (
                f"Clinical rule {row['rule_id']} for {row['condition_name']} "
                f"({row['condition_code']}), type={row['rule_type']}, "
                f"org={row['reference_org']}: {row['rule_text']}"
            )
            meta = {
                "table": "clinical_rules",
                "rule_id": row["rule_id"],
                "condition_code": row["condition_code"],
            }
            self.docs.append({"text": text, "metadata": meta})

        # 2) Drug master
        for _, row in drugs_df.iterrows():
            text = (
                f"Drug {row['generic_name']} (ID {row['drug_id']}), brand {row['brand_name']}, "
                f"class {row['drug_class']}, ATC-like code {row['atc_code']}."
            )
            meta = {
                "table": "drugs",
                "drug_id": row["drug_id"],
                "generic_name": row["generic_name"],
            }
            self.docs.append({"text": text, "metadata": meta})

        # 3) Drug interactions
        for _, row in drug_interactions_df.iterrows():
            text = (
                f"Interaction between {row['drug_a_id']} and {row['drug_b_id']}: "
                f"severity {row['interaction_severity']}. "
                f"Description: {row['interaction_description']}"
            )
            meta = {
                "table": "drug_interactions",
                "drug_a_id": row["drug_a_id"],
                "drug_b_id": row["drug_b_id"],
            }
            self.docs.append({"text": text, "metadata": meta})

    # ---------- Embeddings ----------

    def _embed_all(self) -> None:
        """
        Compute embeddings for all docs in self.docs and attach as 'embedding'.
        Only called if cache is not available.
        """
        texts = [d["text"] for d in self.docs]
        if not texts:
            return

        batch_size = 32
        embeddings: List[List[float]] = []

        for i in range(0, len(texts), batch_size):
            batch = texts[i : i + batch_size]

            res = client.embeddings.create(
                model=EMBEDDING_MODEL,
                input=batch,
            )

            # new OpenAI client returns a list of data items
            for item in res.data:
                embeddings.append(item.embedding)

        for doc, emb in zip(self.docs, embeddings):
            doc["embedding"] = np.array(emb, dtype="float32")

    @staticmethod
    def _cosine_sim(a: np.ndarray, b: np.ndarray) -> float:
        denom = (np.linalg.norm(a) * np.linalg.norm(b))
        if denom == 0:
            return 0.0
        return float(np.dot(a, b) / denom)

    # ---------- Query ----------

    def query(self, text: str, k: int = 5) -> List[Dict[str, Any]]:
        """
        Embed the query, compute cosine similarity vs cached embeddings,
        return top-k docs.
        """
        if not self.docs:
            return []

        res = client.embeddings.create(
            model=EMBEDDING_MODEL,
            input=[text],
        )
        q_emb = np.array(res.data[0].embedding, dtype="float32")

        scored = []
        for d in self.docs:
            sim = self._cosine_sim(q_emb, d["embedding"])
            scored.append(
                {
                    "text": d["text"],
                    "metadata": d["metadata"],
                    "score": sim,
                }
            )

        scored.sort(key=lambda x: x["score"], reverse=True)
        return scored[:k]


# Singleton instance
rag_store = RAGStore()

# set GRADIO_ANALYTICS_ENABLED=False
