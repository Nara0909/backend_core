# agents.py
"""
LLM-powered clinical agents using the synthetic datasets as context.
"""

from typing import Dict, Any, List, Optional
import json
import requests

from config import client, MODEL, MCP_SERVER_URL
from clinical_data import ClinicalDataStore
from rag_store import rag_store  # <-- RAG over synthetic CSVs


def _chat(system_prompt: str, user_prompt: str) -> str:
    """Small helper around chat.completions."""
    resp = client.chat.completions.create(
        model=MODEL,
        messages=[
            {"role": "system", "content": system_prompt},
            {"role": "user", "content": user_prompt},
        ],
        temperature=0.3,
        max_tokens=1200,
    )
    # new OpenAI client returns .message.content as a str
    return resp.choices[0].message.content


class ClinicalQueryAgent:
    """
    Interprets the clinician's query and sets intent:
    - "drug_interaction"
    - "clinical_guideline"
    - "general"

    Note: entity extraction is simple keyword + patient_context based.
    """

    SYSTEM_PROMPT = (
        "You are a clinical query interpretation agent. "
        "You will be given a clinician question and a summary of patient data. "
        "Explain what the clinician is asking and what type of task it is "
        "(interaction check, guideline question, or general explanation). "
        "Do not give treatment advice; just interpret."
    )

    def analyze(
        self,
        query: str,
        patient_context: Optional[Dict[str, Any]],
    ) -> Dict[str, Any]:
        ql = query.lower()
        if (
            "interaction" in ql
            or "combine" in ql
            or "together" in ql
            or "safe to prescribe" in ql
            or "safe with" in ql
        ):
            intent = "drug_interaction"
        elif (
            "risk" in ql
            or "predict" in ql
            or "likelihood" in ql
            or "chance of" in ql
        ):
            intent = "risk_prediction"
        elif "guideline" in ql or "treatment" in ql or "manage" in ql or "management" in ql:
            intent = "clinical_guideline"
        else:
            intent = "general"

        # entities mostly from patient_context, not full NER
        meds = patient_context.get("medications", []) if patient_context else []
        conds = patient_context.get("conditions", []) if patient_context else []

        entities = {
            "intent": intent,
            "medications": meds,
            "conditions": conds,
        }

        ctx_str = json.dumps(
            {
                "patient_summary": patient_context or {},
                "entities": entities,
            },
            indent=2,
        )

        analysis = _chat(
            self.SYSTEM_PROMPT,
            f"Clinician query:\n{query}\n\nStructured context:\n{ctx_str}",
        )

        return {
            "intent": intent,
            "entities": entities,
            "llm_analysis": analysis,
        }


class DrugInteractionAgent:
    """
    Uses drug_interactions.csv + LLM explanation.
    """

    SYSTEM_PROMPT = (
        "You are a pharmacology expert working on a synthetic cardiology dataset. "
        "You receive a list of patient medications and structured interaction records "
        "from a synthetic database. Explain the clinical significance in clear, "
        "cautious language. Do NOT invent new interactions that are not in the "
        "structured list. Make it explicit that this is synthetic demo data, not "
        "real medical advice."
    )

    def evaluate_for_patient(self, patient_id: str) -> Dict[str, Any]:
        ctx = ClinicalDataStore.get_patient_context(patient_id)
        if not ctx:
            return {"error": f"Unknown patient_id {patient_id}"}

        meds = ctx["medications"]
        drug_ids = [m["drug_id"] for m in meds if m.get("drug_id")]
        interactions = ClinicalDataStore.check_interactions(drug_ids)

        payload = {
            "patient": ctx["patient"],
            "medications": meds,
            "interactions": interactions,
        }

        analysis = _chat(
            self.SYSTEM_PROMPT,
            f"Structured data (synthetic):\n{json.dumps(payload, indent=2)}\n\n"
            "Provide a concise clinical-style summary of the interaction profile. "
            "Remind the reader this is synthetic, not real clinical guidance.",
        )

        return {
            "patient_id": patient_id,
            "interactions": interactions,
            "analysis": analysis,
        }


class GuidelineAgent:
    """
    Uses clinical_rules.csv + LLM to summarize for this patient.
    """

    SYSTEM_PROMPT = (
        "You are a clinical guidelines summarization agent working on synthetic data. "
        "You receive synthetic guideline rules for a patient's cardiovascular "
        "conditions and the patient's basic profile. Summarize key treatment "
        "principles in a structured but concise way. Make it clear this is "
        "synthetic data and not real medical advice, and do not reference any "
        "real-world guideline text verbatim."
    )

    def summarize_for_patient(self, patient_id: str) -> Dict[str, Any]:
        ctx = ClinicalDataStore.get_patient_context(patient_id)
        if not ctx:
            return {"error": f"Unknown patient_id {patient_id}"}

        rules = ClinicalDataStore.get_rules_for_patient(patient_id)

        payload = {
            "patient": ctx["patient"],
            "conditions": ctx["conditions"],
            "rules": rules,
        }

        summary = _chat(
            self.SYSTEM_PROMPT,
            f"Synthetic rules + patient context:\n{json.dumps(payload, indent=2)}\n\n"
            "Summarize guideline-style recommendations for this patient using only "
            "this synthetic information.",
        )

        return {
            "patient_id": patient_id,
            "rules_used": rules,
            "summary": summary,
        }


class RagAgent:
    """
    Generic RAG agent over the synthetic cardiology corpus (drugs, interactions, rules).

    Uses rag_store.query(...) to retrieve the most relevant synthetic rows
    and then asks the LLM to answer using ONLY that context.
    """

    SYSTEM_PROMPT = (
        "You are an assistant that answers questions using ONLY the provided synthetic "
        "cardiology context. The context comes from synthetic tables: drugs, drug "
        "interactions, and clinical rules. Do not invent facts beyond the context. "
        "Make it clear this is synthetic demo data and not real clinical advice."
    )

    def answer(self, query: str) -> Dict[str, Any]:
        # 1) Retrieve top-k relevant synthetic chunks
        retrieved = rag_store.query(query, k=5)

        context_block_lines: List[str] = []
        for r in retrieved:
            score = round(r.get("score", 0.0), 3)
            text = r.get("text", "")
            metadata = r.get("metadata", {})
            context_block_lines.append(
                f"[score={score}] {text}\nMETA: {json.dumps(metadata)}"
            )
        context_block = "\n\n".join(context_block_lines)

        # 2) Ask LLM to answer using only this context
        answer_text = _chat(
            self.SYSTEM_PROMPT,
            (
                "User question:\n"
                f"{query}\n\n"
                "Retrieved synthetic context:\n"
                f"{context_block}\n\n"
                "Use ONLY this context to answer. If the context is insufficient, "
                "say so explicitly."
            ),
        )

        return {
            "query": query,
            "retrieved": retrieved,
            "answer": answer_text,
        }


class RiskPredictionAgent:
    """
    Uses patient context and LLM reasoning to generate a synthetic risk score.
    """

    SYSTEM_PROMPT = (
        "You are a clinical risk prediction model simulator working with synthetic data. "
        "You will receive a patient's full context (demographics, conditions, medications) "
        "and a risk topic to predict (e.g., '1-year cardiovascular event risk').\n\n"
        "Your task is to analyze the patient's profile and generate a structured risk assessment. "
        "If Patient already suffering from same related diseases predict the score as 100"
        "Your output MUST be a JSON object with the following keys:\n"
        '- "risk_topic": The topic you are assessing.\n'
        '- "qualitative_risk": A string, one of "Low", "Moderate", "High", or "Very High".\n'
        '- "quantitative_risk_percent": A synthetic numerical percentage (e.g., 15.5).\n'
        '- "key_risk_factors": A list of strings describing the top 3-5 factors from the patient\'s profile that contribute to this risk.\n'
        '- "explanation": A brief, cautious explanation of why these factors contribute to the risk.\n\n'
        "IMPORTANT: This is a SYNTHETIC demonstration. The risk score is not real. "
        "Base your assessment on general medical knowledge as applied to the synthetic data provided."
    )

    def predict_risk(
        self, patient_id: str, risk_topic: str = "1-year major adverse cardiovascular event (MACE)"
    ) -> Dict[str, Any]:
        ctx = ClinicalDataStore.get_patient_context(patient_id)
        if not ctx:
            return {"error": f"Unknown patient_id {patient_id}"}

        user_prompt = (
            f"Patient Context (Synthetic):\n{json.dumps(ctx, indent=2)}\n\n"
            f"Risk Topic to Predict: {risk_topic}\n\n"
            "Generate the JSON risk assessment based on this patient's profile."
        )

        try:
            raw_json = _chat(self.SYSTEM_PROMPT, user_prompt)
            # Clean up potential markdown fences
            clean_json = raw_json.replace("```json", "").replace("```", "").strip()
            result = json.loads(clean_json)
            result["patient_id"] = patient_id
            return result
        except (json.JSONDecodeError, Exception) as e:
            return {"error": f"Failed to generate or parse risk prediction: {str(e)}"}

    def predict_risk_ml(self, patient_id: str) -> Dict[str, Any]:
        """Calls the external ML model server for risk prediction."""
        ctx = ClinicalDataStore.get_patient_context(patient_id)
        if not ctx or "patient" not in ctx:
            return {"error": f"Unknown patient_id {patient_id}"}

        patient_data = ctx["patient"]

        # Prepare the feature payload for the model API
        features = {
            "age": int(patient_data.get("age", 0)),
            "gender": patient_data.get("gender", "Other"),
            "smoker_status": patient_data.get("smoker_status", "never"),
            "bmi_category": patient_data.get("bmi_category", "normal"),
            "diabetes_status": patient_data.get("diabetes_status", "none"),
            "family_history_cvd": patient_data.get("family_history_cvd", "no"),
        }

        try:
            # Call the external model server
            response = requests.post(f"{MCP_SERVER_URL}/predict", json=features)
            response.raise_for_status()
            
            prediction_data = response.json()
            risk_score = prediction_data.get("risk_score")

            # Convert quantitative score to a qualitative category
            qualitative_risk = "N/A"
            if risk_score is not None:
                if risk_score <= 25:
                    qualitative_risk = "Low"
                elif risk_score <= 50:
                    qualitative_risk = "Moderate"
                elif risk_score <= 75:
                    qualitative_risk = "High"
                else:
                    qualitative_risk = "Very High"

            # Adapt the response to the format expected by the UI
            return {
                "risk_topic": prediction_data.get("risk_topic"),
                "qualitative_risk": qualitative_risk,
                "quantitative_risk_percent": risk_score,
                "key_risk_factors": ["Age", "BMI", "Smoker Status", "Diabetes Status"], # Example factors
                "explanation": "Risk score calculated by a dedicated ML regression model based on patient demographics."
            }
        except requests.exceptions.RequestException as e:
            return {"error": f"Could not connect to the ML model server: {e}"}


class SummaryAgent:
    """
    Final summarizer that combines outputs from other agents, with medication
    safety handling (allergies + interactions + alternatives).
    """

    SYSTEM_PROMPT = (
        "You are a clinical orchestration summarizer working as an assistant to a healthcare professional"
        " Your response MUST be structured and follow these rules:\n\n"
        "- A clear, direct answer to the clinician's question.\n"
        "- A safety-first interpretation of medication risks.\n"
        "- Strong warnings when allergies or interactions exist.\n"
        "- Any follow-up tests or reports (if required) should be presented in a section called Follow-up instructions."
        "- Simple, direct language.\n\n"
        "- Technical language may be used to provide justification for the recommendations.\n\n"
        "CITATION RULE:\n"
        "When you state a clinical recommendation that comes from the 'guideline_result' context, you MUST cite the source. Append the citation in the format `(Ref: [rule_id] - [reference_org])` at the end of the sentence. For example: 'First-line treatment should include a thiazide-like diuretic (Ref: RULE0001 - FDA)'.\n\n"
        "STRICT SAFETY RULES:\n"
        "4. Offer alternative suggestions only from the provided data. Do not make assumptions about the interactions.\n\n"
        "IMPORTANT:\n"
        "The advice given by you is going to a qualified healthcare professional.\n"
        "The Advice is already prefixed with a disclaimer while displaying it. You don't need to add a disclaimer in your output."
    )

    def summarize(self, query: str, partial: Dict[str, Any]) -> str:
        """
        Build a highly structured summary, letting the LLM phrase it clearly
        based on a very strict prompt and structured context.
        """
        interaction = partial.get("interaction_result", {}) or {}
        safety = interaction.get("medication_safety", {}) or {}

        # Extract high-level flags for clearer prompting
        proposed = safety.get("proposed_drugs", [])
        any_allergy = safety.get("any_allergy_conflict", False)
        any_interaction = safety.get("any_interaction", False)

        # Provide a structured interpretation context to LLM
        summary_context = {
            "query": query,
            "proposed_medications": proposed,
            "medication_safety": safety,
            "has_allergy_conflicts": any_allergy,
            "has_interaction_risks": any_interaction,
            "allergy_conflicts_detail": interaction.get("allergy_conflicts", []),
            "alternative_suggestions": interaction.get("alternative_suggestions", []),
            "guideline_result": partial.get("guideline_result", {}),
            "risk_prediction_result": partial.get("risk_prediction_result", {}),
            "rag_result": partial.get("rag_result", {}),
            "query_analysis": partial.get("query_analysis", {}),
        }

        return _chat(
            self.SYSTEM_PROMPT,
            "Final summarization context (JSON):\n"
            + json.dumps(summary_context, indent=2)
        )
