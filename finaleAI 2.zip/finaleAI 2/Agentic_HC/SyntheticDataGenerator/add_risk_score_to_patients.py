"""
add_risk_score_to_patients.py

This utility script reads the existing patients.csv file and adds the
'health_risk_score' column if it's missing. It uses an LLM to generate a
plausible score for each patient based on their demographics.

This is a faster alternative to re-running the entire synthetic_agent_generator.py
script when you only need to add the target variable for model training.

USAGE:
  Run this script from within the SyntheticDataGenerator directory.
  It will create a backup of your original patients.csv file.
"""

import pandas as pd
import os
import shutil
from tqdm import tqdm

from config import client, MODEL

# --- Configuration ---
BASE_DIR = os.path.dirname(__file__)
DATA_PATH = os.path.join(BASE_DIR, "data_agent", "patients", "patients.csv")

# --- System Prompt for the Agent ---
SYSTEM_PROMPT = """
You are a data augmentation agent. Your task is to generate a single numerical health risk score based on a patient's demographic data.
The score should be between 0.0 and 100.0. A higher score means higher risk.
Base the score on factors like age, smoking status, BMI, and diabetes.
Respond with ONLY the numerical score. For example: 45.3
"""


def get_risk_score_for_patient(patient_row: pd.Series) -> float:
    """Calls the LLM to get a risk score for a single patient."""
    try:
        # Create a concise user prompt from the patient data
        user_prompt = (
            f"Patient Data:\n"
            f"- Age: {patient_row.get('age', 'N/A')}\n"
            f"- Gender: {patient_row.get('gender', 'N/A')}\n"
            f"- Smoker Status: {patient_row.get('smoker_status', 'N/A')}\n"
            f"- BMI Category: {patient_row.get('bmi_category', 'N/A')}\n"
            f"- Diabetes Status: {patient_row.get('diabetes_status', 'N/A')}\n"
            f"- Family History CVD: {patient_row.get('family_history_cvd', 'N/A')}\n\n"
            "Generate the health risk score for this patient."
        )

        resp = client.chat.completions.create(
            model=MODEL,
            messages=[
                {"role": "system", "content": SYSTEM_PROMPT},
                {"role": "user", "content": user_prompt},
            ],
            temperature=0.5,
        )
        score_str = resp.choices[0].message.content or "0.0"
        return float(score_str.strip())
    except (ValueError, TypeError, AttributeError):
        # In case of a non-numeric response from the LLM
        return 0.0


def main():
    """Main function to augment the patient data."""
    print(f"Loading patient data from {DATA_PATH}...")
    try:
        df = pd.read_csv(DATA_PATH)
    except FileNotFoundError:
        print(f"ERROR: Patient data file not found at {DATA_PATH}")
        return

    if "health_risk_score" in df.columns:
        print("INFO: 'health_risk_score' column already exists. No action needed.")
        return

    print("INFO: 'health_risk_score' column not found. Proceeding to generate scores.")

    # Create a backup
    backup_path = DATA_PATH + ".bak"
    shutil.copy(DATA_PATH, backup_path)
    print(f"  -> Backup of original file created at {backup_path}")

    risk_scores = []
    # Use tqdm for a nice progress bar
    for _, row in tqdm(df.iterrows(), total=df.shape[0], desc="Generating risk scores"):
        score = get_risk_score_for_patient(row)
        risk_scores.append(score)

    df["health_risk_score"] = risk_scores

    # Save the updated DataFrame
    df.to_csv(DATA_PATH, index=False)
    print(f"\n✅ Success! Updated patient data with 'health_risk_score' has been saved to {DATA_PATH}")


if __name__ == "__main__":
    main()