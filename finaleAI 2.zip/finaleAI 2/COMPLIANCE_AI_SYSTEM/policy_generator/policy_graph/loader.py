# policy_generator/policy_graph/loader.py

import pickle
from pathlib import Path

GRAPH_PATH = Path(__file__).resolve().parent / "policy_graph.pkl"

_POLICY_GRAPH = None


def get_policy_graph():
    """
    Load and cache the policy knowledge graph.
    """
    global _POLICY_GRAPH

    if _POLICY_GRAPH is None:
        if not GRAPH_PATH.exists():
            raise FileNotFoundError(
                f"policy_graph.pkl not found at {GRAPH_PATH}. "
                f"Run the graph builder first."
            )

        with open(GRAPH_PATH, "rb") as f:
            _POLICY_GRAPH = pickle.load(f)

    return _POLICY_GRAPH
