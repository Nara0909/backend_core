from .actions import AI_SCOPE_TO_ACTIONS
from .loader import get_policy_graph


def resolve_policies_from_graph(request_type: str):
    G = get_policy_graph()

    policies = []
    agents = set()
    actions = set()
    regulations = set()

    if not G.has_node(request_type):
        return {
            "regulations": [],
            "policies": [],
            "agents": [],
            "actions": []
        }

    # RequestType → Regulation
    for reg in G.successors(request_type):
        if G.nodes[reg].get("node_type") != "Regulation":
            continue

        regulations.add(reg)

        # Regulation → PolicyRule
        for rule in G.successors(reg):
            if G.nodes[rule].get("node_type") != "PolicyRule":
                continue

            rule_data = G.nodes[rule]
            ai_scope = rule_data.get("ai_scope", "General_Governance")

            # Actions from AI scope
            for action in AI_SCOPE_TO_ACTIONS.get(ai_scope, []):
                actions.add(action)

            # Rule → AI Scope → Agent
            for scope in G.successors(rule):
                if G.nodes[scope].get("node_type") == "AI_Scope":
                    for agent in G.successors(scope):
                        agents.add(agent)

            policies.append({
                "rule_id": rule,
                "article": rule_data.get("article"),
                "principle": rule_data.get("principle"),
                "requirement": rule_data.get("requirement"),
                "ai_scope": ai_scope,
            })

    return {
        "regulations": sorted(regulations),
        "policies": policies,
        "agents": sorted(agents),
        "actions": sorted(actions),
    }
