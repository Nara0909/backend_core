# Frontend Healthcare Compliance AI Module

LangGraph-based frontend for orchestrating healthcare AI with regulatory compliance.

## Architecture

```
┌─────────────────────────────────────────────┐
│   Frontend (Streamlit UI)                   │
│   - Clinical Triage Interface               │
│   - Compliance Dashboard                    │
│   - Audit Trail Viewer                      │
│   - Settings                                │
└──────────────┬──────────────────────────────┘
               │
┌──────────────▼──────────────────────────────┐
│   LangGraph Compliance Agent                │
│   - Orchestrates compliance workflow        │
│   - 6 nodes: plan → access → mask →         │
│     LLM → sanitize → store                  │
│   - Conditional routing for failures        │
└──────────────┬──────────────────────────────┘
               │
       ┌───────┴────────┐
       │                │
┌──────▼────────┐  ┌────▼───────────┐
│ Frontend DB   │  │ Backend API     │
│ (SQLAlchemy)  │  │ (FastAPI)       │
│ - audit_log   │  │ - enforcement   │
│ - decisions   │  │ - access check  │
│ - patient_ehr │  │ - mask PII      │
│ - events      │  │ - sanitize out  │
└───────────────┘  └─────────────────┘
```

## Components

### 1. `healthcare_compliance_agent.py`
**LangGraph-based compliance orchestration agent**

- **HealthcareComplianceState**: TypedDict defining workflow state
- **HealthcareComplianceAgent**: Main agent class with LangGraph graph
- **Nodes**:
  - `get_enforcement_plan`: Fetch applicable regulations
  - `check_access`: Verify user permissions
  - `mask_pii`: Detect and mask sensitive data
  - `call_llm`: Clinical AI with masked input only
  - `sanitize_output`: Ensure no PII leakage
  - `store_audit`: Save audit trail
  - `compliance_fail`: Handle violations

### 2. `backend_client.py`
**HTTP client for backend compliance middleware**

```python
client = BackendClient("http://localhost:8000")

# Get enforcement plan
plan = client.get_enforcement_plan("triage")

# Check access
result = client.check_access(
    user_id="clinician_001",
    user_role="clinician",
    patient_id="P12345"
)

# Mask PII
result = client.mask_pii("Patient John Doe SSN 123-45-6789")

# Sanitize output
result = client.sanitize_output(llm_output)

# Log compliance action
client.log_compliance_action(...)
```

### 3. `database.py`
**SQLAlchemy models and database client**

**Models**:
- `AuditLog`: Complete audit trail (input, output, decisions, regulations)
- `ClinicalDecision`: Triage/scheduling/referral decisions
- `PatientEHR`: Patient electronic health record
- `ComplianceEvent`: Compliance violations, warnings, successes

**Client**:
```python
db = DatabaseClient()

# Store audit
audit_id = db.store_audit_log(audit_record)

# Get audits by user
audits = db.get_audit_logs_by_user("clinician_001")

# Get audits by patient
audits = db.get_audit_logs_by_patient("P12345")

# Store decision
decision_id = db.store_clinical_decision(decision_record)

# Get patient EHR
ehr = db.get_or_create_patient_ehr("P12345")

# Get compliance violations
violations = db.get_compliance_violations()
```

## Usage

### Basic Usage

```python
from frontend import create_compliance_agent, create_db_client

# Initialize
db_client = create_db_client()
agent = create_compliance_agent(db_client=db_client)

# Process clinical request
result = agent.process_clinical_request(
    user_id="clinician_001",
    user_role="clinician",
    patient_id="P12345",
    input_text="Patient presents with chest pain...",
    request_type="triage"
)

# Result contains:
# - compliance_passed: bool
# - audit_id: str
# - sanitized_output: str
# - violations: list
# - audit_record: dict (full details)
```

### Streamlit UI

```bash
streamlit run ui/app.py
```

Opens on `http://localhost:8501` with:
- **Clinical Triage**: Process patient data through compliance
- **Compliance Dashboard**: System health metrics
- **Audit Trail**: Query compliance history
- **Settings**: Configuration options

### Example Clinical Flow

```bash
python example_clinical_flow.py
```

Demonstrates:
1. Successful triage with PII detection
2. Access denied scenario
3. Specialist referral
4. Audit trail queries
5. Compliance statistics

## Workflow

### Compliance Orchestration Flow

```
START
  ↓
[Get Enforcement Plan]
  ├─ Which regulations apply?
  ├─ Which agents to use?
  ↓
[Check Access]
  ├─ User role has permission?
  ├─ If NO → FAIL
  ↓
[Mask PII]
  ├─ Detect sensitive data
  ├─ Replace with [MASKED]
  ↓
[Call LLM]
  ├─ ONLY with masked input
  ├─ Never use raw data
  ↓
[Sanitize Output]
  ├─ Ensure no PII in output
  ├─ If PII found → FAIL
  ↓
[Store Audit]
  ├─ Save complete trail to DB
  ├─ Link to regulations
  ↓
END (PASSED or FAILED)
```

### Conditional Branches

1. **Access Denied**: Jump to `compliance_fail`
2. **PII Masking Failed**: Jump to `compliance_fail`
3. **Output Contains PII**: Jump to `compliance_fail`
4. **Compliance Fail**: Log violation and END

## Database Schema

### AuditLog Table

```sql
CREATE TABLE audit_log (
    id VARCHAR PRIMARY KEY,
    timestamp DATETIME,
    user_id VARCHAR,
    user_role VARCHAR,
    patient_id VARCHAR,
    request_type VARCHAR,
    
    -- Input handling
    input_text TEXT,
    pii_detected JSON,
    masked_text TEXT,
    
    -- Access control
    access_granted BOOLEAN,
    access_reason VARCHAR,
    
    -- Processing
    llm_output TEXT,
    sanitized_output TEXT,
    safe_to_store BOOLEAN,
    pii_in_output JSON,
    
    -- Compliance
    enforcement_plan JSON,
    applicable_regulations JSON,
    compliance_passed BOOLEAN,
    violations JSON
);
```

### ClinicalDecision Table

```sql
CREATE TABLE clinical_decision (
    id VARCHAR PRIMARY KEY,
    timestamp DATETIME,
    audit_id VARCHAR REFERENCES audit_log(id),
    user_id VARCHAR,
    patient_id VARCHAR,
    decision_type VARCHAR,  -- triage, scheduling, referral
    
    decision_reasoning TEXT,
    decision_output TEXT,
    confidence_score INTEGER,
    severity_level VARCHAR,  -- low, medium, high, critical
    recommended_action VARCHAR,
    
    requires_escalation BOOLEAN,
    escalated_to VARCHAR,
    
    model_used VARCHAR,
    processing_time_ms INTEGER
);
```

### PatientEHR Table

```sql
CREATE TABLE patient_ehr (
    patient_id VARCHAR PRIMARY KEY,
    date_of_birth DATETIME,
    gender VARCHAR,
    
    medical_conditions JSON,
    current_medications JSON,
    allergies JSON,
    
    recent_visits JSON,
    recent_labs JSON,
    recent_imaging JSON,
    
    last_updated DATETIME,
    gdpr_consent BOOLEAN,
    hipaa_consent BOOLEAN,
    ai_consent BOOLEAN,
    
    access_count INTEGER,
    last_accessed_by VARCHAR,
    last_accessed_at DATETIME
);
```

## Configuration

### Environment Variables

```bash
# Database
DATABASE_URL=sqlite:///./compliance_frontend.db
# or
DATABASE_URL=postgresql://user:password@localhost/compliance_db

# OpenAI
OPENAI_API_KEY=sk-...

# Backend
BACKEND_URL=http://localhost:8000
```

### LLM Integration

Currently uses OpenAI GPT-4. To change:

```python
# In healthcare_compliance_agent.py, modify _call_llm method
response = openai.ChatCompletion.create(
    model="gpt-4",  # Change this
    messages=[...]
)
```

For local LLMs (Ollama, LLaMA, etc.), use LiteLLM:

```python
import litellm

response = litellm.completion(
    model="ollama/mistral",
    messages=[...]
)
```

## Workflow State

The `HealthcareComplianceState` TypedDict contains:

```python
{
    # Input
    "user_id": str,
    "user_role": str,
    "patient_id": str,
    "input_text": str,
    "request_type": str,
    
    # Enforcement
    "enforcement_plan": dict,
    "applicable_regulations": list,
    
    # Access
    "access_granted": bool,
    "access_reason": str,
    
    # PII
    "pii_detected": list,
    "masked_text": str,
    
    # LLM
    "llm_output": str,
    
    # Safety
    "sanitized_output": str,
    "safe_to_store": bool,
    "pii_in_output": list,
    
    # Audit
    "audit_id": str,
    "audit_record": dict,
    "compliance_passed": bool,
    "violations": list
}
```

## Error Handling

All errors are logged and returned in result:

```python
result = agent.process_clinical_request(...)

if not result['compliance_passed']:
    print("Compliance failed!")
    for violation in result['violations']:
        print(f"  - {violation['type']}: {violation['reason']}")
```

## Security

- **PII Protection**: Regex-based masking (SSN, EMAIL, PHONE, NAME patterns)
- **Access Control**: Role-based (clinician, specialist, admin, nurse, patient)
- **Audit Trail**: Every operation logged with regulations
- **Encryption**: LLM only sees masked data
- **Data Isolation**: Frontend DB separate from backend

## Future Extensions

1. **Multi-Specialty Agents**: Route to cardiology, neurology agents based on indicators
2. **Human-in-the-Loop**: Escalation for high-risk decisions
3. **Federated Learning**: Train models on decentralized healthcare data
4. **Real-Time Monitoring**: Dashboard for compliance violations
5. **Automated Remediation**: Auto-retry and escalation policies

## Debugging

### Enable Verbose Logging

```python
agent.process_clinical_request(...) 
# Already prints workflow steps with [COMPLIANCE], [AUDIT], [ALERT] prefixes
```

### Query Audit Trail

```python
db_client.get_audit_logs_by_user("clinician_001")
db_client.get_audit_logs_by_patient("P12345")
db_client.get_compliance_violations()
```

### Check Backend Health

```python
from frontend import create_backend_client

backend = create_backend_client()
is_healthy = backend.health_check()
```

## License

Proprietary - Healthcare Compliance AI
