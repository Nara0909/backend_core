"""
Frontend Database Models

SQLAlchemy models for:
- audit_log: Complete audit trail with regulations
- clinical_decision: Triage, scheduling, referral decisions
- patient_ehr: Patient electronic health record
"""

from sqlalchemy import create_engine, Column, String, DateTime, JSON, Boolean, Text, Integer, ForeignKey
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import sessionmaker, relationship
from datetime import datetime
import os

# Database setup
DATABASE_URL = os.getenv("DATABASE_URL", "sqlite:///./compliance_frontend.db")
engine = create_engine(DATABASE_URL, connect_args={"check_same_thread": False} if "sqlite" in DATABASE_URL else {})
SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)
Base = declarative_base()


class AuditLog(Base):
    """Complete audit trail for all operations"""
    __tablename__ = "audit_log"
    
    id = Column(String, primary_key=True, index=True)
    timestamp = Column(DateTime, default=datetime.utcnow, index=True)
    
    # User and context
    user_id = Column(String, index=True)
    user_role = Column(String)
    patient_id = Column(String, index=True)
    request_type = Column(String)
    
    # Input handling
    input_text = Column(Text)
    pii_detected = Column(JSON, default=[])
    masked_text = Column(Text)
    
    # Access control
    access_granted = Column(Boolean)
    access_reason = Column(String)
    
    # Processing
    llm_output = Column(Text)
    sanitized_output = Column(Text)
    safe_to_store = Column(Boolean)
    pii_in_output = Column(JSON, default=[])
    
    # Compliance
    enforcement_plan = Column(JSON)
    applicable_regulations = Column(JSON, default=[])
    compliance_passed = Column(Boolean)
    violations = Column(JSON, default=[])
    
    # Relationship
    clinical_decision = relationship("ClinicalDecision", back_populates="audit_log")
    
    class Config:
        """Pydantic config"""
        arbitrary_types_allowed = True


class ClinicalDecision(Base):
    """Clinical decisions (triage, scheduling, referrals)"""
    __tablename__ = "clinical_decision"
    
    id = Column(String, primary_key=True, index=True)
    timestamp = Column(DateTime, default=datetime.utcnow, index=True)
    
    # Reference to audit
    audit_id = Column(String, ForeignKey("audit_log.id"), index=True)
    audit_log = relationship("AuditLog", back_populates="clinical_decision")
    
    # Context
    user_id = Column(String, index=True)
    patient_id = Column(String, index=True)
    decision_type = Column(String)  # "triage", "scheduling", "referral"
    
    # Decision content
    decision_reasoning = Column(Text)
    decision_output = Column(Text)
    confidence_score = Column(Integer)  # 0-100
    
    # Severity/priority
    severity_level = Column(String)  # "low", "medium", "high", "critical"
    recommended_action = Column(String)
    
    # Follow-up
    requires_escalation = Column(Boolean, default=False)
    escalated_to = Column(String)  # Role or specialist
    
    # Metadata
    model_used = Column(String)  # e.g., "gpt-4"
    processing_time_ms = Column(Integer)
    
    class Config:
        """Pydantic config"""
        arbitrary_types_allowed = True


class PatientEHR(Base):
    """Patient Electronic Health Record"""
    __tablename__ = "patient_ehr"
    
    patient_id = Column(String, primary_key=True, index=True)
    
    # Demographics (masked in most views)
    date_of_birth = Column(DateTime)  # Masked as age
    gender = Column(String)
    
    # Medical history
    medical_conditions = Column(JSON, default=[])  # List of conditions
    current_medications = Column(JSON, default=[])  # List of medications
    allergies = Column(JSON, default=[])  # List of allergies
    
    # Recent encounters
    recent_visits = Column(JSON, default=[])
    recent_labs = Column(JSON, default=[])
    recent_imaging = Column(JSON, default=[])
    
    # Compliance info
    last_updated = Column(DateTime, default=datetime.utcnow)
    gdpr_consent = Column(Boolean, default=True)
    hipaa_consent = Column(Boolean, default=True)
    ai_consent = Column(Boolean, default=True)
    
    # Access log
    access_count = Column(Integer, default=0)
    last_accessed_by = Column(String)
    last_accessed_at = Column(DateTime)
    
    class Config:
        """Pydantic config"""
        arbitrary_types_allowed = True


class ComplianceEvent(Base):
    """Track compliance events (violations, warnings, successes)"""
    __tablename__ = "compliance_event"
    
    id = Column(String, primary_key=True, index=True)
    timestamp = Column(DateTime, default=datetime.utcnow, index=True)
    
    # Event details
    event_type = Column(String, index=True)  # "violation", "warning", "success", "audit"
    severity = Column(String)  # "info", "warning", "error", "critical"
    
    # What happened
    user_id = Column(String, index=True)
    action = Column(String)
    resource = Column(String)
    outcome = Column(String)
    
    # Compliance context
    regulations_involved = Column(JSON, default=[])
    policy_violated = Column(String)
    
    # Details
    description = Column(Text)
    remediation = Column(Text)
    
    # References
    audit_id = Column(String, index=True)
    patient_id = Column(String, index=True)
    
    class Config:
        """Pydantic config"""
        arbitrary_types_allowed = True


# Database initialization
def init_db():
    """Create all tables"""
    Base.metadata.create_all(bind=engine)


def get_db():
    """Dependency for FastAPI to get database session"""
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()


# ============ DATABASE CLIENT ============

class DatabaseClient:
    """High-level database client for frontend"""
    
    def __init__(self):
        """Initialize database client"""
        init_db()
        self.SessionLocal = SessionLocal
    
    # ---- Audit Log ----
    
    def store_audit_log(self, audit_record: dict) -> str:
        """Store audit log entry"""
        db = self.SessionLocal()
        try:
            import uuid
            audit_id = str(uuid.uuid4())
            
            audit = AuditLog(
                id=audit_id,
                **audit_record
            )
            db.add(audit)
            db.commit()
            return audit_id
        finally:
            db.close()
    
    def get_audit_log(self, audit_id: str) -> dict:
        """Retrieve audit log entry"""
        db = self.SessionLocal()
        try:
            audit = db.query(AuditLog).filter(AuditLog.id == audit_id).first()
            return audit.__dict__ if audit else None
        finally:
            db.close()
    
    def get_audit_logs_by_user(self, user_id: str, limit: int = 100) -> list:
        """Get all audit logs for a user"""
        db = self.SessionLocal()
        try:
            audits = db.query(AuditLog).filter(
                AuditLog.user_id == user_id
            ).order_by(AuditLog.timestamp.desc()).limit(limit).all()
            return [a.__dict__ for a in audits]
        finally:
            db.close()
    
    def get_audit_logs_by_patient(self, patient_id: str, limit: int = 100) -> list:
        """Get all audit logs for a patient"""
        db = self.SessionLocal()
        try:
            audits = db.query(AuditLog).filter(
                AuditLog.patient_id == patient_id
            ).order_by(AuditLog.timestamp.desc()).limit(limit).all()
            return [a.__dict__ for a in audits]
        finally:
            db.close()
    
    # ---- Clinical Decisions ----
    
    def store_clinical_decision(self, decision_record: dict) -> str:
        """Store clinical decision"""
        db = self.SessionLocal()
        try:
            import uuid
            decision_id = str(uuid.uuid4())
            
            decision = ClinicalDecision(
                id=decision_id,
                **decision_record
            )
            db.add(decision)
            db.commit()
            return decision_id
        finally:
            db.close()
    
    def get_clinical_decisions_by_patient(self, patient_id: str, limit: int = 50) -> list:
        """Get all clinical decisions for a patient"""
        db = self.SessionLocal()
        try:
            decisions = db.query(ClinicalDecision).filter(
                ClinicalDecision.patient_id == patient_id
            ).order_by(ClinicalDecision.timestamp.desc()).limit(limit).all()
            return [d.__dict__ for d in decisions]
        finally:
            db.close()
    
    # ---- Patient EHR ----
    
    def get_or_create_patient_ehr(self, patient_id: str) -> dict:
        """Get or create patient EHR record"""
        db = self.SessionLocal()
        try:
            ehr = db.query(PatientEHR).filter(PatientEHR.patient_id == patient_id).first()
            if not ehr:
                ehr = PatientEHR(patient_id=patient_id)
                db.add(ehr)
                db.commit()
            return ehr.__dict__
        finally:
            db.close()
    
    def update_patient_ehr(self, patient_id: str, updates: dict) -> dict:
        """Update patient EHR record"""
        db = self.SessionLocal()
        try:
            ehr = db.query(PatientEHR).filter(PatientEHR.patient_id == patient_id).first()
            if ehr:
                for key, value in updates.items():
                    if hasattr(ehr, key):
                        setattr(ehr, key, value)
                ehr.last_updated = datetime.utcnow()
                db.commit()
            return ehr.__dict__ if ehr else None
        finally:
            db.close()
    
    # ---- Compliance Events ----
    
    def store_compliance_event(self, event_record: dict) -> str:
        """Store compliance event"""
        db = self.SessionLocal()
        try:
            import uuid
            event_id = str(uuid.uuid4())
            
            event = ComplianceEvent(
                id=event_id,
                **event_record
            )
            db.add(event)
            db.commit()
            return event_id
        finally:
            db.close()
    
    def get_compliance_violations(self, limit: int = 100) -> list:
        """Get all compliance violations"""
        db = self.SessionLocal()
        try:
            events = db.query(ComplianceEvent).filter(
                ComplianceEvent.event_type == "violation"
            ).order_by(ComplianceEvent.timestamp.desc()).limit(limit).all()
            return [e.__dict__ for e in events]
        finally:
            db.close()


# Create client
def create_db_client() -> DatabaseClient:
    """Create and return database client"""
    return DatabaseClient()
