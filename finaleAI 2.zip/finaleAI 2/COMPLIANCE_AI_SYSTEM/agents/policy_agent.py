from policy_generator import policy_tools


class PolicyAgent:
    def __init__(self):
        # load policies and build a simple keyword index for quick lookup
        self.policies = policy_tools.load_policies()
        self.index = policy_tools.build_keyword_index(self.policies)

    def get_ai_rules_by_scope(self, scope: str):
        """Return all rules across policies matching `ai_scope`."""
        out = []
        for fname, rules in self.policies.items():
            for r in rules:
                if r.get("ai_scope") == scope:
                    out.append(r)
        return out

    def find_rules_by_keywords(self, keywords):
        return policy_tools.find_rules_by_keywords(self.index, self.policies, keywords)

    def run(self, state):
        if state.user_role != "clinician":
            state.context["allow_sensitive_output"] = False
        else:
            state.context["allow_sensitive_output"] = True

        # attach a helper to state for downstream nodes to query AI rules
        state.context.setdefault("helpers", {})["policy_agent"] = self

        return state

