import hashlib
import hmac
import os
from datetime import datetime
from typing import Any, Dict

HMAC_SECRET_ENV = "AUDIT_HMAC_SECRET"


def _secret() -> bytes:
    key = os.getenv(HMAC_SECRET_ENV)
    if not key:
        raise RuntimeError(f"Missing audit HMAC secret in env: {HMAC_SECRET_ENV}")
    return key.encode()


def pseudonymize(value: str) -> str:
    digest = hmac.new(_secret(), value.encode(), hashlib.sha256).hexdigest()
    return f"hmac:{digest[:16]}"


def make_event(agent: str, action: str, details: Dict[str, Any]) -> Dict[str, Any]:
    base = {
        "agent": agent,
        "action": action,
        "timestamp": datetime.utcnow().isoformat(),
        "status": "COMPLETED",
    }
    # Ensure no raw PII in audit details
    safe_details = {}
    for k, v in (details or {}).items():
        if not isinstance(v, str):
            safe_details[k] = v
        else:
            # Best-effort: do not store potential PII directly
            if k in {"name", "email", "phone", "ssn"}:
                safe_details[k] = "[REDACTED]"
            else:
                safe_details[k] = v
    base.update(safe_details)
    return base
