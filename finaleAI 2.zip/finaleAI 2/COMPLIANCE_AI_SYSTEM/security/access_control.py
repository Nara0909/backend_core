from typing import Set
from config.config import ALLOW_LOG_VIEW_ROLES


def allowed_to_view_logs(role: str) -> bool:
    return role in ALLOW_LOG_VIEW_ROLES
