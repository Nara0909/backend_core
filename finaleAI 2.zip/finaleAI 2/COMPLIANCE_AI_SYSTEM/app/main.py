from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from datetime import datetime
from typing import List, Dict, Set, Optional
from pathlib import Path
import sys
from cryptography.fernet import Fernet
import os
import base64

# --------------------------------------------------
# Project path
# --------------------------------------------------
project_root = Path(__file__).resolve().parent.parent
if str(project_root) not in sys.path:
    sys.path.insert(0, str(project_root))

# --------------------------------------------------
# Imports
# --------------------------------------------------
from app.compliance_state import ComplianceStateManager
from app.api_models import (
    ProcessRequest,
    ProcessResponse,
    HealthResponse,
    AuditLogResponse,
    PolicyInfo,
    ComplianceStatusResponse,
    CheckAccessRequest,
    MaskPIIRequest,
    SanitizeOutputRequest,
    LogComplianceActionRequest,
)
from config.compliance_config import (
    compliance_config,
    load_config_from_file,
    update_allowed_roles,
    update_request_permissions,
    VALID_REQUEST_TYPES,
    validate_request_type,
)
from policy_generator.policy_graph.resolver import resolve_policies_from_graph
from security.pii import redact_and_detect

# --------------------------------------------------
# Encryption Key Management
# --------------------------------------------------
ENCRYPTION_KEY_ENV = "COMPLIANCE_ENCRYPTION_KEY"

def get_or_create_encryption_key() -> bytes:
    """Get encryption key from environment or create new one"""
    key_str = os.environ.get(ENCRYPTION_KEY_ENV)
    
    if key_str:
        try:
            return base64.urlsafe_b64decode(key_str)
        except Exception as e:
            print(f"⚠️ Invalid encryption key in environment, generating new one")
    
    # Generate new key
    key = Fernet.generate_key()
    print(f"🔑 Generated new encryption key")
    print(f"   Set environment variable: {ENCRYPTION_KEY_ENV}={key.decode()}")
    
    return key

# Global encryption cipher
ENCRYPTION_KEY = get_or_create_encryption_key()
cipher = Fernet(ENCRYPTION_KEY)

# --------------------------------------------------
# App init
# --------------------------------------------------
app = FastAPI(
    title="Compliance AI Backend",
    description="Healthcare Compliance Backend (Policy-driven tools with encryption)",
    version="2.0.0",
    docs_url="/api/docs",
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

compliance_manager = ComplianceStateManager()

# Load config on startup
@app.on_event("startup")
async def startup_event():
    """Load configuration on startup"""
    
    # Try multiple possible locations
    possible_paths = [
        project_root / "config" / "config.json",
        project_root / "config.json",
        Path(__file__).parent / "config.json",
    ]
    
    config_file = None
    for path in possible_paths:
        print(f"🔍 Checking: {path}")
        if path.exists():
            config_file = path
            print(f"✅ Found config at: {config_file}")
            break
    
    if config_file and config_file.exists():
        load_config_from_file(str(config_file))
    else:
        print("⚠️ No config.json found in any expected location, using default configuration")
        print(f"   Searched locations:")
        for path in possible_paths:
            print(f"   - {path}")
    
    print(f"\n📋 Configuration loaded:")
    print(f"   ✅ Allowed roles: {compliance_config.access_control.allowed_roles}")
    print(f"   ❌ Denied roles: {compliance_config.access_control.denied_roles}")
    print(f"   🔐 Encryption enabled: True")


# ==================================================
# ENCRYPTION/DECRYPTION HELPER FUNCTIONS
# ==================================================

def encrypt_data(data: str) -> str:
    """Encrypt string data and return base64 encoded string"""
    try:
        encrypted_bytes = cipher.encrypt(data.encode())
        return base64.urlsafe_b64encode(encrypted_bytes).decode()
    except Exception as e:
        print(f"❌ Encryption error: {e}")
        raise


def decrypt_data(encrypted_data: str) -> str:
    """Decrypt base64 encoded encrypted string"""
    try:
        encrypted_bytes = base64.urlsafe_b64decode(encrypted_data.encode())
        decrypted_bytes = cipher.decrypt(encrypted_bytes)
        return decrypted_bytes.decode()
    except Exception as e:
        print(f"❌ Decryption error: {e}")
        raise


# ==================================================
# TOOL IMPLEMENTATIONS WITH data_state SUPPORT
# ==================================================

def tool_check_access(state: dict, data_state: Optional[str] = None):
    """
    Check user access based on role and request type
    
    Args:
        state: Execution state dictionary
        data_state: Optional state indicator ('store', 'process_allowed', None)
    """
    user_role = state.get("user_role", "").lower().strip()
    request_type = state.get("request_type", "")
    
    print(f"🔒 [AccessControl] Checking access")
    print(f"   Role: {user_role}")
    print(f"   Request Type: {request_type}")
    print(f"   Data State: {data_state or 'default'}")
    
    # Use config-based access check
    allowed, reason = compliance_config.access_control.is_role_allowed(
        user_role=user_role,
        request_type=request_type
    )
    
    state["access_granted"] = allowed
    state["deny_reason"] = reason if not allowed else ""
    state["data_state"] = data_state  # Store for downstream tools
    
    if allowed:
        print(f"✅ [AccessControl] {reason}")
    else:
        print(f"❌ [AccessControl] {reason}")
    
    # Log to audit
    state["audit_log"].append({
        "agent": "AccessControlAgent",
        "action": "check_role_permissions",
        "result": "granted" if allowed else "denied",
        "user_role": user_role,
        "request_type": request_type,
        "data_state": data_state,
        "reason": reason,
        "timestamp": datetime.utcnow().isoformat(),
    })
    
    return state


def tool_mask_pii(state: dict, data_state: Optional[str] = None):
    """
    Detect and mask PII in input text
    
    Args:
        state: Execution state dictionary
        data_state: Optional state indicator
            - 'store': Mask PII for storage/logging
            - 'process_allowed': Mask PII for processing by authorized users
            - None: Default masking behavior
    """
    print(f"🔍 [PrivacyAgent] Masking PII")
    print(f"   Data State: {data_state or 'default'}")
    
    input_text = state.get("input_text", "")
    
    if not input_text:
        print(f"⚠️ [PrivacyAgent] No input text to mask")
        state["masked_input"] = ""
        state["pii_detected"] = []
        return state
    
    try:
        
        masked, pii = redact_and_detect(input_text)
        print('hellllo',masked, pii)
        state["masked_input"] = masked
        state["pii_detected"] = pii
        
        print(f"✅ [PrivacyAgent] Masked {len(pii)} PII entities")
        if len(pii) > 0:
            print(f"   Original: {input_text[:80]}...")
            print(f"   Masked:   {masked[:80]}...")
            print(f"   PII types: {[p.get('type', 'UNKNOWN') for p in pii]}")
        
    except Exception as e:
        print(f"❌ [PrivacyAgent] Error masking PII: {e}")
        state["masked_input"] = input_text
        state["pii_detected"] = []
    
    # Log to audit
    state["audit_log"].append({
        "agent": "PrivacyAgent",
        "action": "mask_phi",
        "pii_count": len(state["pii_detected"]),
        "pii_types": [p.get("type") for p in state["pii_detected"]],
        "data_state": data_state,
        "timestamp": datetime.utcnow().isoformat(),
    })
    
    return state


def tool_encrypt_pii(state: dict, data_state: Optional[str] = None):
    """
    Encrypt PII data based on data_state
    
    Args:
        state: Execution state dictionary
        data_state: State indicator
            - 'store': Encrypt and keep encrypted (for database storage)
            - 'process_allowed': Skip encryption (authorized processing)
            - None: Encrypt by default
    """
    print(f"🔐 [EncryptionAgent] Encrypting PII")
    print(f"   Data State: {data_state or 'default'}")
    
    # Get text to encrypt (prefer masked input if available)
    text_to_encrypt = state.get("masked_input") or state.get("input_text", "")
    
    if not text_to_encrypt:
        print(f"⚠️ [EncryptionAgent] No text to encrypt")
        state["encrypted_data"] = None
        return state
    
    # Decision based on data_state
    if data_state == "process_allowed":
        # Authorized processing - don't encrypt, keep plaintext
        print(f"✅ [EncryptionAgent] Process allowed - keeping plaintext for authorized processing")
        state["encrypted_data"] = None
        state["encryption_applied"] = False
        state["plaintext_preserved"] = True
        
    elif data_state == "store" or data_state is None:
        # Storage or default - encrypt the data
        try:
            encrypted = encrypt_data(text_to_encrypt)
            state["encrypted_data"] = encrypted
            state["encryption_applied"] = True
            state["plaintext_preserved"] = False
            
            # Store PII entities metadata separately (encrypted)
            if state.get("pii_detected"):
                pii_metadata = []
                for pii in state["pii_detected"]:
                    pii_metadata.append({
                        "type": pii.get("type"),
                        "encrypted_text": encrypt_data(pii.get("text", "")),
                        "start": pii.get("start"),
                        "end": pii.get("end")
                    })
                state["encrypted_pii_metadata"] = pii_metadata
            
            print(f"✅ [EncryptionAgent] Data encrypted for storage")
            print(f"   Original length: {len(text_to_encrypt)}")
            print(f"   Encrypted length: {len(encrypted)}")
            
        except Exception as e:
            print(f"❌ [EncryptionAgent] Encryption failed: {e}")
            state["encrypted_data"] = None
            state["encryption_applied"] = False
    
    # Log to audit
    state["audit_log"].append({
        "agent": "EncryptionAgent",
        "action": "encrypt_pii_at_rest",
        "data_state": data_state,
        "encryption_applied": state.get("encryption_applied", False),
        "plaintext_preserved": state.get("plaintext_preserved", False),
        "pii_count": len(state.get("pii_detected", [])),
        "timestamp": datetime.utcnow().isoformat(),
    })
    
    return state


def tool_decrypt_pii(state: dict, data_state: Optional[str] = None):
    """
    Decrypt PII data based on data_state and authorization
    
    Args:
        state: Execution state dictionary
        data_state: State indicator
            - 'process_allowed': Decrypt for authorized processing
            - 'store': Do not decrypt (keep encrypted)
            - None: Check authorization and decrypt if allowed
    """
    print(f"🔓 [DecryptionAgent] Decrypting PII")
    print(f"   Data State: {data_state or 'default'}")
    
    encrypted_data = state.get("encrypted_data")
    user_role = state.get("user_role", "").lower()
    
    if not encrypted_data:
        print(f"⚠️ [DecryptionAgent] No encrypted data to decrypt")
        state["decrypted_data"] = None
        return state
    
    # Decision based on data_state
    if data_state == "store":
        # Storage mode - never decrypt
        print(f"🔒 [DecryptionAgent] Store mode - keeping data encrypted")
        state["decrypted_data"] = None
        state["decryption_applied"] = False
        state["decryption_reason"] = "Storage mode - decryption not permitted"
        
    elif data_state == "process_allowed":
        # Authorized processing - decrypt
        authorized_roles = ["clinician", "admin"]
        
        if user_role in authorized_roles:
            try:
                decrypted = decrypt_data(encrypted_data)
                state["decrypted_data"] = decrypted
                state["decryption_applied"] = True
                state["decryption_reason"] = f"Authorized role ({user_role}) - decryption granted"
                
                # Decrypt PII metadata if present
                if state.get("encrypted_pii_metadata"):
                    decrypted_pii = []
                    for pii in state["encrypted_pii_metadata"]:
                        decrypted_pii.append({
                            "type": pii.get("type"),
                            "text": decrypt_data(pii.get("encrypted_text", "")),
                            "start": pii.get("start"),
                            "end": pii.get("end")
                        })
                    state["decrypted_pii_metadata"] = decrypted_pii
                
                print(f"✅ [DecryptionAgent] Data decrypted for authorized user")
                print(f"   Decrypted length: {len(decrypted)}")
                
            except Exception as e:
                print(f"❌ [DecryptionAgent] Decryption failed: {e}")
                state["decrypted_data"] = None
                state["decryption_applied"] = False
                state["decryption_reason"] = f"Decryption error: {str(e)}"
        else:
            print(f"❌ [DecryptionAgent] Unauthorized role: {user_role}")
            state["decrypted_data"] = None
            state["decryption_applied"] = False
            state["decryption_reason"] = f"Unauthorized role ({user_role}) - decryption denied"
    
    else:  # data_state is None
        # Default behavior - check authorization
        authorized_roles = ["clinician", "admin"]
        
        if user_role in authorized_roles and state.get("access_granted"):
            try:
                decrypted = decrypt_data(encrypted_data)
                state["decrypted_data"] = decrypted
                state["decryption_applied"] = True
                state["decryption_reason"] = f"Authorized access - decryption granted"
                
                print(f"✅ [DecryptionAgent] Data decrypted")
                
            except Exception as e:
                print(f"❌ [DecryptionAgent] Decryption failed: {e}")
                state["decrypted_data"] = None
                state["decryption_applied"] = False
        else:
            print(f"⚠️ [DecryptionAgent] Not authorized to decrypt")
            state["decrypted_data"] = None
            state["decryption_applied"] = False
            state["decryption_reason"] = "Not authorized"
    
    # Log to audit
    state["audit_log"].append({
        "agent": "DecryptionAgent",
        "action": "decrypt_pii_for_processing",
        "data_state": data_state,
        "decryption_applied": state.get("decryption_applied", False),
        "user_role": user_role,
        "reason": state.get("decryption_reason", ""),
        "timestamp": datetime.utcnow().isoformat(),
    })
    
    return state


def tool_sanitize_output(state: dict, data_state: Optional[str] = None):
    """
    Sanitize output text (remove any remaining PII)
    
    Args:
        state: Execution state dictionary
        data_state: Optional state indicator
    """
    print(f"🧹 [OutputGuardAgent] Sanitizing output")
    print(f"   Data State: {data_state or 'default'}")
    
    # Choose text to sanitize based on what's available
    if data_state == "process_allowed" and state.get("decrypted_data"):
        text_to_sanitize = state["decrypted_data"]
    else:
        text_to_sanitize = state.get("masked_input") or state.get("input_text", "")
    
    if not text_to_sanitize:
        print(f"⚠️ [OutputGuardAgent] No text to sanitize")
        state["final_output"] = ""
        return state
    
    try:
        sanitized, remaining_pii = redact_and_detect(text_to_sanitize)
        state["final_output"] = sanitized
        
        if remaining_pii:
            print(f"⚠️ [OutputGuardAgent] Found {len(remaining_pii)} additional PII entities")
            existing_texts = {p.get("text") for p in state.get("pii_detected", [])}
            for pii in remaining_pii:
                if pii.get("text") not in existing_texts:
                    state["pii_detected"].append(pii)
        else:
            print(f"✅ [OutputGuardAgent] Output is clean")
        
    except Exception as e:
        print(f"❌ [OutputGuardAgent] Error sanitizing: {e}")
        state["final_output"] = text_to_sanitize
    
    # Log to audit
    state["audit_log"].append({
        "agent": "OutputGuardAgent",
        "action": "sanitize_output",
        "additional_pii_found": len(remaining_pii) if remaining_pii else 0,
        "data_state": data_state,
        "timestamp": datetime.utcnow().isoformat(),
    })
    
    return state


def tool_log_audit(state: dict, data_state: Optional[str] = None):
    """
    Create final audit log entry
    
    Args:
        state: Execution state dictionary
        data_state: Optional state indicator
    """
    print(f"📝 [AuditAgent] Logging compliance action")
    print(f"   Data State: {data_state or 'default'}")
    
    state["audit_log"].append({
        "agent": "AuditAgent",
        "action": "record_policy_execution",
        "request_type": state.get("request_type"),
        "user_role": state.get("user_role"),
        "data_state": data_state,
        "access_granted": state.get("access_granted"),
        "encryption_applied": state.get("encryption_applied", False),
        "decryption_applied": state.get("decryption_applied", False),
        "pii_detected_count": len(state.get("pii_detected", [])),
        "regulations": state.get("regulations_applied", []),
        "timestamp": datetime.utcnow().isoformat(),
    })
    
    print(f"✅ [AuditAgent] Audit complete - {len(state['audit_log'])} entries")
    
    return state


# ==================================================
# ACTION → TOOL MAP WITH data_state SUPPORT
# ==================================================
ENCRYPTION_ACTIONS = {
    "encrypt_pii_at_rest",
    "encrypt_phi_at_rest",
    "encrypt_database_fields",
    "decrypt_pii_for_processing",
    "decrypt_phi_for_processing",
    "decrypt_for_authorized_user",
}


ACTION_TO_TOOL = {
    # Access Control
    "check_role_permissions": tool_check_access,
    "verify_data_access_rights": tool_check_access,
    
    # Privacy - Masking
    "mask_phi": tool_mask_pii,
    "mask_pii": tool_mask_pii,
    "detect_pii": tool_mask_pii,
    "anonymize_input": tool_mask_pii,
    
    # Privacy - Encryption
    "encrypt_pii_at_rest": tool_encrypt_pii,
    "encrypt_phi_at_rest": tool_encrypt_pii,
    "encrypt_database_fields": tool_encrypt_pii,
    
    # Privacy - Decryption
    "decrypt_pii_for_processing": tool_decrypt_pii,
    "decrypt_phi_for_processing": tool_decrypt_pii,
    "decrypt_for_authorized_user": tool_decrypt_pii,
    
    # Output Sanitization
    "redact_pii": tool_sanitize_output,
    "sanitize_public_output": tool_sanitize_output,
    
    # Audit
    "log_decision": tool_log_audit,
    "record_policy_path": tool_log_audit,
}


# ==================================================
# REQUEST TYPES ENDPOINT
# ==================================================

@app.get("/api/request-types", tags=["Configuration"])
async def get_request_types():
    """Get available request types with metadata"""
    return {
        "request_types": VALID_REQUEST_TYPES,
        "count": len(VALID_REQUEST_TYPES)
    }


@app.get("/api/request-types/{request_type}", tags=["Configuration"])
async def get_request_type_info(request_type: str):
    """Get detailed information about a specific request type"""
    from config.compliance_config import get_request_type_info
    
    info = get_request_type_info(request_type)
    if not info:
        raise HTTPException(404, f"Request type '{request_type}' not found")
    
    return {
        "request_type": request_type,
        "info": info
    }


# ==================================================
# HEALTH
# ==================================================

@app.get("/api/health", response_model=HealthResponse, tags=["System"])
async def health():
    """Health check endpoint"""
    return {
        "status": "healthy",
        "timestamp": datetime.utcnow().isoformat(),
        "compliance_enabled": compliance_manager.is_enabled(),
        "encryption_enabled": True,
        "version": "2.0.0",
    }


# ==================================================
# COMPLIANCE STATUS & TOGGLE
# ==================================================

@app.get("/api/compliance/status", response_model=ComplianceStatusResponse, tags=["Compliance"])
async def get_compliance_status():
    """Get current compliance enforcement status"""
    state = compliance_manager.get_state()
    return {
        "enabled": state["enabled"],
        "updated_at": state["updated_at"],
        "encryption_enabled": True,
        "enforced_regulations": ["GDPR", "HIPAA", "PCI-DSS", "AI Act"] if state["enabled"] else [],
        "active_agents": [
            "AccessControlAgent",
            "PrivacyAgent",
            "EncryptionAgent",
            "DecryptionAgent",
            "OutputGuardAgent",
            "AuditAgent"
        ] if state["enabled"] else []
    }


@app.post("/api/compliance/enable", tags=["Compliance"])
async def enable_compliance():
    """Enable compliance enforcement"""
    compliance_manager.enable()
    state = compliance_manager.get_state()
    return {
        "enabled": True,
        "updated_at": state["updated_at"],
        "message": "Compliance enforcement enabled",
        "enforced_regulations": ["GDPR", "HIPAA", "PCI-DSS", "AI Act"],
        "encryption_enabled": True,
    }


@app.post("/api/compliance/disable", tags=["Compliance"])
async def disable_compliance():
    """Disable compliance enforcement"""
    compliance_manager.disable()
    state = compliance_manager.get_state()
    return {
        "enabled": False,
        "updated_at": state["updated_at"],
        "message": "Compliance enforcement disabled",
        "enforced_regulations": [],
        "encryption_enabled": False,
    }


# ==================================================
# MAIN PROCESS ENDPOINT WITH data_state SUPPORT
# ==================================================

@app.post("/api/process", tags=["Processing"])
async def process_request(
    request: ProcessRequest,
    data_state: Optional[str] = None
):
    
    # --------------------------------------------------
# NO-OP when data_state is None
# --------------------------------------------------
    # if data_state is None:
    #     return {
    #         "success": True,
    #         "compliance_enabled": compliance_manager.is_enabled(),
    #         "compliance_applied": False,
    #         "access_granted": True,
    #         "original_input": request.input_text,
    #         "processed_output": "",
    #         "output_text": "",
    #         "masked_input": "",
    #         "pii_detected": [],
    #         "encrypted": False,
    #         "decrypted": False,
    #         "data_state": None,
    #         "audit_id": None,
    #         "audit_log": [],
    #         "policies_applied": [],
    #         "execution_path": [],
    #         "timestamp": datetime.utcnow().isoformat(),
    #         "message": "ℹdata_state=None → No processing performed",
    #     }

    """
    Core execution with encryption/decryption support:
    - Resolve policy graph
    - Execute tools sequentially with data_state parameter
    - Return fully processed result
    
    Args:
        request: Process request with input text, user role, request type
        data_state: Optional state indicator
            - 'store': Encrypt data for storage
            - 'process_allowed': Decrypt for authorized processing
            - None: Default behavior
    """
    print(f"\n{'='*60}")
    print(f"🚀 Processing request: {request.request_type}")
    print(f"   User: {request.user_role}")
    print(f"   Data State: {data_state or 'default'}")
    print(f"   Input: {request.input_text[:80]}...")
    print(f"{'='*60}\n")

    # ✅ VALIDATE REQUEST TYPE
    if not validate_request_type(request.request_type):
        raise HTTPException(
            400,
            f"Invalid request_type: '{request.request_type}'. "
            f"Valid types: {list(VALID_REQUEST_TYPES.keys())}"
        )

    if not compliance_manager.is_enabled():
        print("⚠️ Compliance DISABLED - bypassing checks")
        return {
            "success": True,
            "compliance_enabled": False,
            "compliance_applied": False,
            "original_input": request.input_text,
            "processed_output": request.input_text,
            "output_text": request.input_text,
            "masked_input": None,
            "pii_detected": [],
            "access_granted": True,
            "encrypted": False,
            "decrypted": False,
            "data_state": data_state,
            "audit_id": "N/A",
            "audit_log": [],
            "policies_applied": [],
            "execution_path": ["BYPASS"],
            "timestamp": datetime.utcnow().isoformat(),
            "message": "⚠️ Compliance DISABLED - request bypassed",
        }

    # Resolve policy graph
    print("📋 Resolving policy graph...")
    try:
        policy_result = resolve_policies_from_graph(request.request_type)
        actions = policy_result.get("actions", [])

        # --------------------------------------------------
        # 🔐 Skip encryption/decryption if data_state is None
        # --------------------------------------------------
        if not data_state:
            actions = [
                action for action in actions
                if action not in ENCRYPTION_ACTIONS
            ]


        regulations = policy_result.get("regulations", [])
        
        print(f"✅ Policy resolved:")
        print(f"   Regulations: {regulations}")
        print(f"   Actions: {actions}\n")
    except Exception as e:
        print(f"❌ Policy resolution failed: {e}")
        raise HTTPException(500, f"Policy resolution failed: {str(e)}")

    # Execution state
    state = {
        "input_text": request.input_text,
        "user_role": request.user_role or "clinician",
        "request_type": request.request_type,
        "data_state": data_state,
        "access_granted": True,
        "masked_input": "",
        "encrypted_data": None,
        "decrypted_data": None,
        "final_output": "",
        "pii_detected": [],
        "audit_log": [],
        "deny_reason": "",
        "regulations_applied": regulations,
        "encryption_applied": False,
        "decryption_applied": False,
    }

    # Execute tools sequentially with data_state
    print(f"🔧 Executing {len(actions)} actions...\n")
    
    executed_actions = []
    
    for i, action in enumerate(actions, 1):
        tool = ACTION_TO_TOOL.get(action)
        
        if not tool:
            print(f"⚠️ [{i}/{len(actions)}] No tool found for action: {action}")
            continue
        
        print(f"[{i}/{len(actions)}] Executing: {action}")
        
        try:
            # Pass data_state to tool
            state = tool(state, data_state=data_state)
            executed_actions.append(action)
            
            # CHECK FOR ACCESS DENIAL
            if state.get("access_granted") is False:
                print(f"\n❌ ACCESS DENIED - Stopping execution")
                print(f"   Reason: {state.get('deny_reason')}\n")
                
                # Save audit logs for denied access
                compliance_manager.add_request_audit(state["audit_log"])
                
                return {
                    "success": False,
                    "compliance_enabled": True,
                    "compliance_applied": True,
                    "access_granted": False,
                    "original_input": request.input_text,
                    "processed_output": "",
                    "output_text": "",
                    "masked_input": "",
                    "pii_detected": [],
                    "encrypted": False,
                    "decrypted": False,
                    "data_state": data_state,
                    "audit_id": f"AUDIT-{datetime.utcnow().strftime('%Y%m%d-%H%M%S')}",
                    "audit_log": state["audit_log"],
                    "policies_applied": [p.get("rule_id", "") for p in policy_result.get("policies", [])],
                    "execution_path": executed_actions,
                    "timestamp": datetime.utcnow().isoformat(),
                    "message": state.get("deny_reason", "Access denied"),
                }
        
        except Exception as e:
            print(f"❌ [{i}/{len(actions)}] Tool execution failed: {e}")
            import traceback
            traceback.print_exc()
            continue
    
    print(f"\n✅ All tools executed successfully\n")

    # Always audit at the end
    if "log_decision" not in executed_actions and "record_policy_path" not in executed_actions:
        print("📝 Running final audit log...")
        state = tool_log_audit(state, data_state=data_state)
        executed_actions.append("log_decision")

    # Determine final output based on data_state
    if data_state == "process_allowed" and state.get("decrypted_data"):
        final_output = state["decrypted_data"]
    elif state.get("final_output"):
        final_output = state["final_output"]
    elif state.get("encrypted_data"):
        final_output = "[ENCRYPTED DATA - Authorization required for decryption]"
    else:
        final_output = state.get("masked_input", "")

    # Success response
    print(f"{'='*60}")
    print(f"✅ REQUEST COMPLETED SUCCESSFULLY")
    print(f"   Data State: {data_state or 'default'}")
    print(f"   PII Detected: {len(state['pii_detected'])}")
    print(f"   Encrypted: {state.get('encryption_applied', False)}")
    print(f"   Decrypted: {state.get('decryption_applied', False)}")
    print(f"   Audit Entries: {len(state['audit_log'])}")
    print(f"{'='*60}\n")
    
    execution_path = list(dict.fromkeys([log["agent"] for log in state["audit_log"]]))
    
    # Save audit logs to manager
    compliance_manager.add_request_audit(state["audit_log"])
    
    return {
        "success": True,
        "compliance_enabled": True,
        "compliance_applied": True,
        "access_granted": True,
        "original_input": request.input_text,
        "masked_input": state["masked_input"],
        "encrypted_data": state.get("encrypted_data"),
        "decrypted_data": state.get("decrypted_data") if data_state == "process_allowed" else None,
        "processed_output": final_output,
        "output_text": final_output,
        "pii_detected": state["pii_detected"],
        "encrypted": state.get("encryption_applied", False),
        "decrypted": state.get("decryption_applied", False),
        "data_state": data_state,
        "audit_id": f"AUDIT-{datetime.utcnow().strftime('%Y%m%d-%H%M%S')}",
        "audit_log": state["audit_log"],
        "policies_applied": [p.get("rule_id", "") for p in policy_result.get("policies", [])],
        "execution_path": execution_path,
        "regulatory_compliance": {
            "regulations_applied": regulations,
            "agents_executed": execution_path,
            "actions_performed": executed_actions,
            "encryption_summary": {
                "encryption_applied": state.get("encryption_applied", False),
                "decryption_applied": state.get("decryption_applied", False),
                "data_state": data_state,
            }
        },
        "timestamp": datetime.utcnow().isoformat(),
        "message": "✅ Request processed with encryption/decryption support",
    }


# ==================================================
# AUDIT & LOGGING ENDPOINTS
# ==================================================

@app.get("/api/audit/logs", response_model=AuditLogResponse, tags=["Audit"])
async def get_audit_logs(
    limit: int = 100,
    agent_filter: Optional[str] = None
):
    """Retrieve audit logs from recent requests"""
    logs = compliance_manager.get_audit_logs(limit=limit, agent_filter=agent_filter)
    
    return {
        "total_logs": len(logs),
        "logs": logs,
        "compliance_enabled": compliance_manager.is_enabled(),
        "timestamp": datetime.utcnow().isoformat()
    }


# ==================================================
# INDIVIDUAL COMPLIANCE TOOLS
# ==================================================

@app.post("/api/check-access", tags=["Compliance Tools"])
async def check_access(request: CheckAccessRequest):
    """Check user access based on role"""
    user_role = request.user_role or "clinician"
    request_type = request.request_type or "patient_triage"
    
    state = {
        "user_role": user_role,
        "request_type": request_type,
        "access_granted": True,
        "deny_reason": "",
        "audit_log": [],
    }
    
    state = tool_check_access(state)
    
    return {
        "success": True,
        "access_granted": state["access_granted"],
        "user_role": state["user_role"],
        "request_type": request_type,
        "deny_reason": state.get("deny_reason", ""),
        "message": "Access granted" if state["access_granted"] else state.get("deny_reason"),
        "regulations": ["HIPAA", "GDPR"],
        "audit_log": state.get("audit_log", []),
    }


@app.post("/api/mask-pii", tags=["Compliance Tools"])
async def mask_pii(request: MaskPIIRequest):
    """Detect and mask PII in input text"""
    text = request.input_text or request.text or ""
    
    if not text:
        raise HTTPException(400, "No text provided")
    
    try:
        masked, pii_list = redact_and_detect(text)
        
        return {
            "success": True,
            "original_text": text,
            "masked_text": masked,
            "pii_detected": pii_list,
            "pii_count": len(pii_list),
            "message": f"Detected and masked {len(pii_list)} PII entities",
        }
    except Exception as e:
        raise HTTPException(500, f"PII masking failed: {str(e)}")


# ==================================================
# ROOT
# ==================================================

@app.get("/", tags=["System"])
async def root():
    """API root endpoint"""
    return {
        "message": "Compliance AI Backend with Encryption",
        "version": "2.0.0",
        "docs": "/api/docs",
        "compliance_enabled": compliance_manager.is_enabled(),
        "encryption_enabled": True,
        "endpoints": {
            "health": "/api/health",
            "compliance_status": "/api/compliance/status",
            "process": "/api/process?data_state=store|process_allowed",
            "check_access": "/api/check-access",
            "mask_pii": "/api/mask-pii",
            "audit_logs": "/api/audit/logs",
        }
    }


# ==================================================
# RUN
# ==================================================

if __name__ == "__main__":
    import uvicorn
    
    print("🚀 Starting Compliance AI Backend with Encryption...")
    print("📝 API Documentation: http://localhost:8000/api/docs")
    print(f"🔒 Compliance Status: {'ENABLED' if compliance_manager.is_enabled() else 'DISABLED'}")
    print(f"🔐 Encryption: ENABLED")
    
    uvicorn.run(
        "main:app",
        host="0.0.0.0",
        port=8000,
        reload=True,
        log_level="info"
    )