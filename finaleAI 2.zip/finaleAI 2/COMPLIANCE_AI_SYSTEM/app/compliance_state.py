"""
Compliance State Manager

Manages the enable/disable state of compliance enforcement.
Provides persistent storage for compliance configuration.
"""

import json
from pathlib import Path
from datetime import datetime
from typing import Dict, List, Any
from threading import Lock


class ComplianceStateManager:
    """
    Singleton manager for compliance on/off state.
    
    Stores state in a JSON file for persistence across restarts.
    Thread-safe for concurrent API requests.
    """
    
    _instance = None
    _lock = Lock()
    
    def __new__(cls):
        if cls._instance is None:
            with cls._lock:
                if cls._instance is None:
                    cls._instance = super().__new__(cls)
                    cls._instance._initialized = False
        return cls._instance
    
    def __init__(self):
        if self._initialized:
            return
            
        self.state_file = Path(__file__).parent / "compliance_state.json"
        self.audit_logs = []  # In-memory audit logs (in production, use database)
        self.max_logs = 1000  # Keep last 1000 logs in memory
        
        # Load or initialize state
        self._load_state()
        self._initialized = True
    
    def _load_state(self):
        """Load compliance state from file, or create default."""
        if self.state_file.exists():
            with open(self.state_file, "r") as f:
                self.state = json.load(f)
        else:
            # Default: compliance ENABLED for safety
            self.state = {
                "enabled": True,
                "updated_at": datetime.utcnow().isoformat(),
                "regulations": ["GDPR", "HIPAA", "PCI-DSS", "AI Act"],
                "active_agents": [
                    "AccessControlAgent",
                    "PrivacyAgent",
                    "OutputGuardAgent",
                    "AuditAgent",
                    "EncryptionAgent",
                    "RetentionAgent"
                ]
            }
            self._save_state()
    
    def _save_state(self):
        """Persist compliance state to file."""
        try:
            with open(self.state_file, "w") as f:
                json.dump(self.state, f, indent=2)
        except Exception as e:
            print(f"Warning: Could not save state: {e}")
    
    def is_enabled(self) -> bool:
        """Check if compliance enforcement is currently enabled."""
        return self.state.get("enabled", True)
    
    def enable(self):
        """Enable compliance enforcement."""
        with self._lock:
            self.state["enabled"] = True
            self.state["updated_at"] = datetime.utcnow().isoformat()
            self._save_state()
            
            # Log the change
            self._add_audit_log({
                "agent": "ComplianceManager",
                "action": "enable_compliance",
                "timestamp": datetime.utcnow().isoformat(),
                "status": "COMPLETED"
            })
    
    def disable(self):
        """Disable compliance enforcement (BYPASS MODE)."""
        with self._lock:
            self.state["enabled"] = False
            self.state["updated_at"] = datetime.utcnow().isoformat()
            self._save_state()
            
            # Log the change
            self._add_audit_log({
                "agent": "ComplianceManager",
                "action": "disable_compliance",
                "timestamp": datetime.utcnow().isoformat(),
                "status": "COMPLETED",
                "warning": "⚠️ Compliance disabled - requests will bypass all privacy controls"
            })
    
    def get_state(self) -> Dict[str, Any]:
        """Get current compliance state."""
        return self.state.copy()
    
    def _add_audit_log(self, log_entry: Dict[str, Any]):
        """Add an audit log entry (in-memory for demo)."""
        self.audit_logs.append(log_entry)
        
        # Keep only the most recent logs
        if len(self.audit_logs) > self.max_logs:
            self.audit_logs = self.audit_logs[-self.max_logs:]
    
    def get_audit_logs(self, limit: int = 100, agent_filter: str = None) -> List[Dict[str, Any]]:
        """Retrieve audit logs with optional filtering."""
        logs = self.audit_logs[-limit:]
        
        if agent_filter:
            logs = [log for log in logs if log.get("agent") == agent_filter]
        
        return logs
    
    def add_request_audit(self, audit_log: List[Dict[str, Any]]):
        """Add audit logs from a processed request."""
        for log_entry in audit_log:
            self._add_audit_log(log_entry)
