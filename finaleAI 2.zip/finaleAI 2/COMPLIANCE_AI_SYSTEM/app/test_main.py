import requests
import json

BASE_URL = "http://localhost:8000"

def pretty(response):
    print(json.dumps(response.json(), indent=2))

# ==================================================
# TEST 1: Check current config
# ==================================================
print("\n🧪 TEST 1: Check current role configuration")
resp = requests.get(f"{BASE_URL}/api/config/roles")
pretty(resp)

# ==================================================
# TEST 2: Test visitor (should be denied)
# ==================================================
print("\n🧪 TEST 2: Visitor access (should be DENIED)")
resp = requests.post(
    f"{BASE_URL}/api/config/check-role",
    params={"user_role": "visitor", "request_type": "patient_lookup"}
)
pretty(resp)

# ==================================================
# TEST 3: Test receptionist for patient_lookup (should be denied)
# ==================================================
print("\n🧪 TEST 3: Receptionist for patient_lookup (should be DENIED)")
resp = requests.post(
    f"{BASE_URL}/api/config/check-role",
    params={"user_role": "receptionist", "request_type": "patient_lookup"}
)
pretty(resp)

# ==================================================
# TEST 4: Test receptionist for appointment_scheduling (should be allowed)
# ==================================================
print("\n🧪 TEST 4: Receptionist for appointment_scheduling (should be ALLOWED)")
resp = requests.post(
    f"{BASE_URL}/api/config/check-role",
    params={"user_role": "receptionist", "request_type": "appointment_scheduling"}
)
pretty(resp)

# ==================================================
# TEST 5: Update permissions dynamically
# ==================================================
print("\n🧪 TEST 5: Add 'receptionist' to patient_lookup permissions")
resp = requests.post(
    f"{BASE_URL}/api/config/permissions/patient_lookup",
    json=["admin", "clinician", "doctor", "nurse", "receptionist"]
)
pretty(resp)

# ==================================================
# TEST 6: Retest receptionist for patient_lookup (now should be allowed)
# ==================================================
print("\n🧪 TEST 6: Receptionist for patient_lookup (now should be ALLOWED)")
resp = requests.post(
    f"{BASE_URL}/api/config/check-role",
    params={"user_role": "receptionist", "request_type": "patient_lookup"}
)
pretty(resp)

# ==================================================
# TEST 7: Actual request processing
# ==================================================
print("\n🧪 TEST 7: Process request with visitor (DENIED)")
resp = requests.post(
    f"{BASE_URL}/api/process",
    json={
        "input_text": "Show medical history of patient John Doe",
        "request_type": "patient_lookup",
        "user_role": "visitor"
    }
)
pretty(resp)

print("\n🧪 TEST 8: Process request with doctor (ALLOWED)")
resp = requests.post(
    f"{BASE_URL}/api/process",
    json={
        "input_text": "Patient John Doe (SSN: 123-45-6789) has diabetes",
        "request_type": "patient_lookup",
        "user_role": "doctor"
    }
)
pretty(resp)