from security.pii import redact_text


def redact_phi(text: str) -> str:
    """Final output guard to prevent PHI/PII leakage.

    Applies the same centralized redaction used at ingress.
    """
    return redact_text(text)
