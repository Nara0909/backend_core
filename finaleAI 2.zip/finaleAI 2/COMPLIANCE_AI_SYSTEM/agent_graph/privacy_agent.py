from security.pii import redact_and_detect


def mask_phi(text: str):
    """De-identify input text by redacting PHI/PII.

    Deterministic, regex-based, HIPAA-friendly baseline. Extend with NLP if needed.
    
    Returns:
        Tuple of (redacted_text, pii_detected_list)
    """
    return redact_and_detect(text)
