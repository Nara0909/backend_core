import truststore
truststore.inject_into_ssl()
## Test Suite
# test_pure_nlp_classifier.py
from agent_graph.classifier.pure_clinical_nlp_classifier import PureClinicalNLPClassifier

def test_pure_nlp():
    print("Testing Pure Clinical NLP Classifier")
    print("No regex patterns")
    print("No LLM/SLM")
    print("Only spaCy/scispaCy/medspaCy + Embeddings\n")
    
    classifier = PureClinicalNLPClassifier()
    
    test_cases = [
        {
            "name": "Triage with Clinical Entities",
            "text": """
            Patient John Doe presenting with acute chest pain radiating to left arm.
            Vital signs: BP 180/110, HR 120, RR 24, Temp 98.6F, O2 Sat 92%.
            Patient reports shortness of breath and dizziness.
            History of diabetes and hypertension.
            Emergency contact: Jane Doe
            """
        },
        {
            "name": "Triage with Negation",
            "text": "Patient denies chest pain but reports mild fatigue. No fever. No shortness of breath."
        },
        {
            "name": "Clinical Decision Support",
            "text": """
            Recommend treatment for newly diagnosed Type 2 diabetes.
            Consider metformin as first-line therapy.
            Check for contraindications and drug interactions.
            Patient has mild renal impairment (GFR 55).
            """
        },
        {
            "name": "Billing and Claims",
            "text": """
            Submit insurance claim for office visit.
            CPT code 99214 for established patient visit level 4.
            ICD-10 code E11.9 for Type 2 diabetes without complications.
            Patient copay $30, insurance coverage verified.
            """
        },
    ]
    
    for i, test in enumerate(test_cases, 1):
        print(f"\n{'='*70}")
        print(f"Test {i}: {test['name']}")
        print(f"{'='*70}")
        print(f"Input: {test['text'][:80]}...")
        
        result = classifier.classify(test['text'])
        
        print(f"\nClassification: {result.request_type}")
        print(f"Confidence: {result.confidence:.3f}")
        
        print(f"\n Entities Detected:")
        for ent in result.entities[:10]:
            markers = []
            if ent.get('is_phi'):
                markers.append("PHI")
            if ent['is_negated']:
                markers.append("NEGATED")
            if ent['is_uncertain']:
                markers.append("UNCERTAIN")
            
            marker_str = f" [{', '.join(markers)}]" if markers else ""
            print(f"  - {ent['text']} ({ent['label']}){marker_str}")
        
        print(f"\n Scoring Breakdown:")
        print(f"  NER Scores: {result.scoring_breakdown['ner_scores']}")
        print(f"  Semantic Scores: {result.scoring_breakdown['semantic_scores']}")
        print(f"  Combined: {result.scoring_breakdown['combined_scores']}")
        
        if result.clinical_context['is_phi']:
            print(f"\n PHI Detected: {result.clinical_context['phi_count']} entities")
        
        if result.clinical_context['sections_detected']:
            print(f"\n Clinical Sections: {result.clinical_context['sections_detected']}")

if __name__ == "__main__":
    test_pure_nlp()

## Key Features

#  **100% NLP-based** - No regex patterns at all  
# **No LLM/SLM** - Only embeddings for similarity  
# **Clinical context** - Handles negation, uncertainty, historical context  
# **PHI detection** - Via NER (PERSON, DATE entities)  
# **Section-aware** - Detects clinical document sections  
# **Explainable** - Every entity has a clear source   **HIPAA-compliant** - All processing is deterministic and auditable

# This is pure clinical NLP at its best! 