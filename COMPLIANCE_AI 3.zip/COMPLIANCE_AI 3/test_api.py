"""
Test Script for Compliance AI Backend

Tests all major endpoints to verify the system is working correctly.
"""

import requests
import json
from time import sleep

BASE_URL = "http://localhost:8000/api"

def test_health():
    """Test health endpoint"""
    print("\n🏥 Testing Health Endpoint...")
    response = requests.get(f"{BASE_URL}/health")
    print(f"Status: {response.status_code}")
    print(f"Response: {json.dumps(response.json(), indent=2)}")
    return response.status_code == 200

def test_compliance_status():
    """Test compliance status endpoint"""
    print("\n🔍 Testing Compliance Status...")
    response = requests.get(f"{BASE_URL}/compliance/status")
    print(f"Status: {response.status_code}")
    data = response.json()
    print(f"Compliance Enabled: {data.get('enabled')}")
    print(f"Regulations: {data.get('enforced_regulations')}")
    return response.status_code == 200

def test_enable_compliance():
    """Test enabling compliance"""
    print("\n✅ Testing Enable Compliance...")
    response = requests.post(f"{BASE_URL}/compliance/enable")
    print(f"Status: {response.status_code}")
    data = response.json()
    print(f"Compliance Enabled: {data.get('enabled')}")
    return response.status_code == 200 and data.get('enabled') == True

def test_disable_compliance():
    """Test disabling compliance"""
    print("\n❌ Testing Disable Compliance...")
    response = requests.post(f"{BASE_URL}/compliance/disable")
    print(f"Status: {response.status_code}")
    data = response.json()
    print(f"Compliance Enabled: {data.get('enabled')}")
    return response.status_code == 200 and data.get('enabled') == False

def test_process_with_compliance():
    """Test processing with compliance enabled"""
    print("\n🔒 Testing Processing WITH Compliance...")
    
    # First enable compliance
    requests.post(f"{BASE_URL}/compliance/enable")
    sleep(0.5)
    
    # Process request
    payload = {
        "input_text": "Patient John Doe (SSN: 123-45-6789, Email: john@email.com) reports chest pain",
        "request_type": "patient_triage",
        "user_role": "clinician",
        "regulations": ["HIPAA", "GDPR"]
    }
    
    response = requests.post(f"{BASE_URL}/process", json=payload)
    print(f"Status: {response.status_code}")
    
    if response.status_code == 200:
        data = response.json()
        print(f"✅ Success: {data.get('success')}")
        print(f"🔒 Compliance Enabled: {data.get('compliance_enabled')}")
        print(f"📝 Original: {data.get('original_input')[:50]}...")
        print(f"🔐 Masked: {data.get('masked_input', 'N/A')[:50]}...")
        print(f"📤 Output: {data.get('processed_output')[:50]}...")
        print(f"📊 Execution Path: {data.get('execution_path', [])}")
        print(f"📋 Audit Logs: {len(data.get('audit_log', []))} entries")
        return True
    return False

def test_process_without_compliance():
    """Test processing with compliance disabled"""
    print("\n⚠️  Testing Processing WITHOUT Compliance (Bypass Mode)...")
    
    # First disable compliance
    requests.post(f"{BASE_URL}/compliance/disable")
    sleep(0.5)
    
    # Process request
    payload = {
        "input_text": "Patient John Doe (SSN: 123-45-6789, Email: john@email.com) reports chest pain",
        "request_type": "patient_triage",
        "user_role": "clinician"
    }
    
    response = requests.post(f"{BASE_URL}/process", json=payload)
    print(f"Status: {response.status_code}")
    
    if response.status_code == 200:
        data = response.json()
        print(f"✅ Success: {data.get('success')}")
        print(f"⚠️  Compliance Enabled: {data.get('compliance_enabled')}")
        print(f"📝 Original: {data.get('original_input')[:50]}...")
        print(f"📤 Output: {data.get('processed_output')[:80]}...")
        print(f"📊 Execution Path: {data.get('execution_path', [])}")
        print(f"📋 Audit Logs: {len(data.get('audit_log', []))} entries")
        return True
    return False

def test_policies():
    """Test policies endpoint"""
    print("\n📜 Testing Policies Endpoint...")
    response = requests.get(f"{BASE_URL}/policies")
    print(f"Status: {response.status_code}")
    
    if response.status_code == 200:
        policies = response.json()
        print(f"Found {len(policies)} policies:")
        for policy in policies[:3]:
            print(f"  - {policy.get('name')}")
        return True
    return False

def test_request_types():
    """Test request types endpoint"""
    print("\n📋 Testing Request Types Endpoint...")
    response = requests.get(f"{BASE_URL}/request-types")
    print(f"Status: {response.status_code}")
    
    if response.status_code == 200:
        data = response.json()
        print(f"Available request types: {data.get('request_types', [])}")
        return True
    return False

def run_all_tests():
    """Run all tests"""
    print("=" * 60)
    print("🧪 COMPLIANCE AI BACKEND TEST SUITE")
    print("=" * 60)
    
    tests = [
        ("Health Check", test_health),
        ("Compliance Status", test_compliance_status),
        ("Enable Compliance", test_enable_compliance),
        ("Disable Compliance", test_disable_compliance),
        ("Process WITH Compliance", test_process_with_compliance),
        ("Process WITHOUT Compliance", test_process_without_compliance),
        ("List Policies", test_policies),
        ("Request Types", test_request_types),
    ]
    
    results = []
    for name, test_func in tests:
        try:
            result = test_func()
            results.append((name, result))
        except Exception as e:
            print(f"❌ Error in {name}: {str(e)}")
            results.append((name, False))
        sleep(0.5)
    
    # Summary
    print("\n" + "=" * 60)
    print("📊 TEST SUMMARY")
    print("=" * 60)
    
    passed = sum(1 for _, result in results if result)
    total = len(results)
    
    for name, result in results:
        status = "✅ PASS" if result else "❌ FAIL"
        print(f"{status} - {name}")
    
    print(f"\n🎯 Results: {passed}/{total} tests passed")
    
    if passed == total:
        print("🎉 All tests passed!")
    else:
        print(f"⚠️  {total - passed} test(s) failed")
    
    print("=" * 60)

if __name__ == "__main__":
    print("\n⏳ Waiting for backend to start...")
    print("Make sure backend is running: ./start_backend.sh\n")
    
    try:
        run_all_tests()
    except requests.exceptions.ConnectionError:
        print("\n❌ ERROR: Cannot connect to backend!")
        print("Please start the backend first: ./start_backend.sh")
    except KeyboardInterrupt:
        print("\n\n⚠️  Tests interrupted by user")
