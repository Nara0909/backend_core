#!/usr/bin/env python3
"""
Test Regulatory Compliance Flow

This script demonstrates the complete regulatory compliance workflow:
1. Text input flows through enforcement plan
2. Regulations are mapped to agents (HIPAA, GDPR, PCI-DSS, etc.)
3. Agents execute based on policy traces
4. Response includes full regulatory compliance trace
"""

import requests
import json
from rich.console import Console
from rich.panel import Panel
from rich.table import Table
from rich import box

console = Console()

API_BASE_URL = "http://127.0.0.1:8000/api"


def test_regulatory_flow():
    """Test complete regulatory compliance flow"""
    
    console.print("\n[bold cyan]═══════════════════════════════════════════════════════════[/bold cyan]")
    console.print("[bold cyan]        🛡️  REGULATORY COMPLIANCE FLOW TEST[/bold cyan]")
    console.print("[bold cyan]═══════════════════════════════════════════════════════════[/bold cyan]\n")
    
    # Test data with PII
    test_input = "Patient John Doe (SSN: 123-45-6789, DOB: 1985-03-15) reports severe chest pain. Contact: john.doe@email.com, Phone: 555-123-4567. Previous cardiac history documented."
    
    console.print(Panel(
        test_input,
        title="[bold green]📥 Original Input Text[/bold green]",
        border_style="green"
    ))
    
    # Step 1: Check compliance status
    console.print("\n[bold yellow]STEP 1:[/bold yellow] Checking compliance status...")
    status_response = requests.get(f"{API_BASE_URL}/compliance/status")
    status = status_response.json()
    console.print(f"  ✓ Compliance Enabled: [bold]{'✅ YES' if status['enabled'] else '❌ NO'}[/bold]")
    console.print(f"  ✓ Active Regulations: [bold]{', '.join(status['enforced_regulations'])}[/bold]")
    
    # Step 2: Process request through enforcement plan
    console.print("\n[bold yellow]STEP 2:[/bold yellow] Processing through enforcement plan...")
    
    payload = {
        "input_text": test_input,
        "request_type": "clinical_query",
        "user_role": "clinician"
    }
    
    process_response = requests.post(
        f"{API_BASE_URL}/process",
        json=payload,
        timeout=30
    )
    result = process_response.json()
    
    # Step 3: Display enforcement plan execution
    console.print("\n[bold yellow]STEP 3:[/bold yellow] Enforcement Plan Execution")
    
    regulatory = result.get("regulatory_compliance", {})
    
    # Display regulations applied
    console.print("\n[bold cyan]📋 Regulations Applied:[/bold cyan]")
    for reg in regulatory.get("regulations_applied", []):
        console.print(f"  • {reg}")
    
    # Display agent execution path
    console.print("\n[bold cyan]🔄 Agent Execution Path:[/bold cyan]")
    execution_table = Table(show_header=True, header_style="bold magenta", box=box.ROUNDED)
    execution_table.add_column("Step", style="dim", width=6)
    execution_table.add_column("Agent", style="cyan")
    execution_table.add_column("Status", justify="center")
    
    for idx, agent in enumerate(regulatory.get("agents_executed", []), 1):
        execution_table.add_row(
            str(idx),
            agent,
            "✅"
        )
    
    console.print(execution_table)
    
    # Display policy trace map
    console.print("\n[bold cyan]🗺️  Policy Trace Map (Agent → Regulations):[/bold cyan]")
    trace_table = Table(show_header=True, header_style="bold green", box=box.ROUNDED)
    trace_table.add_column("Agent", style="yellow", width=25)
    trace_table.add_column("Policy Traces", style="white")
    
    policy_trace_map = regulatory.get("policy_trace_map", {})
    for agent, policies in policy_trace_map.items():
        trace_table.add_row(
            agent,
            "\n".join(policies) if policies else "N/A"
        )
    
    console.print(trace_table)
    
    # Step 4: Display PII Detection
    console.print("\n[bold yellow]STEP 4:[/bold yellow] PII Detection Results")
    
    pii_detected = result.get("pii_detected", [])
    if pii_detected:
        pii_table = Table(show_header=True, header_style="bold red", box=box.ROUNDED)
        pii_table.add_column("Type", style="red")
        pii_table.add_column("Value", style="yellow")
        pii_table.add_column("Masked As", style="green")
        
        for pii in pii_detected:
            pii_table.add_row(
                pii.get("type", "Unknown"),
                pii.get("value", "N/A"),
                pii.get("masked", "[REDACTED]")
            )
        
        console.print(pii_table)
        console.print(f"\n  [bold red]⚠️  Total PII Entities Detected: {len(pii_detected)}[/bold red]")
    else:
        console.print("  [green]✅ No PII detected[/green]")
    
    # Step 5: Output comparison
    console.print("\n[bold yellow]STEP 5:[/bold yellow] Input/Output Comparison")
    
    console.print(Panel(
        result.get("masked_input", "N/A"),
        title="[bold blue]🔒 Masked Input (Privacy-Protected)[/bold blue]",
        border_style="blue"
    ))
    
    console.print(Panel(
        result.get("processed_output", "N/A"),
        title="[bold green]📤 Final Output[/bold green]",
        border_style="green"
    ))
    
    # Step 6: Audit trail
    console.print("\n[bold yellow]STEP 6:[/bold yellow] Audit Trail")
    console.print(f"  ✓ Audit ID: [bold]{result.get('audit_id')}[/bold]")
    console.print(f"  ✓ Timestamp: [bold]{result.get('timestamp')}[/bold]")
    console.print(f"  ✓ Audit Log Entries: [bold]{len(result.get('audit_log', []))}[/bold]")
    
    # Display audit log
    audit_table = Table(show_header=True, header_style="bold cyan", box=box.ROUNDED)
    audit_table.add_column("Agent", style="cyan")
    audit_table.add_column("Action", style="white")
    audit_table.add_column("Timestamp", style="dim")
    
    for log_entry in result.get("audit_log", []):
        audit_table.add_row(
            log_entry.get("agent", "Unknown"),
            log_entry.get("action", "N/A"),
            log_entry.get("timestamp", "N/A")
        )
    
    console.print(audit_table)
    
    # Summary
    console.print("\n[bold green]═══════════════════════════════════════════════════════════[/bold green]")
    console.print("[bold green]                     ✅ TEST COMPLETE[/bold green]")
    console.print("[bold green]═══════════════════════════════════════════════════════════[/bold green]\n")
    
    console.print(Panel(
        result.get("message", "Processing complete"),
        title="[bold magenta]Status Message[/bold magenta]",
        border_style="magenta"
    ))
    
    # Final summary metrics
    summary_table = Table(show_header=True, header_style="bold yellow", box=box.DOUBLE)
    summary_table.add_column("Metric", style="cyan", width=30)
    summary_table.add_column("Value", style="white", justify="right")
    
    summary_table.add_row("Regulations Applied", str(len(regulatory.get("regulations_applied", []))))
    summary_table.add_row("Agents Executed", str(len(regulatory.get("agents_executed", []))))
    summary_table.add_row("Enforcement Steps", str(regulatory.get("enforcement_steps", 0)))
    summary_table.add_row("PII Entities Detected", str(len(pii_detected)))
    summary_table.add_row("Policies Enforced", str(len(result.get("policies_applied", []))))
    summary_table.add_row("Compliance Applied", "✅ YES" if result.get("compliance_applied") else "❌ NO")
    
    console.print("\n")
    console.print(summary_table)
    console.print("\n")


if __name__ == "__main__":
    try:
        test_regulatory_flow()
    except requests.exceptions.ConnectionError:
        console.print("[bold red]❌ ERROR: Cannot connect to backend API[/bold red]")
        console.print("[yellow]Make sure the backend is running:[/yellow]")
        console.print("  ./start_backend.sh")
        console.print("  OR")
        console.print("  python -m uvicorn app.main:app --port 8000")
    except Exception as e:
        console.print(f"[bold red]❌ ERROR: {str(e)}[/bold red]")
