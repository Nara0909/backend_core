# Architecture Overview - Compliance AI System

## System Architecture

```
┌─────────────────────────────────────────────────────────────────────┐
│                         FRONTEND LAYER                              │
│                                                                     │
│  ┌──────────────────────────────────────────────────────────────┐  │
│  │                    React Dashboard (Port 3000)                 │  │
│  │  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐        │  │
│  │  │  Compliance  │  │   Request    │  │    Audit     │        │  │
│  │  │    Toggle    │  │  Processing  │  │  Log Viewer  │        │  │
│  │  └──────────────┘  └──────────────┘  └──────────────┘        │  │
│  └──────────────────────────────────────────────────────────────┘  │
│                              │                                      │
│                              │ HTTP REST API                        │
│                              ▼                                      │
└─────────────────────────────────────────────────────────────────────┘

                               │
                               │
                               ▼

┌─────────────────────────────────────────────────────────────────────┐
│                       BACKEND LAYER (Port 8000)                     │
│                                                                     │
│  ┌──────────────────────────────────────────────────────────────┐  │
│  │                FastAPI REST API Server                        │  │
│  │  ┌──────────────────────────────────────────────────────────┐│  │
│  │  │  API Endpoints:                                          ││  │
│  │  │  • POST /api/compliance/enable                           ││  │
│  │  │  • POST /api/compliance/disable                          ││  │
│  │  │  • GET  /api/compliance/status                           ││  │
│  │  │  • POST /api/process                                     ││  │
│  │  │  • GET  /api/audit/logs                                  ││  │
│  │  │  • GET  /api/policies                                    ││  │
│  │  └──────────────────────────────────────────────────────────┘│  │
│  └──────────────────────────────────────────────────────────────┘  │
│                              │                                      │
│                              ▼                                      │
│  ┌──────────────────────────────────────────────────────────────┐  │
│  │              Compliance State Manager                         │  │
│  │         (Enable/Disable Toggle + Persistence)                 │  │
│  └──────────────────────────────────────────────────────────────┘  │
│                              │                                      │
│                    ┌─────────┴─────────┐                           │
│                    ▼                   ▼                           │
│        ┌─────────────────┐   ┌─────────────────┐                  │
│        │  Bypass Mode    │   │ Compliance Mode │                  │
│        │  (Disabled)     │   │   (Enabled)     │                  │
│        └─────────────────┘   └─────────────────┘                  │
│                │                      │                            │
│                │                      ▼                            │
│                │         ┌────────────────────────┐               │
│                │         │   LangGraph Workflow   │               │
│                │         └────────────────────────┘               │
│                │                      │                            │
│                │                      ▼                            │
└────────────────┼──────────────────────────────────────────────────┘
                 │                      │
                 ▼                      ▼

┌────────────────────┐    ┌──────────────────────────────────────────┐
│  Direct Output     │    │      COMPLIANCE PIPELINE                 │
│  (No Controls)     │    │                                          │
│                    │    │  ┌────────────────────────────────────┐  │
│  Input → Output    │    │  │ 1. Access Control Agent            │  │
│                    │    │  │    ├─ Check roles & permissions    │  │
│  • No PII masking  │    │  │    └─ Verify consent               │  │
│  • No encryption   │    │  └────────────────────────────────────┘  │
│  • No audit logs   │    │                ▼                         │
│  • Fast            │    │  ┌────────────────────────────────────┐  │
│  • Non-compliant   │    │  │ 2. Privacy Agent                   │  │
└────────────────────┘    │  │    ├─ Mask PHI/PII                 │  │
                          │  │    ├─ Anonymize data               │  │
                          │  │    ├─ Tokenize sensitive fields    │  │
                          │  │    └─ Apply data minimization      │  │
                          │  └────────────────────────────────────┘  │
                          │                ▼                         │
                          │  ┌────────────────────────────────────┐  │
                          │  │ 3. LLM Task Execution              │  │
                          │  │    └─ Process masked input         │  │
                          │  └────────────────────────────────────┘  │
                          │                ▼                         │
                          │  ┌────────────────────────────────────┐  │
                          │  │ 4. Output Guard Agent              │  │
                          │  │    ├─ Scan output for PII          │  │
                          │  │    ├─ Redact sensitive data        │  │
                          │  │    └─ Sanitize for public use      │  │
                          │  └────────────────────────────────────┘  │
                          │                ▼                         │
                          │  ┌────────────────────────────────────┐  │
                          │  │ 5. Audit Agent                     │  │
                          │  │    ├─ Log all decisions            │  │
                          │  │    ├─ Record policy enforcement    │  │
                          │  │    └─ Generate compliance report   │  │
                          │  └────────────────────────────────────┘  │
                          │                                          │
                          └──────────────────────────────────────────┘
                                           ▼

┌─────────────────────────────────────────────────────────────────────┐
│                        SECURITY & POLICY LAYER                      │
│                                                                     │
│  ┌──────────────┐  ┌──────────────┐  ┌──────────────────────────┐  │
│  │ Encryption   │  │ PII Detection│  │  Policy Graph            │  │
│  │ (Fernet)     │  │ (Regex/NLP)  │  │  (GDPR,HIPAA,PCI,AI Act) │  │
│  └──────────────┘  └──────────────┘  └──────────────────────────┘  │
│                                                                     │
│  ┌──────────────┐  ┌──────────────┐  ┌──────────────────────────┐  │
│  │ Audit Logging│  │  Retention   │  │  Access Control          │  │
│  │ (HMAC)       │  │  Policies    │  │  (Role-based)            │  │
│  └──────────────┘  └──────────────┘  └──────────────────────────┘  │
└─────────────────────────────────────────────────────────────────────┘
```

## Data Flow

### Compliance ENABLED Flow
```
User Input (with PII)
    │
    ▼
Access Control Check
    │
    ▼
Privacy Masking (PII → [REDACTED])
    │
    ▼
Encrypted Masked Data
    │
    ▼
LLM Processing (on masked data)
    │
    ▼
Output Guard (scan & redact)
    │
    ▼
Audit Logging (full trail)
    │
    ▼
Secure Output (compliant)
```

### Compliance DISABLED Flow
```
User Input (with PII)
    │
    ▼
Direct Processing (BYPASS)
    │
    ▼
Raw Output (PII visible, non-compliant)
```

## Key Components

### Frontend
- **Technology:** React (vanilla, no build step)
- **Features:** 
  - Real-time compliance toggle
  - Request processing UI
  - Audit log visualization
  - Status monitoring

### Backend API
- **Technology:** FastAPI + Uvicorn
- **Features:**
  - RESTful endpoints
  - CORS enabled
  - Auto-generated OpenAPI docs
  - Pydantic validation

### Compliance Pipeline
- **Technology:** LangGraph
- **Agents:**
  - AccessControlAgent
  - PrivacyAgent
  - OutputGuardAgent
  - AuditAgent
  - EncryptionAgent
  - RetentionAgent

### Security Layer
- **Encryption:** Fernet (symmetric)
- **PII Detection:** Regex + NLP
- **Audit:** HMAC-based pseudonymization
- **Access Control:** Role-based permissions

## Deployment Options

### Development (Current)
```
Frontend:  http://localhost:3000  (Python HTTP server)
Backend:   http://localhost:8000  (Uvicorn dev server)
```

### Production
```
Frontend:  Nginx/Apache static hosting
Backend:   Gunicorn + Uvicorn workers
Database:  PostgreSQL for audit logs
Cache:     Redis for session management
Gateway:   API Gateway + Load Balancer
```

## Compliance Coverage

| Regulation | Coverage | Key Features |
|------------|----------|--------------|
| GDPR | ✅ Full | Data minimization, consent, right to erasure, encryption |
| HIPAA | ✅ Full | PHI masking, audit trails, access control, breach notification |
| PCI-DSS | ✅ Full | Encryption, access control, logging, retention policies |
| AI Act | ✅ Full | Explainability, human oversight, risk management, governance |

## Integration Points

### REST API
```
Base URL: http://localhost:8000/api
Authentication: (Optional - implement OAuth2/JWT)
Content-Type: application/json
```

### Supported Clients
- Web browsers (JavaScript/TypeScript)
- Mobile apps (React Native, Flutter)
- Desktop apps (Electron)
- Server-side (Python, Node.js, Java, etc.)
- CLI tools

## Performance Characteristics

| Mode | Latency | Privacy | Compliance | Use Case |
|------|---------|---------|------------|----------|
| Enabled | ~500ms | ✅ High | ✅ Yes | Production |
| Disabled | ~100ms | ❌ None | ❌ No | Testing only |

---

**Note:** This architecture is designed for plug-and-play deployment. 
Simply enable/disable compliance to switch between secure and bypass modes.
