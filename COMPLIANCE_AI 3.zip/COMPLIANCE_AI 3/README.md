# Compliance AI System - Backend & Frontend

## 🏥 Healthcare Privacy & Compliance Enforcement System

A plug-and-play backend and frontend system for enforcing GDPR, HIPAA, PCI-DSS, and AI Act compliance in healthcare AI applications.

---

## 🌟 Features

### Backend (FastAPI)
- ✅ **REST API** for compliance enforcement
- 🔒 **Toggle Compliance** - Enable/Disable compliance checks in real-time
- 🛡️ **Privacy Protection** - PII/PHI masking, encryption, anonymization
- 📋 **Audit Logging** - Complete trail of all compliance actions
- 📊 **Policy Management** - Dynamic policy enforcement based on regulations
- 🔌 **Plug-and-Play** - Easy integration with any frontend

### Frontend (Streamlit)
- 🎨 **Modern UI** - Clean, responsive Python-based dashboard
- 🔄 **Real-time Status** - Live compliance toggle and status updates
- 📝 **Request Processing** - Submit healthcare requests with instant compliance checks
- 📊 **Audit Viewer** - Visualize compliance execution path and audit logs
- ⚡ **Instant Feedback** - See the difference between compliant and non-compliant processing
- 🚀 **Fast & Responsive** - No hanging, immediate response to enable/disable actions

---

## 🚀 Quick Start

### Prerequisites
```bash
# Ensure you have Python 3.8+ installed
python --version

# Virtual environment should be set up
python -m venv .venv
source .venv/bin/activate  # On Mac/Linux
```

### Installation

1. **Clone and navigate to project**
```bash
cd COMPLIANCE_AI
```

2. **Install dependencies**
```bash
pip install -r requirements.txt
```

3. **Set up environment variables** (create `.env` file)
```env
OPENAI_API_KEY=your_openai_key_here
OPENAI_BASE_URL=your_base_url_here  # Optional
APP_ENCRYPTION_KEY=your_fernet_key_here
AUDIT_HMAC_SECRET=your_secret_here
```

### Running the System

#### Option 1: Start Everything (Recommended)
```bash
chmod +x start_all.sh start_backend.sh start_frontend.sh
./start_all.sh
```

#### Option 2: Start Services Separately

**Terminal 1 - Backend:**
```bash
./start_backend.sh
# Backend runs on http://localhost:8000
```

**Terminal 2 - Frontend:**
```bash
./start_frontend.sh
# Frontend runs on http://localhost:8501
```

---

## 📡 API Endpoints

### Compliance Control
- **GET** `/api/compliance/status` - Get compliance status
- **POST** `/api/compliance/enable` - Enable compliance enforcement
- **POST** `/api/compliance/disable` - Disable compliance (bypass mode)

### Processing
- **POST** `/api/process` - Process healthcare request with/without compliance

### Audit & Logs
- **GET** `/api/audit/logs` - Retrieve audit logs
- **GET** `/api/audit/logs?agent_filter=PrivacyAgent` - Filter logs by agent

### Policies
- **GET** `/api/policies` - List all available policies
- **GET** `/api/policies/{regulation_name}` - Get specific policy details

### System
- **GET** `/api/health` - Health check
- **GET** `/api/request-types` - List available request types

---

## 🔌 Frontend-Backend Integration

### Key Integration Points

1. **Compliance Toggle**
   ```python
   import requests
   
   # Enable compliance
   requests.post('http://localhost:8000/api/compliance/enable')
   
   # Disable compliance
   requests.post('http://localhost:8000/api/compliance/disable')
   ```

2. **Process Request**
   ```python
   import requests
   
   response = requests.post('http://localhost:8000/api/process', json={
       "input_text": "Patient data...",
       "request_type": "patient_triage",
       "user_role": "clinician",
       "regulations": ["HIPAA", "GDPR"]
   })
   result = response.json()
   ```

3. **Check Status**
   ```python
   import requests
   
   response = requests.get('http://localhost:8000/api/compliance/status')
   status = response.json()
   print(status['compliance_enabled'])
   ```

---

## 🎯 How It Works

### With Compliance ENABLED ✅

```
User Input → Access Control → Privacy Masking → LLM Processing 
→ Output Guard → Audit Logging → Encrypted Storage
```

**Example:**
- **Input:** "Patient John Doe (SSN: 123-45-6789) has diabetes"
- **Masked:** "Patient [NAME] (SSN: [REDACTED]) has diabetes"
- **Output:** "[PATIENT] has diabetes - recommend follow-up"
- **Audit:** Full trace of all agents and policies applied

### With Compliance DISABLED ❌

```
User Input → Direct Processing → Output (No Controls)
```

**Example:**
- **Input:** "Patient John Doe (SSN: 123-45-6789) has diabetes"
- **Output:** "Patient John Doe (SSN: 123-45-6789) has diabetes - recommend follow-up"
- **Audit:** None

---

## 📊 Use Cases

### Healthcare Scenarios

1. **Patient Triage** (`patient_triage`)
   - Masks PHI in chat sessions
   - Restricts output to authorized clinicians
   - Full HIPAA compliance

2. **Appointment Scheduling** (`appointment_scheduling`)
   - Encrypts patient contact information
   - Applies strict access controls
   - GDPR-compliant data handling

3. **Clinical Decision Support** (`clinical_decision_support`)
   - Masks patient identifiers
   - Enforces data retention policies
   - AI Act compliance for high-risk AI

---

## 🛡️ Security Features

- **Encryption:** Fernet-based encryption for data at rest
- **Access Control:** Role-based permissions
- **Anonymization:** PII/PHI masking and tokenization
- **Audit Trail:** Complete logging of all compliance actions
- **Data Retention:** Automated cleanup based on policies
- **Output Scanning:** Post-LLM PII detection and redaction

---

## 🔧 Configuration

### Compliance State
State is persisted in `app/compliance_state.json`:
```json
{
  "enabled": true,
  "updated_at": "2025-12-17T10:00:00Z",
  "regulations": ["GDPR", "HIPAA", "PCI-DSS", "AI Act"],
  "active_agents": ["AccessControlAgent", "PrivacyAgent", ...]
}
```

### Request Types
Available in `policy_generator/request_types.py`:
- `patient_triage`
- `appointment_scheduling`
- `clinical_decision_support`
- `medication_management`
- `patient_education`

---

## 🧪 Testing the System

### Test Compliance Toggle
1. Open frontend at http://localhost:3000
2. Click "Disable Compliance"
3. Submit a request with PII
4. Notice: No masking, direct output
5. Click "Enable Compliance"
6. Submit same request
7. Notice: PII masked, full audit trail

### Test API Directly
```bash
# Check health
curl http://localhost:8000/api/health

# Process with compliance
curl -X POST http://localhost:8000/api/process \
  -H "Content-Type: application/json" \
  -d '{
    "input_text": "Patient SSN: 123-45-6789",
    "request_type": "patient_triage"
  }'

# Toggle compliance
curl -X POST http://localhost:8000/api/compliance/disable
```

---

## 📁 Project Structure

```
COMPLIANCE_AI/
├── app/
│   ├── main.py                    # FastAPI backend
│   ├── compliance_state.py        # State management
│   ├── api_models.py              # Pydantic models
│   └── compliance_state.json      # Persisted state
├── ui/
│   └── index.html                 # React frontend
├── agent_graph/
│   ├── graph.py                   # LangGraph workflow
│   ├── nodes.py                   # Compliance agents
│   └── state.py                   # State definition
├── policy_generator/
│   ├── output_policies_AI/        # Policy JSON files
│   └── policy_graph/              # Policy graph engine
├── security/
│   ├── encryption.py              # Encryption utilities
│   ├── pii.py                     # PII detection
│   └── audit.py                   # Audit logging
├── start_all.sh                   # Start everything
├── start_backend.sh               # Start backend only
├── start_frontend.sh              # Start frontend only
└── README.md                      # This file
```

---

## 🚨 Important Notes

### Production Considerations
- **Replace in-memory audit logs** with a persistent database (PostgreSQL, MongoDB)
- **Use proper authentication** (OAuth2, JWT tokens)
- **Configure CORS** to allow only your frontend domain
- **Set up HTTPS** for all API communications
- **Implement rate limiting** to prevent abuse
- **Use a proper key management system** (AWS KMS, HashiCorp Vault)

### Compliance Modes

**ENABLED Mode (Default):**
- ✅ All privacy controls active
- ✅ Full audit logging
- ✅ Policy enforcement
- ✅ Encryption and masking
- ⚠️ Slightly slower processing

**DISABLED Mode:**
- ❌ No privacy controls
- ❌ No audit logging
- ❌ No policy enforcement
- ❌ No encryption or masking
- ⚡ Faster processing
- ⚠️ **USE ONLY FOR TESTING!**

---

## 📚 Additional Resources

- **API Documentation:** http://localhost:8000/api/docs
- **Interactive API:** http://localhost:8000/api/redoc
- **Frontend Dashboard:** http://localhost:3000

---

## 🤝 Support

For issues or questions:
1. Check API documentation at `/api/docs`
2. Review audit logs for debugging
3. Check compliance status endpoint
4. Verify all environment variables are set

---

## 📝 License

This project implements compliance controls for GDPR, HIPAA, PCI-DSS, and the EU AI Act.

---

**Built with ❤️ for Healthcare Privacy & Compliance**
