import json
import re
from typing import Dict
from config.config import client, MODEL, MINI_MODEL
from security.audit import make_event


class TriageAgent:
    """Triage agent that uses an LLM to produce a JSON-formatted triage decision.

    Response schema (JSON):
      {
        "level": "Emergency"|"Urgent"|"Routine",
        "reason": "short text explaining why",
        "recommended_action": "short action text"
      }
    """

    def _heuristic_fallback(self, text: str) -> Dict:
        """Simple keyword-based fallback when LLM is unavailable."""
        text = text.lower()
        emergency_kw = ("unconscious", "no pulse", "not breathing", "cardiac arrest", "chest pain", "severe bleeding", "stroke")
        urgent_kw = ("shortness of breath", "high fever", "severe pain", "broken", "head injury")

        for k in emergency_kw:
            if k in text:
                return {"level": "Emergency", "reason": f"Matched emergency keyword: {k}", "recommended_action": "Call emergency services/seek immediate care"}

        for k in urgent_kw:
            if k in text:
                return {"level": "Urgent", "reason": f"Matched urgent keyword: {k}", "recommended_action": "Seek urgent clinical evaluation"}

        return {"level": "Routine", "reason": "No red-flag keywords detected", "recommended_action": "Schedule routine follow-up"}

    def run(self, state: Dict) -> Dict:
        # Prepare context for the LLM
        masked = state.get("masked_input") or state.get("input_text") or ""
        payload = {
            "masked_input": masked,
            "request_type": state.get("request_type"),
            "user_role": state.get("user_role"),
        }

        system_prompt = (
            "You are a clinical triage assistant. Given a short patient symptom description and minimal context, "
            "respond ONLY with a JSON object with keys: level, reason, recommended_action. "
            "level must be one of: Emergency, Urgent, Routine. Keep values concise."
        )

        user_prompt = json.dumps(payload, indent=2)

        model_to_use = MINI_MODEL or MODEL

        try:
            resp = client.chat.completions.create(
                model=model_to_use,
                messages=[{"role": "system", "content": system_prompt}, {"role": "user", "content": user_prompt}],
                temperature=0.0,
            )
            raw = resp.choices[0].message.content
            state["llm_response"] = raw

            # Attempt to parse JSON from the response
            try:
                triage = json.loads(raw)
            except Exception:
                # try to extract first JSON object in text
                m = re.search(r"\{.*\}", raw, re.DOTALL)
                if m:
                    try:
                        triage = json.loads(m.group(0))
                    except Exception:
                        triage = self._heuristic_fallback(masked)
                else:
                    triage = self._heuristic_fallback(masked)

        except Exception:
            # on any LLM failure, fallback to heuristics
            state["llm_response"] = None
            triage = self._heuristic_fallback(masked)

        # Normalize triage fields
        if not isinstance(triage, dict):
            triage = self._heuristic_fallback(masked)

        triage.setdefault("level", "Routine")
        triage.setdefault("reason", "No reason provided")
        triage.setdefault("recommended_action", "Follow-up as appropriate")

        state["triage"] = triage

        # Audit the triage decision
        try:
            audit_entry = make_event("TriageAgent", "triage_decision", {"triage": triage, "policy_trace_ids": state.get("policy_trace_map", {}).get("TriageAgent", [])})
            state.setdefault("audit_log", []).append(audit_entry)
        except Exception:
            pass

        return state