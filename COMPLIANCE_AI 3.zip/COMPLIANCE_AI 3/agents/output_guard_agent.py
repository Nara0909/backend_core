import re



class OutputGuardAgent:

    def run(self, state):

        if not state.context.get("allow_sensitive_output"):

            state.final_output = re.sub(

                r"PATIENT_\d+", "[REDACTED]", state.llm_response

            )

        else:

            state.final_output = state.llm_response

        return state

