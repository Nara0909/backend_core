#!/bin/bash

# Frontend Server Startup Script

echo "🎨 Starting Compliance AI Frontend (Streamlit)..."
echo ""

# Check if Python is available
if ! command -v python3 &> /dev/null; then
    echo "❌ Python3 not found!"
    exit 1
fi

# Activate virtual environment if it exists
if [ -d "$(dirname "$0")/.venv" ]; then
    source "$(dirname "$0")/.venv/bin/activate"
fi

echo "✅ Starting Streamlit dashboard..."
echo ""
echo "🌐 Frontend URL: http://localhost:8501"
echo "🔌 Backend API: http://localhost:8000"
echo ""
echo "⚠️  Make sure the backend is running (./start_backend.sh)"
echo ""
echo "Press CTRL+C to stop the server"
echo ""

# Navigate to ui directory and start Streamlit
cd "$(dirname "$0")/ui"
streamlit run app.py --server.port=8501 --server.address=0.0.0.0
