import os
import time
from datetime import datetime, timedelta
from typing import Iterable
from config.config import DATA_RETENTION_DAYS


def should_delete(mtime: float, retention_days: int = DATA_RETENTION_DAYS) -> bool:
    cutoff = datetime.utcnow() - timedelta(days=retention_days)
    return datetime.utcfromtimestamp(mtime) < cutoff


def cleanup_files(paths: Iterable[str], retention_days: int = DATA_RETENTION_DAYS) -> int:
    """Delete files older than retention_days. Returns count deleted."""
    deleted = 0
    for p in paths:
        try:
            st = os.stat(p)
            if should_delete(st.st_mtime, retention_days):
                os.remove(p)
                deleted += 1
        except FileNotFoundError:
            continue
        except Exception:
            # best-effort only
            continue
    return deleted
