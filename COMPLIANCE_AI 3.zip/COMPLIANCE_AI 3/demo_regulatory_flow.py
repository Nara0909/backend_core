#!/usr/bin/env python3
"""
Visual Demonstration of Complete Regulatory Compliance Flow

This script shows the step-by-step execution of a compliance request
with detailed regulatory mapping and agent execution.
"""

import requests
import json
from datetime import datetime

API_URL = "http://127.0.0.1:8000/api"

print("=" * 80)
print("  REGULATORY COMPLIANCE FLOW DEMONSTRATION")
print("=" * 80)
print()

# Test input with various PII types
test_data = {
    "input_text": "Patient Maria Garcia (SSN: 987-65-4321, DOB: 1990-05-20) presents with severe headaches. Medical history includes hypertension. Contact: maria.garcia@example.com, Phone: (555) 987-6543. Insurance: Blue Cross ID#12345.",
    "request_type": "clinical_query",
    "user_role": "clinician"
}

print("📋 INPUT DATA")
print("-" * 80)
print(f"Text: {test_data['input_text']}")
print(f"Type: {test_data['request_type']}")
print(f"Role: {test_data['user_role']}")
print()

# Send request
print("🚀 SENDING REQUEST TO COMPLIANCE API...")
print()

try:
    response = requests.post(f"{API_URL}/process", json=test_data, timeout=30)
    result = response.json()
    
    if result.get("success"):
        print("✅ REQUEST PROCESSED SUCCESSFULLY")
        print()
        
        # Show regulatory compliance
        reg_compliance = result.get("regulatory_compliance", {})
        
        print("=" * 80)
        print("  REGULATORY COMPLIANCE ANALYSIS")
        print("=" * 80)
        print()
        
        print("📜 REGULATIONS APPLIED:")
        for reg in reg_compliance.get("regulations_applied", []):
            print(f"   • {reg}")
        print()
        
        print("🔄 AGENT EXECUTION FLOW:")
        print("-" * 80)
        agents = reg_compliance.get("agents_executed", [])
        for i, agent in enumerate(agents, 1):
            print(f"   Step {i}: {agent}")
        print()
        
        print("🗺️  POLICY TRACE MAP (Agent → Regulations):")
        print("-" * 80)
        policy_map = reg_compliance.get("policy_trace_map", {})
        for agent, policies in policy_map.items():
            print(f"\n   {agent}:")
            for policy in policies:
                print(f"      → {policy}")
        print()
        
        print("=" * 80)
        print("  PII DETECTION RESULTS")
        print("=" * 80)
        print()
        
        pii_list = result.get("pii_detected", [])
        if pii_list:
            print(f"⚠️  DETECTED {len(pii_list)} PII ENTITIES:")
            print()
            for pii in pii_list:
                print(f"   Type:   {pii.get('type')}")
                print(f"   Value:  {pii.get('value')}")
                print(f"   Masked: {pii.get('masked')}")
                print()
        else:
            print("✅ No PII detected")
            print()
        
        print("=" * 80)
        print("  TEXT TRANSFORMATION")
        print("=" * 80)
        print()
        
        print("📥 ORIGINAL INPUT:")
        print("-" * 80)
        print(result.get("original_input"))
        print()
        
        print("🔒 MASKED INPUT (Privacy Protected):")
        print("-" * 80)
        print(result.get("masked_input"))
        print()
        
        print("📤 FINAL OUTPUT:")
        print("-" * 80)
        print(result.get("processed_output"))
        print()
        
        print("=" * 80)
        print("  AUDIT TRAIL")
        print("=" * 80)
        print()
        
        print(f"Audit ID:  {result.get('audit_id')}")
        print(f"Timestamp: {result.get('timestamp')}")
        print(f"Total Log Entries: {len(result.get('audit_log', []))}")
        print()
        
        print("DETAILED AUDIT LOG:")
        print("-" * 80)
        for log_entry in result.get("audit_log", []):
            print(f"\n[{log_entry.get('timestamp')}]")
            print(f"  Agent:  {log_entry.get('agent')}")
            print(f"  Action: {log_entry.get('action')}")
            print(f"  Status: {log_entry.get('status')}")
            policies = log_entry.get('policy_trace_ids', [])
            if policies:
                print(f"  Policies:")
                for p in policies:
                    print(f"    - {p}")
        print()
        
        print("=" * 80)
        print("  SUMMARY METRICS")
        print("=" * 80)
        print()
        
        print(f"Compliance Enabled:    {'✅' if result.get('compliance_enabled') else '❌'}")
        print(f"Compliance Applied:    {'✅' if result.get('compliance_applied') else '❌'}")
        print(f"Access Granted:        {'✅' if result.get('access_granted') else '❌'}")
        print(f"Data Encrypted:        {'✅' if result.get('encrypted') else '❌'}")
        print()
        print(f"Regulations Applied:   {len(reg_compliance.get('regulations_applied', []))}")
        print(f"Enforcement Steps:     {reg_compliance.get('enforcement_steps', 0)}")
        print(f"Agents Executed:       {len(reg_compliance.get('agents_executed', []))}")
        print(f"Policies Enforced:     {len(result.get('policies_applied', []))}")
        print(f"PII Entities Found:    {len(pii_list)}")
        print()
        
        print("=" * 80)
        print("  STATUS MESSAGE")
        print("=" * 80)
        print()
        print(result.get("message"))
        print()
        
    else:
        print(f"❌ ERROR: {result.get('error', 'Unknown error')}")
        
except requests.exceptions.ConnectionError:
    print("❌ ERROR: Cannot connect to backend API")
    print("Make sure the backend is running:")
    print("  ./start_backend.sh")
    print("  OR")
    print("  python -m uvicorn app.main:app --host 0.0.0.0 --port 8000 --reload")
except Exception as e:
    print(f"❌ ERROR: {str(e)}")

print()
print("=" * 80)
print("  END OF DEMONSTRATION")
print("=" * 80)
