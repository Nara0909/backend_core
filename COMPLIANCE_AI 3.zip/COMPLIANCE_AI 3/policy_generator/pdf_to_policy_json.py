import truststore
truststore.inject_into_ssl()

import os
import sys
import json
from pathlib import Path
from pypdf import PdfReader
import tiktoken
from dotenv import load_dotenv

# Ensure project root is importable when running as a script
CURRENT_DIR = os.path.dirname(os.path.abspath(__file__))
ROOT_DIR = os.path.dirname(CURRENT_DIR)
if ROOT_DIR not in sys.path:
    sys.path.insert(0, ROOT_DIR)

from config.config import client, MODEL, MAX_TOKENS_PER_CHUNK, MINI_MODEL

# -----------------------------
# ENV + PATH SETUP
# -----------------------------
load_dotenv()

BASE_DIR = Path(__file__).resolve().parent

INPUT_PDF_DIR = BASE_DIR / "input_pdfs"
OUTPUT_DIR = BASE_DIR / "output_policies_general"
PROMPT_FILE = BASE_DIR / "prompts" / "regulation_to_json.txt"
REG_DETECT_PROMPT_FILE = BASE_DIR / "prompts" / "detect_regulation_name.txt"

OUTPUT_DIR.mkdir(parents=True, exist_ok=True)

print("MAX_TOKENS_PER_CHUNK:", MAX_TOKENS_PER_CHUNK)

# -----------------------------
# LOAD PROMPTS
# -----------------------------
with open(PROMPT_FILE, "r", encoding="utf-8") as f:
    BASE_PROMPT = f.read()

with open(REG_DETECT_PROMPT_FILE, "r", encoding="utf-8") as f:
    REG_DETECT_PROMPT = f.read()

# -----------------------------
# PDF TEXT EXTRACTION
# -----------------------------
def extract_text_from_pdf(pdf_path: Path) -> str:
    reader = PdfReader(str(pdf_path))
    pages = []

    for page in reader.pages:
        text = page.extract_text()
        if text:
            pages.append(text)

    return "\n".join(pages)

# -----------------------------
# FAST + CHEAP CHUNKING (4.1-mini)
# -----------------------------
def chunk_text(text: str, max_tokens: int):
    encoder = tiktoken.get_encoding("cl100k_base")
    tokens = encoder.encode(text)

    # 🔹 Overlap-free, fixed-size chunks (cheapest)
    return [
        encoder.decode(tokens[i:i + max_tokens])
        for i in range(0, len(tokens), max_tokens)
    ]

# -----------------------------
# REGULATION NAME DETECTION (ONCE)
# -----------------------------
def detect_regulation_name(text: str) -> str:
    print("Detecting regulation name from document content")

    sample = text[:4000]  # title + intro is enough

    messages = [
        {"role": "system", "content": REG_DETECT_PROMPT},
        {"role": "user", "content": sample},
    ]

    response = client.chat.completions.create(
        model=MINI_MODEL,
        messages=messages,
        temperature=0.0,
    )

    try:
        result = json.loads(response.choices[0].message.content)
        name = result.get("regulation_name", "UNKNOWN_REGULATION")
        print(f"Detected regulation: {name}")
        return name
    except Exception:
        print("Regulation detection failed, using UNKNOWN_REGULATION")
        return "UNKNOWN_REGULATION"

# -----------------------------
# POLICY EXTRACTION FROM CHUNK
# -----------------------------
def extract_policies_from_chunk(chunk: str, regulation_name: str):
    messages = [
        {"role": "system", "content": BASE_PROMPT},
        {
            "role": "user",
            "content": f"""
Regulation: {regulation_name}

Regulatory Text:
----------------
{chunk}
"""
        }
    ]

    response = client.chat.completions.create(
        model=MINI_MODEL,
        messages=messages,
        temperature=0.1,
    )

    content = response.choices[0].message.content.strip()
    return json.loads(content)

# -----------------------------
# MAIN PDF PROCESSOR
# -----------------------------
def process_pdf(pdf_file: Path):
    print(f"\nProcessing {pdf_file.name}")

    text = extract_text_from_pdf(pdf_file)
    if not text.strip():
        print("No text extracted, skipping")
        return

    # 🔹 Detect regulation name ONCE
    regulation_name = detect_regulation_name(text)

    chunks = chunk_text(text, MAX_TOKENS_PER_CHUNK)
    print(f"Split into {len(chunks)} chunks")

    all_policies = []

    for idx, chunk in enumerate(chunks, start=1):
        try:
            policies = extract_policies_from_chunk(chunk, regulation_name)
            all_policies.extend(policies)
            print(f"  Chunk {idx}/{len(chunks)} extracted ({len(policies)} rules)")
        except Exception as e:
            print(f"  Chunk {idx} failed: {e}")

    if not all_policies:
        print("No policies extracted")
        return

    output_path = OUTPUT_DIR / f"{regulation_name.lower().replace(' ', '_')}.json"

    with open(output_path, "w", encoding="utf-8") as f:
        json.dump(all_policies, f, indent=2)

    print(f"Saved {len(all_policies)} rules → {output_path.name}")

# -----------------------------
# ENTRY POINT
# -----------------------------
if __name__ == "__main__":
    for pdf in INPUT_PDF_DIR.iterdir():
        if pdf.suffix.lower() == ".pdf":
            process_pdf(pdf)
