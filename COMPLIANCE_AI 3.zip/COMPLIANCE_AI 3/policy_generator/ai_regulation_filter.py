
import truststore
truststore.inject_into_ssl()

import os
import sys
import json
from pathlib import Path
from dotenv import load_dotenv

# Ensure project root on sys.path when run as a script
CURRENT_DIR = os.path.dirname(os.path.abspath(__file__))
ROOT_DIR = os.path.dirname(CURRENT_DIR)
if ROOT_DIR not in sys.path:
    sys.path.insert(0, ROOT_DIR)

# Load environment before importing config values
load_dotenv()

from config.config import client, MODEL, MINI_MODEL
import hashlib
import time

# Base dir and cache path
BASE_DIR = Path(__file__).resolve().parent
# Simple on-disk cache for LLM classification to avoid repeated calls
CACHE_PATH = BASE_DIR / ".llm_classify_cache.json"


def _cache_load():
    try:
        if CACHE_PATH.exists():
            return json.loads(CACHE_PATH.read_text(encoding="utf-8"))
    except Exception:
        pass
    return {}


def _cache_save(cache: dict):
    try:
        CACHE_PATH.write_text(json.dumps(cache, indent=2), encoding="utf-8")
    except Exception:
        pass


def _rule_key(rule: dict) -> str:
    s = (rule.get("principle", "") + "|" + rule.get("requirement", "")).strip()
    return hashlib.sha256(s.encode()).hexdigest()

# -----------------------------
# CONFIG
# -----------------------------
INPUT_DIR = BASE_DIR / "output_policies_general"
OUTPUT_DIR = BASE_DIR / "output_policies_AI"
FILTER_PROMPT_FILE = BASE_DIR / "prompts" / "filter_ai_relevant_from_json.txt"
SCOPE_PROMPT_FILE = BASE_DIR / "prompts" / "classify_ai_scope.txt"

OUTPUT_DIR.mkdir(parents=True, exist_ok=True)

FILTER_PROMPT = FILTER_PROMPT_FILE.read_text(encoding="utf-8")
SCOPE_PROMPT = SCOPE_PROMPT_FILE.read_text(encoding="utf-8")

# Toggle LLM classification (set env var ENABLE_LLM_CLASSIFICATION=0 or false to disable)
ENABLE_LLM_CLASSIFICATION = os.getenv("ENABLE_LLM_CLASSIFICATION", "1")
ENABLE_LLM_CLASSIFICATION = False if ENABLE_LLM_CLASSIFICATION.lower() in ("0", "false", "no") else True

# Toggle AI relevance filtering (set env var ENABLE_AI_RELEVANCE_FILTER=0 or false to disable)
ENABLE_AI_RELEVANCE_FILTER = os.getenv("ENABLE_AI_RELEVANCE_FILTER", "1")
ENABLE_AI_RELEVANCE_FILTER = False if ENABLE_AI_RELEVANCE_FILTER.lower() in ("0", "false", "no") else True

# -----------------------------
# CANONICAL PRINCIPLES
# -----------------------------
PRINCIPLE_MAP = {
    "data minimization": "Data Minimization",
    "privacy": "Privacy",
    "security": "Security",
    "access control": "Access Control",
    "retention": "Retention",
    "governance and accountability": "Governance and Accountability",
}

ALLOWED_AI_SCOPES = {
    "AI_Privacy_Control",
    "AI_Access_Control",
    "AI_Governance",
    "AI_Explainability",
    "General_Governance",
}

# -----------------------------
# NORMALIZATION
# -----------------------------
def normalize_principle(rule: dict) -> dict:
    raw = rule.get("principle", "")
    rule["principle"] = PRINCIPLE_MAP.get(raw.strip().lower(), raw)
    return rule


def normalize_actor_language(rule: dict) -> dict:
    text = rule.get("requirement", "")
    lower = text.lower()

    prefixes = [
        "businesses must ",
        "a business must ",
        "service providers must ",
        "contractors must ",
        "covered entities must ",
    ]

    for p in prefixes:
        if lower.startswith(p):
            rule["requirement"] = text[len(p):].capitalize()
            break

    return rule

# -----------------------------
# HEURISTIC CLASSIFIER (PRIMARY)
# -----------------------------
def heuristic_ai_scope(rule: dict) -> tuple[str, str]:
    text = f"{rule.get('principle','')} {rule.get('requirement','')}".lower()

    if any(k in text for k in ["phi", "pii", "personal data", "privacy", "de-identif", "anonym"]):
        return "AI_Privacy_Control", "Heuristic keyword match: privacy/PII"

    if any(k in text for k in ["access", "authorize", "role", "permission"]):
        return "AI_Access_Control", "Heuristic keyword match: access control"

    if any(k in text for k in ["audit", "log", "monitor", "oversight"]):
        return "AI_Governance", "Heuristic keyword match: audit/governance"

    if any(k in text for k in ["automated", "algorithm", "explain", "logic"]):
        return "AI_Explainability", "Heuristic keyword match: explainability"

    return "General_Governance", "No heuristic match"

# -----------------------------
# LLM CLASSIFIER (SECONDARY)
# -----------------------------
def classify_ai_scope_llm_batch(rules: list) -> list:
    print(f"LLM classifying {len(rules)} unresolved rules")

    # Load cache and determine which rules need LLM classification
    cache = _cache_load()
    uncached = []
    uncached_indices = []

    for i, r in enumerate(rules):
        key = _rule_key(r)
        if key in cache:
            ai_scope = cache[key].get("ai_scope")
            if ai_scope in ALLOWED_AI_SCOPES:
                r["ai_scope"] = ai_scope
                r["ai_scope_reason"] = "cached"
            else:
                r["ai_scope"] = "General_Governance"
                r["ai_scope_reason"] = "cached fallback"
        else:
            uncached.append(r)
            uncached_indices.append(i)

    # If nothing to call LLM for, return early
    if not uncached:
        return rules

    # Batch calls to reduce token sizes and use a smaller model when available
    BATCH_SIZE = 20
    model_to_use = MINI_MODEL or MODEL

    for start in range(0, len(uncached), BATCH_SIZE):
        batch = uncached[start : start + BATCH_SIZE]
        messages = [
            {"role": "system", "content": SCOPE_PROMPT},
            {"role": "user", "content": json.dumps(batch, indent=2)},
        ]

        try:
            response = client.chat.completions.create(
                model=model_to_use,
                messages=messages,
                temperature=0.0,
            )
            raw = json.loads(response.choices[0].message.content)
        except Exception as e:
            print(f"LLM scope classification failed for batch start {start}: {e}")
            raw = []

        results = raw.get("results", raw) if isinstance(raw, dict) else raw
        if not isinstance(results, list):
            results = []

        for j, item in enumerate(batch):
            global_idx = uncached_indices[start + j]
            classified = results[j] if j < len(results) else {}
            ai_scope = classified.get("ai_scope")

            if ai_scope in ALLOWED_AI_SCOPES:
                rules[global_idx]["ai_scope"] = ai_scope
                rules[global_idx]["ai_scope_reason"] = "LLM classification"
            else:
                rules[global_idx]["ai_scope"] = "General_Governance"
                rules[global_idx]["ai_scope_reason"] = "LLM failed → fallback"

            # persist to cache
            try:
                cache[_rule_key(item)] = {"ai_scope": rules[global_idx]["ai_scope"]}
            except Exception:
                pass

    _cache_save(cache)
    return rules

# -----------------------------
# AI RELEVANCE FILTER
# -----------------------------
def filter_with_llm(rules: list) -> list:
    print(f"Filtering AI relevance from {len(rules)} rules")

    messages = [
        {"role": "system", "content": FILTER_PROMPT},
        {"role": "user", "content": json.dumps(rules, indent=2)},
    ]

    try:
        response = client.chat.completions.create(
            model=MODEL,
            messages=messages,
            temperature=0.0,
        )
        return json.loads(response.choices[0].message.content)
    except Exception as e:
        print(f"AI relevance filtering failed: {e}")
        return []

# -----------------------------
# MAIN PIPELINE
# -----------------------------
def process_all_files():
    files = list(INPUT_DIR.glob("*.json"))
    print(f"Found {len(files)} policy files")

    for idx, json_file in enumerate(files, start=1):
        print(f"\n[{idx}/{len(files)}] Processing {json_file.name}")

        rules = json.loads(json_file.read_text(encoding="utf-8"))
        print(f"   Loaded {len(rules)} raw rules")

        resolved = []
        unresolved = []

        # Step 1: Normalize + Heuristic classification
        for r in rules:
            r = normalize_principle(r)
            r = normalize_actor_language(r)

            scope, reason = heuristic_ai_scope(r)
            r["ai_scope"] = scope
            r["ai_scope_reason"] = reason

            if scope == "General_Governance":
                unresolved.append(r)
            else:
                resolved.append(r)

        print(f"   Heuristic resolved: {len(resolved)}")
        print(f"   LLM required: {len(unresolved)}")

        # Step 2: LLM classification only if needed (can be disabled via env)
        if unresolved:
            if ENABLE_LLM_CLASSIFICATION:
                unresolved = classify_ai_scope_llm_batch(unresolved)
            else:
                print("   LLM classification disabled via ENABLE_LLM_CLASSIFICATION — applying heuristic fallback")
                for r in unresolved:
                    r["ai_scope"] = "General_Governance"
                    r["ai_scope_reason"] = "LLM disabled — heuristic fallback"

        combined = resolved + unresolved

        # Step 3: AI relevance filtering (can be disabled via env)
        if ENABLE_AI_RELEVANCE_FILTER:
            ai_rules = filter_with_llm(combined)
        else:
            print("   AI relevance filtering disabled via ENABLE_AI_RELEVANCE_FILTER — applying heuristic fallback")
            ai_rules = []
            ai_keywords = [
                "ai",
                "artificial intelligence",
                "machine learning",
                "model",
                "algorithm",
                "automated",
                "automation",
            ]
            for r in combined:
                if r.get("ai_scope") and r.get("ai_scope") != "General_Governance":
                    ai_rules.append(r)
                    continue
                text = (r.get("principle", "") + " " + r.get("requirement", "")).lower()
                if any(k in text for k in ai_keywords):
                    r["ai_filter_reason"] = "heuristic keyword match"
                    ai_rules.append(r)

        output_path = OUTPUT_DIR / json_file.name
        output_path.write_text(json.dumps(ai_rules, indent=2), encoding="utf-8")

        print(f"   Saved {len(ai_rules)} AI rules → {output_path.name}")

    print("\nAI policy extraction completed successfully")

# -----------------------------
# ENTRY POINT
# -----------------------------
if __name__ == "__main__":
    process_all_files()
