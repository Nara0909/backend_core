"""
Compliance AI - Streamlit Dashboard
Healthcare Privacy and Compliance Management Interface
"""

import streamlit as st
import requests
from datetime import datetime
import json
import time

# Configuration
API_BASE_URL = "http://127.0.0.1:8000/api"

# Page config
st.set_page_config(
    page_title="Compliance AI Dashboard",
    page_icon="🛡️",
    layout="wide",
    initial_sidebar_state="expanded"
)

# Custom CSS
st.markdown("""
<style>
    .main-header {
        font-size: 2.5rem;
        font-weight: bold;
        color: #667eea;
        margin-bottom: 0.5rem;
    }
    .sub-header {
        font-size: 1.2rem;
        color: #718096;
        margin-bottom: 2rem;
    }
    .status-enabled {
        background-color: #48bb78;
        color: white;
        padding: 0.5rem 1rem;
        border-radius: 0.5rem;
        font-weight: bold;
        display: inline-block;
    }
    .status-disabled {
        background-color: #f56565;
        color: white;
        padding: 0.5rem 1rem;
        border-radius: 0.5rem;
        font-weight: bold;
        display: inline-block;
    }
    .metric-card {
        background-color: #f7fafc;
        padding: 1rem;
        border-radius: 0.5rem;
        border-left: 4px solid #667eea;
    }
</style>
""", unsafe_allow_html=True)

# Helper functions
def fetch_compliance_status():
    """Fetch current compliance status from API"""
    try:
        response = requests.get(f"{API_BASE_URL}/compliance/status", timeout=5)
        response.raise_for_status()
        return response.json()
    except Exception as e:
        st.error(f"❌ Failed to fetch compliance status: {str(e)}")
        return None

def enable_compliance():
    """Enable compliance mode"""
    try:
        with st.spinner("Enabling compliance..."):
            response = requests.post(f"{API_BASE_URL}/compliance/enable", timeout=10)
            response.raise_for_status()
            st.success("✅ Compliance enabled successfully!")
            time.sleep(0.5)
            st.rerun()
    except Exception as e:
        st.error(f"❌ Failed to enable compliance: {str(e)}")

def disable_compliance():
    """Disable compliance mode"""
    try:
        with st.spinner("Disabling compliance..."):
            response = requests.post(f"{API_BASE_URL}/compliance/disable", timeout=10)
            response.raise_for_status()
            st.success("✅ Compliance disabled successfully!")
            time.sleep(0.5)
            st.rerun()
    except Exception as e:
        st.error(f"❌ Failed to disable compliance: {str(e)}")

def process_request(input_text, request_type, user_role="clinician"):
    """Process a request through the compliance pipeline"""
    try:
        payload = {
            "input_text": input_text,
            "request_type": request_type,
            "user_role": user_role
        }
        with st.spinner("Processing request..."):
            response = requests.post(
                f"{API_BASE_URL}/process",
                json=payload,
                timeout=30
            )
            response.raise_for_status()
            return response.json()
    except Exception as e:
        st.error(f"❌ Processing failed: {str(e)}")
        return None

def fetch_audit_logs(limit=10):
    """Fetch recent audit logs"""
    try:
        response = requests.get(f"{API_BASE_URL}/audit/logs?limit={limit}", timeout=5)
        response.raise_for_status()
        return response.json()
    except Exception as e:
        st.error(f"❌ Failed to fetch audit logs: {str(e)}")
        return {"logs": []}

def fetch_request_types():
    """Fetch available request types"""
    try:
        response = requests.get(f"{API_BASE_URL}/request-types", timeout=5)
        response.raise_for_status()
        data = response.json()
        return list(data.get("request_types", {}).keys())
    except Exception as e:
        return ["patient_triage", "appointment_scheduling", "clinical_decision_support"]

# Main App
def main():
    # Header
    st.markdown('<div class="main-header">🛡️ Compliance AI Dashboard</div>', unsafe_allow_html=True)
    st.markdown('<div class="sub-header">Healthcare Privacy & Compliance Management</div>', unsafe_allow_html=True)
    
    # Fetch compliance status
    status = fetch_compliance_status()
    
    if status is None:
        st.error("⚠️ Cannot connect to backend API. Make sure it's running on port 8000.")
        st.info("Run: `./start_backend.sh` or `python -m uvicorn app.main:app --port 8000`")
        return
    
    # Sidebar - Compliance Control
    with st.sidebar:
        st.header("⚙️ Compliance Control")
        
        # Status display
        compliance_enabled = status.get("enabled", False)
        if compliance_enabled:
            st.markdown('<div class="status-enabled">🟢 ENABLED</div>', unsafe_allow_html=True)
        else:
            st.markdown('<div class="status-disabled">🔴 DISABLED</div>', unsafe_allow_html=True)
        
        st.markdown("---")
        
        # Control buttons
        col1, col2 = st.columns(2)
        with col1:
            if st.button("✅ Enable", use_container_width=True, disabled=compliance_enabled):
                enable_compliance()
        with col2:
            if st.button("❌ Disable", use_container_width=True, disabled=not compliance_enabled):
                disable_compliance()
        
        st.markdown("---")
        
        # Status details
        st.subheader("📊 Status Details")
        st.json({
            "enabled": status.get("enabled"),
            "updated_at": status.get("updated_at", "")[:19],
            "active_agents": len(status.get("active_agents", []))
        })
    
    # Main content area - tabs
    tab1, tab2, tab3 = st.tabs(["📝 Process Request", "📋 Audit Logs", "ℹ️ About"])
    
    # Tab 1: Process Request
    with tab1:
        st.header("Process Healthcare Request")
        
        # Request type selection
        request_types = fetch_request_types()
        request_type = st.selectbox(
            "Request Type",
            request_types,
            index=0 if "patient_triage" in request_types else 0
        )
        
        # User role selection
        user_role = st.selectbox(
            "User Role",
            ["clinician", "nurse", "admin", "patient"],
            index=0
        )
        
        # Input text area
        default_text = "Patient John Doe (DOB: 1985-03-15, SSN: 123-45-6789) reports chest pain and shortness of breath. Contact: john.doe@email.com, Phone: 555-1234"
        input_text = st.text_area(
            "Input Text (include PII for testing)",
            value=default_text,
            height=150,
            help="Enter patient data. Try including SSN, email, phone numbers to see PII masking in action."
        )
        
        # Process button
        if st.button("🚀 Process Request", type="primary", use_container_width=True):
            if not input_text.strip():
                st.warning("⚠️ Please enter some text to process")
            else:
                result = process_request(input_text, request_type, user_role)
                
                if result:
                    st.success("✅ Request processed successfully!")
                    
                    # Display results in columns
                    col1, col2 = st.columns(2)
                    
                    with col1:
                        st.subheader("📥 Original Input")
                        st.text_area("Input", value=input_text, height=100, disabled=True)
                        
                        st.subheader("🔒 Privacy Protection")
                        pii_detected = result.get("pii_detected", [])
                        if pii_detected:
                            st.warning(f"⚠️ Detected {len(pii_detected)} PII entities")
                            for pii in pii_detected:
                                st.code(f"{pii.get('type', 'Unknown')}: {pii.get('value', 'N/A')}")
                        else:
                            st.success("✅ No PII detected")
                    
                    with col2:
                        st.subheader("📤 Processed Output")
                        output_text = result.get("output_text", "")
                        st.text_area("Output", value=output_text, height=100, disabled=True)
                        
                        st.subheader("📊 Regulatory Compliance")
                        regulatory = result.get("regulatory_compliance", {})
                        if regulatory:
                            st.metric("Regulations Applied", ", ".join(regulatory.get("regulations_applied", [])))
                            st.metric("Agents Executed", len(regulatory.get("agents_executed", [])))
                            st.metric("Enforcement Steps", regulatory.get("enforcement_steps", 0))
                            
                            # Display policy trace map
                            with st.expander("🗺️ Policy Trace Map"):
                                trace_map = regulatory.get("policy_trace_map", {})
                                for agent, policies in trace_map.items():
                                    st.write(f"**{agent}:**")
                                    for policy in policies:
                                        st.code(policy)
                        else:
                            st.json({
                                "compliance_applied": result.get("compliance_applied", False),
                                "access_granted": result.get("access_granted", True),
                                "encrypted": result.get("encrypted", False),
                                "audit_id": result.get("audit_id", "N/A")
                            })
                    
                    # Full response (expandable)
                    with st.expander("🔍 View Full Response"):
                        st.json(result)
    
    # Tab 2: Audit Logs
    with tab2:
        st.header("Audit Trail")
        
        # Refresh button
        col1, col2, col3 = st.columns([1, 1, 4])
        with col1:
            log_limit = st.number_input("Limit", min_value=5, max_value=100, value=10, step=5)
        with col2:
            if st.button("🔄 Refresh Logs"):
                st.rerun()
        
        # Fetch and display logs
        audit_data = fetch_audit_logs(limit=log_limit)
        logs = audit_data.get("logs", [])
        
        if not logs:
            st.info("📭 No audit logs available")
        else:
            st.success(f"📊 Showing {len(logs)} recent audit log(s)")
            
            for idx, log in enumerate(logs):
                with st.expander(f"🔍 Log {idx + 1}: {log.get('action', 'Unknown')} - {log.get('timestamp', 'N/A')[:19]}"):
                    col1, col2 = st.columns(2)
                    
                    with col1:
                        st.markdown("**Details:**")
                        st.json({
                            "action": log.get("action"),
                            "user_role": log.get("user_role"),
                            "request_type": log.get("request_type"),
                            "timestamp": log.get("timestamp", "")[:19]
                        })
                    
                    with col2:
                        st.markdown("**Metadata:**")
                        metadata = log.get("metadata", {})
                        if metadata:
                            st.json(metadata)
                        else:
                            st.info("No metadata")
    
    # Tab 3: About
    with tab3:
        st.header("About Compliance AI")
        
        st.markdown("""
        ### 🛡️ Healthcare Privacy & Compliance System
        
        This system provides **plug-and-play compliance** for healthcare applications with:
        
        #### ✨ Features
        - **🔒 PII Detection & Masking**: Automatically detects and masks sensitive information (SSN, email, phone, DOB)
        - **👥 Role-Based Access Control**: Different permissions for clinicians, nurses, admins, patients
        - **📝 Comprehensive Audit Trail**: Every action is logged with cryptographic verification
        - **🔐 Data Encryption**: Sensitive data encrypted at rest and in transit
        - **⏱️ Data Retention**: Automatic data lifecycle management
        - **🔌 Plug & Play**: Enable/disable compliance with a single click
        
        #### 🏗️ Architecture
        - **Backend**: FastAPI (Python) on port 8000
        - **Frontend**: Streamlit (Python) on port 8501
        - **Workflow Engine**: LangGraph for compliance pipeline
        - **Storage**: Secure encrypted storage with retention policies
        
        #### 📚 Regulations Supported
        - HIPAA (Health Insurance Portability and Accountability Act)
        - GDPR (General Data Protection Regulation)
        - CCPA (California Consumer Privacy Act)
        - AI Act (EU Artificial Intelligence Act)
        - DPDPA (Digital Personal Data Protection Act, India)
        - PCI DSS (Payment Card Industry Data Security Standard)
        
        #### 🚀 Quick Start
        ```bash
        # Start backend
        ./start_backend.sh
        
        # Start frontend (this app)
        ./start_frontend.sh
        ```
        
        #### 📖 API Documentation
        - Interactive API Docs: http://localhost:8000/docs
        - Health Check: http://localhost:8000/api/health
        """)
        
        st.markdown("---")
        st.info("💡 **Tip**: Toggle compliance on/off to see how PII masking works in real-time!")

if __name__ == "__main__":
    main()
