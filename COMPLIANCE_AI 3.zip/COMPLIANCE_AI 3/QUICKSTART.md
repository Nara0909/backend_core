# 🚀 QUICK START - 5 Minutes to Running System

## Option 1: Fastest Start (All-in-One)

```bash
# 1. Navigate to project
cd /Users/chakravarthynara/Documents/COMPLIANCE_AI

# 2. Activate virtual environment
source .venv/bin/activate

# 3. Start everything
./start_all.sh
```

**That's it!** 🎉

- Frontend: http://localhost:3000
- Backend: http://localhost:8000
- API Docs: http://localhost:8000/api/docs

---

## Option 2: Manual Start (Step by Step)

### Terminal 1 - Backend
```bash
cd /Users/chakravarthynara/Documents/COMPLIANCE_AI
source .venv/bin/activate
./start_backend.sh
```

Wait for: `Application startup complete`

### Terminal 2 - Frontend
```bash
cd /Users/chakravarthynara/Documents/COMPLIANCE_AI
./start_frontend.sh
```

---

## 🧪 Test in 30 Seconds

### Test 1: Health Check
```bash
curl http://localhost:8000/api/health
```

### Test 2: Toggle Compliance
```bash
# Disable
curl -X POST http://localhost:8000/api/compliance/disable

# Enable
curl -X POST http://localhost:8000/api/compliance/enable
```

### Test 3: Process Data
```bash
curl -X POST http://localhost:8000/api/process \
  -H "Content-Type: application/json" \
  -d '{"input_text":"Patient SSN: 123-45-6789","request_type":"patient_triage"}'
```

---

## 🎨 Use the Frontend

1. Open: http://localhost:3000
2. Click **"Disable Compliance"**
3. Enter: `Patient John Doe, SSN: 123-45-6789, has diabetes`
4. Click **"Process Request"**
5. See: PII is NOT masked ❌

6. Click **"Enable Compliance"**
7. Enter same text
8. Click **"Process Request"**
9. See: PII is MASKED ✅ (SSN → [REDACTED])

---

## 📊 What You Get

### With Compliance ON ✅
- PII/PHI masking
- Data encryption
- Full audit trail
- GDPR/HIPAA compliant
- 6+ compliance agents active

### With Compliance OFF ❌
- No masking
- No encryption
- No audit logs
- Fast but non-compliant
- Direct bypass mode

---

## 🔌 API Endpoints You Can Use

```
POST /api/compliance/enable    - Turn on compliance
POST /api/compliance/disable   - Turn off compliance
GET  /api/compliance/status    - Check if enabled
POST /api/process              - Process healthcare data
GET  /api/audit/logs           - View audit trail
GET  /api/policies             - List policies
GET  /api/health               - Health check
```

---

## 🛠️ Troubleshooting

**Backend won't start?**
```bash
# Check port
lsof -i :8000
kill -9 <PID>  # if occupied

# Reinstall dependencies
pip install -r requirements.txt
```

**Frontend can't connect?**
```bash
# Verify backend is up
curl http://localhost:8000/api/health

# Check browser console for errors
```

**Need environment variables?**
```bash
# Create .env file
echo "OPENAI_API_KEY=your_key" > .env
echo "APP_ENCRYPTION_KEY=$(python -c 'from cryptography.fernet import Fernet; print(Fernet.generate_key().decode())')" >> .env
echo "AUDIT_HMAC_SECRET=your_secret" >> .env
```

---

## 📚 Next Steps

1. **Read full docs:** See `README.md`
2. **View architecture:** See `ARCHITECTURE.md`
3. **Setup guide:** See `SETUP.md`
4. **Run demo:** `python demo.py`
5. **Run tests:** `python test_api.py`
6. **Integration:** See `integration_examples.py`

---

## ✅ Success Checklist

- [ ] Backend starts on port 8000
- [ ] Frontend accessible on port 3000
- [ ] Health endpoint returns "healthy"
- [ ] Can toggle compliance ON/OFF
- [ ] Process endpoint works
- [ ] PII is masked when compliance ON
- [ ] PII is visible when compliance OFF
- [ ] Audit logs show when compliance ON
- [ ] Frontend reflects backend status

---

**You're Ready! 🎉**

Your plug-and-play compliance backend is running!
Toggle compliance to see instant privacy control.
