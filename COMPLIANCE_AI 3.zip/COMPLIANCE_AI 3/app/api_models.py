"""
API Models and Schemas

Pydantic models for request/response validation in FastAPI.
"""

from pydantic import BaseModel, Field
from typing import List, Dict, Any, Optional
from datetime import datetime


# ============================================================
# REQUEST MODELS
# ============================================================

class ProcessRequest(BaseModel):
    """Request model for processing healthcare data."""
    
    input_text: str = Field(
        ...,
        description="Input text to process (may contain PHI/PII)",
        example="Patient John Doe (DOB: 1985-03-15, SSN: 123-45-6789) reports chest pain"
    )
    
    request_type: str = Field(
        default="patient_triage",
        description="Type of healthcare request",
        example="patient_triage"
    )
    
    user_role: Optional[str] = Field(
        default="clinician",
        description="Role of the user making the request",
        example="clinician"
    )
    
    regulations: Optional[List[str]] = Field(
        default=None,
        description="Specific regulations to enforce (default: all)",
        example=["HIPAA", "GDPR"]
    )
    
    class Config:
        json_schema_extra = {
            "example": {
                "input_text": "Patient needs appointment for diabetes checkup. Contact: john@email.com, 555-1234",
                "request_type": "appointment_scheduling",
                "user_role": "clinician",
                "regulations": ["HIPAA", "GDPR"]
            }
        }


# ============================================================
# RESPONSE MODELS
# ============================================================

class ProcessResponse(BaseModel):
    """Response model for processed requests."""
    
    success: bool = Field(..., description="Whether processing succeeded")
    compliance_enabled: bool = Field(..., description="Whether compliance was enforced")
    compliance_applied: bool = Field(..., description="Whether compliance was actually applied")
    original_input: str = Field(..., description="Original input text")
    processed_output: str = Field(..., description="Final processed output")
    output_text: str = Field(..., description="Final output text")
    masked_input: Optional[str] = Field(None, description="Privacy-masked version of input")
    pii_detected: List[Dict[str, Any]] = Field(default_factory=list, description="List of PII entities detected")
    access_granted: bool = Field(True, description="Whether access was granted")
    encrypted: bool = Field(False, description="Whether data was encrypted")
    audit_id: str = Field("N/A", description="Audit trail ID")
    audit_log: List[Dict[str, Any]] = Field(default_factory=list, description="Audit trail of all actions")
    policies_applied: List[str] = Field(default_factory=list, description="Policy IDs that were enforced")
    execution_path: List[str] = Field(default_factory=list, description="Sequence of agents executed")
    regulatory_compliance: Optional[Dict[str, Any]] = Field(None, description="Regulatory compliance trace with regulation mapping")
    timestamp: str = Field(..., description="Processing timestamp (ISO format)")
    message: str = Field(..., description="Status message")
    
    class Config:
        json_schema_extra = {
            "example": {
                "success": True,
                "compliance_enabled": True,
                "original_input": "Patient John Doe needs appointment",
                "processed_output": "Patient [REDACTED] needs appointment",
                "masked_input": "Patient [NAME] needs appointment",
                "audit_log": [{"agent": "PrivacyAgent", "action": "mask_phi"}],
                "policies_applied": ["hipaa_rule_001", "gdpr_article_32"],
                "execution_path": ["AccessControlAgent", "PrivacyAgent", "OutputGuardAgent", "AuditAgent"],
                "timestamp": "2025-12-17T10:30:00Z",
                "message": "✅ Compliance ENABLED - Request processed with full privacy controls"
            }
        }


class ComplianceStatusResponse(BaseModel):
    """Response model for compliance status."""
    
    enabled: bool = Field(..., description="Whether compliance is currently enabled")
    updated_at: str = Field(..., description="When compliance state was last updated")
    enforced_regulations: List[str] = Field(default_factory=list, description="Active regulations")
    active_agents: List[str] = Field(default_factory=list, description="Agents in enforcement pipeline")
    
    class Config:
        json_schema_extra = {
            "example": {
                "enabled": True,
                "updated_at": "2025-12-17T10:00:00Z",
                "enforced_regulations": ["GDPR", "HIPAA", "PCI-DSS", "AI Act"],
                "active_agents": ["AccessControlAgent", "PrivacyAgent", "OutputGuardAgent", "AuditAgent"]
            }
        }


class AuditLogResponse(BaseModel):
    """Response model for audit logs."""
    
    total_logs: int = Field(..., description="Total number of logs returned")
    logs: List[Dict[str, Any]] = Field(default_factory=list, description="Audit log entries")
    compliance_enabled: bool = Field(..., description="Current compliance status")
    timestamp: str = Field(..., description="Response timestamp")
    
    class Config:
        json_schema_extra = {
            "example": {
                "total_logs": 5,
                "logs": [
                    {"agent": "PrivacyAgent", "action": "mask_phi", "timestamp": "2025-12-17T10:30:00Z"},
                    {"agent": "AuditAgent", "action": "log_decision", "timestamp": "2025-12-17T10:30:01Z"}
                ],
                "compliance_enabled": True,
                "timestamp": "2025-12-17T10:35:00Z"
            }
        }


class PolicyInfo(BaseModel):
    """Model for policy information."""
    
    name: str = Field(..., description="Human-readable policy name")
    file_name: str = Field(..., description="Policy file name")
    regulation_type: str = Field(..., description="Type of regulation")
    enabled: bool = Field(..., description="Whether this policy is currently enforced")
    path: str = Field(..., description="Full path to policy file")
    
    class Config:
        json_schema_extra = {
            "example": {
                "name": "HIPAA",
                "file_name": "hipaa.json",
                "regulation_type": "hipaa",
                "enabled": True,
                "path": "/path/to/hipaa.json"
            }
        }


class HealthResponse(BaseModel):
    """Response model for health check."""
    
    status: str = Field(..., description="Health status")
    timestamp: str = Field(..., description="Current server time")
    compliance_enabled: bool = Field(..., description="Compliance enforcement status")
    version: str = Field(..., description="API version")
    
    class Config:
        json_schema_extra = {
            "example": {
                "status": "healthy",
                "timestamp": "2025-12-17T10:00:00Z",
                "compliance_enabled": True,
                "version": "1.0.0"
            }
        }


class ErrorResponse(BaseModel):
    """Standard error response model."""
    
    error: str = Field(..., description="Error type")
    message: str = Field(..., description="Error message")
    details: Optional[Dict[str, Any]] = Field(None, description="Additional error details")
    timestamp: str = Field(..., description="Error timestamp")
    
    class Config:
        json_schema_extra = {
            "example": {
                "error": "ValidationError",
                "message": "Invalid request format",
                "details": {"field": "input_text", "issue": "Required field missing"},
                "timestamp": "2025-12-17T10:00:00Z"
            }
        }
