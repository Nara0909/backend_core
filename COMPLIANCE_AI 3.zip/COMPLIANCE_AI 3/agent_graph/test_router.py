import os
import sys
from pathlib import Path


# Ensure project root on sys.path when run as a script
def _ensure_project_root():
    p = Path(__file__).resolve().parent
    for _ in range(6):
        if (p / 'policy_generator').exists() or (p / 'requirements.txt').exists():
            root = str(p)
            if root not in sys.path:
                sys.path.insert(0, root)
            return
        p = p.parent


_ensure_project_root()

from agent_graph.graph import router_node, route_next
from policy_generator.policy_graph.policy_engine.enforcement_plan import (
    build_enforcement_plan
)

def test_router_with_real_policy():
    # 🔹 Get REAL enforcement plan from policy graph
    region = os.environ.get("APPLICATION_REGION") or os.environ.get("APP_REGION")

    enforcement_plan = build_enforcement_plan(
        request_type="PatientTriage",
        application_region=region,
    )


    state = {
        "request_type": "Patient Triage",
        "regulation": "HIPAA",
        "enforcement_plan": enforcement_plan,
        "application_region": region,
        "execution_queue": [],
        "audit_log": []
    }

    print("\n--- Enforcement Plan ---")
    for step in enforcement_plan["enforcement_steps"]:
        print(step["agent"], "→ policies:", len(step.get("policy_trace", [])))

    print("\n--- Running router_node ---")
    state = router_node(state)

    print("\nExecution Queue:")
    print(state["execution_queue"])

    print("\nPolicy Trace Map:")
    for agent, traces in state.get("policy_trace_map", {}).items():
        print(agent)
        for t in traces:
            print("  ", t)

    print("\n--- Stepping through route_next ---")
    while True:
        step = route_next(state)
        if step == "END":
            print("END")
            break
        print("Next step:", step)

if __name__ == "__main__":
    test_router_with_real_policy()
