# 🛡️ Regulatory Compliance Flow Documentation

## Overview

The Compliance AI system implements a complete regulatory compliance workflow where:

1. **Input text flows through an enforcement plan**
2. **Regulations are mapped to specific agents** (HIPAA, GDPR, PCI-DSS, AI Act, etc.)
3. **Agents execute based on policy traces**
4. **Response includes full regulatory compliance trace**

---

## Architecture Flow

```
Input Text
    ↓
Enforcement Plan (with regulations)
    ↓
Router Node (builds execution queue)
    ↓
Agent Execution (based on enforcement plan)
    ↓  ↓  ↓  ↓
    AccessControlAgent → PrivacyAgent → TaskAgent → OutputGuardAgent → AuditAgent
    ↓
Final State (with regulatory trace)
    ↓
API Response (includes compliance details)
```

---

## Enforcement Plan Structure

The enforcement plan is automatically generated based on the request type and contains:

```python
enforcement_plan = {
    "regulations": ["GDPR", "HIPAA", "PCI-DSS", "AI Act"],  # Applicable regulations
    "enforcement_steps": [
        {
            "agent": "AccessControlAgent",
            "actions": ["check_role_permissions", "verify_data_access_rights"],
            "policy_trace": [
                "GDPR Article 32 (Access Control)",
                "HIPAA 164.312(a)(1)"
            ],
            "regulation": "GDPR, HIPAA"
        },
        {
            "agent": "PrivacyAgent",
            "actions": ["mask_phi", "anonymize_input", "detect_pii"],
            "policy_trace": [
                "HIPAA 164.502 (PHI Protection)",
                "GDPR Article 32 (Data Minimization)",
                "CCPA 1798.100 (Consumer Privacy)"
            ],
            "regulation": "HIPAA, GDPR, CCPA"
        },
        # ... more steps
    ]
}
```

---

## How Regulations Drive Agent Execution

### Step 1: Enforcement Plan Creation

Based on the request type, the system determines applicable regulations:

- **Base Regulations**: GDPR, HIPAA (always applied)
- **Clinical Requests**: + PCI-DSS
- **AI Model Requests**: + AI Act
- **Custom**: User can specify regulations in request

### Step 2: Router Node Processing

The `router_node` in [agent_graph/graph.py](agent_graph/graph.py):

1. Reads the `enforcement_plan` from state
2. Extracts `enforcement_steps`
3. Builds `execution_queue` with agents to execute
4. Creates `policy_trace_map` mapping agents to policy traces

```python
def router_node(state):
    steps = state["enforcement_plan"]["enforcement_steps"]
    queue = []
    policy_trace_map = {}

    for step in steps:
        agent = step["agent"]
        queue.append(agent)
        policy_trace_map[agent] = step.get("policy_trace", [])

    state["execution_queue"] = queue
    state["policy_trace_map"] = policy_trace_map
    return state
```

### Step 3: Agent Execution

Each agent:

1. Receives the state with `policy_trace_map`
2. Executes actions defined in enforcement plan
3. Logs actions with associated policy traces
4. Updates state with results

Example from `privacy_node`:

```python
def privacy_node(state):
    agent = "PrivacyAgent"
    actions = _actions_for_agent(state, agent)  # From enforcement plan
    
    # Execute privacy masking
    original = state.get("input_text", "")
    masked, pii_detected = mask_phi(original)
    
    # Store results
    state["pii_detected"] = pii_detected
    state["masked_input"] = masked
    
    # Log with policy traces
    state["audit_log"].append({
        "agent": agent,
        "action": "mask_phi",
        "policy_trace_ids": state["policy_trace_map"].get(agent, [])
    })
    
    return state
```

### Step 4: Regulatory Compliance Trace

The final response includes complete regulatory information:

```json
{
  "regulatory_compliance": {
    "regulations_applied": ["GDPR", "HIPAA", "PCI-DSS", "AI Act"],
    "policy_trace_map": {
      "AccessControlAgent": [
        "GDPR Article 32 (Access Control)",
        "HIPAA 164.312(a)(1)"
      ],
      "PrivacyAgent": [
        "HIPAA 164.502 (PHI Protection)",
        "GDPR Article 32 (Data Minimization)",
        "CCPA 1798.100 (Consumer Privacy)"
      ],
      "OutputGuardAgent": [
        "GDPR Article 25 (Data Protection by Design)",
        "HIPAA 164.514 (De-identification)"
      ],
      "AuditAgent": [
        "GDPR Article 30 (Records of Processing)",
        "HIPAA 164.308(a)(1)(ii)(D) (Audit Controls)",
        "PCI-DSS 10.1 (Audit Trail)"
      ]
    },
    "enforcement_steps": 4,
    "agents_executed": [
      "AccessControlAgent",
      "PrivacyAgent",
      "PrivacyAgent",
      "OutputGuardAgent",
      "OutputGuardAgent",
      "OutputGuardAgent",
      "AuditAgent"
    ]
  }
}
```

---

## PII Detection Flow

### Detection Process

1. **Input arrives** at Privacy Agent
2. **Security module** (`security/pii.py`) scans for:
   - SSN patterns: `123-45-6789`
   - Email addresses: `user@domain.com`
   - Phone numbers: `555-1234`, `(555) 123-4567`
   - Names: `Patient John Doe`, `Dr. Smith`
3. **PII entities detected** and stored in state
4. **Text is masked** with placeholders: `[SSN]`, `[EMAIL]`, `[PHONE]`, `[NAME]`
5. **Results returned** in API response

### PII Detection Example

**Input:**
```
Patient John Doe (SSN: 123-45-6789, DOB: 1985-03-15) reports chest pain. 
Contact: john.doe@email.com, Phone: 555-123-4567
```

**Output:**
```
Patient [NAME] (SSN: [SSN], DOB: 1985-03-15) reports chest pain. 
Contact: [EMAIL], Phone: [PHONE]
```

**PII Detected:**
```json
[
  {"type": "SSN", "value": "123-45-6789", "masked": "[SSN]"},
  {"type": "EMAIL", "value": "john.doe@email.com", "masked": "[EMAIL]"},
  {"type": "PHONE", "value": "555-123-4567", "masked": "[PHONE]"},
  {"type": "NAME", "value": "John Doe", "masked": "[NAME]"}
]
```

---

## Testing the Regulatory Flow

### Using the Test Script

Run the comprehensive regulatory flow test:

```bash
python test_regulatory_flow.py
```

This test demonstrates:
- ✅ Compliance status check
- ✅ Enforcement plan execution
- ✅ Regulations mapping to agents
- ✅ Policy trace visibility
- ✅ PII detection and masking
- ✅ Complete audit trail
- ✅ Regulatory compliance summary

### Using the API Directly

```bash
curl -X POST "http://127.0.0.1:8000/api/process" \
  -H "Content-Type: application/json" \
  -d '{
    "input_text": "Patient John Doe (SSN: 123-45-6789) has chest pain",
    "request_type": "clinical_query",
    "user_role": "clinician"
  }'
```

### Using the Streamlit Dashboard

```bash
streamlit run ui/app.py
```

Navigate to http://localhost:8501 and:
1. Enter patient data with PII
2. Click "Process Request"
3. View **Regulatory Compliance** section showing:
   - Regulations Applied
   - Agents Executed
   - Policy Trace Map

---

## Key Components

### 1. Enforcement Plan Generator
- **Location**: [app/main.py](app/main.py) lines 186-219
- **Purpose**: Creates enforcement plan based on request type and regulations
- **Output**: Structured plan with agents, actions, and policy traces

### 2. Router Node
- **Location**: [agent_graph/graph.py](agent_graph/graph.py) lines 16-48
- **Purpose**: Converts enforcement plan to execution queue
- **Output**: Ordered list of agents to execute with policy mappings

### 3. Agent Nodes
- **Location**: [agent_graph/nodes.py](agent_graph/nodes.py)
- **Purpose**: Execute compliance actions with policy tracing
- **Agents**:
  - `access_control_node` - Role-based access control
  - `privacy_node` - PII detection and masking
  - `task_node` - LLM processing (when enabled)
  - `output_guard_node` - Output sanitization
  - `audit_node` - Logging and compliance recording

### 4. PII Detection Module
- **Location**: [security/pii.py](security/pii.py)
- **Functions**:
  - `detect_pii(text)` - Detects PII entities
  - `redact_and_detect(text)` - Masks PII and returns detection list
  - `redact_text(text)` - Masks PII only

### 5. State Management
- **Location**: [agent_graph/state.py](agent_graph/state.py)
- **Fields**:
  - `enforcement_plan` - Enforcement configuration
  - `regulations` - Applicable regulations
  - `execution_queue` - Agents to execute
  - `policy_trace_map` - Agent → Policy mapping
  - `pii_detected` - Detected PII entities
  - `audit_log` - Complete audit trail

---

## Supported Regulations

| Regulation | Acronym | Coverage |
|------------|---------|----------|
| General Data Protection Regulation | GDPR | Data privacy, consent, breach notification |
| Health Insurance Portability and Accountability Act | HIPAA | Protected Health Information (PHI) |
| Payment Card Industry Data Security Standard | PCI-DSS | Payment data security |
| California Consumer Privacy Act | CCPA | Consumer data rights |
| Artificial Intelligence Act | AI Act | AI system governance |
| Digital Personal Data Protection Act | DPDPA | Indian data protection |

---

## Compliance Features

### ✅ Access Control
- Role-based permissions (clinician, nurse, admin, patient)
- Data access verification
- Policy: GDPR Article 32, HIPAA 164.312(a)(1)

### ✅ Privacy Protection
- PII/PHI detection and masking
- Data minimization
- Anonymization
- Policy: HIPAA 164.502, GDPR Article 32, CCPA 1798.100

### ✅ Output Sanitization
- PII redaction from responses
- Data leakage prevention
- Public output safety
- Policy: GDPR Article 25, HIPAA 164.514

### ✅ Audit Logging
- Complete action trail
- Policy execution recording
- Regulatory compliance tracking
- Policy: GDPR Article 30, HIPAA 164.308(a)(1)(ii)(D), PCI-DSS 10.1

---

## API Response Structure

```json
{
  "success": true,
  "compliance_enabled": true,
  "compliance_applied": true,
  "original_input": "Patient John Doe...",
  "processed_output": "Patient [NAME]...",
  "masked_input": "Patient [NAME] (SSN: [SSN])...",
  "pii_detected": [
    {"type": "SSN", "value": "123-45-6789", "masked": "[SSN]"},
    {"type": "NAME", "value": "John Doe", "masked": "[NAME]"}
  ],
  "access_granted": true,
  "encrypted": false,
  "audit_id": "AUDIT-20251216-213720",
  "audit_log": [
    {
      "agent": "AccessControlAgent",
      "action": "check_role_permissions",
      "timestamp": "2025-12-16T21:37:20.693450",
      "status": "COMPLETED",
      "policy_trace_ids": ["GDPR Article 32 (Access Control)", "HIPAA 164.312(a)(1)"]
    }
    // ... more entries
  ],
  "policies_applied": [
    "GDPR Article 32 (Access Control)",
    "HIPAA 164.502 (PHI Protection)",
    // ... more policies
  ],
  "execution_path": [
    "AccessControlAgent",
    "PrivacyAgent",
    "OutputGuardAgent",
    "AuditAgent"
  ],
  "regulatory_compliance": {
    "regulations_applied": ["GDPR", "HIPAA", "PCI-DSS", "AI Act"],
    "policy_trace_map": {
      "AccessControlAgent": ["GDPR Article 32 (Access Control)", "HIPAA 164.312(a)(1)"],
      "PrivacyAgent": ["HIPAA 164.502 (PHI Protection)", "GDPR Article 32 (Data Minimization)"],
      "OutputGuardAgent": ["GDPR Article 25 (Data Protection by Design)"],
      "AuditAgent": ["GDPR Article 30 (Records of Processing)"]
    },
    "enforcement_steps": 4,
    "agents_executed": ["AccessControlAgent", "PrivacyAgent", "OutputGuardAgent", "AuditAgent"]
  },
  "timestamp": "2025-12-16T21:37:20.694806",
  "message": "✅ Compliance ENABLED - Request processed under GDPR, HIPAA, PCI-DSS, AI Act regulations"
}
```

---

## Configuration

### Enabling/Disabling Compliance

**Via API:**
```bash
# Enable compliance
curl -X POST "http://127.0.0.1:8000/api/compliance/enable"

# Disable compliance
curl -X POST "http://127.0.0.1:8000/api/compliance/disable"

# Check status
curl "http://127.0.0.1:8000/api/compliance/status"
```

**Via Streamlit UI:**
- Click "🔒 Enable Compliance" button
- Click "🔓 Disable Compliance" button

### When Compliance is Disabled
- Requests bypass all agents
- No PII masking
- No audit logging
- Faster but non-compliant
- Response includes warning message

---

## Troubleshooting

### Backend Not Running
```bash
./start_backend.sh
# OR
python -m uvicorn app.main:app --host 0.0.0.0 --port 8000 --reload
```

### Frontend Not Running
```bash
./start_frontend.sh
# OR
streamlit run ui/app.py
```

### PII Not Detected
1. Check that compliance is enabled
2. Verify backend has reloaded after code changes
3. Test PII detection directly:
```python
from security.pii import redact_and_detect
masked, pii_list = redact_and_detect("SSN: 123-45-6789")
print(pii_list)
```

### Regulatory Trace Not Showing
1. Ensure backend is running with latest code
2. Check that `regulatory_compliance` field is in API response
3. Verify `pii_detected` field is in AgentState TypedDict

---

## Future Enhancements

- [ ] Dynamic regulation selection based on data geography
- [ ] Custom enforcement plans per organization
- [ ] Real-time regulation updates from policy database
- [ ] Advanced NLP for PII detection (beyond regex)
- [ ] Consent management integration
- [ ] Automated compliance reporting
- [ ] Multi-language support for regulations

---

## References

- **GDPR**: https://gdpr.eu/
- **HIPAA**: https://www.hhs.gov/hipaa/
- **PCI-DSS**: https://www.pcisecuritystandards.org/
- **CCPA**: https://oag.ca.gov/privacy/ccpa
- **AI Act**: https://artificialintelligenceact.eu/
- **DPDPA**: https://www.meity.gov.in/

---

## Contact & Support

For questions or issues with the regulatory compliance flow:
1. Review this documentation
2. Check [ARCHITECTURE.md](ARCHITECTURE.md) for system design
3. See [QUICK_START.md](QUICK_START.md) for setup instructions
4. Run [test_regulatory_flow.py](test_regulatory_flow.py) to verify functionality

---

**Last Updated**: December 16, 2025  
**Version**: 1.0.0  
**Status**: ✅ Production Ready
