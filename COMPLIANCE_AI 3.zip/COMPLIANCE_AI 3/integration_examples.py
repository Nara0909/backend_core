"""
Integration Examples for Compliance AI Backend

This file shows how to integrate the Compliance AI backend
with different types of frontends and applications.
"""

# =============================================================================
# Example 1: Python Integration (Flask/Django/FastAPI Frontend)
# =============================================================================

import requests
from typing import Dict, Any

class ComplianceClient:
    """
    Python client for Compliance AI Backend
    Use this in your Flask, Django, or FastAPI frontend
    """
    
    def __init__(self, base_url: str = "http://localhost:8000/api"):
        self.base_url = base_url
    
    def check_compliance_status(self) -> Dict[str, Any]:
        """Check if compliance is currently enabled"""
        response = requests.get(f"{self.base_url}/compliance/status")
        return response.json()
    
    def enable_compliance(self) -> Dict[str, Any]:
        """Enable compliance enforcement"""
        response = requests.post(f"{self.base_url}/compliance/enable")
        return response.json()
    
    def disable_compliance(self) -> Dict[str, Any]:
        """Disable compliance enforcement"""
        response = requests.post(f"{self.base_url}/compliance/disable")
        return response.json()
    
    def process_healthcare_data(
        self,
        input_text: str,
        request_type: str = "patient_triage",
        user_role: str = "clinician",
        regulations: list = None
    ) -> Dict[str, Any]:
        """
        Process healthcare data with compliance enforcement
        
        Args:
            input_text: Text that may contain PHI/PII
            request_type: Type of healthcare request
            user_role: Role of the user making request
            regulations: List of regulations to enforce
        
        Returns:
            Processing result with masked data and audit trail
        """
        payload = {
            "input_text": input_text,
            "request_type": request_type,
            "user_role": user_role,
            "regulations": regulations or ["HIPAA", "GDPR"]
        }
        
        response = requests.post(
            f"{self.base_url}/process",
            json=payload
        )
        return response.json()


# Flask Example
# -----------------------------------------------------------------------------
def flask_integration_example():
    """
    Example: Integrating with Flask
    
    pip install flask flask-cors
    """
    from flask import Flask, request, jsonify
    from flask_cors import CORS
    
    app = Flask(__name__)
    CORS(app)
    
    # Initialize compliance client
    compliance = ComplianceClient()
    
    @app.route('/api/triage', methods=['POST'])
    def triage_patient():
        """Endpoint to triage a patient with compliance"""
        data = request.json
        patient_input = data.get('patient_data')
        
        # Process through compliance backend
        result = compliance.process_healthcare_data(
            input_text=patient_input,
            request_type='patient_triage',
            user_role=data.get('user_role', 'clinician')
        )
        
        return jsonify(result)
    
    @app.route('/api/compliance/toggle', methods=['POST'])
    def toggle_compliance():
        """Toggle compliance on/off"""
        enable = request.json.get('enable', True)
        
        if enable:
            result = compliance.enable_compliance()
        else:
            result = compliance.disable_compliance()
        
        return jsonify(result)
    
    # app.run(debug=True, port=5000)


# =============================================================================
# Example 2: JavaScript/React Integration
# =============================================================================

JAVASCRIPT_EXAMPLE = """
// JavaScript/React Integration Example
// ----------------------------------------------------------------------------

// Create a compliance service
class ComplianceService {
  constructor(baseURL = 'http://localhost:8000/api') {
    this.baseURL = baseURL;
  }

  async getStatus() {
    const response = await fetch(`${this.baseURL}/compliance/status`);
    return response.json();
  }

  async enableCompliance() {
    const response = await fetch(`${this.baseURL}/compliance/enable`, {
      method: 'POST'
    });
    return response.json();
  }

  async disableCompliance() {
    const response = await fetch(`${this.baseURL}/compliance/disable`, {
      method: 'POST'
    });
    return response.json();
  }

  async processRequest(inputText, requestType = 'patient_triage', userRole = 'clinician') {
    const response = await fetch(`${this.baseURL}/process`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        input_text: inputText,
        request_type: requestType,
        user_role: userRole,
        regulations: ['HIPAA', 'GDPR']
      })
    });
    return response.json();
  }
}

// React Component Example
function PatientTriageComponent() {
  const [complianceEnabled, setComplianceEnabled] = React.useState(true);
  const [result, setResult] = React.useState(null);
  const complianceService = new ComplianceService();

  const handleSubmit = async (patientData) => {
    const result = await complianceService.processRequest(
      patientData,
      'patient_triage',
      'clinician'
    );
    setResult(result);
  };

  const toggleCompliance = async () => {
    if (complianceEnabled) {
      await complianceService.disableCompliance();
    } else {
      await complianceService.enableCompliance();
    }
    setComplianceEnabled(!complianceEnabled);
  };

  return (
    <div>
      <button onClick={toggleCompliance}>
        {complianceEnabled ? 'Disable Compliance' : 'Enable Compliance'}
      </button>
      {/* Rest of your component */}
    </div>
  );
}
"""


# =============================================================================
# Example 3: Vue.js Integration
# =============================================================================

VUE_EXAMPLE = """
// Vue.js Integration Example
// ----------------------------------------------------------------------------

// Create a Vuex store module for compliance
const complianceModule = {
  state: {
    enabled: true,
    regulations: [],
    lastResult: null
  },
  
  mutations: {
    SET_COMPLIANCE_STATUS(state, enabled) {
      state.enabled = enabled;
    },
    SET_RESULT(state, result) {
      state.lastResult = result;
    }
  },
  
  actions: {
    async toggleCompliance({ commit, state }) {
      const endpoint = state.enabled ? 'disable' : 'enable';
      const response = await fetch(`http://localhost:8000/api/compliance/${endpoint}`, {
        method: 'POST'
      });
      const data = await response.json();
      commit('SET_COMPLIANCE_STATUS', data.enabled);
    },
    
    async processPatientData({ commit }, { patientData, requestType }) {
      const response = await fetch('http://localhost:8000/api/process', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          input_text: patientData,
          request_type: requestType,
          user_role: 'clinician'
        })
      });
      const result = await response.json();
      commit('SET_RESULT', result);
      return result;
    }
  }
};
"""


# =============================================================================
# Example 4: Mobile App Integration (React Native)
# =============================================================================

REACT_NATIVE_EXAMPLE = """
// React Native Integration Example
// ----------------------------------------------------------------------------

import AsyncStorage from '@react-native-async-storage/async-storage';

class ComplianceMobileClient {
  constructor() {
    this.baseURL = 'http://your-backend-url.com/api';
  }

  async processHealthcareData(patientData, requestType = 'patient_triage') {
    try {
      const response = await fetch(`${this.baseURL}/process`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': await this.getAuthToken()
        },
        body: JSON.stringify({
          input_text: patientData,
          request_type: requestType,
          user_role: 'clinician'
        })
      });

      const result = await response.json();
      
      // Cache result locally
      await AsyncStorage.setItem(
        'lastProcessingResult',
        JSON.stringify(result)
      );
      
      return result;
    } catch (error) {
      console.error('Processing failed:', error);
      throw error;
    }
  }

  async getAuthToken() {
    // Implement your auth logic
    return await AsyncStorage.getItem('authToken');
  }
}

// Usage in React Native Component
function PatientTriageScreen() {
  const [loading, setLoading] = useState(false);
  const complianceClient = new ComplianceMobileClient();

  const handlePatientTriage = async (patientData) => {
    setLoading(true);
    try {
      const result = await complianceClient.processHealthcareData(
        patientData,
        'patient_triage'
      );
      // Handle result
      console.log('Masked output:', result.processed_output);
    } catch (error) {
      Alert.alert('Error', 'Failed to process patient data');
    } finally {
      setLoading(false);
    }
  };

  return (
    <View>
      {/* Your mobile UI */}
    </View>
  );
}
"""


# =============================================================================
# Example 5: Command Line Interface
# =============================================================================

def cli_integration_example():
    """
    Example: Command-line interface for compliance system
    
    Usage:
        python integration_examples.py triage "Patient John Doe has diabetes"
        python integration_examples.py enable-compliance
        python integration_examples.py status
    """
    import sys
    import argparse
    
    parser = argparse.ArgumentParser(description='Compliance AI CLI')
    subparsers = parser.add_subparsers(dest='command')
    
    # Status command
    subparsers.add_parser('status', help='Check compliance status')
    
    # Enable/disable commands
    subparsers.add_parser('enable', help='Enable compliance')
    subparsers.add_parser('disable', help='Disable compliance')
    
    # Process command
    process_parser = subparsers.add_parser('process', help='Process healthcare data')
    process_parser.add_argument('text', help='Text to process')
    process_parser.add_argument('--type', default='patient_triage', help='Request type')
    
    args = parser.parse_args()
    
    compliance = ComplianceClient()
    
    if args.command == 'status':
        status = compliance.check_compliance_status()
        print(f"Compliance Enabled: {status['enabled']}")
        print(f"Regulations: {', '.join(status['enforced_regulations'])}")
    
    elif args.command == 'enable':
        result = compliance.enable_compliance()
        print("✅ Compliance enabled")
    
    elif args.command == 'disable':
        result = compliance.disable_compliance()
        print("❌ Compliance disabled")
    
    elif args.command == 'process':
        result = compliance.process_healthcare_data(
            args.text,
            request_type=args.type
        )
        print(f"\nOriginal: {result['original_input']}")
        print(f"Masked: {result.get('masked_input', 'N/A')}")
        print(f"Output: {result['processed_output']}")
        print(f"Audit Logs: {len(result['audit_log'])} entries")


# =============================================================================
# Example 6: Webhook Integration
# =============================================================================

def webhook_integration_example():
    """
    Example: Processing data from external webhooks
    Useful for integrating with EHR systems, scheduling software, etc.
    """
    from flask import Flask, request
    
    app = Flask(__name__)
    compliance = ComplianceClient()
    
    @app.route('/webhook/patient-created', methods=['POST'])
    def handle_patient_created():
        """
        Handle patient creation webhook from EHR system
        """
        data = request.json
        
        # Extract patient data
        patient_info = f"""
        Patient: {data.get('name')}
        DOB: {data.get('dob')}
        SSN: {data.get('ssn')}
        Email: {data.get('email')}
        Phone: {data.get('phone')}
        """
        
        # Process through compliance pipeline
        result = compliance.process_healthcare_data(
            input_text=patient_info,
            request_type='patient_registration'
        )
        
        # Store masked version in your database
        store_patient_data(result['masked_input'])
        
        # Log audit trail
        log_audit_trail(result['audit_log'])
        
        return {'status': 'success', 'masked': True}
    
    def store_patient_data(masked_data):
        # Your database storage logic
        pass
    
    def log_audit_trail(audit_log):
        # Your audit logging logic
        pass


# =============================================================================
# Example 7: Batch Processing Integration
# =============================================================================

def batch_processing_example():
    """
    Example: Processing multiple records in batch
    Useful for data migration, bulk imports, etc.
    """
    import pandas as pd
    
    compliance = ComplianceClient()
    
    # Load patient records
    df = pd.read_csv('patient_records.csv')
    
    results = []
    for _, row in df.iterrows():
        patient_text = f"""
        Patient: {row['name']}
        DOB: {row['dob']}
        SSN: {row['ssn']}
        Diagnosis: {row['diagnosis']}
        """
        
        # Process through compliance
        result = compliance.process_healthcare_data(
            input_text=patient_text,
            request_type='clinical_documentation'
        )
        
        results.append({
            'original_id': row['id'],
            'masked_output': result['processed_output'],
            'compliance_applied': result['compliance_enabled']
        })
    
    # Save masked results
    masked_df = pd.DataFrame(results)
    masked_df.to_csv('masked_patient_records.csv', index=False)
    
    print(f"Processed {len(results)} records with compliance")


# =============================================================================
# Print Examples
# =============================================================================

if __name__ == "__main__":
    print("=" * 80)
    print("  COMPLIANCE AI BACKEND - INTEGRATION EXAMPLES")
    print("=" * 80)
    
    print("\n1. Python Client:")
    print("-" * 80)
    print("   compliance = ComplianceClient()")
    print("   result = compliance.process_healthcare_data('Patient data...')")
    
    print("\n2. JavaScript/React:")
    print("-" * 80)
    print(JAVASCRIPT_EXAMPLE[:500] + "...")
    
    print("\n3. Vue.js:")
    print("-" * 80)
    print(VUE_EXAMPLE[:500] + "...")
    
    print("\n4. React Native:")
    print("-" * 80)
    print(REACT_NATIVE_EXAMPLE[:500] + "...")
    
    print("\n" + "=" * 80)
    print("For complete examples, see the source code of this file")
    print("=" * 80)
