from agent_graph.privacy_agent import mask_phi
from agent_graph.output_guard import redact_phi
from datetime import datetime
from security.access_control import allowed_to_view_logs
from security.audit import make_event, pseudonymize
from security.tokenization import tokenize_text
from security.encryption import encrypt_text
from security.logging_filter import setup_secure_logging
from typing import List


def _actions_for_agent(state, agent: str):
    steps = state.get("enforcement_plan", {}).get("enforcement_steps", [])
    for s in steps:
        if s.get("agent") == agent:
            return s.get("actions", [])
    return []


def access_control_node(state):
    agent = "AccessControlAgent"
    actions = _actions_for_agent(state, agent)

    # Always record role permission check
    state["audit_log"].append(
        make_event(
            agent,
            "check_role_permissions",
            {
                "policy_trace_ids": state.get("policy_trace_map", {}).get(agent, []),
                "user_role": state.get("user_role", "unknown"),
            },
        )
    )

    # Additional declared actions
    if "authorize_access" in actions:
        state["access_authorized"] = True
        state["audit_log"].append(
            make_event(agent, "authorize_access", {"policy_trace_ids": state.get("policy_trace_map", {}).get(agent, [])})
        )

    if "check_consent" in actions:
        state["consent_checked"] = True
        state["audit_log"].append(
            make_event(agent, "check_consent", {"policy_trace_ids": state.get("policy_trace_map", {}).get(agent, [])})
        )

    if "enforce_consent_scope" in actions:
        state["consent_scope_enforced"] = True
        state["audit_log"].append(
            make_event(agent, "enforce_consent_scope", {"policy_trace_ids": state.get("policy_trace_map", {}).get(agent, [])})
        )

    if "respond_access_request" in actions:
        state["access_request_response"] = "recorded"
        state["audit_log"].append(
            make_event(agent, "respond_access_request", {"policy_trace_ids": state.get("policy_trace_map", {}).get(agent, [])})
        )

    return state


def privacy_node(state):
    agent = "PrivacyAgent"
    actions = _actions_for_agent(state, agent)

    original = state.get("input_text", "")
    masked, pii_detected = mask_phi(original)
    
    # Store PII detection results in state
    state["pii_detected"] = pii_detected

    # Optional additional privacy actions
    if "anonymize_input" in actions:
        masked = tokenize_text(masked)
        state["audit_log"].append(make_event(agent, "anonymize_input", {"policy_trace_ids": state.get("policy_trace_map", {}).get(agent, [])}))

    if "pseudonymize" in actions:
        # Best-effort pseudonymization: replace any remaining capitalized tokens with pseudonyms
        def _pseudo_token(tok: str) -> str:
            try:
                return pseudonymize(tok)
            except Exception:
                return "hmac:xxxxxxxxxxxxxxx"

        masked = masked  # placeholder, already deidentified; real impl would target entities
        state["audit_log"].append(make_event(agent, "pseudonymize", {"policy_trace_ids": state.get("policy_trace_map", {}).get(agent, [])}))

    if "tokenize" in actions:
        masked = tokenize_text(masked)
        state["audit_log"].append(make_event(agent, "tokenize", {"policy_trace_ids": state.get("policy_trace_map", {}).get(agent, [])}))

    if "apply_data_minimization" in actions:
        # Simple minimization: truncate to 500 chars
        masked = masked[:500]
        state["audit_log"].append(make_event(agent, "apply_data_minimization", {"policy_trace_ids": state.get("policy_trace_map", {}).get(agent, [])}))

    if "encrypt_sensitive_fields" in actions:
        try:
            state["masked_input_encrypted"] = encrypt_text(masked)
            state["audit_log"].append(make_event(agent, "encrypt_sensitive_fields", {"policy_trace_ids": state.get("policy_trace_map", {}).get(agent, [])}))
        except Exception:
            # encryption optional; do not fail pipeline
            pass

    state["masked_input"] = masked

    # Never store raw input in audit; only deidentified output
    state["audit_log"].append(
        make_event(
            agent,
            "mask_phi",
            {
                "policy_trace_ids": state.get("policy_trace_map", {}).get(agent, []),
                "output_snapshot": masked,
                "pii_count": len(pii_detected)
            },
        )
    )
    return state


def task_node(state):
    # Not a governance agent
    state["llm_output"] = f"Triage result based on: {state['masked_input']}"
    return state


def output_guard_node(state):
    agent = "OutputGuardAgent"
    actions = _actions_for_agent(state, agent)

    # Always scan and redact
    cleaned = redact_phi(state.get("llm_output", ""))

    if "redact_pii" in actions:
        cleaned = redact_phi(cleaned)
        state["audit_log"].append(make_event(agent, "redact_pii", {"policy_trace_ids": state.get("policy_trace_map", {}).get(agent, [])}))

    if "sanitize_public_output" in actions:
        # Placeholder: same redaction pass, ensure minimal leakage
        cleaned = redact_phi(cleaned)
        state["audit_log"].append(make_event(agent, "sanitize_public_output", {"policy_trace_ids": state.get("policy_trace_map", {}).get(agent, [])}))

    if "produce_explanation" in actions:
        state["explanation"] = "Output was scanned for PII/PHI and sanitized according to policy."
        state["audit_log"].append(make_event(agent, "produce_explanation", {"policy_trace_ids": state.get("policy_trace_map", {}).get(agent, [])}))

    state["final_output"] = cleaned

    # Store only deidentified output
    state["audit_log"].append(
        make_event(
            agent,
            "scan_and_redact_output",
            {
                "policy_trace_ids": state.get("policy_trace_map", {}).get(agent, []),
                "output_snapshot": cleaned,
            },
        )
    )
    return state


def audit_node(state):
    agent = "AuditAgent"
    actions = _actions_for_agent(state, agent)

    # Ensure logging is configured if requested
    if "enable_audit_logging" in actions:
        try:
            setup_secure_logging()
            state["audit_log"].append(make_event(agent, "enable_audit_logging", {"policy_trace_ids": state.get("policy_trace_map", {}).get(agent, [])}))
        except Exception:
            pass

    if "record_model_version" in actions:
        try:
            from config.config import MODEL
            state["audit_log"].append(make_event(agent, "record_model_version", {"model": MODEL, "policy_trace_ids": state.get("policy_trace_map", {}).get(agent, [])}))
        except Exception:
            pass

    if "record_access_event" in actions:
        state["audit_log"].append(make_event(agent, "record_access_event", {"user_role": state.get("user_role"), "policy_trace_ids": state.get("policy_trace_map", {}).get(agent, [])}))

    # Always record policy execution
    state["audit_log"].append(
        make_event(
            agent,
            "record_policy_execution",
            {
                "policy_trace_ids": state.get("policy_trace_map", {}).get(agent, []),
                "final_output_snapshot": state.get("final_output"),
            },
        )
    )

    # Restrict verbose console output to roles allowed to view logs
    if allowed_to_view_logs(state.get("user_role", "unknown")):
        print("Final Audit Entry:")
        print(state["audit_log"][-1])

    return state


# -----------------------------
# Specialized Agents
# -----------------------------

def encryption_node(state):
    agent = "EncryptionAgent"
    actions = _actions_for_agent(state, agent)

    # Encrypt at rest: store encrypted copy of masked_input or final_output
    if "encrypt_at_rest" in actions:
        try:
            source = state.get("final_output") or state.get("masked_input") or state.get("input_text", "")
            state["data_encrypted_at_rest"] = encrypt_text(source)
            state["audit_log"].append(make_event(agent, "encrypt_at_rest", {"policy_trace_ids": state.get("policy_trace_map", {}).get(agent, [])}))
        except Exception:
            pass

    if "decrypt_for_authorized_use" in actions:
        state["audit_log"].append(make_event(agent, "decrypt_for_authorized_use", {"policy_trace_ids": state.get("policy_trace_map", {}).get(agent, [])}))

    if "manage_keys" in actions:
        state["audit_log"].append(make_event(agent, "manage_keys", {"policy_trace_ids": state.get("policy_trace_map", {}).get(agent, [])}))

    return state


def retention_node(state):
    agent = "RetentionAgent"
    actions = _actions_for_agent(state, agent)

    if "retain_for_period" in actions:
        state["retention_policy"] = "applied"
        state["audit_log"].append(make_event(agent, "retain_for_period", {"policy_trace_ids": state.get("policy_trace_map", {}).get(agent, [])}))

    if "delete_after_retention" in actions:
        state["retention_delete_scheduled"] = True
        state["audit_log"].append(make_event(agent, "delete_after_retention", {"policy_trace_ids": state.get("policy_trace_map", {}).get(agent, [])}))

    if "handle_erasure_request" in actions:
        state["erasure_request_handled"] = True
        state["audit_log"].append(make_event(agent, "handle_erasure_request", {"policy_trace_ids": state.get("policy_trace_map", {}).get(agent, [])}))

    return state


def incident_response_node(state):
    agent = "IncidentResponseAgent"
    actions = _actions_for_agent(state, agent)

    if "detect_incident" in actions:
        state["incident_detected"] = False
        state["audit_log"].append(make_event(agent, "detect_incident", {"policy_trace_ids": state.get("policy_trace_map", {}).get(agent, [])}))

    if "notify_breach" in actions:
        state["breach_notification_prepared"] = True
        state["audit_log"].append(make_event(agent, "notify_breach", {"policy_trace_ids": state.get("policy_trace_map", {}).get(agent, [])}))

    if "execute_mitigation" in actions:
        state["mitigation_plan_executed"] = True
        state["audit_log"].append(make_event(agent, "execute_mitigation", {"policy_trace_ids": state.get("policy_trace_map", {}).get(agent, [])}))

    return state


def model_governance_node(state):
    agent = "ModelGovernanceAgent"
    actions = _actions_for_agent(state, agent)

    if "validate_model" in actions:
        state["model_validated"] = True
        state["audit_log"].append(make_event(agent, "validate_model", {"policy_trace_ids": state.get("policy_trace_map", {}).get(agent, [])}))

    if "record_model_version" in actions:
        try:
            from config.config import MODEL
            state["audit_log"].append(make_event(agent, "record_model_version", {"model": MODEL, "policy_trace_ids": state.get("policy_trace_map", {}).get(agent, [])}))
        except Exception:
            state["audit_log"].append(make_event(agent, "record_model_version", {"policy_trace_ids": state.get("policy_trace_map", {}).get(agent, [])}))

    if "check_model_performance" in actions:
        state["model_performance_checked"] = True
        state["audit_log"].append(make_event(agent, "check_model_performance", {"policy_trace_ids": state.get("policy_trace_map", {}).get(agent, [])}))

    return state


def monitoring_node(state):
    agent = "MonitoringAgent"
    actions = _actions_for_agent(state, agent)

    if "monitor_usage" in actions:
        state["monitoring_enabled"] = True
        state["audit_log"].append(make_event(agent, "monitor_usage", {"policy_trace_ids": state.get("policy_trace_map", {}).get(agent, [])}))

    if "throttle_or_rate_limit" in actions:
        state["rate_limited"] = False
        state["audit_log"].append(make_event(agent, "throttle_or_rate_limit", {"policy_trace_ids": state.get("policy_trace_map", {}).get(agent, [])}))

    if "anomaly_detection" in actions:
        state["anomaly_detection"] = "armed"
        state["audit_log"].append(make_event(agent, "anomaly_detection", {"policy_trace_ids": state.get("policy_trace_map", {}).get(agent, [])}))

    return state
