from langgraph.graph import StateGraph, END
from agent_graph.state import AgentState
from agent_graph.nodes import (
    access_control_node,
    privacy_node,
    task_node,
    output_guard_node,
    audit_node,
    encryption_node,
    retention_node,
    incident_response_node,
    model_governance_node,
    monitoring_node,
)

def router_node(state):
    # Already initialized → do nothing
    if state.get("execution_queue"):
        return state

    steps = state["enforcement_plan"]["enforcement_steps"]
    queue = []
    policy_trace_map = {}

    for step in steps:
        agent = step["agent"]
        queue.append(agent)
        policy_trace_map[agent] = step.get("policy_trace", [])

        # Remove: TASK should NOT be added to backend pipeline
        # TASK (LLM) should be handled by frontend directly

    # Mandatory post-LLM safety - Run OutputGuard AFTER privacy
    if "PrivacyAgent" in queue and "OutputGuardAgent" not in queue:
        queue.insert(queue.index("PrivacyAgent") + 1, "OutputGuardAgent")

    # Ensure AuditAgent is always last
    if "AuditAgent" not in queue:
        queue.append("AuditAgent")
    elif "AuditAgent" in queue:
        # Move AuditAgent to end if it's not already there
        queue.remove("AuditAgent")
        queue.append("AuditAgent")

    state["execution_queue"] = queue
    state["policy_trace_map"] = policy_trace_map

    return state


def route_next(state):
    # Check if queue is empty FIRST
    if not state["execution_queue"]:
        return "END"

    next_step = state["execution_queue"].pop(0)
    state["current_agent"] = next_step
    
    return next_step


def build_graph():
    graph = StateGraph(AgentState)

    # Nodes
    graph.add_node("router", router_node)
    graph.add_node("access", access_control_node)
    graph.add_node("privacy", privacy_node)
    graph.add_node("task", task_node)
    graph.add_node("output_guard", output_guard_node)
    graph.add_node("audit", audit_node)
    graph.add_node("encryption", encryption_node)
    graph.add_node("retention", retention_node)
    graph.add_node("incident", incident_response_node)
    graph.add_node("model_gov", model_governance_node)
    graph.add_node("monitoring", monitoring_node)

    # Entry Point
    graph.set_entry_point("router")

    # Conditional Routing from router
    graph.add_conditional_edges(
        "router",
        route_next,
        {
            "AccessControlAgent": "access",
            "PrivacyAgent": "privacy",
            "EncryptionAgent": "encryption",
            "TASK": "task",
            "OutputGuardAgent": "output_guard",
            "ModelGovernanceAgent": "model_gov",
            "MonitoringAgent": "monitoring",
            "IncidentResponseAgent": "incident",
            "RetentionAgent": "retention",
            "AuditAgent": "audit",
            "PolicyAgent": "router",  # if you need governance fallback
            "END": END,
        }
    )

    # Loop back to router for all nodes EXCEPT audit
    graph.add_edge("access", "router")
    graph.add_edge("privacy", "router")
    graph.add_edge("encryption", "router")
    graph.add_edge("task", "router")
    graph.add_edge("output_guard", "router")
    graph.add_edge("model_gov", "router")
    graph.add_edge("monitoring", "router")
    graph.add_edge("incident", "router")
    graph.add_edge("retention", "router")
    
    # CRITICAL FIX: Audit goes directly to END
    graph.add_edge("audit", END)

    return graph