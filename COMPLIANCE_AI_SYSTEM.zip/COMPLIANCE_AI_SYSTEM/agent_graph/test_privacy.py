import os
import unittest
from security.pii import redact_text

class TestPIIRedaction(unittest.TestCase):
    def test_redact_email_phone(self):
        text = "Contact John Doe at john@example.com or 555-123-4567."
        out = redact_text(text)
        self.assertNotIn("john@example.com", out)
        self.assertNotIn("555-123-4567", out)
        self.assertIn("[EMAIL]", out)
        self.assertIn("[PHONE]", out)

if __name__ == '__main__':
    unittest.main()
