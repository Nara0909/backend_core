from typing import Optional
from security.encryption import encrypt_text, decrypt_text

# Minimal secure store abstraction; adapt to DB/Cloud as needed

def save_secret(value: str) -> str:
    """Encrypt value for storage and return ciphertext."""
    return encrypt_text(value)


def load_secret(token: str) -> Optional[str]:
    """Decrypt ciphertext value; return None if invalid."""
    try:
        return decrypt_text(token)
    except Exception:
        return None
