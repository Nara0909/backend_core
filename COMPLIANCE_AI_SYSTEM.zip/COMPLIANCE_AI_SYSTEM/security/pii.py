import re
from typing import List, Dict, Any, Tuple

# ==================================================
# REGEX PATTERNS
# ==================================================

EMAIL_RE = re.compile(
    r"[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}"
)

PHONE_RE = re.compile(
    r"(?:(?:\+?1[\s.-]?)?(?:\(\d{3}\)|\d{3})[\s.-]?\d{3}[\s.-]?\d{4})"
)

SSN_RE = re.compile(
    r"\b\d{3}-\d{2}-\d{4}\b"
)

# Name detection (conservative, deterministic)
NAME_PATTERNS = [
    # Patient John Doe / Dr. John Doe / Mr. John Doe
    re.compile(
        r"\b(?:Patient|Dr\.|Doctor|Mr\.|Mrs\.|Ms\.)\s+([A-Z][a-zA-Z]+(?:\s+[A-Z][a-zA-Z]+)*)"
    ),

    # Standalone First Last (minimum 2 tokens)
    re.compile(
        r"\b([A-Z][a-zA-Z]+(?:\s+[A-Z][a-zA-Z]+)+)\b"
    )
]


# ==================================================
# PII DETECTION
# ==================================================

def detect_pii(text: str) -> List[Dict[str, Any]]:
    """
    Detect PII entities in text using deterministic regex rules.

    Returns:
        List of dicts with:
        - type
        - value
        - masked
        - start
        - end
    """
    if not isinstance(text, str) or not text.strip():
        return []

    pii_found: List[Dict[str, Any]] = []

    # ---- SSN ----
    for match in SSN_RE.finditer(text):
        pii_found.append({
            "type": "SSN",
            "value": match.group(),
            "masked": "[SSN]",
            "start": match.start(),
            "end": match.end(),
        })

    # ---- EMAIL ----
    for match in EMAIL_RE.finditer(text):
        pii_found.append({
            "type": "EMAIL",
            "value": match.group(),
            "masked": "[EMAIL]",
            "start": match.start(),
            "end": match.end(),
        })

    # ---- PHONE ----
    for match in PHONE_RE.finditer(text):
        pii_found.append({
            "type": "PHONE",
            "value": match.group(),
            "masked": "[PHONE]",
            "start": match.start(),
            "end": match.end(),
        })

    # ---- NAMES ----
    for pattern in NAME_PATTERNS:
        for match in pattern.finditer(text):
            name = match.group(1)

            # Require at least First + Last
            if len(name.split()) < 2:
                continue

            start = match.start(1)
            end = match.end(1)

            # Avoid duplicates (overlapping spans)
            if any(
                start >= p["start"] and end <= p["end"]
                for p in pii_found
            ):
                continue

            pii_found.append({
                "type": "NAME",
                "value": name,
                "masked": "[NAME]",
                "start": start,
                "end": end,
            })

    return pii_found


# ==================================================
# REDACTION
# ==================================================

def redact_and_detect(text: str) -> Tuple[str, List[Dict[str, Any]]]:
    """
    Redact detected PII and return:
      - redacted_text
      - pii_entities
    """
    if not isinstance(text, str) or not text.strip():
        return text, []

    pii_entities = detect_pii(text)

    # Replace from right → left to preserve offsets
    redacted = text
    for pii in sorted(pii_entities, key=lambda x: x["start"], reverse=True):
        redacted = (
            redacted[:pii["start"]] +
            pii["masked"] +
            redacted[pii["end"]:]
        )

    return redacted, pii_entities


# ==================================================
# SIMPLE REDACTION HELPER (OPTIONAL)
# ==================================================

def redact_text(text: str) -> str:
    """
    Convenience wrapper if only redacted text is needed.
    """
    redacted, _ = redact_and_detect(text)
    return redacted
