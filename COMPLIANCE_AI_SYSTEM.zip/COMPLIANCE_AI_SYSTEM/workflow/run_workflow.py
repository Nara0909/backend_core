# workflow/run_workflow.py

import os
import sys
from pathlib import Path

# Ensure project root on sys.path when run as a script from anywhere
def _ensure_project_root():
    p = Path(__file__).resolve().parent
    for _ in range(6):
        if (p / 'policy_generator').exists() or (p / 'requirements.txt').exists():
            root = str(p)
            if root not in sys.path:
                sys.path.insert(0, root)
            return
        p = p.parent


_ensure_project_root()

from typing import Dict, Any
from security.logging_filter import setup_secure_logging
try:
    import truststore  # type: ignore
except Exception:  # pragma: no cover
    truststore = None



from agent_graph.graph import build_graph

from agent_graph.state import AgentState



from policy_generator.policy_graph.policy_engine.enforcement_plan import (

    build_enforcement_plan

)



from agent_graph.classifier.pure_clinical_nlp_classifier import (

    classify_clinical_request

)



# --------------------------------------------------

# MAIN WORKFLOW ENTRY

# --------------------------------------------------

def run_workflow(
    input_text: str,
    user_role: str = "clinician",
    application_region: str = None,
) -> Dict[str, Any]:

    """

    End-to-end secure healthcare workflow



    Responsibilities:

    - Classifier → request_type + clinical context

    - Policy Engine → regulations + enforcement controls

    - Graph → execution + audit

    """


    # --------------------------------------------------
    # 0️⃣ Initialize TLS truststore and secure logging
    # --------------------------------------------------
    if truststore is not None:
        truststore.inject_into_ssl()
    setup_secure_logging()

    # --------------------------------------------------
    # 1️⃣ Classify request type (PURE Clinical NLP)
    # --------------------------------------------------

    classification = classify_clinical_request(input_text)



    request_type = classification.get("request_type", "Unknown")



    if request_type == "Unknown":

        return {

            "error": "Unable to classify request type",

            "details": classification

        }



    # --------------------------------------------------

    # 2️⃣ Build Enforcement Plan (Policy Graph)

    # Regulations are resolved HERE

    # --------------------------------------------------

    enforcement_plan = build_enforcement_plan(
        request_type=request_type,
        application_region=application_region,
    )



    if not enforcement_plan:

        return {

            "error": "Failed to build enforcement plan",

            "request_type": request_type,
            "user_role": user_role,
            "application_region": application_region,
            "input_text": input_text,
        }



    # Extract regulation(s) from enforcement plan

    regulations = enforcement_plan.get("regulations", [])



    if not regulations:

        return {

            "error": "No regulations resolved by policy engine",

            "request_type": request_type,

            "enforcement_plan": enforcement_plan

        }



    # Strongest / primary regulation (policy engine decided)

    primary_regulation = regulations[0]



    # --------------------------------------------------

    # 3️⃣ Initialize LangGraph State

    # --------------------------------------------------

    state: AgentState = {

        # Request context

        "request_type": request_type,

        "user_role": user_role,

        "input_text": input_text,



        # Policy context (authoritative)

        "regulation": primary_regulation,

        "candidate_regulations": regulations,

        "enforcement_plan": enforcement_plan,



        # Execution

        "execution_queue": [],

        "policy_trace_map": {

            "policy_engine_regulations": regulations

        },



        # Data flow

        "masked_input": "",

        "llm_output": "",

        "final_output": "",



        # Audit

        "audit_log": []

    }



    # --------------------------------------------------

    # 4️⃣ Execute LangGraph

    # --------------------------------------------------

    app = build_graph()



    final_state = app.invoke(

        state,

        config={"recursion_limit": 50}

    )



    # --------------------------------------------------

    # 5️⃣ Return Secure Result

    # --------------------------------------------------

    return {

        "request_type": request_type,

        "confidence": classification.get("confidence"),

        "regulation": primary_regulation,

        "final_output": final_state.get("final_output"),

        "audit_log": final_state.get("audit_log"),

        "policy_trace_map": final_state.get("policy_trace_map"),

        "clinical_context": classification.get("clinical_context"),

    }





# --------------------------------------------------

# CLI TEST

# --------------------------------------------------

if __name__ == "__main__":

    text = "45-year-old diabetic male with chest pain and shortness of breath"



    region = os.environ.get("APPLICATION_REGION") or os.environ.get("APP_REGION")

    result = run_workflow(text, application_region=region)



    print("\n=== FINAL OUTPUT ===")

    print(result.get("final_output"))



    print("\n=== AUDIT LOG ===")

    for entry in result.get("audit_log", []):

        print(entry)