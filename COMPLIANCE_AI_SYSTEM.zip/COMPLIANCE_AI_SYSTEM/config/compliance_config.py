"""
Compliance Configuration

Access control, role-based permissions, and request type definitions.
"""

from typing import Dict, List, Set
from pydantic import BaseModel, Field
import sys
from pathlib import Path

# Add project root to path
project_root = Path(__file__).resolve().parent.parent
if str(project_root) not in sys.path:
    sys.path.insert(0, str(project_root))

# Import request types from policy generator
try:
    from policy_generator.request_types import REQUEST_TYPES as POLICY_REQUEST_TYPES
except ImportError:
    print("⚠️ Could not import REQUEST_TYPES from policy_generator, using defaults")
    POLICY_REQUEST_TYPES = {}


class AccessControlConfig(BaseModel):
    """Access control configuration"""
    
    # Role-based access control
    allowed_roles: Set[str] = Field(
        default={"visitor","admin", "clinician", "doctor", "nurse", "pharmacist", "receptionist", "billing_staff"},
        description="Roles allowed to access patient data"
    )
    
    denied_roles: Set[str] = Field(
        default={"guest", "anonymous", "suspended"},
        # default={"visitor", "guest", "anonymous", "suspended"},
        description="Roles explicitly denied access"
    )
    
    # Request-type specific access (auto-generated from POLICY_REQUEST_TYPES if available)
    request_type_permissions: Dict[str, Set[str]] = Field(
        default_factory=lambda: {
            req_type: set(meta.get("required_roles", []))
            for req_type, meta in POLICY_REQUEST_TYPES.items()
        } if POLICY_REQUEST_TYPES else {
            "patient_lookup": {"admin", "clinician", "doctor", "nurse"},
            "patient_triage": {"visitor","admin", "clinician", "doctor", "nurse", "pharmacist"},
            "appointment_scheduling": {"visitor","admin", "clinician", "doctor", "nurse", "receptionist"},
            "prescription": {"admin", "doctor", "pharmacist"},
            "lab_results": {"admin", "clinician", "doctor", "nurse"},
            "billing": {"admin", "billing_staff"},
            "clinical_decision": {"admin", "doctor", "clinician"},
        },
        description="Request types and which roles can access them"
    )
    
    # Default behavior
    default_allow: bool = Field(
        default=False,
        description="If True, allow unknown roles. If False, deny unknown roles."
    )
    
    def is_role_allowed(self, user_role: str, request_type: str = None) -> tuple[bool, str]:
        """
        Check if a role is allowed to perform a request.
        
        Returns:
            (allowed: bool, reason: str)
        """
        # Normalize role
        user_role = user_role.lower().strip()

        # 1. Check explicit denials first
        if user_role in self.denied_roles:
            return False, f"Role '{user_role}' is explicitly denied access"
        
        # 2. Check request-type specific permissions
        if request_type and request_type in self.request_type_permissions:
            print('request_type',request_type,user_role)
            allowed_for_request = self.request_type_permissions[request_type]
            if user_role not in allowed_for_request:
                return False, f"Role '{user_role}' cannot perform '{request_type}' operations"
        
        # 3. Check general allowed roles
        if user_role in self.allowed_roles:
            return True, f"Role '{user_role}' is authorized"
        
        # 4. Default behavior for unknown roles
        if self.default_allow:
            return True, f"Role '{user_role}' allowed by default policy"
        else:
            return False, f"Role '{user_role}' is not in authorized roles list,{self.allowed_roles}"


class ComplianceConfig(BaseModel):
    """Overall compliance configuration"""
    
    access_control: AccessControlConfig = Field(
        default_factory=AccessControlConfig,
        description="Access control settings"
    )
    
    # PII Detection settings
    pii_detection_enabled: bool = True
    pii_types_to_detect: List[str] = [
        "PERSON", "EMAIL_ADDRESS", "PHONE_NUMBER", 
        "SSN", "CREDIT_CARD", "DATE_OF_BIRTH",
        "MEDICAL_RECORD_NUMBER", "IP_ADDRESS"
    ]
    
    # Audit settings
    audit_enabled: bool = True
    audit_all_requests: bool = True
    
    # Regulations
    active_regulations: List[str] = ["GDPR", "HIPAA", "PCI_DSS", "EU_AI_ACT"]


# Global config instance
compliance_config = ComplianceConfig()

# Export valid request types from policy generator (or defaults)
VALID_REQUEST_TYPES = POLICY_REQUEST_TYPES if POLICY_REQUEST_TYPES else {
    "patient_triage": {
        "name": "Patient Triage",
        "description": "Initial patient assessment and symptom evaluation",
        "required_roles": ["admin", "clinician", "doctor", "nurse"],
        "regulations": ["GDPR", "HIPAA"]
    },
    "patient_lookup": {
        "name": "Patient Lookup",
        "description": "Retrieve patient medical records and history",
        "required_roles": ["admin", "clinician", "doctor", "nurse"],
        "regulations": ["GDPR", "HIPAA", "PCI_DSS"]
    },
    "appointment_scheduling": {
        "name": "Appointment Scheduling",
        "description": "Schedule or modify patient appointments",
        "required_roles": ["admin", "clinician", "doctor", "nurse", "receptionist"],
        "regulations": ["GDPR", "HIPAA"]
    },
    "prescription": {
        "name": "Prescription",
        "description": "Create or modify medication prescriptions",
        "required_roles": ["admin", "doctor", "pharmacist"],
        "regulations": ["GDPR", "HIPAA", "PCI_DSS"]
    },
    "lab_results": {
        "name": "Lab Results",
        "description": "View or process laboratory test results",
        "required_roles": ["admin", "clinician", "doctor", "nurse"],
        "regulations": ["GDPR", "HIPAA"]
    },
    "billing": {
        "name": "Billing",
        "description": "Process patient billing and insurance",
        "required_roles": ["admin", "billing_staff"],
        "regulations": ["GDPR", "PCI_DSS"]
    },
    "clinical_decision": {
        "name": "Clinical Decision Support",
        "description": "AI-assisted clinical decision making",
        "required_roles": ["admin", "doctor", "clinician"],
        "regulations": ["GDPR", "HIPAA", "EU_AI_ACT"]
    }
}


def get_valid_request_types():
    """Get list of valid request types"""
    return list(VALID_REQUEST_TYPES.keys())


def validate_request_type(request_type: str) -> bool:
    """Check if request type is valid"""
    return request_type in VALID_REQUEST_TYPES


def get_request_type_info(request_type: str):
    """Get detailed info about a request type"""
    return VALID_REQUEST_TYPES.get(request_type)


def load_config_from_file(filepath: str):
    """Load configuration from JSON file"""
    import json
    from pathlib import Path
    
    path = Path(filepath)
    if path.exists():
        with open(path, 'r') as f:
            data = json.load(f)
            global compliance_config
            compliance_config = ComplianceConfig(**data)
            print(f"✅ Loaded config from {filepath}")
    else:
        print(f"⚠️ Config file not found: {filepath}, using defaults")


def update_allowed_roles(roles: List[str]):
    """Dynamically update allowed roles"""
    compliance_config.access_control.allowed_roles = set(roles)
    print(f"✅ Updated allowed roles: {roles}")


def update_request_permissions(request_type: str, allowed_roles: List[str]):
    """Update permissions for a specific request type"""
    compliance_config.access_control.request_type_permissions[request_type] = set(allowed_roles)
    print(f"✅ Updated permissions for {request_type}: {allowed_roles}")