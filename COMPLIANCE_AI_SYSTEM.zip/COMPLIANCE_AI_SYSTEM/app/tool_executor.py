from datetime import datetime

def execute_tools(actions: list, input_text: str, user_role: str):
    """
    Executes compliance tools sequentially based on actions list
    """
    state = {
        "input_text": input_text,
        "masked_input": input_text,
        "pii_detected": [],
        "audit_log": [],
        "actions_executed": [],
    }

    for action in actions:
        # ---------------- ACCESS CONTROL ----------------
        if action == "check_role_permissions":
            if user_role == "visitor":
                raise PermissionError("Access denied for visitor role")

            state["actions_executed"].append(action)

        # ---------------- PII MASKING ----------------
        elif action in ("mask_phi", "anonymize_input", "detect_pii"):
            from security.pii import redact_and_detect

            masked, pii = redact_and_detect(state["masked_input"])
            state["masked_input"] = masked
            state["pii_detected"].extend(pii)
            state["actions_executed"].append(action)

        # ---------------- OUTPUT SANITIZATION ----------------
        elif action in ("redact_pii", "sanitize_public_output"):
            from security.pii import redact_and_detect

            sanitized, _ = redact_and_detect(state["masked_input"])
            state["masked_input"] = sanitized
            state["actions_executed"].append(action)

        # ---------------- AUDIT ----------------
        elif action == "log_decision":
            state["audit_log"].append({
                "action": action,
                "timestamp": datetime.utcnow().isoformat(),
                "status": "COMPLETED"
            })
            state["actions_executed"].append(action)

    return state
