from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from datetime import datetime
from typing import List, Dict, Set, Optional
from pathlib import Path
import sys
from config.config import (
    compliance_config,
    load_config_from_file,
    update_allowed_roles,
    update_request_permissions,
)

# To:
from config.compliance_config import (
    compliance_config,
    load_config_from_file,
    update_allowed_roles,
    update_request_permissions,
    VALID_REQUEST_TYPES,
    validate_request_type,
)
# --------------------------------------------------
# Project path
# --------------------------------------------------
project_root = Path(__file__).resolve().parent.parent
if str(project_root) not in sys.path:
    sys.path.insert(0, str(project_root))

# --------------------------------------------------
# Imports
# --------------------------------------------------
from app.compliance_state import ComplianceStateManager
from app.api_models import (
    ProcessRequest,
    ProcessResponse,
    HealthResponse,
    AuditLogResponse,
    PolicyInfo,
    ComplianceStatusResponse,
    CheckAccessRequest,
    MaskPIIRequest,
    SanitizeOutputRequest,
    LogComplianceActionRequest,
)
from config.config import (
    compliance_config,
    load_config_from_file,
    update_allowed_roles,
    update_request_permissions,
)
from policy_generator.policy_graph.resolver import resolve_policies_from_graph
from security.pii import redact_and_detect
from config.config import (
    compliance_config,
    load_config_from_file,
    update_allowed_roles,
    update_request_permissions,
    VALID_REQUEST_TYPES,  # Add this
    validate_request_type,  # Add this
)
# --------------------------------------------------
# App init
# --------------------------------------------------
app = FastAPI(
    title="Compliance AI Backend",
    description="Healthcare Compliance Backend (Policy-driven tools)",
    version="1.0.0",
    docs_url="/api/docs",
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

compliance_manager = ComplianceStateManager()

# Load config on startup
@app.on_event("startup")
async def startup_event():
    """Load configuration on startup"""
    
    # Try multiple possible locations
    possible_paths = [
        project_root / "config" / "config.json",
        project_root / "config.json",
        Path(__file__).parent / "config.json",
    ]
    
    config_file = None
    for path in possible_paths:
        print(f"🔍 Checking: {path}")
        if path.exists():
            config_file = path
            print(f"✅ Found config at: {config_file}")
            break
    
    if config_file and config_file.exists():
        load_config_from_file(str(config_file))
    else:
        print("⚠️ No config.json found in any expected location, using default configuration")
        print(f"   Searched locations:")
        for path in possible_paths:
            print(f"   - {path}")
    
    print(f"\n📋 Configuration loaded:")
    print(f"   ✅ Allowed roles: {compliance_config.access_control.allowed_roles}")
    print(f"   ❌ Denied roles: {compliance_config.access_control.denied_roles}")
# ==================================================
# REQUEST TYPES ENDPOINT
# ==================================================

@app.get("/api/request-types", tags=["Configuration"])
async def get_request_types():
    """Get available request types with metadata"""
    return {
        "request_types": VALID_REQUEST_TYPES,
        "count": len(VALID_REQUEST_TYPES)
    }


@app.get("/api/request-types/{request_type}", tags=["Configuration"])
async def get_request_type_info(request_type: str):
    """Get detailed information about a specific request type"""
    from config.config import get_request_type_info
    
    info = get_request_type_info(request_type)
    if not info:
        raise HTTPException(404, f"Request type '{request_type}' not found")
    
    return {
        "request_type": request_type,
        "info": info
    }
# ==================================================
# TOOL IMPLEMENTATIONS
# ==================================================

def tool_check_access(state: dict):
    """Check user access based on role and request type"""
    user_role = state.get("user_role", "").lower().strip()
    request_type = state.get("request_type", "")
    
    print(f"🔒 [AccessControl] Checking access")
    print(f"   Role: {user_role}")
    print(f"   Request Type: {request_type}")
    
    # Use config-based access check
    allowed, reason = compliance_config.access_control.is_role_allowed(
        user_role=user_role,
        request_type=request_type
    )
    
    state["access_granted"] = allowed
    state["deny_reason"] = reason if not allowed else ""
    
    if allowed:
        print(f"✅ [AccessControl] {reason}")
    else:
        print(f"❌ [AccessControl] {reason}")
    
    # Log to audit
    state["audit_log"].append({
        "agent": "AccessControlAgent",
        "action": "check_role_permissions",
        "result": "granted" if allowed else "denied",
        "user_role": user_role,
        "request_type": request_type,
        "reason": reason,
        "timestamp": datetime.utcnow().isoformat(),
    })
    
    return state


def tool_mask_pii(state: dict):
    """Detect and mask PII in input text"""
    print(f"🔍 [PrivacyAgent] Masking PII in input text")
    
    input_text = state.get("input_text", "")
    
    if not input_text:
        print(f"⚠️ [PrivacyAgent] No input text to mask")
        state["masked_input"] = ""
        state["pii_detected"] = []
        return state
    
    try:
        masked, pii = redact_and_detect(input_text)
        state["masked_input"] = masked
        state["pii_detected"] = pii
        
        print(f"✅ [PrivacyAgent] Masked {len(pii)} PII entities")
        if len(pii) > 0:
            print(f"   Original: {input_text[:80]}...")
            print(f"   Masked:   {masked[:80]}...")
            print(f"   PII types: {[p.get('type', 'UNKNOWN') for p in pii]}")
        
    except Exception as e:
        print(f"❌ [PrivacyAgent] Error masking PII: {e}")
        state["masked_input"] = input_text
        state["pii_detected"] = []
    
    # Log to audit
    state["audit_log"].append({
        "agent": "PrivacyAgent",
        "action": "mask_phi",
        "pii_count": len(state["pii_detected"]),
        "pii_types": [p.get("type") for p in state["pii_detected"]],
        "timestamp": datetime.utcnow().isoformat(),
    })
    
    return state


def tool_sanitize_output(state: dict):
    """Sanitize output text (remove any remaining PII)"""
    print(f"🧹 [OutputGuardAgent] Sanitizing output")
    
    text_to_sanitize = state.get("masked_input") or state.get("input_text", "")
    
    if not text_to_sanitize:
        print(f"⚠️ [OutputGuardAgent] No text to sanitize")
        state["final_output"] = ""
        return state
    
    try:
        sanitized, remaining_pii = redact_and_detect(text_to_sanitize)
        state["final_output"] = sanitized
        
        if remaining_pii:
            print(f"⚠️ [OutputGuardAgent] Found {len(remaining_pii)} additional PII entities")
            existing_texts = {p.get("text") for p in state.get("pii_detected", [])}
            for pii in remaining_pii:
                if pii.get("text") not in existing_texts:
                    state["pii_detected"].append(pii)
        else:
            print(f"✅ [OutputGuardAgent] Output is clean")
        
    except Exception as e:
        print(f"❌ [OutputGuardAgent] Error sanitizing: {e}")
        state["final_output"] = text_to_sanitize
    
    # Log to audit
    state["audit_log"].append({
        "agent": "OutputGuardAgent",
        "action": "sanitize_output",
        "additional_pii_found": len(remaining_pii) if remaining_pii else 0,
        "timestamp": datetime.utcnow().isoformat(),
    })
    
    return state


def tool_log_audit(state: dict):
    """Create final audit log entry"""
    print(f"📝 [AuditAgent] Logging compliance action")
    
    state["audit_log"].append({
        "agent": "AuditAgent",
        "action": "record_policy_execution",
        "request_type": state.get("request_type"),
        "user_role": state.get("user_role"),
        "access_granted": state.get("access_granted"),
        "pii_detected_count": len(state.get("pii_detected", [])),
        "regulations": state.get("regulations_applied", []),
        "timestamp": datetime.utcnow().isoformat(),
    })
    
    print(f"✅ [AuditAgent] Audit complete - {len(state['audit_log'])} entries")
    
    return state


# ==================================================
# ACTION → TOOL MAP
# ==================================================

ACTION_TO_TOOL = {
    "check_role_permissions": tool_check_access,
    "verify_data_access_rights": tool_check_access,
    "mask_phi": tool_mask_pii,
    "detect_pii": tool_mask_pii,
    "anonymize_input": tool_mask_pii,
    "redact_pii": tool_sanitize_output,
    "sanitize_public_output": tool_sanitize_output,
    "log_decision": tool_log_audit,
    "record_policy_path": tool_log_audit,
}

# ==================================================
# HEALTH
# ==================================================

@app.get("/api/health", response_model=HealthResponse, tags=["System"])
async def health():
    """Health check endpoint"""
    return {
        "status": "healthy",
        "timestamp": datetime.utcnow().isoformat(),
        "compliance_enabled": compliance_manager.is_enabled(),
        "version": "1.0.0",
    }

# ==================================================
# COMPLIANCE STATUS & TOGGLE
# ==================================================

@app.get("/api/compliance/status", response_model=ComplianceStatusResponse, tags=["Compliance"])
async def get_compliance_status():
    """Get current compliance enforcement status"""
    state = compliance_manager.get_state()
    return {
        "enabled": state["enabled"],
        "updated_at": state["updated_at"],
        "enforced_regulations": ["GDPR", "HIPAA", "PCI-DSS", "AI Act"] if state["enabled"] else [],
        "active_agents": [
            "AccessControlAgent",
            "PrivacyAgent",
            "OutputGuardAgent",
            "AuditAgent"
        ] if state["enabled"] else []
    }


@app.post("/api/compliance/enable", tags=["Compliance"])
async def enable_compliance():
    """Enable compliance enforcement"""
    compliance_manager.enable()
    state = compliance_manager.get_state()
    return {
        "enabled": True,
        "updated_at": state["updated_at"],
        "message": "Compliance enforcement enabled",
        "enforced_regulations": ["GDPR", "HIPAA", "PCI-DSS", "AI Act"],
    }


@app.post("/api/compliance/disable", tags=["Compliance"])
async def disable_compliance():
    """Disable compliance enforcement"""
    compliance_manager.disable()
    state = compliance_manager.get_state()
    return {
        "enabled": False,
        "updated_at": state["updated_at"],
        "message": "Compliance enforcement disabled",
        "enforced_regulations": [],
    }

# ==================================================
# ENFORCEMENT PLAN ENDPOINT
# ==================================================

@app.get("/api/enforcement-plan", tags=["Compliance"])
async def get_enforcement_plan(request_type: str = "patient_triage"):
    """
    Get the applicable enforcement plan for a request type.
    
    Frontend uses this to know which compliance tools to call and in what order.
    
    Args:
        request_type: Type of request (triage, scheduling, clinical_decision, etc.)
    
    Returns:
        Enforcement plan with agents, actions, regulations, policy traces
    """
    
    try:
        # Resolve policies from policy graph
        policy_result = resolve_policies_from_graph(request_type)
        
        return {
            "request_type": request_type,
            "regulations": policy_result.get("regulations", []),
            "agents": policy_result.get("agents", []),
            "actions": policy_result.get("actions", []),
            "policies": policy_result.get("policies", []),
            "enforcement_steps": [
                {
                    "agent": agent,
                    "actions": policy_result.get("actions", []),
                    "policies": [p.get("rule_id", "") for p in policy_result.get("policies", [])]
                }
                for agent in policy_result.get("agents", [])
            ]
        }
    except Exception as e:
        print(f"❌ Error resolving enforcement plan: {e}")
        import traceback
        traceback.print_exc()
        
        # Return fallback plan
        return {
            "request_type": request_type,
            "regulations": ["GDPR", "HIPAA"],
            "agents": ["AccessControlAgent", "PrivacyAgent", "OutputGuardAgent", "AuditAgent"],
            "actions": ["check_role_permissions", "mask_phi", "redact_pii", "log_decision"],
            "policies": [],
            "enforcement_steps": [
                {
                    "agent": "AccessControlAgent",
                    "actions": ["check_role_permissions"],
                    "policies": ["HIPAA 164.312(a)(1)"]
                },
                {
                    "agent": "PrivacyAgent",
                    "actions": ["mask_phi", "detect_pii"],
                    "policies": ["HIPAA 164.502", "GDPR Article 32"]
                },
                {
                    "agent": "OutputGuardAgent",
                    "actions": ["redact_pii"],
                    "policies": ["GDPR Article 25"]
                },
                {
                    "agent": "AuditAgent",
                    "actions": ["log_decision"],
                    "policies": ["GDPR Article 30", "HIPAA 164.308(a)(1)(ii)(D)"]
                }
            ],
            "error": str(e)
        }

# ==================================================
# CONFIG MANAGEMENT ENDPOINTS
# ==================================================

@app.get("/api/config/roles", tags=["Configuration"])
async def get_role_config():
    """Get current role configuration"""
    return {
        "allowed_roles": list(compliance_config.access_control.allowed_roles),
        "denied_roles": list(compliance_config.access_control.denied_roles),
        "default_allow": compliance_config.access_control.default_allow,
    }


@app.post("/api/config/roles/allowed", tags=["Configuration"])
async def update_allowed_roles_endpoint(roles: List[str]):
    """Update the list of allowed roles"""
    update_allowed_roles(roles)
    return {
        "success": True,
        "allowed_roles": list(compliance_config.access_control.allowed_roles),
        "message": f"Updated allowed roles: {roles}"
    }


@app.get("/api/config/permissions", tags=["Configuration"])
async def get_request_permissions():
    """Get request-type specific permissions"""
    return {
        "request_type_permissions": {
            k: list(v) for k, v in compliance_config.access_control.request_type_permissions.items()
        }
    }


@app.post("/api/config/permissions/{request_type}", tags=["Configuration"])
async def update_request_permissions_endpoint(
    request_type: str,
    roles: List[str]
):
    """Update permissions for a specific request type"""
    update_request_permissions(request_type, roles)
    return {
        "success": True,
        "request_type": request_type,
        "allowed_roles": roles,
        "message": f"Updated permissions for {request_type}"
    }


@app.post("/api/config/check-role", tags=["Configuration"])
async def check_role_permission(
    user_role: str,
    request_type: str = None
):
    """Test if a role has permission for a request type"""
    allowed, reason = compliance_config.access_control.is_role_allowed(
        user_role=user_role,
        request_type=request_type
    )
    
    return {
        "user_role": user_role,
        "request_type": request_type,
        "allowed": allowed,
        "reason": reason
    }

# ==================================================
# INDIVIDUAL COMPLIANCE TOOLS
# ==================================================

@app.post("/api/check-access", tags=["Compliance Tools"])
async def check_access(request: CheckAccessRequest):
    """Check user access based on role"""
    user_role = request.user_role or "clinician"
    request_type = request.request_type or "patient_triage"
    
    state = {
        "user_role": user_role,
        "request_type": request_type,
        "access_granted": True,
        "deny_reason": "",
        "audit_log": [],
    }
    
    # Use the access control tool
    state = tool_check_access(state)
    
    return {
        "success": True,
        "access_granted": state["access_granted"],
        "user_role": state["user_role"],
        "request_type": request_type,
        "deny_reason": state.get("deny_reason", ""),
        "message": "Access granted" if state["access_granted"] else state.get("deny_reason"),
        "regulations": ["HIPAA", "GDPR"],
        "audit_log": state.get("audit_log", []),
    }


@app.post("/api/mask-pii", tags=["Compliance Tools"])
async def mask_pii(request: MaskPIIRequest):
    """Detect and mask PII in input text"""
    text = request.input_text or request.text or ""
    
    if not text:
        raise HTTPException(400, "No text provided. Use 'input_text' or 'text' field")
    
    try:
        masked, pii_list = redact_and_detect(text)
        
        return {
            "success": True,
            "original_text": text,
            "masked_text": masked,
            "pii_detected": pii_list,
            "pii_count": len(pii_list),
            "message": f"Detected and masked {len(pii_list)} PII entities",
        }
    except Exception as e:
        raise HTTPException(500, f"PII masking failed: {str(e)}")


@app.post("/api/sanitize-output", tags=["Compliance Tools"])
async def sanitize_output(request: SanitizeOutputRequest):
    """Remove PII from LLM output"""
    text = request.output_text or request.text or ""
    
    if not text:
        raise HTTPException(400, "No text provided. Use 'output_text' or 'text' field")
    
    try:
        sanitized, pii_detected = redact_and_detect(text)
        safe_to_store = len(pii_detected) == 0
        
        return {
            "success": True,
            "original_output": text,
            "sanitized_output": sanitized,
            "pii_detected_in_output": pii_detected,
            "safe_to_store": safe_to_store,
            "message": f"Output sanitized. Safe to store: {safe_to_store}",
        }
    except Exception as e:
        raise HTTPException(500, f"Output sanitization failed: {str(e)}")


@app.post("/api/log-compliance-action", tags=["Compliance Tools"])
async def log_compliance_action(request: LogComplianceActionRequest):
    """Create compliance audit log entry"""
    audit_id = request.audit_id or f"AUDIT-{datetime.utcnow().strftime('%Y%m%d-%H%M%S')}"
    
    return {
        "success": True,
        "audit_id": audit_id,
        "user_id": request.user_id,
        "action": request.action,
        "resource": request.resource,
        "outcome": request.outcome,
        "timestamp": datetime.utcnow().isoformat(),
        "message": "Compliance action logged",
        "regulations_logged": ["HIPAA", "GDPR"],
    }

# ==================================================
# MAIN PROCESS ENDPOINT
# ==================================================

@app.post("/api/process", tags=["Processing"])
async def process_request(request: ProcessRequest):
    """
    Core execution:
    - Resolve policy graph
    - Execute tools sequentially with config-based access control
    - Return fully processed result
    """
    print(f"\n{'='*60}")
    print(f"🚀 Processing request: {request.request_type}")
    print(f"   User: {request.user_role}")
    print(f"   Input: {request.input_text[:80]}...")
    print(f"{'='*60}\n")

    # ✅ VALIDATE REQUEST TYPE
    if not validate_request_type(request.request_type):
        raise HTTPException(
            400,
            f"Invalid request_type: '{request.request_type}'. "
            f"Valid types: {list(VALID_REQUEST_TYPES.keys())}"
        )
    
    print(f"\n{'='*60}")
    print(f"🚀 Processing request: {request.request_type}")
    print(f"   User: {request.user_role}")
    print(f"   Input: {request.input_text[:80]}...")
    print(f"{'='*60}\n")

    if not compliance_manager.is_enabled():
        print("⚠️ Compliance DISABLED - bypassing checks")
        return {
            "success": True,
            "compliance_enabled": False,
            "compliance_applied": False,
            "original_input": request.input_text,
            "processed_output": request.input_text,
            "output_text": request.input_text,
            "masked_input": None,
            "pii_detected": [],
            "access_granted": True,
            "encrypted": False,
            "audit_id": "N/A",
            "audit_log": [],
            "policies_applied": [],
            "execution_path": ["BYPASS"],
            "timestamp": datetime.utcnow().isoformat(),
            "message": "⚠️ Compliance DISABLED - request bypassed",
        }

    # Resolve policy graph
    print("📋 Resolving policy graph...")
    try:
        policy_result = resolve_policies_from_graph(request.request_type)
        actions = policy_result.get("actions", [])
        regulations = policy_result.get("regulations", [])
        
        print(f"✅ Policy resolved:")
        print(f"   Regulations: {regulations}")
        print(f"   Actions: {actions}\n")
    except Exception as e:
        print(f"❌ Policy resolution failed: {e}")
        raise HTTPException(500, f"Policy resolution failed: {str(e)}")

    # Execution state
    state = {
        "input_text": request.input_text,
        "user_role": request.user_role or "clinician",
        "request_type": request.request_type,
        "access_granted": True,
        "masked_input": "",
        "final_output": "",
        "pii_detected": [],
        "audit_log": [],
        "deny_reason": "",
        "regulations_applied": regulations,
    }

    # Execute tools sequentially
    print(f"🔧 Executing {len(actions)} actions...\n")
    
    executed_actions = []
    
    for i, action in enumerate(actions, 1):
        tool = ACTION_TO_TOOL.get(action)
        
        if not tool:
            print(f"⚠️ [{i}/{len(actions)}] No tool found for action: {action}")
            continue
        
        print(f"[{i}/{len(actions)}] Executing: {action}")
        
        try:
            state = tool(state)
            executed_actions.append(action)
            
            # CHECK FOR ACCESS DENIAL
            if state.get("access_granted") is False:
                print(f"\n❌ ACCESS DENIED - Stopping execution")
                print(f"   Reason: {state.get('deny_reason')}\n")
                
                # Save audit logs for denied access
                compliance_manager.add_request_audit(state["audit_log"])
                
                return {
                    "success": False,
                    "compliance_enabled": True,
                    "compliance_applied": True,
                    "access_granted": False,
                    "original_input": request.input_text,
                    "processed_output": "",
                    "output_text": "",
                    "masked_input": "",
                    "pii_detected": [],
                    "encrypted": False,
                    "audit_id": f"AUDIT-{datetime.utcnow().strftime('%Y%m%d-%H%M%S')}",
                    "audit_log": state["audit_log"],
                    "policies_applied": [p.get("rule_id", "") for p in policy_result.get("policies", [])],
                    "execution_path": executed_actions,
                    "timestamp": datetime.utcnow().isoformat(),
                    "message": state.get("deny_reason", "Access denied"),
                }
        
        except Exception as e:
            print(f"❌ [{i}/{len(actions)}] Tool execution failed: {e}")
            import traceback
            traceback.print_exc()
            continue
    
    print(f"\n✅ All tools executed successfully\n")

    # Always audit at the end
    if "log_decision" not in executed_actions and "record_policy_path" not in executed_actions:
        print("📝 Running final audit log...")
        state = tool_log_audit(state)
        executed_actions.append("log_decision")

    # Success response
    print(f"{'='*60}")
    print(f"✅ REQUEST COMPLETED SUCCESSFULLY")
    print(f"   PII Detected: {len(state['pii_detected'])}")
    print(f"   Audit Entries: {len(state['audit_log'])}")
    print(f"   Final Output Length: {len(state.get('final_output', ''))}")
    print(f"{'='*60}\n")
    
    execution_path = list(dict.fromkeys([log["agent"] for log in state["audit_log"]]))
    
    # Save audit logs to manager
    compliance_manager.add_request_audit(state["audit_log"])
    
    return {
        "success": True,
        "compliance_enabled": True,
        "compliance_applied": True,
        "access_granted": True,
        "original_input": request.input_text,
        "masked_input": state["masked_input"],
        "processed_output": state["final_output"] or state["masked_input"],
        "output_text": state["final_output"] or state["masked_input"],
        "pii_detected": state["pii_detected"],
        "encrypted": False,
        "audit_id": f"AUDIT-{datetime.utcnow().strftime('%Y%m%d-%H%M%S')}",
        "audit_log": state["audit_log"],
        "policies_applied": [p.get("rule_id", "") for p in policy_result.get("policies", [])],
        "execution_path": execution_path,
        "regulatory_compliance": {
            "regulations_applied": regulations,
            "agents_executed": execution_path,
            "actions_performed": executed_actions,
        },
        "timestamp": datetime.utcnow().isoformat(),
        "message": "✅ Request processed via policy-driven tools",
    }

# ==================================================
# AUDIT & LOGGING ENDPOINTS
# ==================================================

@app.get("/api/audit/logs", response_model=AuditLogResponse, tags=["Audit"])
async def get_audit_logs(
    limit: int = 100,
    agent_filter: Optional[str] = None
):
    """
    Retrieve audit logs from recent requests.
    
    Note: In production, this should query a persistent audit database.
    Currently returns logs from in-memory state.
    """
    
    logs = compliance_manager.get_audit_logs(limit=limit, agent_filter=agent_filter)
    
    return {
        "total_logs": len(logs),
        "logs": logs,
        "compliance_enabled": compliance_manager.is_enabled(),
        "timestamp": datetime.utcnow().isoformat()
    }


@app.get("/api/audit/logs/{audit_id}", tags=["Audit"])
async def get_audit_log_by_id(audit_id: str):
    """Get a specific audit log entry by ID"""
    
    # In a real system, query database by audit_id
    # For now, return a mock structure
    return {
        "audit_id": audit_id,
        "timestamp": datetime.utcnow().isoformat(),
        "user_role": "clinician",
        "request_type": "patient_lookup",
        "access_granted": True,
        "regulations_applied": ["GDPR", "HIPAA"],
        "agents_executed": ["AccessControlAgent", "PrivacyAgent", "OutputGuardAgent", "AuditAgent"],
        "pii_detected": [],
        "message": "Audit log retrieved"
    }

# ==================================================
# POLICIES
# ==================================================

@app.get("/api/policies", response_model=List[PolicyInfo], tags=["Policies"])
async def list_policies():
    """Get list of available compliance policies"""
    policies_dir = project_root / "policy_generator" / "output_policies_AI"
    policies = []

    if policies_dir.exists():
        for f in policies_dir.glob("*.json"):
            policies.append({
                "name": f.stem.replace("_", " ").title(),
                "file_name": f.name,
                "regulation_type": f.stem,
                "enabled": compliance_manager.is_enabled(),
                "path": str(f),
            })

    return policies

# ==================================================
# ROOT
# ==================================================

@app.get("/", tags=["System"])
async def root():
    """API root endpoint"""
    return {
        "message": "Compliance AI Backend",
        "version": "1.0.0",
        "docs": "/api/docs",
        "compliance_enabled": compliance_manager.is_enabled(),
        "endpoints": {
            "health": "/api/health",
            "compliance_status": "/api/compliance/status",
            "enforcement_plan": "/api/enforcement-plan",
            "process": "/api/process",
            "check_access": "/api/check-access",
            "mask_pii": "/api/mask-pii",
            "audit_logs": "/api/audit/logs",
            "policies": "/api/policies",
        }
    }


# ==================================================
# RUN
# ==================================================

if __name__ == "__main__":
    import uvicorn
    
    print("🚀 Starting Compliance AI Backend...")
    print("📝 API Documentation: http://localhost:8000/api/docs")
    print(f"🔒 Compliance Status: {'ENABLED' if compliance_manager.is_enabled() else 'DISABLED'}")
    
    uvicorn.run(
        "main:app",
        host="0.0.0.0",
        port=8000,
        reload=True,
        log_level="info"
    )