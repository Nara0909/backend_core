"""
Backend Compliance Client

Makes calls to FastAPI backend compliance middleware endpoints
"""

import requests
import json
from typing import Dict, List, Any, Optional
from datetime import datetime


class BackendClient:
    """Client for backend compliance API"""
    
    def __init__(self, base_url: str = "http://localhost:8000"):
        """
        Initialize backend client
        
        Args:
            base_url: Base URL of FastAPI backend (default: http://localhost:8000)
        """
        self.base_url = base_url.rstrip('/')
        self.session = requests.Session()
        self.session.headers.update({'Content-Type': 'application/json'})
    
    def _make_request(
        self,
        method: str,
        endpoint: str,
        data: Optional[Dict] = None,
        timeout: int = 30
    ) -> Dict[str, Any]:
        """
        Make HTTP request to backend
        
        Args:
            method: HTTP method (GET, POST, etc.)
            endpoint: API endpoint path (without base URL)
            data: Request payload for POST/PUT requests
            timeout: Request timeout in seconds
        
        Returns:
            Response JSON as dictionary
        
        Raises:
            Exception if request fails
        """
        url = f"{self.base_url}{endpoint}"
        
        try:
            if method == "GET":
                response = self.session.get(url, timeout=timeout)
            elif method == "POST":
                response = self.session.post(url, json=data, timeout=timeout)
            else:
                raise ValueError(f"Unsupported HTTP method: {method}")
            
            response.raise_for_status()
            return response.json()
        
        except requests.exceptions.RequestException as e:
            print(f"[ERROR] Backend request failed: {e}")
            raise
    
    # ============ ENFORCEMENT PLAN ============
    
    def get_enforcement_plan(self, request_type: str) -> Dict[str, Any]:
        """
        Get applicable regulations and enforcement plan
        
        Args:
            request_type: Type of request (triage, scheduling, referral, etc.)
        
        Returns:
            Enforcement plan with applicable regulations and agents
        
        Example response:
        {
            "regulations": ["HIPAA", "GDPR"],
            "agents": ["AccessControl", "Privacy", "OutputGuard"],
            "policy_trace": {...}
        }
        """
        print(f"[CLIENT] GET /api/enforcement-plan?request_type={request_type}")
        
        return self._make_request(
            "GET",
            f"/api/enforcement-plan?request_type={request_type}"
        )
    
    # ============ ACCESS CONTROL ============
    
    def check_access(
        self,
        user_id: str,
        user_role: str,
        patient_id: str,
        resource_type: str = "patient_data",
        enforcement_plan: Optional[Dict] = None
    ) -> Dict[str, Any]:
        """
        Check if user has access to resource
        
        Args:
            user_id: User identifier
            user_role: User role (clinician, admin, etc.)
            patient_id: Patient identifier
            resource_type: Type of resource
            enforcement_plan: Enforcement plan from get_enforcement_plan()
        
        Returns:
            Access control decision
        
        Example response:
        {
            "access_granted": true,
            "reason": "Clinician has permission",
            "regulations": ["HIPAA"],
            "audit_id": "..."
        }
        """
        payload = {
            "user_id": user_id,
            "user_role": user_role,
            "patient_id": patient_id,
            "resource_type": resource_type,
            "enforcement_plan": enforcement_plan or {}
        }
        
        print(f"[CLIENT] POST /api/check-access")
        
        return self._make_request("POST", "/api/check-access", payload)
    
    # ============ PII MASKING ============
    
    def mask_pii(
        self,
        text: str,
        enforcement_plan: Optional[Dict] = None
    ) -> Dict[str, Any]:
        """
        Detect and mask PII from text
        
        Args:
            text: Input text potentially containing PII
            enforcement_plan: Enforcement plan from get_enforcement_plan()
        
        Returns:
            Masked text and detected PII elements
        
        Example response:
        {
            "masked_text": "Patient [NAME] with SSN [SSN] has fever",
            "pii_detected": [
                {"type": "NAME", "value": "John Doe", "masked_as": "[NAME]"},
                {"type": "SSN", "value": "123-45-6789", "masked_as": "[SSN]"}
            ]
        }
        """
        payload = {
            "text": text,
            "enforcement_plan": enforcement_plan or {}
        }
        
        print(f"[CLIENT] POST /api/mask-pii")
        
        return self._make_request("POST", "/api/mask-pii", payload)
    
    # ============ OUTPUT SANITIZATION ============
    
    def sanitize_output(
        self,
        text: str,
        enforcement_plan: Optional[Dict] = None
    ) -> Dict[str, Any]:
        """
        Sanitize LLM output - ensure no PII leakage
        
        Args:
            text: LLM output text
            enforcement_plan: Enforcement plan from get_enforcement_plan()
        
        Returns:
            Sanitized text and safety check
        
        Example response:
        {
            "sanitized_text": "...",
            "safe_to_store": true,
            "pii_detected": [],
            "regulations": ["HIPAA"]
        }
        """
        payload = {
            "text": text,
            "enforcement_plan": enforcement_plan or {}
        }
        
        print(f"[CLIENT] POST /api/sanitize-output")
        
        return self._make_request("POST", "/api/sanitize-output", payload)
    
    # ============ AUDIT LOGGING ============
    
    def log_compliance_action(
        self,
        user_id: str,
        action: str,
        resource: str,
        outcome: str,
        audit_id: Optional[str] = None,
        enforcement_plan: Optional[Dict] = None,
        details: Optional[Dict] = None
    ) -> Dict[str, Any]:
        """
        Log compliance action to backend audit system
        
        Args:
            user_id: User performing action
            action: Action performed (triage_decision, access_check, etc.)
            resource: Resource affected (patient, patient_data, etc.)
            outcome: Outcome (success, denied, error)
            audit_id: Audit trail ID
            enforcement_plan: Applicable regulations
            details: Additional context
        
        Returns:
            Audit reference
        
        Example response:
        {
            "audit_id": "...",
            "timestamp": "2024-01-15T10:30:00Z",
            "regulations_logged": ["HIPAA"]
        }
        """
        payload = {
            "user_id": user_id,
            "action": action,
            "resource": resource,
            "outcome": outcome,
            "audit_id": audit_id,
            "enforcement_plan": enforcement_plan or {},
            "details": details or {},
            "timestamp": datetime.utcnow().isoformat()
        }
        
        print(f"[CLIENT] POST /api/log-compliance-action")
        
        return self._make_request("POST", "/api/log-compliance-action", payload)
    
    # ============ UTILITY ============
    
    def health_check(self) -> bool:
        """
        Check if backend is running and responsive
        
        Returns:
            True if backend is healthy
        """
        try:
            response = self.session.get(f"{self.base_url}/api/enforcement-plan?request_type=test", timeout=5)
            return response.status_code in [200, 400]  # 400 is OK if backend responds
        except Exception as e:
            print(f"[ERROR] Backend health check failed: {e}")
            return False


# Convenience functions
def create_backend_client(backend_url: str = "http://localhost:8000") -> BackendClient:
    """Create and return a backend client"""
    return BackendClient(backend_url)
