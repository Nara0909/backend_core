"""Utility helpers for loading and indexing policy JSON files in output_policies_AI.

Provides small, dependency-free functions agents can import to query rules.
"""
from pathlib import Path
import json
from collections import defaultdict, Counter
from typing import Dict, List, Tuple
import os
import json as _json
try:
    import numpy as _np
    from sentence_transformers import SentenceTransformer, util
except Exception:
    SentenceTransformer = None
    util = None
    _np = None

BASE_DIR = Path(__file__).resolve().parent
AI_POLICIES_DIR = BASE_DIR / "output_policies_AI"


def load_policies(dir_path: Path = None) -> Dict[str, List[dict]]:
    """Load all JSON policy files from `dir_path` (defaults to output_policies_AI).

    Returns a mapping filename -> list of rule dicts.
    """
    if dir_path is None:
        dir_path = AI_POLICIES_DIR

    policies = {}
    for p in sorted(dir_path.glob("*.json")):
        try:
            policies[p.name] = json.loads(p.read_text(encoding="utf-8"))
        except Exception:
            policies[p.name] = []
    return policies


def summarize_policies(policies: Dict[str, List[dict]]) -> dict:
    """Return a compact summary: counts per file and aggregated ai_scope counts."""
    summary = {"files": {}, "ai_scope_counts": {}}
    agg = Counter()
    for fname, rules in policies.items():
        summary["files"][fname] = len(rules)
        for r in rules:
            agg[r.get("ai_scope", "General_Governance")] += 1
    summary["ai_scope_counts"] = dict(agg)
    return summary


def build_keyword_index(policies: Dict[str, List[dict]], min_word_length: int = 3) -> Dict[str, List[Tuple[str, int]]]:
    """Build a simple keyword -> list of (filename, rule_index) index.

    Only indexes words longer than `min_word_length` and lowercases them.
    """
    index = defaultdict(list)
    for fname, rules in policies.items():
        for i, r in enumerate(rules):
            text = (r.get("principle", "") + " " + r.get("requirement", "")).lower()
            for tok in set([w for w in text.replace("/", " ").split() if len(w) >= min_word_length]):
                cleaned = "".join(ch for ch in tok if ch.isalnum())
                if cleaned:
                    index[cleaned].append((fname, i))
    return dict(index)


def find_rules_by_keywords(index: Dict[str, List[Tuple[str, int]]], policies: Dict[str, List[dict]], keywords: List[str]) -> List[dict]:
    """Return unique rules matching any of the keywords (simple OR semantics)."""
    seen = set()
    results = []
    for k in keywords:
        key = k.lower()
        if key in index:
            for fname, i in index[key]:
                uid = (fname, i)
                if uid in seen:
                    continue
                seen.add(uid)
                results.append(policies[fname][i])
    return results


# -----------------------------
# Semantic search helpers
# -----------------------------
def _flatten_rules(policies: Dict[str, List[dict]]) -> Tuple[List[str], List[Tuple[str,int]]]:
    texts = []
    mapping = []
    for fname, rules in policies.items():
        for i, r in enumerate(rules):
            texts.append((r.get("principle", "") + " " + r.get("requirement", "")).strip())
            mapping.append((fname, i))
    return texts, mapping


def _embeddings_cache_path(model_name: str) -> Path:
    safe = model_name.replace("/", "_")
    return BASE_DIR / f".policy_embeddings_{safe}.npz"


def build_embedding_index(policies: Dict[str, List[dict]], model_name: str = "all-MiniLM-L6-v2", persist: bool = True):
    """Build (or load) embeddings for all rules. Returns (model, embeddings, mapping).

    Embeddings and mapping are cached under `policy_generator/` for reuse.
    """
    if SentenceTransformer is None:
        raise RuntimeError("sentence-transformers not available in the environment")

    cache_path = _embeddings_cache_path(model_name)
    texts, mapping = _flatten_rules(policies)

    if persist and cache_path.exists() and _np is not None:
        try:
            data = _np.load(str(cache_path), allow_pickle=True)
            embs = data["embeddings"]
            mapping_raw = data["mapping"].tolist()
            try:
                mapping = _json.loads(mapping_raw)
            except Exception:
                mapping = mapping_raw
            model = SentenceTransformer(model_name)
            return model, embs, mapping
        except Exception:
            pass

    model = SentenceTransformer(model_name)
    embs = model.encode(texts, convert_to_tensor=True)

    if persist and _np is not None:
        try:
            _np.savez_compressed(str(cache_path), embeddings=embs.cpu().numpy(), mapping=_json.dumps(mapping))
        except Exception:
            pass

    return model, embs, mapping


def semantic_search(policies: Dict[str, List[dict]], query: str, model_name: str = "all-MiniLM-L6-v2", top_k: int = 5):
    """Return top_k most similar rules to `query` across `policies`.

    Returns a list of tuples (rule_dict, score, source_file, rule_index).
    """
    if SentenceTransformer is None or util is None:
        raise RuntimeError("sentence-transformers not available; install it to use semantic_search")

    model, embs, mapping = build_embedding_index(policies, model_name=model_name, persist=True)
    q_emb = model.encode(query, convert_to_tensor=True)
    scores = util.cos_sim(q_emb, embs)[0]
    values, indices = scores.topk(min(top_k, scores.shape[0]))

    results = []
    for score, idx in zip(values.tolist(), indices.tolist()):
        idx = int(idx)
        score = float(score)
        fname, rule_idx = mapping[idx]
        rule = policies[fname][rule_idx]
        results.append((rule, score, fname, rule_idx))
    return results


__all__ = [
    "load_policies",
    "summarize_policies",
    "build_keyword_index",
    "find_rules_by_keywords",
    "build_embedding_index",
    "semantic_search",
]
