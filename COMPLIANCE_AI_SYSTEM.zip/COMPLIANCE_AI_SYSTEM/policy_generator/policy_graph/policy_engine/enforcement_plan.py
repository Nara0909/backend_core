import pickle
from pathlib import Path
from typing import Dict, List
import re

from policy_generator.policy_graph.policy_engine.policy_query import (
    get_enforcing_agents,
    get_enforcing_agents_with_policies,
)

# ==========================================================
# LOAD POLICY GRAPH (ONCE)
# ==========================================================
BASE_DIR = Path(__file__).resolve().parent.parent.parent
GRAPH_PATH = BASE_DIR / "policy_graph" / "policy_graph.pkl"

if not GRAPH_PATH.exists():
    raise FileNotFoundError(f"Policy graph not found: {GRAPH_PATH}")

with open(GRAPH_PATH, "rb") as f:
    POLICY_GRAPH = pickle.load(f)

# ==========================================================
# AGENT → ACTION MAPPING (Expanded)
# ==========================================================
# This mapping lists canonical enforcement actions each agent can perform.
# Add new agents/actions as enforcement needs evolve; policy rules map
# to these actions via the policy graph / enforcement plan builder.
AGENT_ACTIONS = {
    # Access control and consent enforcement
    "AccessControlAgent": [
        "check_role_permissions",
        "authorize_access",
        "check_consent",
        "enforce_consent_scope",
        "respond_access_request",
    ],

    # Privacy + data protection
    "PrivacyAgent": [
        "mask_phi",
        "anonymize_input",
        "pseudonymize",
        "tokenize",
        "apply_data_minimization",
        "encrypt_sensitive_fields",
    ],

    # Output safety and explainability
    "OutputGuardAgent": [
        "scan_output",
        "redact_pii",
        "sanitize_public_output",
        "produce_explanation",
    ],

    # Audit, logging, and provenance
    "AuditAgent": [
        "log_decision",
        "record_policy_path",
        "enable_audit_logging",
        "record_model_version",
        "record_access_event",
    ],

    # Policy-level decisions and human escalation
    "PolicyAgent": [
        "fallback_governance",
        "require_manual_approval",
        "escalate_to_privacy_officer",
    ],

    # Data retention / erasure
    "RetentionAgent": [
        "retain_for_period",
        "delete_after_retention",
        "handle_erasure_request",
    ],

    # Encryption & key management
    "EncryptionAgent": [
        "encrypt_at_rest",
        "decrypt_for_authorized_use",
        "manage_keys",
    ],

    # Incident response / breach handling
    "IncidentResponseAgent": [
        "detect_incident",
        "notify_breach",
        "execute_mitigation",
    ],

    # Model governance and validation
    "ModelGovernanceAgent": [
        "validate_model",
        "record_model_version",
        "check_model_performance",
    ],

    # Monitoring and runtime controls
    "MonitoringAgent": [
        "monitor_usage",
        "throttle_or_rate_limit",
        "anomaly_detection",
    ],
}

# ==========================================================
# CANONICAL EXECUTION ORDER
# ==========================================================
AGENT_ORDER = {
    "AccessControlAgent": 1,
    "PrivacyAgent": 2,
    "EncryptionAgent": 3,
    "TaskAgent": 4,          # injected later by router
    "OutputGuardAgent": 5,
    "ModelGovernanceAgent": 6,
    "MonitoringAgent": 7,
    "IncidentResponseAgent": 8,
    "RetentionAgent": 9,
    "AuditAgent": 10,
    "PolicyAgent": 99,
}

# ==========================================================
# AI_SCOPE → AGENT MAPPING (ROBUST FIX)
# ==========================================================
AI_SCOPE_TO_AGENT = {
    "AI_Privacy_Control": "PrivacyAgent",
    "AI_Access_Control": "AccessControlAgent",
    "AI_Governance": "AuditAgent",
    "AI_Explainability": "OutputGuardAgent",
    "General_Governance": "PolicyAgent",
}

# ==========================================================
# BUILD ENFORCEMENT PLAN (GRAPH-INTERNAL)
# ==========================================================
from policy_generator.request_types import REQUEST_TYPES
from policy_generator.policy_graph.policy_engine.policy_query import (
    get_enforcing_agents_with_policies
)


def build_enforcement_plan(request_type: str, application_region: str = None):
    if request_type not in REQUEST_TYPES:
        raise ValueError(f"Unknown request type: {request_type}")

    regulations = REQUEST_TYPES[request_type]["regulations"]

    enforcement_steps = []
    policy_trace_map = {}

    for regulation in regulations:
        agent_policy_map = get_enforcing_agents_with_policies(regulation)

        for agent, policies in agent_policy_map.items():
            policy_trace_map.setdefault(agent, []).extend(policies)

    # Helper: map policy principle/requirement -> canonical actions
    PRINCIPLE_ACTION_MAP = {
        "Data Minimization": ["apply_data_minimization"],
        "Retention": ["retain_for_period", "delete_after_retention"],
        "Access Control": ["check_consent", "authorize_access"],
        "Privacy": ["mask_phi", "anonymize_input", "pseudonymize"],
        "Security": ["encrypt_at_rest", "enable_audit_logging"],
        "Governance and Accountability": ["record_model_version", "require_manual_approval"],
    }

    KEYWORD_ACTION_MAP = {
        "encrypt": ["encrypt_at_rest"],
        "anonym": ["anonymize_input", "pseudonymize"],
        "de-identif": ["anonymize_input"],
        "delete": ["delete_after_retention", "handle_erasure_request"],
        "erasure": ["handle_erasure_request"],
        "consent": ["check_consent", "enforce_consent_scope"],
        "breach": ["detect_incident", "notify_breach"],
        "audit": ["enable_audit_logging", "record_access_event"],
        "explain": ["produce_explanation"],
        "model": ["record_model_version", "validate_model"],
        "monitor": ["monitor_usage", "anomaly_detection"],
    }

    def determine_actions_for_policies(policies: List[dict]) -> List[str]:
        actions = set()
        for p in policies:
            principle = (p.get("principle") or "").strip()
            requirement = (p.get("requirement") or "").lower()

            # principle-based actions
            if principle in PRINCIPLE_ACTION_MAP:
                actions.update(PRINCIPLE_ACTION_MAP[principle])

            # keyword-based actions from requirement text
            for kw, acts in KEYWORD_ACTION_MAP.items():
                if kw in requirement:
                    actions.update(acts)

        return sorted(actions)

    # If an application_region is provided, filter policy rules by region applicability
    def _region_matches(policy_region, app_region):
        if not app_region:
            return True
        if not policy_region:
            return True
        pr = str(policy_region).lower()
        ar = str(app_region).lower()
        parts = [p.strip() for p in re.split(r"[,/;]", pr) if p.strip()]
        return any(ar in p or p in ar for p in parts)

    filtered_policy_trace_map = {}
    for agent, policies in policy_trace_map.items():
        filtered = [p for p in policies if _region_matches(p.get("region_applicability"), application_region)]
        if filtered:
            filtered_policy_trace_map[agent] = filtered

    # If no policies remain after filtering, fall back to original policy_trace_map
    if not filtered_policy_trace_map:
        filtered_policy_trace_map = policy_trace_map

    # Collect regulations present after filtering
    regs_in_policies = set()
    for policies in filtered_policy_trace_map.values():
        for p in policies:
            if p.get("regulation"):
                regs_in_policies.add(p.get("regulation"))

    # Rank regulations by severity to pick primary regulation (configurable)
    REGULATION_SEVERITY = {
        "GDPR": 100,
        "EU_AI_ACT": 95,
        "HIPAA": 90,
        "PCI_DSS": 85,
        "Digital Personal Data Protection Act, 2023": 88,
        "CCPA": 75,
    }

    def _reg_severity(reg):
        return REGULATION_SEVERITY.get(reg, 50)

    resolved_regulations = sorted(list(regs_in_policies), key=_reg_severity, reverse=True)

    # Build a richer scoring model to choose a primary regulation when multiple apply
    # Components (configurable): base severity + sector match + data scope match + recency
    REGULATION_METADATA = {
        # Example metadata; real values can be enriched from policy JSONs
        "GDPR": {"sector": None, "data_scope": ["personal data"], "amended_year": 2018, "fines": 20000000},
        "EU_AI_ACT": {"sector": None, "data_scope": ["ai_systems"], "amended_year": 2024, "fines": 10000000},
        "HIPAA": {"sector": "healthcare", "data_scope": ["health data"], "amended_year": 1996, "fines": 1000000},
        "PCI_DSS": {"sector": "payments", "data_scope": ["payment card"], "amended_year": 2018, "fines": 500000},
        "Digital Personal Data Protection Act, 2023": {"sector": None, "data_scope": ["personal data"], "amended_year": 2023, "fines": 5000000},
        "CCPA": {"sector": None, "data_scope": ["personal data"], "amended_year": 2020, "fines": 2000000},
    }

    def _reg_score(reg: str, candidate_policies: List[dict]) -> float:
        base = _reg_severity(reg)
        meta = REGULATION_METADATA.get(reg, {})

        # sector bonus: if any policy principle mentions a sector matching metadata
        sector_bonus = 0
        if meta.get("sector"):
            for p in candidate_policies:
                if meta["sector"] and meta["sector"].lower() in (p.get("requirement") or "").lower():
                    sector_bonus = 10
                    break

        # data scope match: if policy rules talk about sensitive data types
        data_scope_bonus = 0
        ds = meta.get("data_scope") or []
        if ds:
            for p in candidate_policies:
                req = (p.get("requirement") or "").lower()
                for d in ds:
                    if d.lower() in req:
                        data_scope_bonus = 20
                        break
                if data_scope_bonus:
                    break

        # recency bonus (more recent amended_year -> small bonus)
        recency_bonus = 0
        if meta.get("amended_year"):
            recency_bonus = max(0, (meta["amended_year"] - 2000) / 5)

        # enforcement likelihood heuristic from fines magnitude
        fines = meta.get("fines", 0)
        fines_score = min(20, fines / 1000000)

        return float(base + sector_bonus + data_scope_bonus + recency_bonus + fines_score)

    # compute scores per resolved regulation by aggregating policies that reference it
    reg_scores = {}
    for reg in resolved_regulations:
        related_policies = []
        for policies in filtered_policy_trace_map.values():
            for p in policies:
                if p.get("regulation") == reg:
                    related_policies.append(p)
        reg_scores[reg] = _reg_score(reg, related_policies)

    # pick winners (highest score)
    if reg_scores:
        max_score = max(reg_scores.values())
        winners = [r for r, s in reg_scores.items() if s == max_score]
    else:
        winners = []

    apply_union_controls = False
    resolution_reasoning = ""
    primary_regulation = None

    if not winners:
        resolution_reasoning = "No applicable regulations found after region filtering; falling back to configured regulations."
    elif len(winners) == 1:
        primary_regulation = winners[0]
        resolution_reasoning = f"Selected primary regulation {primary_regulation} by highest score." 
    else:
        # tie-breaker heuristics
        # 1) prefer more specific scope (more keywords matched)
        specificity_rank = {}
        for r in winners:
            spec = 0
            meta = REGULATION_METADATA.get(r, {})
            keywords = (meta.get("data_scope") or [])
            for policies in filtered_policy_trace_map.values():
                for p in policies:
                    if p.get("regulation") == r:
                        txt = (p.get("requirement") or "").lower()
                        for k in keywords:
                            if k.lower() in txt:
                                spec += 1
            specificity_rank[r] = spec

        best_spec = max(specificity_rank.values())
        spec_winners = [r for r, v in specificity_rank.items() if v == best_spec]

        if len(spec_winners) == 1:
            primary_regulation = spec_winners[0]
            resolution_reasoning = f"Tie broken by specificity: {primary_regulation}."
        else:
            # final conservative fallback: enforce union of controls from all winners
            apply_union_controls = True
            primary_regulation = spec_winners[0]
            resolution_reasoning = f"Multiple regulations tied ({', '.join(spec_winners)}); applying union of controls and marking primary as {primary_regulation}."

    for agent, policies in filtered_policy_trace_map.items():
        # Determine which actions this agent actually needs to perform
        actions = determine_actions_for_policies(policies)

        # Filter actions to those the agent actually supports (from AGENT_ACTIONS)
        supported = set(AGENT_ACTIONS.get(agent, []))
        matched = [a for a in actions if a in supported]
        unknown = sorted([a for a in actions if a not in supported])

        enforcement_steps.append({
            "agent": agent,
            "policy_trace": policies,
            "actions": matched,
            "unknown_actions": unknown,
        })

    # --------------------------------------------------
    # Split specialized actions into their dedicated agents
    # so the runtime graph can route to them explicitly.
    # --------------------------------------------------
    SPECIALIZE = {
        "EncryptionAgent": {"encrypt_at_rest", "decrypt_for_authorized_use", "manage_keys"},
        "RetentionAgent": {"retain_for_period", "delete_after_retention", "handle_erasure_request"},
        "IncidentResponseAgent": {"detect_incident", "notify_breach", "execute_mitigation"},
        "ModelGovernanceAgent": {"validate_model", "record_model_version", "check_model_performance"},
        "MonitoringAgent": {"monitor_usage", "throttle_or_rate_limit", "anomaly_detection"},
    }

    # Collect actions by specialized agent
    spec_steps: Dict[str, Dict[str, List]] = {}
    for step in enforcement_steps:
        remaining = []
        for act in step["actions"]:
            moved = False
            for spec_agent, acts in SPECIALIZE.items():
                if act in acts:
                    slot = spec_steps.setdefault(spec_agent, {"actions": set(), "policies": []})
                    slot["actions"].add(act)
                    # Aggregate policies which informed this action
                    slot["policies"].extend(step.get("policy_trace", []))
                    moved = True
                    break
            if not moved:
                remaining.append(act)
        step["actions"] = remaining

    # Append specialized steps
    for spec_agent, payload in spec_steps.items():
        acts = sorted(list(payload["actions"]))
        if not acts:
            continue
        # Deduplicate policies while preserving simple dict identity via repr
        dedup = []
        seen = set()
        for p in payload["policies"]:
            k = repr(p)
            if k in seen:
                continue
            seen.add(k)
            dedup.append(p)

        enforcement_steps.append({
            "agent": spec_agent,
            "policy_trace": dedup,
            "actions": acts,
            "unknown_actions": [],
        })

        # Enhance policy_trace_map with specialized agent traces
        if dedup:
            policy_trace_map[spec_agent] = dedup

    # Drop no-op steps that have neither actions nor unknown_actions
    enforcement_steps = [s for s in enforcement_steps if s.get("actions") or s.get("unknown_actions")]

    # Sort by canonical order
    enforcement_steps.sort(key=lambda s: AGENT_ORDER.get(s.get("agent"), 50))

    return {
        "request_type": request_type,
        "regulations": regulations,
        "resolved_regulations": resolved_regulations,
        "primary_regulation": primary_regulation,
        "reg_scores": reg_scores,
        "resolution_reasoning": resolution_reasoning,
        "apply_union_controls": apply_union_controls,
        "application_region": application_region,
        "enforcement_steps": enforcement_steps,
        "policy_trace_map": policy_trace_map
    }

