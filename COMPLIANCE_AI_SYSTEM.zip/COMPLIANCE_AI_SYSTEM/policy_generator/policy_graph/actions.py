# AI_SCOPE_TO_ACTIONS = {
#     "AI_Privacy_Control": [
#         "detect_pii",
#         "mask_phi",
#         "anonymize_input",
#         "encrypt_pii_at_rest"

#     ],
#     "AI_Access_Control": [
#         "check_role_permissions",
#         "verify_data_access_rights"
#         "decrypt_pii_for_processing"
#     ],
#     "AI_Explainability": [
#         "redact_pii",
#         "sanitize_public_output",
#         "prevent_data_leakage"
#     ],
#     "AI_Governance": [
#         "log_decision",
#         "record_policy_path",
#         "trace_regulatory_compliance"
#     ],
#     "General_Governance": [
#         "apply_policy_override"
#     ]
# }

AI_SCOPE_TO_ACTIONS = {
    "AI_Privacy_Control": [
        "mask_phi",
        "encrypt_pii_at_rest"
    ],
    "AI_Access_Control": [
        "check_role_permissions"
    ],
    "AI_Governance": [
        "log_decision",
        "record_policy_path"
    ],
    "AI_Explainability": [
        "sanitize_output"
    ]
}
