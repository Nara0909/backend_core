import os
BASE_DIR = os.path.dirname(os.path.abspath(__file__))

print("CWD:", os.getcwd())
print("BASE_DIR:", BASE_DIR)
