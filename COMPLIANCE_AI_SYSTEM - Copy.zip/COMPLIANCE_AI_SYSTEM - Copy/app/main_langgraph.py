"""
FastAPI Backend for Compliance AI System

Provides REST API endpoints for:
- Compliance toggle (enable/disable)
- Request processing with/without compliance
- Audit log retrieval
- Policy management
- Health checks
"""

from fastapi import FastAPI, HTTPException, Depends, status
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field
from typing import List, Dict, Any, Optional
from datetime import datetime
import sys
from pathlib import Path
from policy_generator.policy_graph.resolver import resolve_policies_from_graph

# project_root = Path(__file__).resolve().parent.parent
# sys.path.insert(0, str(project_root))

# Add project root to path
project_root = Path(__file__).resolve().parent.parent
if str(project_root) not in sys.path:
    sys.path.insert(0, str(project_root))

from app.compliance_state import ComplianceStateManager
from app.api_models import (
    ProcessRequest,
    ProcessResponse,
    ComplianceStatusResponse,
    AuditLogResponse,
    PolicyInfo,
    HealthResponse,
    ErrorResponse,
    CheckAccessRequest,
    MaskPIIRequest,
    SanitizeOutputRequest,
    LogComplianceActionRequest
)
from agent_graph.graph import build_graph
from agent_graph.state import AgentState
# from policy_generator.policy_graph.policy_engine.enforcement_plan import build_enforcement_plan
CANONICAL_AGENT_ORDER = [
    "AccessControlAgent",
    "PrivacyAgent",
    "OutputGuardAgent",
    "AuditAgent",
]

# Initialize FastAPI app
app = FastAPI(
    title="Compliance AI Backend",
    description="REST API for healthcare compliance enforcement (GDPR, HIPAA, PCI-DSS, AI Act)",
    version="1.0.0",
    docs_url="/api/docs",
    redoc_url="/api/redoc"
)

# CORS Configuration - allows frontend to connect
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # In production, specify frontend URL
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Initialize compliance state manager
compliance_manager = ComplianceStateManager()

# Graph will be lazy-loaded on first use
app_graph = None

def get_graph():
    """Lazy-load and compile the LangGraph workflow"""
    global app_graph
    if app_graph is None:
        try:
            workflow = build_graph()
            app_graph = workflow.compile()
        except Exception as e:
            print(f"Warning: Could not build graph: {e}")
            app_graph = None
    return app_graph


# ============================================================
# HEALTH & STATUS ENDPOINTS
# ============================================================

@app.get("/api/health", response_model=HealthResponse, tags=["System"])
async def health_check():
    """Check if the API is running and healthy."""
    return {
        "status": "healthy",
        "timestamp": datetime.utcnow().isoformat(),
        "compliance_enabled": compliance_manager.is_enabled(),
        "version": "1.0.0"
    }


@app.get("/api/compliance/status", tags=["Compliance"])
async def get_compliance_status():
    """Get current compliance enforcement status."""
    state = compliance_manager.get_state()
    return {
        "enabled": state["enabled"],
        "updated_at": state["updated_at"],
        "enforced_regulations": state.get("regulations", ["GDPR", "HIPAA", "PCI-DSS", "AI Act"]),
        "active_agents": state.get("active_agents", [
            "AccessControlAgent",
            "PrivacyAgent",
            "OutputGuardAgent",
            "AuditAgent",
            "EncryptionAgent",
            "RetentionAgent"
        ]) if state["enabled"] else []
    }


# ============================================================
# COMPLIANCE TOGGLE ENDPOINTS
# ============================================================

@app.post("/api/compliance/enable", tags=["Compliance"])
async def enable_compliance():
    """Enable compliance enforcement for all requests."""
    compliance_manager.enable()
    state = compliance_manager.get_state()
    return {
        "enabled": state["enabled"],
        "updated_at": state["updated_at"],
        "enforced_regulations": state.get("regulations", ["GDPR", "HIPAA", "PCI-DSS", "AI Act"]),
        "active_agents": state.get("active_agents", [])
    }


@app.post("/api/compliance/disable", tags=["Compliance"])
async def disable_compliance():
    """Disable compliance enforcement - requests bypass all compliance checks."""
    compliance_manager.disable()
    state = compliance_manager.get_state()
    return {
        "enabled": state["enabled"],
        "updated_at": state["updated_at"],
        "enforced_regulations": [],
        "active_agents": []
    }


@app.get("/api/enforcement-plan", tags=["Compliance"])
async def get_enforcement_plan(request_type: str = "triage"):
    """
    Get the applicable enforcement plan for a request type.
    
    Frontend uses this to know which compliance tools to call and in what order.
    
    Args:
        request_type: Type of request (triage, scheduling, clinical_decision, etc.)
    
    Returns:
        Enforcement plan with agents, actions, regulations, policy traces
    """
    
    # Determine applicable regulations based on request type
    applicable_regulations = ["GDPR", "HIPAA"]
    if request_type in ["clinical_query", "patient_lookup", "triage"]:
        applicable_regulations.extend(["PCI-DSS"])
    if request_type in ["ai_model_inference", "ai_decision"]:
        applicable_regulations.append("AI Act")
    
    # Comprehensive enforcement plan with regulation mapping
    @app.get("/api/enforcement-plan", tags=["Compliance"])
    async def get_enforcement_plan(request_type: str = "triage"):
        policy_result = resolve_policies_from_graph(request_type)

        return {
            "request_type": request_type,
            "regulations": policy_result["regulations"],
            "agents": policy_result["agents"],
            "actions": policy_result["actions"],
            "policies": policy_result["policies"],
        }

    

    


# ============================================================
# COMPLIANCE CHECK ENDPOINTS (Frontend Middleware)
# ============================================================

@app.post("/api/check-access", tags=["Compliance"])
async def check_access(request: CheckAccessRequest):
    """Check user access based on role"""
    from agent_graph.nodes import access_control_node
    from agent_graph.state import AgentState
    
    state: AgentState = {
        "input_text": "",
        "user_role": request.user_role or "clinician",
        "request_type": request.request_type or "triage",
        "enforcement_plan": request.enforcement_plan or {},
        "regulations": [],
        "execution_queue": [],
        "policy_trace_map": {},
        "audit_log": [],
        "masked_input": "",
        "llm_output": "",
        "final_output": "",
        "pii_detected": [],
        "current_agent": None,
    }
    
    try:
        result_state = access_control_node(state)
    except:
        result_state = state
    
    return {
        "success": True,
        "access_granted": result_state.get("access_granted", False),
        "user_role": result_state.get("user_role", request.user_role),
        "message": "Access control check completed",
        "regulations": ["HIPAA", "GDPR"]
    }


@app.post("/api/mask-pii", tags=["Compliance"])
async def mask_pii(request: MaskPIIRequest):
    """Detect and mask PII in input text"""
    from security.pii import detect_pii, redact_and_detect
    
    # Accept either input_text or text field
    text = request.input_text or request.text or ""
    if not text:
        return {
            "success": False,
            "error": "No text provided. Use 'input_text' or 'text' field",
            "message": "PII masking failed - no input"
        }
    
    masked, pii_list = redact_and_detect(text)
    
    return {
        "success": True,
        "original_text": text,
        "masked_text": masked,
        "pii_detected": pii_list,
        "pii_count": len(pii_list),
        "message": f"Detected and masked {len(pii_list)} PII entities"
    }


@app.post("/api/sanitize-output", tags=["Compliance"])
async def sanitize_output(request: SanitizeOutputRequest):
    """Remove PII from LLM output"""
    from security.pii import redact_and_detect
    
    # Accept either output_text or text field
    text = request.output_text or request.text or ""
    if not text:
        return {
            "success": False,
            "error": "No text provided. Use 'output_text' or 'text' field",
            "message": "Output sanitization failed - no input"
        }
    
    sanitized, pii_detected = redact_and_detect(text)
    
    safe_to_store = len(pii_detected) == 0
    
    return {
        "success": True,
        "original_output": text,
        "sanitized_output": sanitized,
        "pii_detected_in_output": pii_detected,
        "safe_to_store": safe_to_store,
        "message": f"Output sanitized. Safe to store: {safe_to_store}"
    }


@app.post("/api/log-compliance-action", tags=["Compliance"])
async def log_compliance_action(request: LogComplianceActionRequest):
    """Create compliance audit log entry"""
    
    audit_id = request.audit_id or f"AUDIT-{datetime.utcnow().strftime('%Y%m%d-%H%M%S')}-{hash(str(request)) % 10000:04d}"
    
    return {
        "success": True,
        "audit_id": audit_id,
        "timestamp": datetime.utcnow().isoformat(),
        "message": "Compliance action logged",
        "regulations_logged": ["HIPAA", "GDPR"]
    }


# ============================================================
# COMPLIANCE CHECK ENDPOINT (OLD - Keep for backward compatibility)
# ============================================================

@app.post("/api/compliance-check", tags=["Processing"])
async def compliance_check(request: ProcessRequest):
    """
    Check compliance without LLM processing.
    
    Returns:
    - Access control status
    - PII detection and masking
    - Regulatory compliance info
    
    Frontend then handles LLM tasks (Triage, Scheduling, Clinical Decision)
    """
    
    compliance_enabled = compliance_manager.is_enabled()
    
    if not compliance_enabled:
        return {
            "success": True,
            "compliance_enabled": False,
            "access_granted": True,
            "pii_detected": [],
            "masked_input": request.input_text,
            "audit_id": "N/A"
        }
    
    try:
        # Determine applicable regulations
        applicable_regulations = ["GDPR", "HIPAA"]
        if request.request_type in ["clinical_query", "patient_lookup"]:
            applicable_regulations.extend(["PCI-DSS"])
        
        enforcement_plan = {
            "regulations": list(set(applicable_regulations)),
            "enforcement_steps": [
                {
                    "agent": "AccessControlAgent", 
                    "actions": ["check_role_permissions", "verify_data_access_rights"], 
                    "policy_trace": ["GDPR Article 32 (Access Control)", "HIPAA 164.312(a)(1)"],
                },
                {
                    "agent": "PrivacyAgent", 
                    "actions": ["mask_phi", "anonymize_input", "detect_pii"], 
                    "policy_trace": ["HIPAA 164.502 (PHI Protection)", "GDPR Article 32 (Data Minimization)"],
                },
                {
                    "agent": "OutputGuardAgent", 
                    "actions": ["redact_pii", "sanitize_public_output"], 
                    "policy_trace": ["GDPR Article 25 (Data Protection by Design)", "HIPAA 164.514 (De-identification)"],
                },
                {
                    "agent": "AuditAgent", 
                    "actions": ["log_decision", "record_policy_path"], 
                    "policy_trace": ["GDPR Article 30 (Records of Processing)", "HIPAA 164.308(a)(1)(ii)(D) (Audit Controls)"],
                },
            ]
        }
        
        # 🔁 ADAPTER: Policy-Graph → LangGraph contract
        # 🔁 PolicyGraph → LangGraph Adapter (ORDERED)
        enforcement_steps = []

        for agent in CANONICAL_AGENT_ORDER:
            if agent in enforcement_plan["agents"]:
                enforcement_steps.append({
                    "agent": agent,
                    "actions": enforcement_plan["actions"],
                    "policy_trace": [p["rule_id"] for p in enforcement_plan["policies"]],
                })

        enforcement_plan["enforcement_steps"] = enforcement_steps


        # 🔴 IMPORTANT: inject back
        # enforcement_plan["enforcement_steps"] = enforcement_steps


        initial_state: AgentState = {
            "input_text": request.input_text,
            "user_role": request.user_role or "clinician",
            "request_type": request.request_type,

            "enforcement_plan": enforcement_plan,
            "regulations": enforcement_plan.get("regulations", []),

            # REQUIRED
            "access_granted": True,

            # 🔥 ORDER MATTERS
            "execution_queue": [
                step["agent"] for step in enforcement_plan["enforcement_steps"]
            ],

            "policy_trace_map": {},
            "audit_log": [],
            "masked_input": "",
            "llm_output": "",
            "final_output": "",
            "pii_detected": [],
            "current_agent": None,
        }


        
        graph = get_graph()
        if graph is None:
            return {"success": False, "error": "Compliance graph not available"}
        
        final_state = graph.invoke(initial_state)

        if final_state.get("access_granted") is False:
            return {
                "success": False,
                "compliance_enabled": True,
                "compliance_applied": True,
                "access_granted": False,
                "audit_id": f"AUDIT-{datetime.utcnow().strftime('%Y%m%d-%H%M%S')}",
                "audit_log": final_state.get("audit_log", []),
                "execution_path": ["AccessControlAgent"],
                "timestamp": datetime.utcnow().isoformat(),
                "message": "❌ Access denied: insufficient privileges"
            }
        
        audit_id = f"AUDIT-{datetime.utcnow().strftime('%Y%m%d-%H%M%S')}"
        
        return {
            "success": True,
            "compliance_enabled": True,
            "access_granted": True,
            "user_role": request.user_role,
            "pii_detected": final_state.get("pii_detected", []),
            "masked_input": final_state.get("masked_input", ""),
            "audit_id": audit_id,
            "audit_log": final_state.get("audit_log", []),
            "regulations": final_state.get("regulations", []),
            "policy_trace_map": final_state.get("policy_trace_map", {}),
            "message": "✅ Compliance check passed - Ready for frontend AI processing"
        }
        
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Compliance check failed: {str(e)}"
        )


# ============================================================
# MAIN PROCESSING ENDPOINT
# ============================================================

@app.post("/api/process", tags=["Processing"])
async def process_request(request: ProcessRequest):

    compliance_enabled = compliance_manager.is_enabled()

    # --------------------------------------------------
    # COMPLIANCE DISABLED → BYPASS
    # --------------------------------------------------
    if not compliance_enabled:
        return {
            "success": True,
            "compliance_enabled": False,
            "compliance_applied": False,
            "original_input": request.input_text,
            "processed_output": request.input_text,
            "output_text": request.input_text,
            "masked_input": None,
            "pii_detected": [],
            "access_granted": True,
            "encrypted": False,
            "audit_id": "N/A",
            "audit_log": [],
            "policies_applied": [],
            "execution_path": ["BYPASS"],
            "timestamp": datetime.utcnow().isoformat(),
            "message": "⚠️ Compliance DISABLED - request bypassed"
        }
    
    import time
    # --------------------------------------------------
    # ✅ POLICY GRAPH RESOLUTION (NEW)
    # --------------------------------------------------
    start = time.time()
    print("🟡 STEP 1: received request")

    policy_result = resolve_policies_from_graph(request.request_type)

    print("🟢 STEP 2: policy resolved", time.time() - start)
    # 🔧 ADAPTER: make policy-graph output compatible with existing agents
    enforcement_plan = {
    "regulations": policy_result["regulations"],
    "policies": policy_result["policies"],
    "agents": policy_result["agents"],
    "actions": policy_result["actions"],

    # ✅ REQUIRED by existing agents
    "enforcement_steps": [
        {
            "agent": agent,
            "actions": policy_result["actions"],
            "policies": policy_result["policies"],
        }
        for agent in policy_result["agents"]
    ]
}



    # --------------------------------------------------
    # Initialize LangGraph state
    # --------------------------------------------------
    initial_state: AgentState = {
        "input_text": request.input_text,
        "user_role": request.user_role or "clinician",
        "request_type": request.request_type,
        "enforcement_plan": enforcement_plan,
        "regulations": policy_result["regulations"],
        "execution_queue": policy_result["agents"],
        "policy_trace_map": {},
        "audit_log": [],
        "masked_input": "",
        "llm_output": "",
        "final_output": "",
        "pii_detected": [],
        "current_agent": None,
    }

    graph = get_graph()
    print("🟢 STEP 3: graph loaded", time.time() - start)

    graph = get_graph()
    if graph is None:
        raise HTTPException(500, "Compliance graph not available")

    try:
        final_state = graph.invoke(initial_state)
    except Exception as e:
        raise HTTPException(
            status_code=500,
            detail=f"Compliance graph execution failed: {str(e)}"
        )
    print("🟢 STEP 4: graph finished", time.time() - start)
    # --------------------------------------------------
    # 🚫 HARD STOP IF ACCESS DENIED (GRAPH DECIDES)
    # --------------------------------------------------
    if final_state.get("access_granted") is False:
        return {
            "success": False,
            "compliance_enabled": True,
            "compliance_applied": True,
            "access_granted": False,
            "audit_id": f"AUDIT-{datetime.utcnow().strftime('%Y%m%d-%H%M%S')}",
            "audit_log": final_state.get("audit_log", []),
            "execution_path": ["AccessControlAgent"],
            "timestamp": datetime.utcnow().isoformat(),
            "message": "❌ Access denied by policy"
        }

    # --------------------------------------------------
    # SUCCESS RESPONSE
    # --------------------------------------------------
    execution_path = [log["agent"] for log in final_state.get("audit_log", [])]

    return {
        "success": True,
        "compliance_enabled": True,
        "compliance_applied": True,
        "original_input": request.input_text,
        "processed_output": final_state.get("final_output") or final_state.get("masked_input"),
        "output_text": final_state.get("final_output"),
        "masked_input": final_state.get("masked_input"),
        "pii_detected": final_state.get("pii_detected", []),
        "access_granted": True,
        "encrypted": bool(final_state.get("encrypted_data")),
        "audit_id": f"AUDIT-{datetime.utcnow().strftime('%Y%m%d-%H%M%S')}",
        "audit_log": final_state.get("audit_log", []),
        "policies_applied": [p["rule_id"] for p in policy_result["policies"]],
        "execution_path": execution_path,
        "regulatory_compliance": {
            "regulations_applied": policy_result["regulations"],
            "agents_executed": execution_path,
        },
        "timestamp": datetime.utcnow().isoformat(),
        "message": "✅ Request processed under policy graph enforcement"
    }



# ============================================================
# AUDIT & LOGGING ENDPOINTS
# ============================================================

@app.get("/api/audit/logs", response_model=AuditLogResponse, tags=["Audit"])
async def get_audit_logs(
    limit: int = 100,
    agent_filter: Optional[str] = None
):
    """
    Retrieve audit logs from recent requests.
    
    Note: In production, this should query a persistent audit database.
    Currently returns logs from in-memory state.
    """
    
    # In a real system, fetch from database
    # For now, return mock structure
    logs = compliance_manager.get_audit_logs(limit=limit, agent_filter=agent_filter)
    
    return {
        "total_logs": len(logs),
        "logs": logs,
        "compliance_enabled": compliance_manager.is_enabled(),
        "timestamp": datetime.utcnow().isoformat()
    }


# ============================================================
# POLICY MANAGEMENT ENDPOINTS
# ============================================================

@app.get("/api/policies", response_model=List[PolicyInfo], tags=["Policies"])
async def get_policies():
    """Get list of available compliance policies and regulations."""
    
    # Load available policies from policy_generator
    policies_dir = project_root / "policy_generator" / "output_policies_AI"
    
    policies = []
    if policies_dir.exists():
        for policy_file in policies_dir.glob("*.json"):
            policies.append({
                "name": policy_file.stem.replace("_", " ").title(),
                "file_name": policy_file.name,
                "regulation_type": policy_file.stem,
                "enabled": compliance_manager.is_enabled(),
                "path": str(policy_file)
            })
    
    return policies


@app.get("/api/policies/{regulation_name}", tags=["Policies"])
async def get_policy_details(regulation_name: str):
    """Get detailed policy rules for a specific regulation."""
    
    import json
    
    policy_file = project_root / "policy_generator" / "output_policies_AI" / f"{regulation_name}.json"
    
    if not policy_file.exists():
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Policy not found: {regulation_name}"
        )
    
    with open(policy_file, "r") as f:
        policy_data = json.load(f)
    
    return {
        "regulation": regulation_name,
        "policy_data": policy_data,
        "compliance_enabled": compliance_manager.is_enabled()
    }


# ============================================================
# REQUEST TYPES ENDPOINT
# ============================================================

@app.get("/api/request-types", tags=["Configuration"])
async def get_request_types():
    """Get available healthcare request types."""
    from policy_generator.request_types import REQUEST_TYPES
    
    return {
        "request_types": list(REQUEST_TYPES.keys()),
        "details": REQUEST_TYPES
    }


# ============================================================
# ROOT ENDPOINT
# ============================================================

@app.get("/", tags=["System"])
async def root():
    """API root endpoint."""
    return {
        "message": "Compliance AI Backend API",
        "version": "1.0.0",
        "documentation": "/api/docs",
        "compliance_enabled": compliance_manager.is_enabled(),
        "endpoints": {
            "health": "/api/health",
            "compliance_status": "/api/compliance/status",
            "process": "/api/process",
            "audit_logs": "/api/audit/logs",
            "policies": "/api/policies"
        }
    }


if __name__ == "__main__":
    import uvicorn
    
    print("🚀 Starting Compliance AI Backend...")
    print("📝 API Documentation: http://localhost:8000/api/docs")
    print(f"🔒 Compliance Status: {'ENABLED' if compliance_manager.is_enabled() else 'DISABLED'}")
    
    uvicorn.run(
        "main:app",
        host="0.0.0.0",
        port=8000,
        reload=True,
        log_level="info"
    )
