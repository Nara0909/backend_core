import logging
from .pii import redact_text

class PIIRedactionFilter(logging.Filter):
    """A logging filter that scrubs PII/PHI from log records' messages."""

    def filter(self, record: logging.LogRecord) -> bool:
        try:
            if isinstance(record.msg, str):
                record.msg = redact_text(record.msg)
            # Scrub common fields
            for attr in ("user", "email", "phone", "subject_id"):
                if hasattr(record, attr) and isinstance(getattr(record, attr), str):
                    setattr(record, attr, "[REDACTED]")
        except Exception:
            # Never block logging due to redaction errors
            pass
        return True


def setup_secure_logging(level: int = logging.INFO) -> None:
    root = logging.getLogger()
    if not any(isinstance(h, logging.StreamHandler) for h in root.handlers):
        handler = logging.StreamHandler()
        handler.setLevel(level)
        handler.addFilter(PIIRedactionFilter())
        formatter = logging.Formatter(
            fmt="%(asctime)s %(levelname)s %(name)s: %(message)s",
            datefmt="%Y-%m-%dT%H:%M:%SZ",
        )
        handler.setFormatter(formatter)
        root.addHandler(handler)
    root.setLevel(level)
