from utils.logger import audit_log



class AuditAgent:

    def run(self, state):

        audit_log({

            "role": state.user_role,

            "input": state.masked_input,

            "output": state.final_output

        })

        return state

