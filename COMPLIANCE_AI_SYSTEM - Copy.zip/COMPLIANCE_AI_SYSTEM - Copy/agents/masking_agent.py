from security.tokenization import tokenize_text



class MaskingAgent:

    def run(self, state):

        state.masked_input = tokenize_text(state.raw_input)

        return state

