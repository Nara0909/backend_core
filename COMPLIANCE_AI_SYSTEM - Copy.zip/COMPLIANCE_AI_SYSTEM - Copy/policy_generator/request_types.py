"""
Request Types Configuration
Defines all valid healthcare request types with their compliance requirements
"""

def list_request_types():
    return list(REQUEST_TYPES.keys())


REQUEST_TYPES = {
    "patient_triage": {
        "name": "Patient Triage",
        "description": "Initial patient assessment and symptom evaluation",
        "regulations": [
            "HIPAA",
            "GDPR"
        ],
        "principles": [
            "Privacy",
            "Access Control",
            "Data Minimization",
            "Security",
            "Governance and Accountability"
        ],
        "required_roles": ["admin", "clinician", "doctor", "nurse"],
        "keywords": [
            "chest pain",
            "shortness of breath",
            "fever",
            "emergency",
            "triage",
            "vital signs",
            "symptoms",
            "assessment"
        ],
        "exemplars": [
            "Patient with chest pain and shortness of breath",
            "Emergency triage assessment",
            "Collect vital signs for triage",
            "Initial symptom evaluation"
        ]
    },

    "patient_lookup": {
        "name": "Patient Lookup",
        "description": "Retrieve patient medical records and history",
        "regulations": [
            "HIPAA",
            "GDPR",
            "PCI_DSS"
        ],
        "principles": [
            "Privacy",
            "Access Control",
            "Data Minimization",
            "Security",
            "Governance and Accountability"
        ],
        "required_roles": ["admin", "clinician", "doctor", "nurse"],
        "keywords": [
            "medical history",
            "patient record",
            "EHR",
            "medical record",
            "patient information",
            "lookup",
            "search patient"
        ],
        "exemplars": [
            "Show medical history of patient John Doe",
            "Retrieve patient records",
            "Access patient EHR",
            "Search patient by MRN"
        ]
    },

    "appointment_scheduling": {
        "name": "Appointment Scheduling",
        "description": "Schedule or modify patient appointments",
        "regulations": [
            "HIPAA",
            "GDPR"
        ],
        "principles": [
            "Privacy",
            "Access Control",
            "Data Minimization",
            "Governance and Accountability"
        ],
        "required_roles": ["visitor","admin", "clinician", "doctor", "nurse", "receptionist"],
        "keywords": [
            "appointment",
            "schedule",
            "booking",
            "calendar",
            "visit",
            "reschedule",
            "cancel appointment"
        ],
        "exemplars": [
            "Schedule appointment for patient",
            "Book follow-up visit",
            "Reschedule patient appointment",
            "Cancel upcoming appointment"
        ]
    },

    "prescription": {
        "name": "Prescription",
        "description": "Create or modify medication prescriptions",
        "regulations": [
            "HIPAA",
            "GDPR",
            "PCI_DSS"
        ],
        "principles": [
            "Privacy",
            "Access Control",
            "Security",
            "Governance and Accountability",
            "Data Minimization"
        ],
        "required_roles": ["admin", "doctor", "pharmacist"],
        "keywords": [
            "prescription",
            "medication",
            "drug",
            "pharmacy",
            "dosage",
            "refill",
            "e-prescribe"
        ],
        "exemplars": [
            "Prescribe medication for patient",
            "Refill prescription",
            "Adjust medication dosage",
            "E-prescribe to pharmacy"
        ]
    },

    "lab_results": {
        "name": "Lab Results",
        "description": "View or process laboratory test results",
        "regulations": [
            "HIPAA",
            "GDPR"
        ],
        "principles": [
            "Privacy",
            "Access Control",
            "Security",
            "Governance and Accountability"
        ],
        "required_roles": ["admin", "clinician", "doctor", "nurse"],
        "keywords": [
            "lab results",
            "test results",
            "laboratory",
            "blood test",
            "pathology",
            "radiology",
            "diagnostics"
        ],
        "exemplars": [
            "View patient lab results",
            "Review blood test results",
            "Check pathology report",
            "Access radiology findings"
        ]
    },

    "billing": {
        "name": "Billing",
        "description": "Process patient billing and insurance",
        "regulations": [
            "HIPAA",
            "GDPR",
            "PCI_DSS"
        ],
        "principles": [
            "Access Control",
            "Data Minimization",
            "Retention",
            "Security",
            "Privacy"
        ],
        "required_roles": ["admin", "billing_staff"],
        "keywords": [
            "billing",
            "insurance",
            "CPT code",
            "ICD-10",
            "payment",
            "invoice",
            "claim",
            "reimbursement"
        ],
        "exemplars": [
            "Insurance claim submission",
            "ICD-10 and CPT billing",
            "Process payment for medical services",
            "Generate patient invoice"
        ]
    },

    "clinical_decision": {
        "name": "Clinical Decision Support",
        "description": "AI-assisted clinical decision making",
        "regulations": [
            "HIPAA",
            "GDPR",
            "EU_AI_ACT"
        ],
        "principles": [
            "Privacy",
            "Access Control",
            "Explainability",
            "Governance and Accountability",
            "Security",
            "Data Minimization"
        ],
        "required_roles": ["admin", "doctor", "clinician"],
        "keywords": [
            "diagnosis",
            "treatment",
            "medication",
            "drug interaction",
            "dosage",
            "clinical decision",
            "AI recommendation",
            "treatment plan"
        ],
        "exemplars": [
            "Recommend medication dosage",
            "Check drug interactions",
            "Suggest treatment options based on diagnosis",
            "AI-assisted diagnosis recommendation"
        ]
    }
}


# Helper functions
def get_request_type_info(request_type: str):
    """Get detailed information about a request type"""
    return REQUEST_TYPES.get(request_type)


def get_request_type_regulations(request_type: str):
    """Get regulations for a specific request type"""
    info = REQUEST_TYPES.get(request_type, {})
    return info.get("regulations", [])


def get_request_type_principles(request_type: str):
    """Get principles for a specific request type"""
    info = REQUEST_TYPES.get(request_type, {})
    return info.get("principles", [])


def validate_request_type(request_type: str):
    """Check if request type is valid"""
    return request_type in REQUEST_TYPES


def get_required_roles(request_type: str):
    """Get required roles for a request type"""
    info = REQUEST_TYPES.get(request_type, {})
    return info.get("required_roles", [])