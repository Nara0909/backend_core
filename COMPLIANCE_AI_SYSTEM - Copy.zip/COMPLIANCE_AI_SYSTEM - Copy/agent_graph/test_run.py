import os
import sys
from pathlib import Path


# Ensure project root on sys.path when run as a script
def _ensure_project_root():
    p = Path(__file__).resolve().parent
    for _ in range(6):
        if (p / 'policy_generator').exists() or (p / 'requirements.txt').exists():
            root = str(p)
            if root not in sys.path:
                sys.path.insert(0, root)
            return
        p = p.parent


_ensure_project_root()

from agent_graph.graph import build_graph
from policy_generator.policy_graph.policy_engine.enforcement_plan import build_enforcement_plan

app = build_graph()

region = os.environ.get("APPLICATION_REGION") or os.environ.get("APP_REGION")

state = {
    "request_type": "Patient Triage",
    "regulation": "HIPAA",
    "user_role": "patient",
    "input_text": "John Doe, 45, diabetic with chest pain",
    "application_region": region,
    "enforcement_plan": build_enforcement_plan("PatientTriage", application_region=region),
    "masked_input": "",
    "llm_output": "",
    "final_output": "",
    "audit_log": []
}

result = app.invoke(state)
print(result["final_output"])
print(result["audit_log"])
