from typing import TypedDict, List, Dict, Any


class AgentState(TypedDict):
    # -----------------------------
    # Request Context
    # -----------------------------
    request_type: str                 # e.g. "PatientTriage"
    regulations: List[str]            # e.g. ["HIPAA", "GDPR", "CCPA"]
    user_role: str                    # e.g. "clinician", "admin"
    input_text: str                   # raw user / system input

    # -----------------------------
    # Policy & Enforcement
    # -----------------------------
    enforcement_plan: Dict[str, Any]

    # Ordered list of execution steps
    # e.g. ["AccessControlAgent", "PrivacyAgent", "TASK", "OutputGuardAgent", "AuditAgent"]
    execution_queue: List[str]

    # agent_name -> list of policy_rule_ids enforced
    # populated from Policy Knowledge Graph
    policy_trace_map: Dict[str, List[str]]

    # -----------------------------
    # Data Flow
    # -----------------------------
    masked_input: str                 # post-privacy enforcement
    llm_output: str                   # raw model output
    final_output: str                 # post-output-guard output
    pii_detected: List[Dict[str, Any]]  # PII entities detected by privacy agent

    # -----------------------------
    # Audit & Compliance Evidence
    # -----------------------------
    audit_log: List[Dict[str, Any]]
