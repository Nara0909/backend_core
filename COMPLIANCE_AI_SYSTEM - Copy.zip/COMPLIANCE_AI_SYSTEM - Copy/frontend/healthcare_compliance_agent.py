"""
LangGraph-based Healthcare Compliance Orchestration Agent

This module implements the frontend compliance orchestration workflow:
1. Get enforcement plan (which regulations apply)
2. Check access (user can access patient data)
3. Mask PII (anonymize sensitive data)
4. Call LLM (clinical decision with masked data only)
5. Sanitize output (ensure no PII in output)
6. Store audit (full audit trail with regulations)
"""

from langgraph.graph import StateGraph, END
from typing import TypedDict, Literal, Any
from datetime import datetime
import requests
import json
import os
from .backend_client import BackendClient

# Try to import config and OpenAI client
try:
    from config.openai_config import MINI_MODEL, client as openai_client, API_KEY
    HAS_OPENAI_CONFIG = True
except (ImportError, RuntimeError):
    HAS_OPENAI_CONFIG = False
    openai_client = None
    MINI_MODEL = "gpt-3.5-turbo"


class HealthcareComplianceState(TypedDict):
    """State for healthcare compliance workflow"""
    # Input
    user_id: str
    user_role: str
    patient_id: str
    input_text: str
    request_type: str  # "triage", "scheduling", "referral", etc.
    
    # Enforcement plan
    enforcement_plan: dict
    applicable_regulations: list
    
    # Access control
    access_granted: bool
    access_reason: str
    
    # PII handling
    pii_detected: list
    masked_text: str
    
    # LLM processing
    llm_output: str
    
    # Output validation
    sanitized_output: str
    safe_to_store: bool
    pii_in_output: list
    
    # Audit trail
    audit_id: str
    audit_record: dict
    compliance_passed: bool
    violations: list


class HealthcareComplianceAgent:
    """LangGraph-based compliance orchestration agent"""
    
    def __init__(self, backend_url: str = "http://localhost:8000", db_client=None):
        """
        Initialize compliance agent
        
        Args:
            backend_url: URL of FastAPI backend
            db_client: Database client for storing audit logs
        """
        self.backend = BackendClient(backend_url)
        self.db = db_client
        self.graph = self._build_graph()
        
    def _build_graph(self) -> Any:
        """Build LangGraph compliance workflow"""
        
        # Define nodes
        graph = StateGraph(HealthcareComplianceState)
        
        # Add nodes
        graph.add_node("get_enforcement_plan", self._get_enforcement_plan)
        graph.add_node("check_access", self._check_access)
        graph.add_node("mask_pii", self._mask_pii)
        graph.add_node("call_llm", self._call_llm)
        graph.add_node("sanitize_output", self._sanitize_output)
        graph.add_node("store_audit", self._store_audit)
        graph.add_node("compliance_fail", self._compliance_fail)
        
        # Add edges
        graph.add_edge("get_enforcement_plan", "check_access")
        
        # Conditional: check access result
        graph.add_conditional_edges(
            "check_access",
            self._should_proceed_after_access,
            {
                "proceed": "mask_pii",
                "fail": "compliance_fail"
            }
        )
        
        # Conditional: check PII masking
        graph.add_conditional_edges(
            "mask_pii",
            self._should_proceed_after_pii,
            {
                "proceed": "call_llm",
                "fail": "compliance_fail"
            }
        )
        
        graph.add_edge("call_llm", "sanitize_output")
        
        # Conditional: check output safety
        graph.add_conditional_edges(
            "sanitize_output",
            self._should_store_output,
            {
                "store": "store_audit",
                "fail": "compliance_fail"
            }
        )
        
        graph.add_edge("store_audit", END)
        graph.add_edge("compliance_fail", END)
        
        # Set entry point
        graph.set_entry_point("get_enforcement_plan")
        
        return graph.compile()
    
    # ============ NODE IMPLEMENTATIONS ============
    
    def _get_enforcement_plan(self, state: HealthcareComplianceState) -> dict:
        """Get applicable regulations/enforcement plan from backend"""
        print(f"[COMPLIANCE] Getting enforcement plan for {state['request_type']}")
        
        plan = self.backend.get_enforcement_plan(state['request_type'])
        
        return {
            "enforcement_plan": plan,
            "applicable_regulations": plan.get("regulations", [])
        }
    
    def _check_access(self, state: HealthcareComplianceState) -> dict:
        """Check if user has access to patient data"""
        print(f"[COMPLIANCE] Checking access for {state['user_role']} → {state['patient_id']}")
        
        result = self.backend.check_access(
            user_id=state['user_id'],
            user_role=state['user_role'],
            patient_id=state['patient_id'],
            resource_type="patient_data",
            enforcement_plan=state['enforcement_plan']
        )
        
        return {
            "access_granted": result.get("access_granted", False),
            "access_reason": result.get("reason", "Unknown")
        }
    
    def _mask_pii(self, state: HealthcareComplianceState) -> dict:
        """Mask PII from input text"""
        print(f"[COMPLIANCE] Masking PII from input text")
        
        result = self.backend.mask_pii(
            text=state['input_text'],
            enforcement_plan=state['enforcement_plan']
        )
        
        return {
            "pii_detected": result.get("pii_detected", []),
            "masked_text": result.get("masked_text", ""),
        }
    
    def _call_llm(self, state: HealthcareComplianceState) -> dict:
        """Call LLM with MASKED input ONLY"""
        print(f"[COMPLIANCE] Calling LLM with masked input")
        print(f"[SECURITY] Input has {len(state['pii_detected'])} PII elements - all masked")
        
        # This is where healthcare AI logic happens
        # IMPORTANT: Never use state['input_text'], always use state['masked_text']
        
        llm_output = None
        
        # Try OpenAI with configured mini model
        if HAS_OPENAI_CONFIG and openai_client and API_KEY:
            try:
                print(f"[LLM] Using OpenAI mini model: {MINI_MODEL}")
                response = openai_client.chat.completions.create(
                    model=MINI_MODEL,
                    messages=[{
                        "role": "user",
                        "content": f"Clinical triage decision:\n\n{state['masked_text']}"
                    }],
                    temperature=0.7,
                    max_tokens=500
                )
                llm_output = response.choices[0].message.content
                print(f"[LLM] ✅ OpenAI response generated with {MINI_MODEL}")
            except Exception as e:
                print(f"[WARNING] OpenAI call failed with {MINI_MODEL}: {e}")
        else:
            print(f"[LLM] OpenAI config not available, using fallback")
        
        # Fallback to local clinical decision generator
        if not llm_output:
            print("[LLM] Using fallback clinical decision generator")
            llm_output = self._generate_clinical_decision(state['masked_text'], state['request_type'])
        
        return {
            "llm_output": llm_output
        }
    
    def _generate_clinical_decision(self, masked_input: str, request_type: str) -> str:
        """Generate clinical decision using rule-based templates (when LLM unavailable)"""
        
        # Detect clinical indicators from masked input
        has_fever = "fever" in masked_input.lower() or "temperature" in masked_input.lower()
        has_chest_pain = "chest pain" in masked_input.lower() or "chest" in masked_input.lower()
        has_respiratory = "respiratory" in masked_input.lower() or "breath" in masked_input.lower()
        has_infection = "infection" in masked_input.lower() or "viral" in masked_input.lower()
        
        # Generate appropriate clinical response
        decision_parts = []
        
        if request_type == "triage":
            decision_parts.append("CLINICAL TRIAGE ASSESSMENT:")
            decision_parts.append("")
            
            if has_chest_pain:
                decision_parts.append("⚠️ PRIORITY: HIGH - Acute chest pain symptoms detected")
                decision_parts.append("  • Recommend immediate EKG")
                decision_parts.append("  • Consider troponin levels")
                decision_parts.append("  • Vital signs monitoring required")
            elif has_fever:
                decision_parts.append("⚠️ PRIORITY: MEDIUM - Fever symptoms detected")
                decision_parts.append("  • Recommend full blood work")
                decision_parts.append("  • Culture and sensitivity testing")
                decision_parts.append("  • Consider isolation precautions")
            else:
                decision_parts.append("✓ PRIORITY: LOW - Stable presentation")
                decision_parts.append("  • Continue monitoring")
                decision_parts.append("  • Standard diagnostic workup")
            
            if has_respiratory:
                decision_parts.append("  • Respiratory assessment and imaging recommended")
            
            if has_infection:
                decision_parts.append("  • Infectious disease consult may be warranted")
            
            decision_parts.append("")
            decision_parts.append("RECOMMENDATION: Escalate to appropriate specialist based on findings")
            
        else:
            decision_parts.append(f"Clinical decision for {request_type}:")
            decision_parts.append("Assessment: Patient evaluation completed")
            decision_parts.append("Status: Awaiting diagnostic confirmation")
            decision_parts.append("Action: Proceed with standard clinical protocol")
        
        return "\n".join(decision_parts)
    
    def _sanitize_output(self, state: HealthcareComplianceState) -> dict:
        """Sanitize LLM output - ensure no PII leakage"""
        print(f"[COMPLIANCE] Sanitizing output")
        
        result = self.backend.sanitize_output(
            text=state['llm_output'],
            enforcement_plan=state['enforcement_plan']
        )
        
        return {
            "sanitized_output": result.get("sanitized_text", ""),
            "safe_to_store": result.get("safe_to_store", False),
            "pii_in_output": result.get("pii_detected", [])
        }
    
    def _store_audit(self, state: HealthcareComplianceState) -> dict:
        """Store complete audit trail in frontend database"""
        print(f"[AUDIT] Storing compliance audit trail")
        
        audit_record = {
            "timestamp": datetime.utcnow(),
            "user_id": state['user_id'],
            "user_role": state['user_role'],
            "patient_id": state['patient_id'],
            "request_type": state['request_type'],
            
            # Input handling
            "input_text": state['input_text'],
            "pii_detected": state['pii_detected'],
            "masked_text": state['masked_text'],
            
            # Access control
            "access_granted": state['access_granted'],
            "access_reason": state['access_reason'],
            
            # Processing
            "llm_output": state['llm_output'],
            "sanitized_output": state['sanitized_output'],
            "safe_to_store": state['safe_to_store'],
            "pii_in_output": state['pii_in_output'],
            
            # Compliance
            "enforcement_plan": state['enforcement_plan'],
            "applicable_regulations": state['applicable_regulations'],
            "compliance_passed": True,
            "violations": []
        }
        
        # Store in database if available
        if self.db:
            audit_id = self.db.store_audit_log(audit_record)
        else:
            audit_id = str(datetime.utcnow().timestamp())
        
        # Log to backend for secondary audit trail
        self.backend.log_compliance_action(
            user_id=state['user_id'],
            action="triage_decision",
            resource="patient",
            outcome="success",
            audit_id=audit_id,
            enforcement_plan=state['enforcement_plan']
        )
        
        print(f"[AUDIT] ✅ Stored audit record with ID: {audit_id}")
        print(f"[AUDIT] Sanitized output length: {len(state.get('sanitized_output', ''))}")
        
        return {
            "audit_id": audit_id,
            "audit_record": audit_record,
            "compliance_passed": True,
            "violations": [],
            "sanitized_output": state['sanitized_output']  # Ensure it flows through
        }
    
    def _compliance_fail(self, state: HealthcareComplianceState) -> dict:
        """Handle compliance failure"""
        violations = []
        
        if not state.get('access_granted'):
            violations.append({
                "type": "ACCESS_DENIED",
                "reason": state.get('access_reason', 'Unauthorized access'),
                "user_role": state['user_role']
            })
        
        if state.get('pii_detected') and not state.get('masked_text'):
            violations.append({
                "type": "PII_MASKING_FAILED",
                "pii_elements": state.get('pii_detected', [])
            })
        
        if not state.get('safe_to_store') and state.get('pii_in_output'):
            violations.append({
                "type": "OUTPUT_CONTAINS_PII",
                "pii_elements": state.get('pii_in_output', [])
            })
        
        print(f"[ALERT] Compliance failure: {len(violations)} violations")
        for v in violations:
            print(f"  - {v['type']}: {v.get('reason', '')}")
        
        # Log violation to backend
        self.backend.log_compliance_action(
            user_id=state['user_id'],
            action="compliance_violation",
            resource="patient",
            outcome="denied",
            audit_id=None,
            enforcement_plan=state.get('enforcement_plan', {})
        )
        
        # Create audit record even for failures
        audit_record = {
            "timestamp": datetime.utcnow(),
            "user_id": state['user_id'],
            "user_role": state['user_role'],
            "patient_id": state['patient_id'],
            "request_type": state['request_type'],
            "input_text": state['input_text'],
            "pii_detected": state['pii_detected'],
            "masked_text": state['masked_text'],
            "access_granted": state['access_granted'],
            "access_reason": state['access_reason'],
            "llm_output": state.get('llm_output', ''),
            "sanitized_output": state.get('sanitized_output', ''),
            "safe_to_store": state['safe_to_store'],
            "pii_in_output": state['pii_in_output'],
            "enforcement_plan": state['enforcement_plan'],
            "applicable_regulations": state['applicable_regulations'],
            "compliance_passed": False,
            "violations": violations
        }
        
        return {
            "compliance_passed": False,
            "violations": violations,
            "audit_record": audit_record,
            "audit_id": None,
            "sanitized_output": state.get('sanitized_output', 'Compliance check failed')
        }
    
    # ============ CONDITIONAL EDGES ============
    
    def _should_proceed_after_access(self, state: HealthcareComplianceState) -> Literal["proceed", "fail"]:
        """Decide if we should proceed after access check"""
        if state.get('access_granted'):
            return "proceed"
        return "fail"
    
    def _should_proceed_after_pii(self, state: HealthcareComplianceState) -> Literal["proceed", "fail"]:
        """Decide if we should proceed after PII masking"""
        # If PII was detected but masked successfully, proceed
        if state.get('masked_text'):
            return "proceed"
        # If no PII was detected, also proceed
        if not state.get('pii_detected'):
            return "proceed"
        return "fail"
    
    def _should_store_output(self, state: HealthcareComplianceState) -> Literal["store", "fail"]:
        """Decide if output is safe to store"""
        if state.get('safe_to_store'):
            return "store"
        return "fail"
    
    # ============ PUBLIC INTERFACE ============
    
    def process_clinical_request(
        self,
        user_id: str,
        user_role: str,
        patient_id: str,
        input_text: str,
        request_type: str = "triage"
    ) -> dict:
        """
        Process clinical request through compliance workflow
        
        Args:
            user_id: ID of user making request
            user_role: Role of user (clinician, admin, etc.)
            patient_id: ID of patient
            input_text: Clinical input text
            request_type: Type of request (triage, scheduling, referral)
        
        Returns:
            Compliance result with sanitized output and audit trail
        """
        print(f"\n{'='*60}")
        print(f"[START] Processing clinical request: {request_type}")
        print(f"  User: {user_id} ({user_role})")
        print(f"  Patient: {patient_id}")
        print(f"{'='*60}\n")
        
        initial_state = {
            "user_id": user_id,
            "user_role": user_role,
            "patient_id": patient_id,
            "input_text": input_text,
            "request_type": request_type,
            
            # These will be filled by nodes
            "enforcement_plan": {},
            "applicable_regulations": [],
            "access_granted": False,
            "access_reason": "",
            "pii_detected": [],
            "masked_text": "",
            "llm_output": "",
            "sanitized_output": "",
            "safe_to_store": False,
            "pii_in_output": [],
            "audit_id": "",
            "audit_record": {},
            "compliance_passed": False,
            "violations": []
        }
        
        try:
            result = self.graph.invoke(initial_state)
            
            print(f"\n{'='*60}")
            print(f"[RESULT] Compliance workflow completed")
            print(f"  Status: {'✅ PASSED' if result['compliance_passed'] else '❌ FAILED'}")
            print(f"  Output: {result['sanitized_output'][:100]}...")
            print(f"  Audit ID: {result['audit_id']}")
            print(f"{'='*60}\n")
            
            return result
            
        except Exception as e:
            print(f"\n[ERROR] Workflow execution failed: {e}\n")
            return {
                "compliance_passed": False,
                "violations": [{"type": "WORKFLOW_ERROR", "reason": str(e)}],
                "sanitized_output": "",
                "audit_id": None
            }


# Convenience function
def create_compliance_agent(backend_url: str = "http://localhost:8000", db_client=None):
    """Create and return a compliance agent"""
    return HealthcareComplianceAgent(backend_url, db_client)
